<?php

function articles_categories($block_name, $top_id, $top_name, $block_prefix="a_cats", $category_id = 0)
{
	global $t, $db, $table_prefix, $restrict_categories_images;
	global $page_settings, $restrict_categories_images;
	global $categories, $category_number, $settings, $list_url, $list_page;
	global $site_id, $db_type;
	
	$user_id = get_session("session_user_id");		
	$user_info = get_session("session_user_info");
	$user_type_id = get_setting_value($user_info, "user_type_id", "");

	if(get_setting_value($page_settings, $block_name . "_column_hide", 0)) {
		return;
	}

	$friendly_urls = get_setting_value($settings, "friendly_urls", 0);
	$friendly_extension = get_setting_value($settings, "friendly_extension", "");
	$columns = get_setting_value($page_settings, $block_prefix."_cols_" . $top_id, 1);
	$categories_type = get_setting_value($page_settings, $block_prefix."_type_" . $top_id);

	if (!strlen($top_name)) {
		$sql  = " SELECT ac.category_name ";
		$sql .= " FROM ";
		
		$sql_join  = $table_prefix . "articles_categories ac ";
		$sql_where = " WHERE ac.category_id=" . $db->tosql($top_id, INTEGER);				
		
		if (isset($site_id))  {
			$sql_join   = "(" . $sql_join . " LEFT JOIN " . $table_prefix . "articles_categories_sites acs ON acs.category_id=ac.category_id)";
			$sql_where .= " AND (ac.sites_all=1 OR acs.site_id=". $db->tosql($site_id, INTEGER, true, false) . ") ";
		} else {
			$sql_where .= " AND ac.sites_all=1 ";					
		}
		
		if (strlen($user_id)) {
			$sql_join   = "(" . $sql_join . " LEFT JOIN " . $table_prefix . "articles_categories_types ut ON ut.category_id=ac.category_id)";
			$sql_where .= " AND ( ac.user_types_all=1 OR ut.user_type_id=". $db->tosql($user_type_id , INTEGER) . " )";
		} else {
			$sql_where .= " AND ac.user_types_all=1 ";
		}
		
		$sql .= $sql_join . $sql_where;
		
		$db->query($sql);
		if ($db->next_record()) {
			$top_name = get_translation($db->f("category_name"));
		} else {
			return false;
		}
	}

	$t->set_var("articles_href",    "articles.php");
	$t->set_var("list_href",        "articles.php");
	$t->set_var("details_href",     "article.php");
	$t->set_var("rss_href",     "articles_rss.php");
	$t->set_var("top_category_name",$top_name);

	$list_page = "articles.php";
	$list_url = new VA_URL("articles.php");

	if (($categories_type == 2)||($categories_type == 1)) 
	{
    $t->set_file("block_body", "block_categories_catalog.html");
		$t->set_var("catalog_sub",      "");
		$t->set_var("catalog_sub_more", "");
		$t->set_var("catalog_rows",     "");
		$t->set_var("catalog_top",      "");
		$t->set_var("catalog_description", "");
		if ($categories_type == 1) {
			$sql  = $table_prefix . "articles_categories ac ";
			if (isset($site_id))  {
				$sql   = " (" . $sql . " LEFT JOIN " . $table_prefix . "articles_categories_sites acs ON acs.category_id=ac.category_id)";				
			}			
			if (strlen($user_id)) {
				$sql   = " (" . $sql . " LEFT JOIN " . $table_prefix . "articles_categories_types ut ON ut.category_id=ac.category_id)";
			}
			$sql  = " SELECT ac.category_id AS top_category_id, ac.category_name AS top_category_name, ac.friendly_url AS top_friendly_url, "
			      . " ac.short_description, ac.image_small, ac.image_small_alt, ac.is_rss, ac.rss_on_list "
			      . " FROM " .$sql;			
			$sql .= " WHERE ac.allowed_view=1 ";								
			if (isset($site_id))  {
				$sql .= " AND (ac.sites_all=1 OR acs.site_id=". $db->tosql($site_id, INTEGER, true, false) . ") ";
			} else {
				$sql .= " AND ac.sites_all=1 ";					
			}			
			if (strlen($user_id)) {
				$sql .= " AND ( ac.user_types_all=1 OR ut.user_type_id=". $db->tosql($user_type_id , INTEGER) . " )";
			} else {
				$sql .= " AND ac.user_types_all=1 ";
			}		
			if ($category_id > 0) {
				$sql .= " AND ac.parent_category_id = " . $db->tosql($category_id, INTEGER);
			} else {
				$sql .= " AND ac.parent_category_id = " . $db->tosql($top_id, INTEGER);
			}
			if ($db_type == "access" || $db_type == "db2"  || $db_type == "postgre") {
				$sql .= " GROUP BY ac.category_id, ac.category_name, ac.friendly_url, ";
				$sql .= " ac.short_description, ac.image_small, ac.image_small_alt, ac.is_rss, ac.rss_on_list, ac.category_order ";
			} else {
				$sql .= " GROUP BY ac.category_id ";
			}			
			$sql .= " ORDER BY ac.category_order, ac.category_name ";
		} else { 
			// show categories as catalog
			$sql = $table_prefix . "articles_categories ac ";
			$sql = " (" . $sql . " LEFT JOIN " . $table_prefix . "articles_categories sc ON ac.category_id=sc.parent_category_id) ";
			if (isset($site_id)) {
				$sql = " (" . $sql . " LEFT JOIN " . $table_prefix . "articles_categories_sites acs ON acs.category_id=ac.category_id)";		
			}	
			if (strlen($user_id)) {
				$sql = " (" . $sql . " LEFT JOIN " . $table_prefix . "articles_categories_types ut ON ut.category_id=ac.category_id)";
			}
			$sql  = " SELECT ac.category_id AS top_category_id, ac.category_name AS top_category_name, ac.friendly_url AS top_friendly_url,"
			      . " ac.image_small, ac.image_small_alt,"
			      . " sc.category_id AS sub_category_id,sc.category_name AS sub_category_name, "
			      . " sc.friendly_url AS sub_friendly_url, ac.is_rss, ac.rss_on_list "
			      . " FROM " . $sql;			
			$sql .= " WHERE ac.allowed_view=1 ";	
			$sql .= " AND (sc.allowed_view=1 OR sc.allowed_view IS NULL) ";	
			if (isset($site_id)) {
				$sql .= " AND (ac.sites_all=1 OR acs.site_id=". $db->tosql($site_id, INTEGER, true, false) . ") ";
			} else {
				$sql .= " AND ac.sites_all=1 ";		
			}			
			if (strlen($user_id)) {
				$sql .= " AND ( ac.user_types_all=1 OR ut.user_type_id=". $db->tosql($user_type_id , INTEGER) . " )";
			} else {
				$sql .= " AND ac.user_types_all=1 ";
			}				
			if ($category_id > 0) {
				$sql .= " AND ac.parent_category_id = " . $db->tosql($category_id, INTEGER);
			} else {
				$sql .= " AND ac.parent_category_id = " . $db->tosql($top_id, INTEGER);
			}			
			if ($db_type == "access" || $db_type == "db2"  || $db_type == "postgre") {
				$sql .= " GROUP BY ac.category_id, ac.category_name, ac.friendly_url, ";
				$sql .= " ac.image_small, ac.image_small_alt,";
				$sql .= " sc.category_id,sc.category_name, ";
				$sql .= " sc.friendly_url, ac.is_rss, ac.rss_on_list, ac.category_order, sc.category_order ";
			} else {
				$sql .= " GROUP BY ac.category_id, sc.category_id ";
			}			
			$sql .= " ORDER BY ac.category_order, ac.category_name, ac.category_id, sc.category_order, sc.category_name ";
		}
		$db->query($sql);
		if($db->next_record())
		{
			$category_number = 0;
			$is_subcategories = true;
			$shown_sub_categories = get_setting_value($page_settings, $block_prefix."_subs_" . $top_id); 
			$catalog_top_number = 0;
			$catalog_sub_number = 0;
			$column_width = intval(90 / $columns);
			$t->set_var("column_width", $column_width . "%");
			do
			{
				$category_number++;
				$catalog_sub_number++;
				$top_category_id = $db->f("top_category_id");
				$top_category_name = get_translation($db->f("top_category_name"));
				$top_friendly_url = $db->f("top_friendly_url");
				$sub_category_id = $db->f("sub_category_id");
				$sub_category_name = get_translation($db->f("sub_category_name"));
				$sub_friendly_url = $db->f("sub_friendly_url");

				$t->set_var("catalog_top_id", $top_category_id);
				if ($db->f("is_rss") && $db->f("rss_on_list")){
					$t->parse("category_rss", false);
				} else {
					$t->set_var("category_rss", "");
				}
				$t->set_var("catalog_top_name", $top_category_name);
				if ($categories_type == 2) {
					$t->set_var("catalog_sub_id",   $sub_category_id);
					$t->set_var("catalog_sub_name", $sub_category_name);
				} else {
					if (strlen($db->f("short_description"))) {
						$t->set_var("short_description", get_translation($db->f("short_description")));
						$t->parse("catalog_description", false);
					} else {
						$t->set_var("catalog_description", "");
					}
				}
  
				$category_image = $db->f("image_small");
				$image_alt      = $db->f("image_small_alt");
				$category_name  = $db->f("top_category_name");
				$is_next_record = $db->next_record();

				$is_new_top = ($top_category_id != $db->f("top_category_id"));
  
				if ($categories_type == 2) {
					if($shown_sub_categories >= $catalog_sub_number || !$shown_sub_categories)
					{
						if ($friendly_urls && $sub_friendly_url) {
							$list_url->remove_parameter("category_id");
							$t->set_var("list_url", $list_url->get_url($sub_friendly_url. $friendly_extension));
						} else {
							$list_url->add_parameter("category_id", CONSTANT, $sub_category_id);
							$t->set_var("list_url", $list_url->get_url($list_page));
						}
						if($is_next_record && !$is_new_top){
							$t->parse("catalog_sub_separator", false);
						} else {
							$t->set_var("catalog_sub_separator", "");
						}
						$t->parse("catalog_sub", true);
					} else if(($shown_sub_categories + 1) == $catalog_sub_number) {
						if ($friendly_urls && $top_friendly_url) {
							$list_url->remove_parameter("category_id");
							$t->set_var("list_url", $list_url->get_url($top_friendly_url . $friendly_extension));
						} else {
							$list_url->add_parameter("category_id", CONSTANT, $top_category_id);
							$t->set_var("list_url", $list_url->get_url($list_page));
						}

						$t->parse("catalog_sub_more", false);
					}
				}
  
				if($is_new_top)
				{
					$catalog_top_number++;

					if ($friendly_urls && $top_friendly_url) {
						$list_url->remove_parameter("category_id");
						$t->set_var("list_url", $list_url->get_url($top_friendly_url . $friendly_extension));
					} else {
						$list_url->add_parameter("category_id", CONSTANT, $top_category_id);
						$t->set_var("list_url", $list_url->get_url($list_page));
					}

					if ($category_image)
					{
						if (preg_match("/^http\:\/\//", $category_image)) {
							$image_size = "";
						} else {
							$image_size = @GetImageSize($category_image);
							if (isset($restrict_categories_images) && $restrict_categories_images) { $category_image = "image_show.php?art_cat_id=".$top_category_id."&type=small"; }
						}
            //$image_size = @GetImageSize($category_image);
						if (!strlen($image_alt)) { $image_alt = $category_name; }
							$t->set_var("alt", htmlspecialchars($image_alt));
							$t->set_var("src", htmlspecialchars($category_image));
						if(is_array($image_size)) {
							$t->set_var("width", "width=\"" . $image_size[0] . "\"");
							$t->set_var("height", "height=\"" . $image_size[1] . "\"");
						} else {
							$t->set_var("width", "");
							$t->set_var("height", "");
						}
						$t->parse("catalog_image", false);
					} else {
						$t->set_var("catalog_image", "");
					}

					$t->parse("catalog_top");
					$t->set_var("catalog_sub", "");
					$t->set_var("catalog_sub_more", "");
					if($catalog_top_number % $columns == 0)
					{
						$t->parse("catalog_rows");
						$t->set_var("catalog_top", "");
					}
					$catalog_sub_number = 0;
				}

			} while ($is_next_record);

			if($catalog_top_number % $columns != 0) {
				$t->parse("catalog_rows");
			}
  
			$t->parse("block_body", false);
			$t->parse($block_name, true);
		}

	} else { // list type 

		$t->set_file("block_body", "block_categories_list.html");
		$t->set_var("categories_rows", "");
		$t->set_var("categories",      "");

		$categories_image = get_setting_value($page_settings, $block_prefix."_image_".$top_id);
		if (!$category_id) { $category_id = $top_id; }
		$category_path = "0," . $category_id;
		if ($categories_type == 4) { // Tree-type structure
			$sql  = " SELECT ac.category_path ";
			$sql .= " FROM ((" . $table_prefix . "articles_categories ac ";
			if (isset($site_id)) {
				$sql .= " LEFT JOIN " . $table_prefix . "articles_categories_sites acs ON acs.category_id=ac.category_id) ";
			} else {
				$sql .= " ) ";
			}
			if (strlen($user_id)) {
				$sql .= " LEFT JOIN " . $table_prefix . "articles_categories_types ut ON ut.category_id=ac.category_id) ";
			} else {
				$sql .= " ) ";
			}		
			$sql .= " WHERE ac.category_id=" . $db->tosql($category_id, INTEGER);
			$sql .= " AND ac.allowed_view=1 ";
			if (isset($site_id)) {
				$sql .= " AND (ac.sites_all=1 OR acs.site_id=". $db->tosql($site_id, INTEGER, true, false) . ") ";
			} else {
				$sql .= " AND ac.sites_all=1 ";					
			}			
			if (strlen($user_id)) {
				$sql .= " AND ( ac.user_types_all=1 OR ut.user_type_id=". $db->tosql($user_type_id , INTEGER) . " )";
			} else {
				$sql .= " AND ac.user_types_all=1 ";
			}		
			$db->query($sql);
			if ($db->next_record()) {
				$category_path  = $db->f("category_path");
				$category_path .= $category_id;
			} 
		}

		$categories = array();
		$sql  = " SELECT ac.category_id, ac.category_name, ac.friendly_url, ac.short_description, ac.parent_category_id, ";
		$sql .= " ac.image_small, ac.image_small_alt, ac.is_rss, ac.rss_on_list ";
		$sql .= " FROM ((" . $table_prefix . "articles_categories ac ";
		if (isset($site_id)) {
			$sql .= " LEFT JOIN " . $table_prefix . "articles_categories_sites acs ON acs.category_id=ac.category_id) ";
		} else {
			$sql .= " ) ";
		}
		if (strlen($user_id)) {
			$sql .= " LEFT JOIN " . $table_prefix . "articles_categories_types ut ON ut.category_id=ac.category_id) ";
		} else {
			$sql .= " ) ";
		}		
		$sql .= " WHERE ac.allowed_view=1";
		if ($categories_type == 4) {
			$category_path = preg_replace("/^0,/", "", $category_path);
			$sql .= " AND ac.parent_category_id IN (" . $db->tosql($category_path, TEXT, false) . ") ";
		} else {
			$sql .= " AND ac.category_path LIKE '0," . $top_id . ",%' ";
		}
		if (isset($site_id)) {
			$sql .= " AND (ac.sites_all=1 OR acs.site_id=". $db->tosql($site_id, INTEGER, true, false) . ") ";
		} else {
			$sql .= " AND ac.sites_all=1 ";					
		}
		if (strlen($user_id)) {
			$sql .= " AND (ac.user_types_all=1 OR ut.user_type_id=". $db->tosql($user_type_id , INTEGER) . " )";
		} else {
			$sql .= " AND ac.user_types_all=1 ";
		}		
		$sql .= " GROUP BY ac.category_id, ac.category_name, ac.friendly_url, ac.short_description, ac.parent_category_id, ";
		$sql .= " ac.image_small, ac.image_small_alt, ac.is_rss, ac.rss_on_list, ac.category_order  ";
		$sql .= " ORDER BY ac.category_order, ac.category_name ";
		$db->query($sql);
		while ($db->next_record()) {
			$cur_category_id = $db->f("category_id");
			$category_name = get_translation($db->f("category_name"));
			$friendly_url = $db->f("friendly_url");
			$short_description = get_translation($db->f("short_description"));
			$image_small = $db->f("image_small");
			$image_small_alt = $db->f("image_small_alt");
			$is_rss = ($db->f("is_rss") && $db->f("rss_on_list"));

			$parent_category_id = $db->f("parent_category_id");
			$categories[$cur_category_id]["parent_id"] = $parent_category_id;
			$categories[$cur_category_id]["category_name"] = $category_name;
			$categories[$cur_category_id]["friendly_url"] = $friendly_url;
			$categories[$cur_category_id]["short_description"] = $short_description;
			$categories[$cur_category_id]["image"] = $image_small;
			$categories[$cur_category_id]["image_alt"] = $image_small_alt;
			$categories[$cur_category_id]["is_rss"] = $is_rss;
			$categories[$parent_category_id]["subs"][] = $cur_category_id;
		}
  
		if (sizeof($categories) > 0 && isset($categories[$top_id]))
		{
			$category_number = 0;
			$column_width = intval(100 / $columns);
			$t->set_var("column_width", $column_width . "%");

			set_categories($top_id, 0, $columns, $top_id, $categories_image);

			if ($category_number % $columns != 0) {
				$t->parse("categories_rows");
			}
  
			$t->parse("block_body", false);
			$t->parse($block_name, true);
		}
	}

}

?>