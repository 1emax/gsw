<?php

function top_products($block_name)
{
	global $t, $db, $site_id, $db_type, $table_prefix;
	global $settings, $page_settings;
	global $category_id, $language_code;

	if (get_setting_value($page_settings, $block_name . "_column_hide", 0)) {
		return;
	}

	$user_id = get_session("session_user_id");
	$user_type_id = get_session("session_user_type_id");
	
	$friendly_urls = get_setting_value($settings, "friendly_urls", 0);
	$friendly_extension = get_setting_value($settings, "friendly_extension", "");
	$product_no_image = get_setting_value($settings, "product_no_image", "");
	$top_rated_image = get_setting_value($page_settings, "top_rated_image",  0);
	$top_rated_desc = get_setting_value($page_settings, "top_rated_desc", 0);
	$restrict_products_images = get_setting_value($settings, "restrict_products_images", "");
	product_image_fields($top_rated_image, $image_type_name, $image_field, $image_alt_field, $watermark, $product_no_image);

	$php_in_desc = 0; $desc_field = "";
	if ($top_rated_desc == 1) {
		$desc_field = "short_description";
		$php_in_desc = get_setting_value($settings, "php_in_products_short_desc", 0);
	} elseif ($top_rated_desc == 2) {
		$desc_field = "full_description";
		$php_in_desc = get_setting_value($settings, "php_in_products_full_desc", 0);
	} elseif ($top_rated_desc == 3) {
		$desc_field = "features";
		$php_in_desc = get_setting_value($settings, "php_in_products_features", 0);
	} elseif ($top_rated_desc == 4) {
		$desc_field = "special_offer";
		$php_in_desc = get_setting_value($settings, "php_in_products_hot_desc", 0);
	}

	// new product settings	
	$new_product_enable = get_setting_value($settings, "new_product_enable", 0);
	$new_product_order  = get_setting_value($settings, "new_product_order", 0);
	
	$t->set_file("block_body", "block_top_rated.html");
	$t->set_var("top_category_name",PRODUCTS_TITLE);
	$t->set_var("top_rated_items",  "");

	$sql  = " SELECT i.item_id, i.item_name, i.friendly_url, i.rating ";
	// new product db
	if ($new_product_enable) {
		switch ($new_product_order) {
			case 0:
				$sql .= ", i.issue_date AS new_product_date ";
			break;
			case 1:
				$sql .= ", i.date_added AS new_product_date ";
			break;
			case 2:
				$sql .= ", i.date_modified AS new_product_date ";
			break;
		}		
	}
	if ($image_field) { $sql .= " , i." . $image_field; }
	if ($image_alt_field) { $sql .= " , i." . $image_alt_field; }
	if ($desc_field) { $sql .= " , i." . $desc_field; }
	$sql .= " FROM (";
	if (isset($site_id)) {
		$sql .= "(";
	}
	if (strlen($user_id)) {
		$sql .= "(";
	}
	$sql .= $table_prefix . "items i ";
	if (isset($site_id)) {
		$sql .= " LEFT JOIN " . $table_prefix . "items_sites s ON s.item_id=i.item_id)";
	}
	if (strlen($user_id)) {
		$sql .= " LEFT JOIN " . $table_prefix . "items_user_types ut ON ut.item_id=i.item_id)";
	}
	$sql .= " LEFT JOIN " . $table_prefix . "items_categories ic ON ic.item_id=i.item_id)";
	$sql .= " WHERE i.is_showing=1 AND i.is_approved=1 AND ((i.hide_out_of_stock=1 AND i.stock_level > 0) OR i.hide_out_of_stock=0 OR i.hide_out_of_stock IS NULL)";
	$sql .= " AND (i.language_code IS NULL OR i.language_code='' OR i.language_code=" . $db->tosql($language_code, TEXT) . ")";
	$sql .= " AND i.votes>=" . $db->tosql(get_setting_value($settings, "min_votes", 10), INTEGER);
	$sql .= " AND i.rating>=" . $db->tosql(get_setting_value($settings, "min_rating", 1), FLOAT);
	if (isset($site_id)) {
		$sql .= " AND (i.sites_all=1 OR s.site_id=". $db->tosql($site_id, INTEGER, true, false) . ") ";
	} else {
		$sql .= " AND i.sites_all=1 ";			
	}
	if (strlen($user_id)) {
		$sql .= " AND (i.user_types_all=1 OR ut.user_type_id=". $db->tosql($user_type_id , INTEGER) . " )";
	} else {
		$sql .= " AND i.user_types_all=1 ";
	}
	if ($db_type == "access" || $db_type == "db2" || $db_type == "postgre") {
		$sql .= " GROUP BY i.item_id, i.item_name, i.friendly_url, i.rating, i.item_order, i.votes ";
		if ($image_field) { $sql .= " , " . $image_field; }
		if ($image_alt_field) { $sql .= " , " . $image_alt_field; }
		if ($desc_field) { $sql .= " , " . $desc_field; }
	} else {
		$sql .= " GROUP BY i.item_id ";
	}
	$sql .= " ORDER BY i.rating DESC, i.votes DESC ";

	$db->RecordsPerPage = 10;
	$db->PageNumber = 1;
	$db->query($sql);
	if($db->next_record())
	{
		$item_number = 0;
		do
		{
			$item_number++;
			$item_id = $db->f("item_id");
			$item_name = get_translation($db->f("item_name"));
			$friendly_url = $db->f("friendly_url");
			$item_image = ""; $item_image_alt = ""; $item_desc = "";
			$image_exists = false;
			if ($image_field) {
				$item_image = $db->f($image_field);
				$item_image_alt = get_translation($db->f($image_alt_field));
				if (!strlen($item_image)) {
					$item_image = $product_no_image;
				} elseif (!image_exists($item_image)) {
					$item_image = $product_no_image;
				} else {
					$image_exists = true;
				}
			}
			if ($desc_field) {
				$item_desc = get_translation($db->f($desc_field));
			}

			if ($friendly_urls && $friendly_url) {
				$details_href = $friendly_url . $friendly_extension;
			} else {
				$details_href = "product_details.php?item_id=".urlencode($item_id);
			}

			if ($new_product_enable) {
				$new_product_date = $db->f("new_product_date");
				$is_new_product   = is_new_product($new_product_date);
			} else {
				$is_new_product = false;
			}
			if ($is_new_product) {
				$t->set_var("product_new_class", " newProduct");
				$t->sparse("product_new_image", false);
			} else {
				$t->set_var("product_new_class", "");
				$t->set_var("product_new_image", "");
			}
		
			$t->set_var("top_position", $item_number);
			$t->set_var("top_name", $item_name);
			$t->set_var("top_rating", number_format($db->f("rating"), 2));
			$t->set_var("details_href", $details_href);

			if ($item_image)
			{
				if (preg_match("/^http\:\/\//", $item_image)) {
					$image_size = "";
				} else {
					$image_size = @GetImageSize($item_image);
					if ($image_exists && ($watermark || $restrict_products_images)) {
						$item_image = "image_show.php?item_id=".$item_id."&type=".$image_type_name."&vc=".md5($item_image);
					}
				}
				if (!strlen($item_image_alt)) { $item_image_alt = $item_name; }
				$t->set_var("alt", htmlspecialchars($item_image_alt));
				$t->set_var("src", htmlspecialchars($item_image));
				if (is_array($image_size)) {
					$t->set_var("width", "width=\"" . $image_size[0] . "\"");
					$t->set_var("height", "height=\"" . $image_size[1] . "\"");
				} else {
					$t->set_var("width", "");
					$t->set_var("height", "");
				}
				$t->sparse("top_image", false);
			} else {
				$t->set_var("top_image", "");
			}
			if ($item_desc) {
				if ($php_in_desc) {
					eval_php_code($item_desc);
				}
				$t->set_var("desc_text", $item_desc);
				$t->sparse("top_desc", false);
			} else {
				$t->set_var("top_desc", "");
			}

			$t->parse("top_rated_items", true);
		} while ($db->next_record());
		$t->parse("block_body", false);
		$t->parse($block_name, true);
	}
}

?>