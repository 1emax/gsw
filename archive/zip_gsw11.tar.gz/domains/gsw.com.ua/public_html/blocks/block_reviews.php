<?php                           

function reviews($block_name, $review_type = 1)
{
	global $t;
	global $db, $site_id, $table_prefix;
	global $settings;
	global $page_settings;
	global $category_id;
	global $datetime_show_format, $meta_description;

	if(get_setting_value($page_settings, $block_name . "_column_hide", 0)) {
		return;
	}

	$user_id = get_session("session_user_id");		
	$user_type_id = get_session("session_user_type_id");
	
	$t->set_file("block_body", "block_reviews.html");
	$t->set_var("AVERAGE_RATING_MSG", AVERAGE_RATING_MSG);
	$t->set_var("ALL_REVIEWS_MSG", ALL_REVIEWS_MSG);
	$t->set_var("ONLY_POSITIVE_MSG", ONLY_POSITIVE_MSG);
	$t->set_var("ONLY_NEGATIVE_MSG", ONLY_NEGATIVE_MSG);
	$t->set_var("POSITIVE_REVIEWS_MSG", POSITIVE_REVIEWS_MSG);
	$t->set_var("NEGATIVE_REVIEWS_MSG", NEGATIVE_REVIEWS_MSG);

	$t->set_var("REVIEWS_MSG", REVIEWS_MSG);
	$t->set_var("NO_REVIEWS_MSG", NO_REVIEWS_MSG);
	$t->set_var("RECOMMEND_PRODUCT_MSG", RECOMMEND_PRODUCT_MSG);
	$t->set_var("RATE_IT_MSG", RATE_IT_MSG);
	$t->set_var("ONE_LINE_SUMMARY_MSG", ONE_LINE_SUMMARY_MSG);
	$t->set_var("DETAILED_COMMENT_MSG", DETAILED_COMMENT_MSG);
	$t->set_var("NAME_ALIAS_MSG", NAME_ALIAS_MSG);
	$t->set_var("SHOW_MSG", SHOW_MSG);
	$t->set_var("VOTES_MSG", VOTES_MSG);
	$t->set_var("FOUND_MSG", FOUND_MSG);
	$t->set_var("SUBMIT_REVIEW_MSG", SUBMIT_REVIEW_MSG);
	$t->set_var("RATE_IT_BUTTON", RATE_IT_BUTTON);
	$t->set_var("VALIDATION_CODE_FIELD",   VALIDATION_CODE_FIELD);

	$errors = "";
	$is_item = true;

	$approve_review   = $settings["approve_review"];
	$reviews_per_page = $settings["reviews_per_page"];

	$category_id = get_param("category_id");

	$use_random_image = get_setting_value($settings, "review_random_image", 0); 
	if (($use_random_image == 2) || ($use_random_image == 1 && !strlen(get_session("session_user_id")))) { 
		$use_validation = true;
	} else {
		$use_validation = false;
	}

	if ($review_type == 1) {
		$column_id = get_param("item_id");
		$reviews_href = "reviews.php";
		$reviews_table = $table_prefix . "reviews ";
		$column_name = "item_id";
		$recommend_msg = RECOMMEND_PRODUCT_MSG;

		$sql  = " SELECT i.item_name FROM ";
		if (isset($site_id)) {
			$sql .= "(";
		}
		if (strlen($user_id)) {
			$sql .= "(";
		}
		$sql .= $table_prefix . "items i ";
		if (isset($site_id)) {
			$sql .= " LEFT JOIN " . $table_prefix . "items_sites s ON s.item_id = i.item_id) ";	
		}
		if (strlen($user_id)) {
			$sql .= " LEFT JOIN " . $table_prefix . "items_user_types ut ON ut.item_id = i.item_id) ";	
		}
		$sql .= " WHERE i.is_showing=1 AND i.is_approved=1 AND i.item_id = " . $db->tosql($column_id, INTEGER);
		if (isset($site_id)) {
			$sql .= " AND (i.sites_all=1 OR s.site_id=" . $db->tosql($site_id, INTEGER, true, false) . ")";
		} else {
			$sql .= " AND i.sites_all=1 ";	
		}
		if (strlen($user_id)) {
			$sql .= " AND (i.user_types_all=1 OR ut.user_type_id=". $db->tosql($user_type_id, INTEGER, true. false) . ")";
		} else {
			$sql .= " AND i.user_types_all=1 ";		
		}
		$db->query($sql);
		if($db->next_record())
		{
			$item_name = get_translation($db->f("item_name"));
			$t->set_var("reviewed_item_name", $item_name);
			$meta_description = $item_name . " " . REVIEWS_MSG;
		}
		else
		{
			return;
			$is_item = false;
			$errors = ERRORS_MSG;
			$t->set_var("reviewed_item_name", ERRORS_MSG);
		}
	} else if ($review_type == 2) {
		$column_id  = get_param("article_id");
		$reviews_href = "articles_reviews.php";
		$reviews_table = $table_prefix . "articles_reviews ";
		$column_name = "article_id";
		$recommend_msg = RECOMMEND_ARTICLE_MSG;

		$sql  = " SELECT a.article_title ";
		$sql .= " FROM " . $table_prefix . "articles a, " . $table_prefix . "articles_statuses st ";
		$sql .= " WHERE st.allowed_view=1 ";
		$sql .= " AND a.article_id = " . $db->tosql($column_id, INTEGER);
		$db->query($sql);
		if($db->next_record())
		{
			$article_title = get_translation($db->f("article_title"));
			$t->set_var("reviewed_item_name", $article_title);
			$meta_description = $article_title . " " . REVIEWS_MSG;
		}
		else
		{
			return;
			$is_item = false;
			$errors = ERRORS_MSG;
			$t->set_var("reviewed_item_name", ERRORS_MSG);
		}
	}

	$t->set_var("rnd",           va_timestamp());
	$t->set_var("reviews_href",  $reviews_href);
	$t->set_var("recommend_msg", $recommend_msg);
	$t->set_var("column_id",     htmlspecialchars($column_id));
	$t->set_var("column_name",   htmlspecialchars($column_name));

	$r = new VA_Record($reviews_table);

	$recommended = 
		array( 
			array(1, YES_MSG), array(0, NO_MSG)
			);

	$rating = 
		array( 
			array(0, OPTIONAL_MSG), array(1, BAD_MSG), array(2, POOR_MSG), 
			array(3, AVERAGE_MSG), array(4, GOOD_MSG), array(5, EXCELLENT_MSG),
			);

	$r->add_textbox($column_name, INTEGER);
	$r->add_radio("recommended", INTEGER, $recommended);
	$r->add_textbox("approved", INTEGER);
	$r->add_select("rating", INTEGER, $rating);
	$r->add_textbox("summary", TEXT);
	$r->add_textbox("user_name", TEXT);
	$r->add_textbox("remote_address", TEXT);
	$r->add_textbox("date_added", DATETIME);
	$r->add_textbox("comments", TEXT);
	$r->add_textbox("validation_number", TEXT, VALIDATION_CODE_FIELD);
	$r->change_property("validation_number", USE_IN_INSERT, false);
	$r->change_property("validation_number", USE_IN_UPDATE, false);
	$r->change_property("validation_number", USE_IN_SELECT, false);
	if ($use_validation) {
		$r->change_property("validation_number", REQUIRED, true);
		$r->change_property("validation_number", SHOW, true);
	} else {
		$r->change_property("validation_number", REQUIRED, false);
		$r->change_property("validation_number", SHOW, false);
	}

	
	$recommended_class = "normal"; 
	$user_name_class = "normal"; 
	$validation_class = "normal"; 

	$action = get_param("action");
	$rnd = get_param("rnd");
	$filter = get_param("filter");
	$remote_address = get_ip();

	if($action && !strlen($errors))
	{
		$review_date = mktime(0,0,0, date("m"), date("d") - 7, date("Y")); // allow post another review after 7 days
		$sql  = " SELECT review_id FROM " . $reviews_table;
		$sql .= " WHERE " . $column_name . "=" . $db->tosql($column_id, INTEGER) . " AND remote_address='" . $remote_address . "'";		
		$sql .= " AND date_added>" . $db->tosql($review_date, DATETIME);		
		$db->query($sql);

		if($db->next_record()) {
			$errors = ALREADY_REVIEW_MSG;
		}
	}

	$session_rnd = get_session("session_rnd");
	if($action && !strlen($errors) && $rnd != $session_rnd)
	{
		set_session("session_rnd", $rnd);
		$is_errors = false;

		$r->get_form_values();

		if ($use_validation) { 
			if(!check_image_validation($r->get_value("validation_number"))) {
				$validation_class = "error"; $is_errors = true; 
				$errors .= str_replace("{field_name}", VALIDATION_CODE_FIELD, VALIDATION_MESSAGE) . "<br>";
			}
		}

		if($r->is_empty("recommended")) {
			$recommended_class = "error"; $is_errors = true; 
		}
		if($r->is_empty("user_name")) {
			$user_name_class = "error"; $is_errors = true; 
		}
		if ($is_errors) {
			$provide_info_message = str_replace("{button_name}", RATE_IT_BUTTON, PROVIDE_INFO_MSG);
			$errors .= $provide_info_message . "<br>";	
			set_session("session_rnd", "");
		} else if (check_black_ip()) {
			$errors = BLACK_IP_MSG;	
		} else if (check_banned_content($r->get_value("comments"))) {
			$errors = BANNED_CONTENT_MSG;	
		}

		if(!strlen($errors))
		{
			$r->set_value("date_added", va_time());
			$r->set_value("remote_address", $remote_address);
			$approve = $approve_review ? 0 : 1;
			$r->set_value("approved", $approve);

			$r->insert_record();
			if($approve) {
				update_rating($column_id, $review_type);
			}

			$r->empty_values();
		}
	}

	$sql = " SELECT COUNT(*) FROM " . $reviews_table. " WHERE approved=1 AND rating <> 0 AND " . $column_name . "=" . $db->tosql($column_id, INTEGER);
	$total_rating_votes = get_db_value($sql);

	$average_rating_float = 0;
	$total_rating_sum = 0;
	if($total_rating_votes)
	{
		$sql = " SELECT SUM(rating) FROM " . $reviews_table . " WHERE approved=1 AND rating <> 0 AND " . $column_name . "=" . $db->tosql($column_id, INTEGER);
		$total_rating_sum = get_db_value($sql);
		$average_rating_float = round($total_rating_sum / $total_rating_votes, 2);
	}

	$t->set_var("current_category_id", htmlspecialchars($category_id));
	$t->set_var($column_name, htmlspecialchars($column_id));
	$r->set_value($column_name, $column_id);

	if($is_item)
	{
		$n = new VA_Navigator($settings["templates_dir"], "navigator.html", $reviews_href);
		// count recommended reviews
		$sql = " SELECT COUNT(*) FROM " . $reviews_table . " WHERE recommended=1 AND approved=1 AND " . $column_name . "=" . $db->tosql($column_id, INTEGER);
		$commend = get_db_value($sql);

		// count discommend reviews
		$sql = " SELECT COUNT(*) FROM " . $reviews_table . " WHERE recommended=0 AND approved=1 AND " . $column_name . "=" . $db->tosql($column_id, INTEGER);
		$discommend = get_db_value($sql);

		$total_votes = $commend + $discommend;

		if(strlen($filter))
		{
			$t->parse("all_reviews_link", false);
			if($filter == 1)
			{
				$t->parse("positive_reviews", false);
				$t->parse("negative_reviews_link", false);
			}
			else
			{
				$t->parse("positive_reviews_link", false);
				$t->parse("negative_reviews", false);
			}
		}
		else
		{
			$t->parse("all_reviews", false);
			$t->parse("positive_reviews_link", false);
			$t->parse("negative_reviews_link", false);
		}
		
		if($total_votes)
		{
			// parse summary statistic
			$t->set_var("commend_percent", round($commend / $total_votes * 100, 0));
			$t->set_var("discommend_percent", round($discommend / $total_votes * 100, 0));
			$t->set_var("total_votes", $total_votes);

			$average_rating = round($average_rating_float, 0);
			$average_rating_image = $average_rating ? "rating_" . $average_rating . ".gif" : "not_rated.gif";
			$t->set_var("average_rating_image", $average_rating_image);
			$t->set_var("average_rating_alt", $average_rating_float);

			$t->parse("summary_statistic", false);

			$sql    = " SELECT COUNT(*) FROM " . $reviews_table . " ";
			$where  = " WHERE (summary IS NOT NULL OR comments IS NOT NULL) ";
			$where .= " AND approved=1 AND " . $column_name . "=" . $db->tosql($column_id, INTEGER);
			if(strlen($filter))
				$where .= " AND recommended=" . $db->tosql($filter, INTEGER);
		
			$total_records = get_db_value($sql . $where);
			$t->set_var("total_records", $total_records);
			

			$record_number = 0;
			$records_per_page = $reviews_per_page ? $reviews_per_page : 10;
			$pages_number = 5;
			$page_number = $n->set_navigator("navigator", "page", SIMPLE, $pages_number, $records_per_page, $total_records, false);
  
			$sql = " SELECT * FROM " . $reviews_table . " ";
			$order_by = " ORDER BY date_added DESC";  
			$db->RecordsPerPage = $records_per_page;
			$db->PageNumber = $page_number;
			$db->query($sql . $where . $order_by);
			if($db->next_record())
			{
				$latest_comments = $db->f("comments");
				if($latest_comments) {
					$meta_description = $latest_comments;
				}
				do 
				{
					$record_number++;
					if($record_number > 1)
						$t->parse("delimiter", false);
					else
						$t->set_var("delimiter", "");
      
					$recommended_image = $db->f("recommended") ? "commend.gif" : "discommend.gif";
					$t->set_var("recommended_image", $recommended_image);
					$rating = round($db->f("rating"), 0);
					$rating_image = $rating ? "rating_" . $rating . ".gif" : "not_rated.gif";
					$t->set_var("rating_image", $rating_image);
					$t->set_var("review_user_name", htmlspecialchars($db->f("user_name")));
					$date_added = $db->f("date_added", DATETIME);
					$date_added_string = va_date($datetime_show_format, $date_added);
					$t->set_var("review_date_added", $date_added_string);
					$t->set_var("review_summary", htmlspecialchars($db->f("summary")));
					$t->set_var("review_comments", nl2br(htmlspecialchars($db->f("comments"))));
      
					$t->parse("reviews", true);
				} while ($db->next_record());
				$t->parse("reviews_block", false);
			}
			else
				$t->parse("no_reviews", false);
		}
		else
		{
			$t->set_var("total_records", 0);
			$t->parse("no_reviews", false);
		}
	}

	$t->set_var("recommended_class", $recommended_class);
	$t->set_var("user_name_class", $user_name_class);
	$t->set_var("validation_class", $validation_class);
	$r->set_parameters();

	if(strlen($errors)) {
		$t->set_var("errors", $errors);
		$t->parse("errors_block", false);
	}

	if(!strlen($errors) && $action) {
		$t->parse("thanks_block", false);
	}

	$t->parse("block_body", false);
	$t->parse($block_name, true);

}

function update_rating($column_id, $review_type = 1)
{
	global $db, $table_prefix;

	if ($review_type == 1) {
		$reviews_table = $table_prefix . "reviews ";
		$column_name = "item_id";
	} else if ($review_type == 2) {
		$reviews_table = $table_prefix . "articles_reviews ";
		$column_name = "article_id";
	}
	
	$sql = " SELECT COUNT(*) FROM " . $reviews_table . " WHERE approved=1 AND rating <> 0 AND " . $column_name . "=" . $db->tosql($column_id, INTEGER);
	$total_rating_votes = get_db_value($sql);

	$sql = " SELECT SUM(rating) FROM " . $reviews_table . " WHERE approved=1 AND rating <> 0 AND " . $column_name . "=" . $db->tosql($column_id, INTEGER);
	$total_rating_sum = get_db_value($sql);
	if(!strlen($total_rating_sum)) $total_rating_sum = 0;

	$average_rating = $total_rating_votes ? $total_rating_sum / $total_rating_votes : 0;

	if ($review_type == 1) {
		$sql  = " UPDATE " . $table_prefix . "items ";
		$sql .= " SET votes=" . $total_rating_votes . ", points=" . $total_rating_sum . ", ";
		$sql .= " rating=" . $average_rating;
		$sql .= " WHERE item_id=" . $db->tosql($column_id, INTEGER);
		$db->query($sql);
	} else {
		$sql  = " UPDATE " . $table_prefix . "articles ";
		$sql .= " SET total_votes=" . $total_rating_votes . ", total_points=" . $total_rating_sum . ", ";
		$sql .= " rating=" . $average_rating;
		$sql .= " WHERE article_id=" . $db->tosql($column_id, INTEGER);
		$db->query($sql);
	}
}


?>