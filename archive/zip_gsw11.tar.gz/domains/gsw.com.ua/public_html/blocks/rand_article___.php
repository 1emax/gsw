<?php
    $db_host       = "localhost";
    $db_user       = "gswcomua_db";
    $db_password   = "X15TTw0w";
    $db_name       = "gswcomua_db";
    
	// @mysql_query("SET NAMES `cp1251`");
	
    $dbLink = new mysqli($db_host, $db_user, $db_password, $db_name);
    	
    if(mysqli_connect_errno($dbLink)) {
        die("Ошибка при подключении к бд ".$db_name);
    }
    
    $sqlArticles = "SELECT * FROM va_articles ORDER BY article_id DESC LIMIT 0, 3";
    
	$dbLink->set_charset('cp1251'); 
	
    $res = $dbLink->query($sqlArticles);
    $row = $res->fetch_array();
    
    echo "<div class='news_kibal4iw' style='width:100%'>";
    
	do {
		printf('<a class="news_title_kibal4iw" href="../article.php?article_id=%s"><b>%s</b></a><p class="news_description_kibal4iw">%s</p> <a class="news_read_more_kibal4iw" href="../article.php?article_id=%s">{READ_MORE_MSG}</a><br class="spacer clear" /><br class="spacer clear" />', $row['article_id'], $row['article_title'], $row['short_description'], $row['article_id']);
	}
    while ($row = $res->fetch_array());
    
    echo "</div>";
	
	/*-----------------------------------------------------------*/
	/*$assignedID = 1;
	$assignedArray = array();
	
	$sqlAssigned = "SELECT * FROM va_articles_assigned WHERE category_id=" . $assignedID;
	
	$res = $dbLink->query($sqlAssigned);
    $row = $res->fetch_array();
	
	echo "<div style='display:none'>";
	do {
		$assignedArray[ $row['article_id'] ] = $row['article_id'];
		 
		echo $assignedArray[ $row['article_id'] ] . "<br>";
	}
    while ($row = $res->fetch_array());
	echo "</div>";*/

?>
