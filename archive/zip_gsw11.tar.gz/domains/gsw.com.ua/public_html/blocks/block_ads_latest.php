<?php

function ads_latest($block_name)
{
	global $t, $db, $table_prefix;
	global $settings, $page_settings;
	global $date_show_format;
	global $site_id, $db_type;

	if(get_setting_value($page_settings, $block_name . "_column_hide", 0)) {
		return;
	}

	$t->set_file("block_body", "block_ads_latest.html");
	$t->set_var("latest_rows", "");
	$t->set_var("latest_cols", "");
	$t->set_var("ADS_TITLE",        ADS_TITLE);
	$t->set_var("LATEST_TITLE",     LATEST_TITLE);
	$t->set_var("MORE_MSG",         MORE_MSG);
	$t->set_var("READ_MORE_MSG",    READ_MORE_MSG);
	$t->set_var("CLICK_HERE_MSG",   CLICK_HERE_MSG);

	$friendly_urls = get_setting_value($settings, "friendly_urls", 0);
	$friendly_extension = get_setting_value($settings, "friendly_extension", "");
	$records_per_page = get_setting_value($page_settings, "ads_latest_recs", 10);

	$sql  = " SELECT i.item_id, i.item_title, i.friendly_url, i.date_start, i.short_description ";
	if (isset($site_id))  {
		$sql .= " FROM (((" . $table_prefix . "ads_items i ";
	} else {
		$sql .= " FROM ((" . $table_prefix . "ads_items i ";
	}
	$sql .= " LEFT JOIN " . $table_prefix . "ads_assigned aac ON aac.item_id=i.item_id) ";
	$sql .= " LEFT JOIN " . $table_prefix . "ads_categories ac ON ac.category_id=aac.category_id) ";				
	if (isset($site_id))  {
		$sql .= " LEFT JOIN " . $table_prefix . "ads_categories_sites acs ON acs.category_id=ac.category_id)";
		$sql .= " WHERE (ac.sites_all=1 OR acs.site_id=". $db->tosql($site_id, INTEGER, true, false) . ") ";
	} else {
		$sql .= " WHERE ac.sites_all=1 ";					
	}	
	$sql .= " AND i.is_approved=1 ";
	$sql .= " AND i.date_start<=" . $db->tosql(va_time(), DATETIME);
	$sql .= " AND i.date_end>" . $db->tosql(va_time(), DATETIME);

	if ($db_type == "access" || $db_type == "db2"  || $db_type == "postgre") {
		$sql .= " GROUP BY i.item_id, i.item_title, i.friendly_url, i.date_start, i.short_description,i.date_added, i.date_start ";
	} else {
		$sql .= " GROUP BY i.item_id ";
	}
		
	$sql .= " ORDER BY i.date_start DESC, i.date_added ";

	$db->RecordsPerPage = $records_per_page;
	$db->PageNumber = 1;
	$db->query($sql);
	if($db->next_record())
	{
		$latest_columns = get_setting_value($page_settings, "ads_latest_cols", 1);
		$t->set_var("latest_column", (100 / $latest_columns) . "%");
		$latest_number = 0;
		do
		{
			$latest_number++;
			$item_id = $db->f("item_id");
			$item_title = get_translation($db->f("item_title"));
			$friendly_url = $db->f("friendly_url");
			$short_description = get_translation($db->f("short_description"));
		
			$t->set_var("item_id", $item_id);
			$t->set_var("latest_item_title", $item_title);
			$t->set_var("short_description", nl2br($short_description));
			if ($friendly_urls && $friendly_url) {
				$t->set_var("details_href", $friendly_url . $friendly_extension);
			} else {
				$t->set_var("details_href", "ads_details.php?item_id=" . $item_id);
			}

			$date_start = $db->f("date_start", DATETIME);
			$date_start_string  = va_date($date_show_format, $date_start);
			$t->set_var("date_start", $date_start_string);

			$t->parse("latest_cols");
			if($latest_number % $latest_columns == 0)
			{
				$t->parse("latest_rows");
				$t->set_var("latest_cols", "");
			}
			
		} while ($db->next_record());              	

		if ($latest_number % $latest_columns != 0) {
			$t->parse("latest_rows");
		}

		$t->parse("block_body", false);
		$t->parse($block_name, true);
	}

}

?>