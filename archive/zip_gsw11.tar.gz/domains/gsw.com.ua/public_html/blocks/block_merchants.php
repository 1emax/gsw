<?php

function merchants($block_name)
{
	global $t, $db, $site_id, $db_type, $table_prefix;
	global $settings, $page_settings, $language_code;

	if(get_setting_value($page_settings, $block_name . "_column_hide", 0)) {
		return;
	}

	$friendly_urls = get_setting_value($settings, "friendly_urls", 0);
	$friendly_extension = get_setting_value($settings, "friendly_extension", "");
	$merchants_selection = get_setting_value($page_settings, "merchants_selection", 1);
	$user = get_param("user");
		
	$user_id = get_session("session_user_id");
	$user_type_id = get_session("session_user_type_id");

	$t->set_file("block_body",    "block_merchants.html");
	$t->set_var("user_list_href", "user_list.php");

	$sql  = " SELECT u.user_id, u.company_name, u.name, u.login, u.friendly_url, COUNT(*) AS merchant_products ";
	$sql .= " FROM ((";
	if (isset($site_id)) {
		$sql .= "((";
	}
	if (strlen($user_id)) {
		$sql .= "(";
	}
	$sql .= $table_prefix . "items i ";
	if (isset($site_id)) {		
		$sql .=	" LEFT JOIN " . $table_prefix . "items_sites s ON (s.item_id=i.item_id AND i.sites_all=0)) ";
	}
	$sql .=	" INNER JOIN " . $table_prefix . "users u ON i.user_id=u.user_id) ";
	$sql .=	" INNER JOIN " . $table_prefix . "user_types t ON t.type_id=u.user_type_id) ";
	if (isset($site_id)) {
		$sql .=	" LEFT JOIN " . $table_prefix . "user_types_sites uts ON (uts.type_id=t.type_id AND t.sites_all=0)) ";
	}
	if (strlen($user_id)) {
		$sql .= " LEFT JOIN " . $table_prefix . "items_user_types ut ON (ut.item_id=i.item_id AND i.user_types_all=0))";
	}
	$sql .= " WHERE i.is_showing=1 AND i.is_approved=1 ";
	$sql .= " AND ((i.hide_out_of_stock=1 AND i.stock_level > 0) OR i.hide_out_of_stock=0 OR i.hide_out_of_stock IS NULL)";
	$sql .= " AND (i.language_code IS NULL OR i.language_code='' OR i.language_code=" . $db->tosql($language_code, TEXT) . ")";
	if (isset($site_id)) {		
		$sql .=	" AND ( i.sites_all=1 OR s.site_id=" . $db->tosql($site_id, INTEGER, true, false) . ") ";
		$sql .=	" AND ( t.sites_all=1 OR uts.site_id=" . $db->tosql($site_id, INTEGER, true, false) . ") ";
	} else {
		$sql .=	" AND i.sites_all=1 ";
		$sql .=	" AND t.sites_all=1 ";
	}
	if (strlen($user_id)) {
		$sql .= " AND (i.user_types_all=1 OR ut.user_type_id=". $db->tosql($user_type_id , INTEGER) . " )";
	} else {
		$sql .= " AND i.user_types_all=1 ";
	}
	if ($db_type == "access" || $db_type == "db2" || $db_type == "postgre") {
		$sql .= " GROUP BY u.user_id, u.company_name, u.name, u.login, u.friendly_url ";
	} else {
		$sql .= " GROUP BY u.user_id ";
	}
	$sql .= " ORDER BY u.company_name, u.name, u.login ";
	$db->query($sql);
	if ($db->next_record()) {

		do {
			$merchant_id = $db->f("user_id");
			$merchant_name = $db->f("company_name");
			if (!strlen($merchant_name)) {
				$merchant_name = $db->f("name");
			}
			if (!strlen($merchant_name)) {
				$merchant_name = $db->f("login");
			}
			$friendly_url = $db->f("friendly_url");
			$merchant_products = $db->f("merchant_products");

			if ($friendly_urls && $friendly_url) {
				$merchant_url = $friendly_url. $friendly_extension;
			} else {
				$merchant_url = "user_list.php?user=" . $merchant_id;
			}

			$merchant_selected = ($user == $merchant_id) ? "selected" : "";

			$t->set_var("merchant_id",   $merchant_id);
			$t->set_var("merchant_name", $merchant_name);
			$t->set_var("merchant_url",  $merchant_url);
			$t->set_var("merchant_selected", $merchant_selected);
			$t->set_var("merchant_products", $merchant_products);

			$t->sparse("merchants", true);
			$t->sparse("merchants_options", true);

		} while ($db->next_record());

		if ($merchants_selection == 2) {
			$t->sparse("merchants_select", false);
		} else {
			$t->sparse("merchants_list", false);
		}


		$t->parse("block_body", false);
		$t->parse($block_name, true);
	}

}

?>