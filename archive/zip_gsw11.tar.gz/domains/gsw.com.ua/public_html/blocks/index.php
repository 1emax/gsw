<?php

	header("Location: ../");
	exit;

?>