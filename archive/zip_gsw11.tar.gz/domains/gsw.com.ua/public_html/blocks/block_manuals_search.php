<?php

function manuals_search($block_name) {
	global $t, $db, $table_prefix;
	global $site_id, $db_type;

	$t->set_file("block_body", "block_manuals_search.html");
	$t->set_var("MANUALS_SEARCH_IN_FIRST_VARIANT", MANUALS_SEARCH_IN_FIRST_VARIANT);
	$t->set_var("MANUALS_SEARCH_FOR_MSG", MANUALS_SEARCH_FOR_MSG);
	$t->set_var("MANUALS_SEARCH_IN_MSG", MANUALS_SEARCH_IN_MSG);
	$t->set_var("MANUALS_SEARCH_TITLE", MANUALS_SEARCH_TITLE);
	
	$search_string = get_param("manuals_search");
	$manual_id = intval(get_param("manual_id"));

	// Select manuals
	$sql  = " SELECT ml.manual_id,ml.manual_title ";
	$sql .= " FROM ((".$table_prefix."manuals_list ml ";
	$sql .= " INNER JOIN ".$table_prefix."manuals_categories mc ON mc.category_id = ml.category_id)";
	if (isset($site_id)) {
		$sql .= " LEFT JOIN ".$table_prefix."manuals_categories_sites AS mcs ON mcs.category_id = mc.category_id) ";
		$sql .= " WHERE (mc.sites_all = 1 OR mcs.site_id=" . $db->tosql($site_id, INTEGER, true, false) . ") ";
	} else {
		$sql .= ") WHERE mc.sites_all = 1 ";
	}	
	$sql .= " AND ml.allowed_view = 1 AND mc.allowed_view=1 ";
	if (isset($site_id)) {
		if ($db_type == "access" || $db_type == "db2"  || $db_type == "postgre") {
			$sql .= " GROUP BY ml.manual_id,ml.manual_title,ml.allowed_view";
		} else {
			$sql .= " GROUP BY ml.manual_id";
		}
	}
	$sql .= " ORDER BY ml.manual_title";
	
	$db->query($sql);
	if ($db->next_record()) {
		do {
			$t->set_var("option_value", $db->f("manual_id"));
			if ($db->f("manual_id") == $manual_id)
				$t->set_var("option_selected", "selected");
			$t->set_var("option_description", $db->f("manual_title"));
			$t->parse("option", true);
		} while($db->next_record());
	}
	$t->parse("manuals_select", false);
	
	$t->set_var("manuals_search", $search_string);
	
	$t->parse("block_body", false);
	$t->parse($block_name, true);
}
?>