<?php

function forum_search($block_name) 
{
	global $t, $db, $table_prefix, $language_code;
	global $category_id;
	global $page_settings;
	global $site_id, $db_type;

	if(get_setting_value($page_settings, $block_name . "_column_hide", 0)) {
		return;
	}

	$user_id = get_session("session_user_id");	
	$user_info = get_session("session_user_info");
	$user_type_id = get_setting_value($user_info, "user_type_id", "");		

	$t->set_var("forum_href",   "forum.php");
	$t->set_file("block_body", "block_forum_search.html");
	$t->set_var("SEARCH_TITLE",  SEARCH_TITLE);
	$t->set_var("SEARCH_BUTTON", SEARCH_BUTTON);

	$search_categories[] = array("", SEARCH_IN_ALL_MSG);
	$sql  = " SELECT fc.category_id, fc.category_name, fl.forum_id, fl.forum_name ";
	$sql .= " FROM (";
	if (isset($site_id)) {
		$sql .= "(";
	}
	if (strlen($user_id)) {
		$sql .= "((";
	}
	$sql .= $table_prefix . "forum_list fl";
	$sql .= " INNER JOIN " . $table_prefix . "forum_categories fc ON  fc.category_id=fl.category_id)";
	if (isset($site_id)) {
		$sql .= " LEFT JOIN " . $table_prefix . "forum_categories_sites fcs ON fcs.category_id=fl.category_id)";
	}
	if (strlen($user_id)) {
		$sql .= " LEFT JOIN " . $table_prefix . "forum_view_types view_forum ON view_forum.forum_id=fl.forum_id)";
		$sql .= " LEFT JOIN " . $table_prefix . "forum_view_topics view_topics ON view_topics.forum_id=fl.forum_id)";
	}
	
	$sql .= " WHERE fc.allowed_view > 0 ";
	if (isset($site_id)) {
		$sql .= " AND (fc.sites_all=1 OR fcs.site_id=". $db->tosql($site_id, INTEGER, true, false) . ") ";
	} else {
		$sql .= " AND fc.sites_all=1 ";					
	}	
	if (strlen($user_id)) {
		$sql .= " AND ( fl.allowed_view = 1 OR ( fl.allowed_view = 2  AND ( view_forum.user_type_id=". $db->tosql($user_type_id , INTEGER) . " OR fl.view_forum_types_all=1) ) )";
		$sql .= " AND ( fl.allowed_view_topics = 1 OR ( fl.allowed_view_topics = 2  AND ( view_topics.user_type_id=". $db->tosql($user_type_id , INTEGER) . " OR fl.view_topics_types_all=1) ) )";
	} else {
		$sql .= " AND fl.allowed_view=1 AND fl.allowed_view_topics=1 ";
	}
	if ($db_type == "access" || $db_type == "db2"  || $db_type == "postgre") {
		$sql .= " GROUP BY fl.forum_id, fc.category_id, fc.category_name, fl.forum_name, fc.category_order, fl.forum_order  ";
	} else {
		$sql .= " GROUP BY fl.forum_id ";
	}
	$sql .= " ORDER BY fc.category_order, fc.category_id, fl.forum_order ";

	$db->query($sql);
	if ($db->next_record()) {
		$last_category_id = "";
		do {
			$category_id = $db->f("category_id");
			$category_name = get_translation($db->f("category_name"));
			$forum_id = $db->f("forum_id");
			$forum_name = get_translation($db->f("forum_name"));
			if ($last_category_id != $category_id) {
				$search_categories[] = array("c".$category_id, $category_name);
			}
			$search_categories[] = array("f".$forum_id, " -- " . $forum_name);
			$last_category_id = $category_id;
		} while ($db->next_record());
	}

	$sf = get_param("sf");
	$sw = get_param("sw");
	if (sizeof($search_categories) > 1) {
		set_options($search_categories, $sf, "sf");
		$t->global_parse("search_categories", false, false, true);
	} else {
		$t->set_var("search_categories", "");
	}
	$t->set_var("sw", htmlspecialchars($sw));
	$t->set_var("current_category_id", htmlspecialchars($category_id));

	$t->parse("block_body", false);
	$t->parse($block_name, true);

}
?>