<?php

	function manuals_list($block_name) {
		global $t, $db, $table_prefix, $settings, $datetime_show_format;
		global $site_id, $db_type;
		$category_id = get_param("category_id");

		// Global friendly url settings
		$friendly_urls = get_setting_value($settings, "friendly_urls", 0);
		$friendly_extension = get_setting_value($settings, "friendly_extension", "");		
		
		$manual_articles_href = "manuals_articles.php?manual_id=";
		// Set messages variables
		$t->set_var("MANUALS_TITLE", MANUALS_TITLE);
		$t->set_var("NO_MANUALS_MSG", NO_MANUALS_MSG);
		
		$t->set_file("block_body", "block_manuals_list.html");

		$sql  = " SELECT ml.manual_id,ml.manual_title,ml.short_description,mc.short_description,mc.category_id,mc.category_name ";
		$sql .= " FROM ((" . $table_prefix . "manuals_categories mc ";
		$sql .= " LEFT JOIN " . $table_prefix . "manuals_list ml ON mc.category_id = ml.category_id)";
		if (isset($site_id))  {
			$sql .= " LEFT JOIN " . $table_prefix . "manuals_categories_sites mcs ON mcs.category_id=mc.category_id)";
			$sql .= " WHERE (mc.sites_all=1 OR mcs.site_id=". $db->tosql($site_id, INTEGER, true, false) . ") ";
		} else {
			$sql .= " ) WHERE mc.sites_all=1 ";					
		}
		$sql .= " AND mc.allowed_view = 1 AND ml.allowed_view = 1 ";
		if ($category_id != "") {
			$sql .= " AND mc.category_id = " . $db->tosql($category_id, INTEGER);
		}		
		if (isset($site_id))  {
			if ($db_type == "access" || $db_type == "db2"  || $db_type == "postgre") {
				$sql .= " GROUP BY ml.manual_id,mc.category_id,ml.manual_title,mc.category_name,ml.short_description,mc.short_description,mc.category_order, ml.manual_order";
			} else {
				$sql .= " GROUP BY ml.manual_id,mc.category_id";		
			}
		}
		$sql .= " ORDER BY mc.category_order, ml.manual_order";

		$db->query($sql);
		$prev_category_id = 0;
		if ($db->next_record()) {
			do {
				$category_id = $db->f("category_id");
				
				if ($prev_category_id != $category_id) {
					//$prev_category_id = $category_id;
					if ($prev_category_id != 0) {
						$t->parse("categories", true);
						$t->set_var("manuals", "");
					}
				}
				
				$t->set_var("cat_name", $db->f("category_name"));
				$manual_id = $db->f("manual_id");
				// Parse manual
				$t->set_var("manual_title", $db->f("manual_title"));
				$t->set_var("short_description", $db->f("short_description"));
				$friendly_url = $db->f("friendly_url");
				
				if ($friendly_urls && $friendly_url != "") {
					$manual_href = $friendly_url . $friendly_extension;
				} else {
					$manual_href = $manual_articles_href.$manual_id;
				}
				$t->set_var("manual_href", $manual_href);
				$t->parse("manuals", true);
				
				$prev_category_id = $category_id;
			} while ($db->next_record());
			$t->set_var("category_id", $category_id);
			$t->parse("categories", true);
		}
		
		$t->parse("block_body", false);
		$t->parse($block_name, true);
	}
?>