<?php

function ads_sellers($block_name, $category_id)
{
	global $t, $db, $db_type, $table_prefix;
	global $page_settings;
	global $site_id;

	if(get_setting_value($page_settings, $block_name . "_column_hide", 0)) {
		return;
	}

	$t->set_file("block_body",        "block_ads_sellers.html");

	$search_tree = new VA_Tree("category_id", "category_name", "parent_category_id", $table_prefix . "ads_categories", "tree", ADS_TITLE);

	$sql  = " SELECT u.user_id, u.name, u.first_name, u.last_name, u.login, ";
	if ($db_type == "access") {
		$sql .= " COUNT(*) AS user_ads ";
	} else {
		$sql .= " COUNT(DISTINCT(i.item_id)) AS user_ads ";
	} 
	if (isset($site_id))  {
		$sql .= " FROM ((((" . $table_prefix . "ads_items i ";
	} else {
		$sql .= " FROM (((" . $table_prefix . "ads_items i ";
	}
	$sql .=	" INNER JOIN " . $table_prefix . "users u ON i.user_id=u.user_id) ";
	$sql .=	" LEFT JOIN " . $table_prefix . "ads_assigned ic ON ic.item_id=i.item_id ) ";
	$sql .=	" LEFT JOIN " . $table_prefix . "ads_categories c ON ic.category_id=c.category_id) ";
	
	if (isset($site_id))  {
		$sql .= " LEFT JOIN " . $table_prefix . "ads_categories_sites cs ON (cs.category_id=c.category_id AND c.sites_all=0))";
		$sql .= " WHERE (c.sites_all=1 OR cs.site_id=". $db->tosql($site_id, INTEGER, true, false) . ")";
	} else {
		$sql .= " WHERE c.sites_all=1 ";					
	}
	
	$sql .= " AND i.is_approved=1 ";
	$sql .= " AND i.date_start<=" . $db->tosql(va_time(), DATETIME);
	$sql .= " AND i.date_end>" . $db->tosql(va_time(), DATETIME);
	if ($category_id > 0) {
		$sql .= " AND (ic.category_id=" . $db->tosql($category_id, INTEGER);
		$sql .= " OR c.category_path LIKE '%" . $db->tosql($search_tree->get_path($category_id), TEXT, false) . "%')";
	}
	
	if ($db_type == "access" || $db_type == "db2"  || $db_type == "postgre") {
		$sql .= " GROUP BY u.user_id, u.name, u.first_name, u.last_name, u.login ";
	} else {
		$sql .= " GROUP BY u.user_id ";
	}
	
	$db->query($sql);
	if ($db->next_record()) {
		do {
			$user_id = $db->f("user_id");
			$user_ads = $db->f("user_ads");
			$name = $db->f("name");
			$login = $db->f("login");
			$first_name = $db->f("first_name");
			$last_name = $db->f("last_name");
			if (strlen($name)) {
				$user_name = $name;
			} else if (strlen($first_name) || strlen($last_name)) {
				$user_name = $first_name." ".$last_name;
			} else {
				$user_name = $login;
			}

			$user_href = "ads.php?category_id=" . urlencode($category_id) . "&user=" . $user_id;

			$t->set_var("user_name", $user_name);
			$t->set_var("user_href", $user_href);
			$t->set_var("user_ads", $user_ads);

			$t->parse("users", true);
		} while ($db->next_record());

		$t->parse("block_body", false);
		$t->parse($block_name, true);
	}

}

?>