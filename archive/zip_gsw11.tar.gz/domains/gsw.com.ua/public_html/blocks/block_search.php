<?php

function search_form($block_name = "")
{
	global $t, $db, $db_type, $site_id, $table_prefix, $language_code;
	global $category_id;
	global $page_settings;

	if(get_setting_value($page_settings, $block_name . "_column_hide", 0)) {
		return;
	}

	$user_id = get_session("session_user_id");		
	$user_info = get_session("session_user_info");
	$user_type_id = get_setting_value($user_info, "user_type_id", "");
	
	if ($block_name) {
		$t->set_file("block_body", "block_search.html");
	}

	$t->set_var("search_href",   get_custom_friendly_url("products_search.php"));
	$t->set_var("search_name",   PRODUCTS_TITLE);

	$category_id = get_param("category_id");
	if (!$category_id) {
		$category_id = get_param("search_category_id");
	}
	$search_string = trim(get_param("search_string"));
	if (!strlen($category_id)) { $category_id = 0; }

	$query_string = transfer_params("", false);
	$t->set_var("advanced_search_href", get_custom_friendly_url("search.php") . $query_string);
	$t->global_parse("advanced_search", false, false, true);

	$search_categories[] = array(0, SEARCH_IN_ALL_MSG);
  
	if($category_id != 0) {
		$search_categories[] = array($category_id, SEARCH_IN_CURRENT_MSG);
	}

	$sql  = " SELECT c.category_id,c.category_name FROM ";
	if (isset($site_id)) {
		$sql .= "(";
	}
	if (strlen($user_id)) {
		$sql .= "(";
	}
	$sql .= $table_prefix . "categories c";
	if (isset($site_id)) {
		$sql .= " LEFT JOIN " . $table_prefix . "categories_sites cs ON cs.category_id=c.category_id)";
	}
	if (strlen($user_id)) {
		$sql .= " LEFT JOIN " . $table_prefix . "categories_user_types ut ON ut.category_id=c.category_id)";
	}
	if (isset($site_id)) {
		$sql .= " WHERE (c.sites_all=1 OR cs.site_id=" . $db->tosql($site_id, INTEGER, true, false) . ")";
	} else {
		$sql .= " WHERE c.sites_all=1";
	}
	if (strlen($user_id)) {
		$sql .= " AND (c.user_types_all=1 OR ut.user_type_id=". $db->tosql($user_type_id , INTEGER) . " )";
	} else {
		$sql .= " AND c.user_types_all=1 ";
	}
	$sql .= " AND c.is_showing=1";
	$sql .= " AND c.parent_category_id = " . $db->tosql($category_id, INTEGER);
	if ($db_type == "access" || $db_type == "db2"  || $db_type == "postgre") {
		$sql .= " GROUP BY c.category_id,c.category_name,c.category_order ";
	} else {
		$sql .= " GROUP BY c.category_id ";
	}
	$sql .= " ORDER BY c.category_order ";
	$db->query($sql);
	while ($db->next_record())
	{
		$show_category_id  = $db->f("category_id");
		$category_name  = get_translation($db->f("category_name"), $language_code);
		$search_categories[] = array($show_category_id, $category_name);
	}

	// set up search form parameters
	$t->set_var("no_search_categories", "");
	if (sizeof($search_categories) > 1) {
		set_options($search_categories, $category_id, "search_category_id");
		$t->global_parse("search_categories", false, false, true);
	} else {
		$t->set_var("search_categories", "");
	}
	$t->set_var("search_string", htmlspecialchars($search_string));
	$t->set_var("current_category_id", htmlspecialchars($category_id));

	if ($block_name) {
		$t->parse("block_body", false);
		$t->parse($block_name, true);
	}

}

?>