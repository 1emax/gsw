<?php

function ads_hot($block_name, $category_id, $category_name, $page_friendly_url = "", $page_friendly_params = array())
{
	global $t, $db, $db_type, $table_prefix;
	global $settings, $page_settings, $restrict_ads_images;
	global $datetime_show_format;
	global $current_page;
	global $site_id;

	if(get_setting_value($page_settings, $block_name . "_column_hide", 0)) {
		return;
	}

	$t->set_file("block_body", "block_ads_hot.html");
	$t->set_var("hot_rows", "");
	$t->set_var("hot_cols", "");
	$t->set_var("top_category_name",$category_name);

	$friendly_urls = get_setting_value($settings, "friendly_urls", 0);
	$friendly_extension = get_setting_value($settings, "friendly_extension", "");

	if ($friendly_urls && $page_friendly_url) {
		$pass_parameters = get_transfer_params($page_friendly_params);
		$current_page = $page_friendly_url . $friendly_extension;
	} else {
		$pass_parameters = get_transfer_params();
	}

	$search_tree = new VA_Tree("category_id", "category_name", "parent_category_id", $table_prefix . "ads_categories", "tree", "");

	// set up variables for navigator
	$total_records = 0;
	
	$sql_join = $table_prefix . "ads_items AS i ";
	$sql_join = " (" . $sql_join . " LEFT JOIN " . $table_prefix . "ads_assigned aa ON i.item_id=aa.item_id)";
	$sql_join = " (" . $sql_join . " LEFT JOIN " . $table_prefix . "ads_categories ac ON aa.category_id=ac.category_id) ";
	
	$sql_where = " WHERE i.is_hot=1 AND i.is_approved=1 ";
	if ($category_id > 0)	{
		$sql_where .= " AND (aa.category_id = " . $db->tosql($category_id, INTEGER);
		$sql_where .= " OR ac.category_path LIKE '" . $db->tosql($search_tree->get_path($category_id), TEXT, false) . "%')";
	}
	$sql_where .= " AND i.date_start<=" . $db->tosql(va_time(), DATETIME);
	$sql_where .= " AND i.date_end>" . $db->tosql(va_time(), DATETIME);	
	
	if (isset($site_id))  {
		$sql_join   = " (" . $sql_join . " LEFT JOIN " . $table_prefix . "ads_categories_sites acs ON acs.category_id=ac.category_id)";
		$sql_where .= " AND (ac.sites_all=1 OR acs.site_id=". $db->tosql($site_id, INTEGER, true, false) . ") ";
	} else {
		$sql_where .= " AND  ac.sites_all=1 ";					
	}
		
	$sql  = " SELECT i.item_id ";
	$sql .= " FROM " . $sql_join . $sql_where;
	$sql .= " GROUP BY i.item_id ";
	$db->query($sql);
	while($db->next_record()) {
		$total_records++;
	}
	$records_per_page = get_setting_value($page_settings, "ads_hot_recs", 10);
	$pages_number = 5;
	$n = new VA_Navigator($settings["templates_dir"], "navigator.html", $current_page);
	$page_number = $n->set_navigator("hot_navigator", "hot_page", SIMPLE, $pages_number, $records_per_page, $total_records, false, $pass_parameters);

	$sql  = " SELECT i.item_id, i.item_title, i.friendly_url, i.short_description, ";
	$sql .= " i.image_small, i.hot_description ";
	$sql .= " FROM " . $sql_join . $sql_where;
	if ($db_type == "access" || $db_type == "db2" || $db_type == "postgre") {
		$sql .= " GROUP BY i.item_id, i.image_small, i.short_description, i.hot_description, i.date_start, i.item_title, i.friendly_url, i.date_end, i.date_added, i.date_updated ";
	} else {
		$sql .= " GROUP BY i.item_id ";
	}
	$sql .= " ORDER BY i.date_start DESC, i.date_added DESC ";

	$db->RecordsPerPage = $records_per_page;
	$db->PageNumber = $page_number;
	$db->query($sql);
	if($db->next_record())
	{
		$hot_columns = get_setting_value($page_settings, "ads_hot_cols", 1);
		$t->set_var("hot_column", (100 / $hot_columns) . "%");
		$hot_number = 0;
		do
		{
			$hot_number++;
			$item_id = $db->f("item_id");
			$item_title = get_translation($db->f("item_title"));
			$friendly_url = $db->f("friendly_url");
			$hot_description = get_translation($db->f("hot_description"));
			if (!strlen($hot_description)) {
				$hot_description = get_translation($db->f("short_description"));
			}

			$t->set_var("item_id", $item_id);
			$t->set_var("hot_item_name", $item_title);
			$t->set_var("hot_description", $hot_description);
			if ($friendly_urls && $friendly_url) {
				$t->set_var("details_href", $friendly_url . $friendly_extension);
			} else {
				$t->set_var("details_href", "ads_details.php?item_id=" . $item_id);
			}

			$image_small = $db->f("image_small");
			if($image_small)
			{
				if (preg_match("/^http\:\/\//", $image_small)) {
					$image_size = "";
				} else {
	        $image_size = @GetImageSize($image_small);
					if (isset($restrict_ads_images) && $restrict_ads_images) { $image_small = "image_show.php?ad_id=".$item_id."&type=small"; }
				}
        $t->set_var("alt", htmlspecialchars($item_title));
        $t->set_var("src", htmlspecialchars($image_small));
				if(is_array($image_size))
				{
	        $t->set_var("width", "width=\"" . $image_size[0] . "\"");
  	      $t->set_var("height", "height=\"" . $image_size[1] . "\"");
				}
				else
				{
	        $t->set_var("width", "");
  	      $t->set_var("height", "");
				}
				$t->parse("image_small", false);
			}
			else
			{
				$t->set_var("image_small", "");
			}

			$t->parse("hot_cols");
			if($hot_number % $hot_columns == 0)
			{
				$t->parse("hot_rows");
				$t->set_var("hot_cols", "");
			}

		} while ($db->next_record());

		if ($hot_number % $hot_columns != 0) {
			$t->parse("hot_rows");
		}

		$t->parse("block_body", false);
		$t->parse($block_name, true);
	}

}

?>