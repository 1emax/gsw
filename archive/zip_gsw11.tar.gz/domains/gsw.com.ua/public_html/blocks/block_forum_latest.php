<?php

function forum_latest($block_name)
{
	global $t, $db, $table_prefix;
	global $settings, $page_settings;
	global $datetime_show_format;
	global $db_type, $db_name, $db_host, $db_port, $db_user, $db_password, $db_persistent;
	global $site_id, $db_type;
	
	if(get_setting_value($page_settings, $block_name . "_column_hide", 0)) {
		return;
	}

	$user_id = get_session("session_user_id");		
	$user_info = get_session("session_user_info");
	$user_type_id = get_setting_value($user_info, "user_type_id", "");	
	$friendly_urls = get_setting_value($settings, "friendly_urls", 0);
	$friendly_extension = get_setting_value($settings, "friendly_extension", "");
	
	// additional connection to get forum details
	$db2 = new VA_SQL();
	$db2->DBType      = $db_type;
	$db2->DBDatabase  = $db_name;
	$db2->DBHost      = $db_host;
	$db2->DBPort      = $db_port;
	$db2->DBUser      = $db_user;
	$db2->DBPassword  = $db_password;
	$db2->DBPersistent= $db_persistent;	

	$t->set_file("block_body", "block_forum_latest.html");
	$t->set_var("latest_rows", "");
	$t->set_var("latest_cols", "");

	$sql  = " SELECT f.thread_id, f.topic, f.replies, f.friendly_url, f.thread_updated, f.forum_id, ";
	$sql .= " fl.allowed_view_topic, fl.view_topic_types_all ";
	$sql .= " FROM ((";
	if (isset($site_id)) {
		$sql .= "(";	
	}
	if (strlen($user_id)) {
		$sql .= "((";
	}
	$sql .= $table_prefix . "forum  f ";
	$sql .= " INNER JOIN " . $table_prefix . "forum_list fl ON  fl.forum_id=f.forum_id)";
	$sql .= " INNER JOIN " . $table_prefix . "forum_categories fc ON  fc.category_id=fl.category_id)";
	if (isset($site_id))  {
		$sql .= " LEFT JOIN " . $table_prefix . "forum_categories_sites fcs ON fcs.category_id=fl.category_id)";
	}
	if (strlen($user_id)) {
		$sql .= " LEFT JOIN " . $table_prefix . "forum_view_types view_forum ON view_forum.forum_id=fl.forum_id)";
		$sql .= " LEFT JOIN " . $table_prefix . "forum_view_topics view_topics ON view_topics.forum_id=fl.forum_id)";
	}
	if (isset($site_id))  {
		$sql .= " WHERE (fc.sites_all=1 OR fcs.site_id=". $db->tosql($site_id, INTEGER, true, false) . ") ";
	} else {
		$sql .= " WHERE fc.sites_all=1 ";					
	}			
	if (strlen($user_id)) {
		$sql .= " AND ( fl.allowed_view = 1 OR ( fl.allowed_view = 2  AND ( view_forum.user_type_id=". $db->tosql($user_type_id , INTEGER) . " OR fl.view_forum_types_all=1) ) )";
		$sql .= " AND ( fl.allowed_view_topics = 1 OR ( fl.allowed_view_topics = 2  AND ( view_topics.user_type_id=". $db->tosql($user_type_id , INTEGER) . " OR fl.view_topics_types_all=1) ) )";
	} else {
		$sql .= " AND fl.allowed_view=1 AND fl.allowed_view_topics=1 ";
	}
	if ($db_type == "access" || $db_type == "db2"  || $db_type == "postgre") {
		$sql .= " GROUP BY f.thread_id, f.topic, f.replies, f.friendly_url, f.thread_updated, f.forum_id, ";
		$sql .= " fl.allowed_view_topic, fl.view_topic_types_all ";
	} else {
		$sql .= " GROUP BY f.thread_id ";
	}	
	$sql .= " ORDER BY f.thread_updated DESC ";
	
	$records_per_page = get_setting_value($page_settings, "forum_latest_recs", 10);
	$db->RecordsPerPage = $records_per_page;
	$db->PageNumber = 1;
	$db->query($sql);
	$topic_is_blocked = array();
	if($db->next_record())
	{
		$latest_columns = get_setting_value($page_settings, "forum_latest_cols", 1);
		$t->set_var("latest_column", (100 / $latest_columns) . "%");
		$latest_number = 0;
		do
		{
			$latest_number++;
			$thread_id = $db->f("thread_id");
			$topic_title = get_translation($db->f("topic"));
			$friendly_url = $db->f("friendly_url");
			$replies = $db->f("replies");
			
			// check topic view privileges + results caching
			$forum_id = $db->f("forum_id");
			if (!isset($topic_is_blocked[$forum_id])) {
				$topic_is_blocked[$forum_id] = true;			
				if ($db->f("allowed_view_topic")==1) {
					$topic_is_blocked[$forum_id] =false;
				} elseif (strlen($user_id) && $db->f("allowed_view_topic")==2) {
					if ($db->f("view_topic_types_all")) {
						$topic_is_blocked[$forum_id] = false;
					} else {					
						$sql  = " SELECT user_type_id FROM " . $table_prefix . "forum_view_topic ";
						$sql .= " WHERE forum_id=" . $db->tosql($forum_id, INTEGER);
						$sql .= " AND user_type_id=" . $db->tosql($user_type_id, INTEGER);
						$db2->query($sql);
						if($db2->next_record())
							$topic_is_blocked[$forum_id] = false;					
					}
				}				
			}

			if ($friendly_urls && $friendly_url) {
				$t->set_var("forum_topic_url", $friendly_url . $friendly_extension);
				$forum_thread_page_url = $friendly_url . $friendly_extension . "?page=";
			} else {
				$t->set_var("forum_topic_url", "forum_topic.php?thread_id=" . $thread_id);
				$forum_thread_page_url = "forum_topic.php?thread_id=" . $thread_id . "&page=";
			}
			
			if ($topic_is_blocked[$forum_id]) {
				$t->sparse('block_topic', false);
			} else {
				$t->set_var("block_topic", "");
			}
		
			$t->set_var("thread_id", $thread_id);
			$t->set_var("topic_title", $topic_title);

			$latest_updated = $db->f("thread_updated", DATETIME);
			$t->set_var("latest_updated", va_date($datetime_show_format, $latest_updated));

			// check if need to show pages number 
			$topic_recs = 25;
			if ($replies > $topic_recs) {
				$t->set_var("latest_topic_pages", "");
				$total_pages = ceil($replies / $topic_recs);
				if ($total_pages > 5) {
					$start_page = $total_pages - 2;
					$t->set_var("forum_topic_page_url", $forum_thread_page_url . "2");
					$t->set_var("page_number", "&nbsp;...");
					$t->sparse("latest_topic_pages", true);
				} else {
					$start_page = 2;
				}
				for ($p = $start_page; $p <= $total_pages; $p++) {
					$t->set_var("forum_topic_page_url", $forum_thread_page_url . $p);
					$t->set_var("page_number", "&nbsp;".$p);
					$t->sparse("latest_topic_pages", true);
				}
				$t->sparse("latest_topic_pages_block", false);
			} else {
				$t->set_var("latest_topic_pages_block", "");
			}


			$t->parse("latest_cols");
			if($latest_number % $latest_columns == 0)
			{
				$t->parse("latest_rows");
				$t->set_var("latest_cols", "");
			}
			
		} while ($db->next_record());              	

		if ($latest_number % $latest_columns != 0) {
			$t->parse("latest_rows");
		}

		$t->parse("block_body", false);
		$t->parse($block_name, true);
	}

}

?>