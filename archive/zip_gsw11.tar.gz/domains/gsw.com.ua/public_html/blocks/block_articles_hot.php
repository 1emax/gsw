<?php

function articles_hot($block_name, $top_id, $top_name = "", $list_fields = "", $articles_order_column = "", $articles_order_direction = "", $current_category_id = 0, $page_friendly_url = "", $page_friendly_params = array())
{
	global $t, $db, $db_type, $table_prefix;
	global $settings, $page_settings, $restrict_articles_images;
	global $datetime_show_format;
	global $current_page;
	global $site_id;
	
	$user_id = get_session("session_user_id");		
	$user_info = get_session("session_user_info");
	$user_type_id = get_setting_value($user_info, "user_type_id", "");

	if(get_setting_value($page_settings, $block_name . "_column_hide", 0)) {
		return;
	}

	if (!strlen($top_name)) {
		$sql  = " SELECT ac.category_name, ac.article_list_fields, ac.articles_order_column, ac.articles_order_direction FROM ";
		if (isset($site_id)) {
			$sql .= "(";
		}
		if (strlen($user_id)) {
			$sql .= "(";
		}
		$sql .= $table_prefix . "articles_categories ac ";
		if (isset($site_id)) {
			$sql .= " LEFT JOIN " . $table_prefix . "articles_categories_sites acs ON acs.category_id=ac.category_id)";				
		}
		if (strlen($user_id)) {
			$sql .= " LEFT JOIN " . $table_prefix . "articles_categories_types ut ON ut.category_id=ac.category_id)";			
		}		
		$sql .= " WHERE ac.category_id=" . $db->tosql($top_id, INTEGER);			
		if (isset($site_id))  {
			$sql .= " AND (ac.sites_all=1 OR acs.site_id=". $db->tosql($site_id, INTEGER, true, false) . ") ";
		} else {
			$sql .= " AND ac.sites_all=1 ";					
		}		
		if (strlen($user_id)) {
			$sql .= " AND ( ac.user_types_all=1 OR ut.user_type_id=". $db->tosql($user_type_id , INTEGER) . " )";
		} else {
			$sql .= " AND ac.user_types_all=1 ";
		}
				
		$db->query($sql);
		if ($db->next_record()) {
			$top_name = get_translation($db->f("category_name"));
			$articles_order_column = $db->f("articles_order_column");
			$articles_order_direction = $db->f("articles_order_direction");
			$list_fields = $db->f("article_list_fields");
		} else {
			return false;
		}
	}

	if (strlen($articles_order_column)) {
		$articles_order = " ORDER BY a." . $articles_order_column . " " . $articles_order_direction;
	} else {
		$articles_order_column = "article_order";
		$articles_order = " ORDER BY a.article_order ";
	}

	$friendly_urls = get_setting_value($settings, "friendly_urls", 0);
	$friendly_extension = get_setting_value($settings, "friendly_extension", "");

	if ($friendly_urls && $page_friendly_url) {
		$pass_parameters = get_transfer_params($page_friendly_params);
		$current_page = $page_friendly_url . $friendly_extension;
	} else {
		$pass_parameters = get_transfer_params();
	}

	$t->set_file("block_body", "block_hot.html");
	$t->set_var("hot_rows", "");
	$t->set_var("hot_cols", "");
	$t->set_var("top_category_name",$top_name);

	if ($current_category_id > 0)	{
		$sql  = " SELECT category_path FROM " . $table_prefix . "articles_categories ";
		$sql .= " WHERE category_id=" . $db->tosql($current_category_id, INTEGER);
		$current_category_path = get_db_value($sql);
		$current_category_path .= $current_category_id . ",";
	} else {
		$current_category_path = "0," . $top_id . ",";
		$current_category_id = $top_id;
	}

	// set up variables for navigator
	$total_records = 0;
	$sql  = " SELECT a.article_id ";
	$sql .= " FROM (((";
	if (isset($site_id)) {
		$sql .= "(";
	}
	if (strlen($user_id)) {
		$sql .= "(";
	}
	$sql .=  $table_prefix . "articles a ";
	$sql .= " LEFT JOIN " . $table_prefix . "articles_statuses st ON a.status_id=st.status_id)";
	$sql .= " LEFT JOIN " . $table_prefix . "articles_assigned aa ON a.article_id=aa.article_id)";
	$sql .= " LEFT JOIN " . $table_prefix . "articles_categories ac ON aa.category_id=ac.category_id)";
	if (isset($site_id))  {
		$sql .= " LEFT JOIN " . $table_prefix . "articles_categories_sites acs ON acs.category_id=ac.category_id)";
	}
	if (strlen($user_id)) {
		$sql .= " LEFT JOIN " . $table_prefix . "articles_categories_types ut ON ut.category_id=ac.category_id)";
	}		
	if (isset($site_id)) {
		$sql .= " WHERE (ac.sites_all=1 OR acs.site_id=". $db->tosql($site_id, INTEGER, true, false) . ") ";
	} else {
		$sql .= " WHERE ac.sites_all=1 ";					
	}	
	if (strlen($user_id)) {
		$sql .= " AND ( ac.user_types_all=1 OR ut.user_type_id=". $db->tosql($user_type_id , INTEGER) . " )";
	} else {
		$sql .= " AND ac.user_types_all=1 ";
	}
	$sql .= " AND (aa.category_id = " . $db->tosql($current_category_id, INTEGER);
	$sql .= " OR ac.category_path LIKE '" . $db->tosql($current_category_path, TEXT, false) . "%')";
	$sql .= " AND a.is_hot=1 AND st.allowed_view=1 ";
	$sql .= " GROUP BY a.article_id ";

	$db->query($sql);
	while($db->next_record()) {
		$total_records++;
	}
	$records_per_page = get_setting_value($page_settings, "a_hot_recs_" . $top_id, 10);
	$pages_number = 5;
	$n = new VA_Navigator($settings["templates_dir"], "navigator.html", $current_page);
	$page_number = $n->set_navigator("hot_navigator", "hot_page", SIMPLE, $pages_number, $records_per_page, $total_records, false, $pass_parameters);
	if ($db->DBType == "db2"){
		$sql  = " SELECT a.article_id, a.article_title, a.friendly_url, a.article_date, a.short_description, ";
		$sql .= " a.image_small, a.image_small_alt, a.hot_description, a.is_remote_rss, a.details_remote_url ";
		$sql .= " FROM " . $table_prefix . "articles a, (SELECT a.article_id as id, a.article_date";
		$sql .= " FROM " . $table_prefix . "articles a ";
		$sql .= " , " . $table_prefix . "articles_statuses st ";
		$sql .= " , " . $table_prefix . "articles_assigned aa ";
		$sql .= " , " . $table_prefix . "articles_categories ac ";
		
		$sql_where = " WHERE a.status_id=st.status_id AND a.article_id=aa.article_id AND aa.category_id=ac.category_id ";		
				
		if (isset($site_id)) {
			$sql .= " LEFT JOIN " . $table_prefix . "articles_categories_sites acs ON acs.category_id=ac.category_id ";
			$sql_where .= " AND (ac.sites_all=1 OR acs.site_id=". $db->tosql($site_id, INTEGER, true, false) . ") ";
		} else {
			$sql_where .= " AND ac.sites_all=1 ";					
		}		
		if (strlen($user_id)) {
			$sql .= " LEFT JOIN " . $table_prefix . "articles_categories_types AS ut ON ut.category_id=ac.category_id ";
			$sql_where .= " AND ( ac.user_types_all=1 OR ut.user_type_id=". $db->tosql($user_type_id , INTEGER) . " )";
		} else {
			$sql_where .= " AND ac.user_types_all=1 ";
		}
		$sql_where .= " AND (aa.category_id = " . $db->tosql($current_category_id, INTEGER);
		$sql_where .= " OR ac.category_path LIKE '" . $db->tosql($current_category_path, TEXT, false) . "%')";
		$sql_where .= " AND a.is_hot=1 AND st.allowed_view=1 ";		
		$sql .= $sql_where . " GROUP BY a.article_id, a.article_date";
		
		$sql .= $articles_order;
		$sql .= ") as articles WHERE articles.id = a.article_id";
	} elseif ($db->DBType == "postgre"){
		$sql  = " SELECT a.article_id, a.article_title, a.friendly_url, a.article_date, a.short_description, ";
		$sql .= " a.image_small, a.image_small_alt, a.hot_description, a.is_remote_rss, a.details_remote_url ";
		$sql .= " FROM " . $table_prefix . "articles a ";
		$sql .= " , " . $table_prefix . "articles_statuses st ";
		$sql .= " , " . $table_prefix . "articles_assigned aa ";
		$sql .= " , " . $table_prefix . "articles_categories ac ";
		
		$sql_where = " WHERE a.status_id=st.status_id AND a.article_id=aa.article_id AND aa.category_id=ac.category_id ";			
		if (isset($site_id)) {
			$sql .= " LEFT JOIN " . $table_prefix . "articles_categories_sites AS acs ON acs.category_id=ac.category_id ";
			$sql_where .= " AND (ac.sites_all=1 OR acs.site_id=". $db->tosql($site_id, INTEGER, true, false) . ") ";
		} else {
			$sql_where .= " AND ac.sites_all=1 ";					
		}
		if (strlen($user_id)) {
			$sql .= " LEFT JOIN " . $table_prefix . "articles_categories_types AS ut ON ut.category_id=ac.category_id ";
			$sql_where .= " AND ( ac.user_types_all=1 OR ut.user_type_id=". $db->tosql($user_type_id , INTEGER) . " )";
		} else {
			$sql_where .= " AND ac.user_types_all=1 ";
		}		
		$sql_where .= " AND (aa.category_id = " . $db->tosql($current_category_id, INTEGER);
		$sql_where .= " OR ac.category_path LIKE '" . $db->tosql($current_category_path, TEXT, false) . "%')";
		$sql_where .= " AND a.is_hot=1 AND st.allowed_view=1 ";
		$sql .= $sql_where . " GROUP BY a.article_id, a.image_small, a.image_small_alt, a.short_description, a.hot_description, a.article_date, a.date_end, a.article_title, a.friendly_url, a.author_name, a.article_order, a.date_added, a.date_updated, a.is_remote_rss, a.details_remote_url ";
		
		$sql .= $articles_order;
	} else {
		$sql  = " SELECT a.article_id, a.article_title, a.friendly_url, a.article_date, a.short_description, ";
		$sql .= " a.image_small, a.image_small_alt, a.hot_description, a.is_remote_rss, a.details_remote_url ";
		$sql .= " FROM (((((" . $table_prefix . "articles a ";
		$sql .= " INNER JOIN " . $table_prefix . "articles_statuses st ON a.status_id=st.status_id)";
		$sql .= " INNER JOIN " . $table_prefix . "articles_assigned aa ON a.article_id=aa.article_id)";
		$sql .= " INNER JOIN " . $table_prefix . "articles_categories ac ON aa.category_id=ac.category_id)";
		$sql_where = " WHERE a.is_hot=1 AND st.allowed_view=1 ";
		if (isset($site_id)) {
			$sql .= " LEFT JOIN " . $table_prefix . "articles_categories_sites AS acs ON acs.category_id=ac.category_id) ";
			$sql_where .= " AND (ac.sites_all=1 OR acs.site_id=". $db->tosql($site_id, INTEGER, true, false) . ") ";
		} else {
			$sql .= " ) ";
			$sql_where .= " AND ac.sites_all=1 ";					
		}
		if (strlen($user_id)) {
			$sql .= " LEFT JOIN " . $table_prefix . "articles_categories_types AS ut ON ut.category_id=ac.category_id) ";
			$sql_where .= " AND ( ac.user_types_all=1 OR ut.user_type_id=". $db->tosql($user_type_id , INTEGER) . " )";
		} else {
			$sql .= " ) ";
			$sql_where .= " AND ac.user_types_all=1 ";
		}
		$sql_where .= " AND (aa.category_id = " . $db->tosql($current_category_id, INTEGER);
		$sql_where .= " OR ac.category_path LIKE '" . $db->tosql($current_category_path, TEXT, false) . "%')";
		$sql .= $sql_where . " GROUP BY a.article_id, a.image_small, a.image_small_alt, a.short_description, a.hot_description, a.article_date, a.date_end, a.article_title, a.friendly_url, a.author_name, a.article_order, a.date_added, a.date_updated, a.is_remote_rss, a.details_remote_url ";
		
		$sql .= $articles_order;
	}

	$db->RecordsPerPage = $records_per_page;
	$db->PageNumber = $page_number;
	$db->query($sql);
	if($db->next_record())
	{
		$hot_columns = get_setting_value($page_settings, "a_hot_cols_" . $top_id, 1);
		$t->set_var("hot_column", (100 / $hot_columns) . "%");
		$hot_number = 0;
		do
		{
			$hot_number++;
			$article_id = $db->f("article_id");
			$article_title = get_translation($db->f("article_title"));
			$friendly_url = $db->f("friendly_url");
			$is_remote_rss = $db->f("is_remote_rss");
			$details_remote_url = $db->f("details_remote_url");
			$image_small = $db->f("image_small");
			$image_small_alt = $db->f("image_small_alt");
			$hot_description = get_translation($db->f("hot_description"));
			if (!strlen($hot_description)) {
				$hot_description = get_translation($db->f("short_description"));
			}
			if ($is_remote_rss == 0){
				if ($friendly_urls && $friendly_url) {
					$t->set_var("details_href", $friendly_url . $friendly_extension);
				} else {
					$t->set_var("details_href", "article.php?article_id=" . $article_id);
				}
			} else {
				$t->set_var("details_href", $details_remote_url);
			}

			$t->set_var("article_id", $article_id);
			$t->set_var("hot_item_name", $article_title);
			$t->set_var("hot_description", $hot_description);

			if (strpos(",," . $list_fields . ",,", ",article_date,")) {
				$article_date = $db->f("article_date", DATETIME);
				$article_date_string  = va_date($datetime_show_format, $article_date);
				$t->set_var("article_date", $article_date_string);
				$t->global_parse("article_date_block", false, false, true);
			} else {
				$t->set_var("article_date_block", "");
			}

			if($image_small)
			{
				if (preg_match("/^http\:\/\//", $image_small)) {
					$image_size = "";
				} else {
	        $image_size = @GetImageSize($image_small);
					if (isset($restrict_articles_images) && $restrict_articles_images) { $image_small = "image_show.php?article_id=".$article_id."&type=small"; }
				}
				if (!strlen($image_small_alt)) { $image_small_alt = $article_title; }
        $t->set_var("alt", htmlspecialchars($image_small_alt));
        $t->set_var("src", htmlspecialchars($image_small));
				if(is_array($image_size))
				{
	        $t->set_var("width", "width=\"" . $image_size[0] . "\"");
  	      $t->set_var("height", "height=\"" . $image_size[1] . "\"");
				}
				else
				{
	        $t->set_var("width", "");
  	      $t->set_var("height", "");
				}
				$t->parse("image_small", false);
			}
			else
			{
				$t->set_var("image_small", "");
			}

			$t->parse("hot_cols");
			if($hot_number % $hot_columns == 0)
			{
				$t->parse("hot_rows");
				$t->set_var("hot_cols", "");
			}

		} while ($db->next_record());

		if ($hot_number % $hot_columns != 0) {
			$t->parse("hot_rows");
		}

		$t->parse("block_body", false);
		$t->parse($block_name, true);
	}

}

?>