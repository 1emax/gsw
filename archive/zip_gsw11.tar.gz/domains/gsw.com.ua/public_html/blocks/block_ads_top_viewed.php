<?php

function ads_top_viewed($block_name)
{
	global $t, $db, $table_prefix;
	global $settings, $page_settings, $language_code;
	global $site_id, $db_type;

	if(get_setting_value($page_settings, $block_name . "_column_hide", 0)) {
		return;
	}

	$friendly_urls = get_setting_value($settings, "friendly_urls", 0);
	$friendly_extension = get_setting_value($settings, "friendly_extension", "");

	$t->set_file("block_body", "block_ads_top_viewed.html");
	$t->set_var("top_viewed_rows", "");
	$t->set_var("top_viewed_rows", "");

	$sql  = " SELECT i.item_id, i.item_title, i.friendly_url, i.total_views, i.short_description ";
	if (isset($site_id))  {
		$sql .= " FROM (((" . $table_prefix . "ads_items i ";
	} else {
		$sql .= " FROM ((" . $table_prefix . "ads_items i ";
	}	
	$sql .= " LEFT JOIN " . $table_prefix . "ads_assigned aac ON aac.item_id=i.item_id) ";
	$sql .= " LEFT JOIN " . $table_prefix . "ads_categories ac ON ac.category_id=aac.category_id) ";				
	if (isset($site_id))  {
		$sql .= " LEFT JOIN " . $table_prefix . "ads_categories_sites acs ON acs.category_id=ac.category_id)";
		$sql .= " WHERE (ac.sites_all=1 OR acs.site_id=". $db->tosql($site_id, INTEGER, true, false) . ")";
	} else {
		$sql .= " WHERE ac.sites_all=1 ";					
	}		
	
	$sql .= " AND i.is_approved=1 ";
	$sql .= " AND i.date_start<=" . $db->tosql(va_time(), DATETIME);
	$sql .= " AND i.date_end>" . $db->tosql(va_time(), DATETIME);
	
	if ($db_type == "access" || $db_type == "db2"  || $db_type == "postgre") {
		$sql .= " GROUP BY i.item_id, i.item_title, i.friendly_url, i.total_views, i.short_description,i.date_start ";
	} else {
		$sql .= " GROUP BY i.item_id ";
	}	
	
	$sql .= " ORDER BY i.total_views DESC, i.date_start DESC, i.item_title ";
	
	$records_per_page = get_setting_value($page_settings, "ads_top_viewed_recs", 10);
	$db->RecordsPerPage = $records_per_page;
	$db->PageNumber = 1;
	$db->query($sql);
	if($db->next_record())
	{
		$top_columns = get_setting_value($page_settings, "ads_top_viewed_cols", 1);
		$t->set_var("top_viewed_column", (100 / $top_columns) . "%");
		$top_number = 0;
		do
		{
			$top_number++;
			$item_id = $db->f("item_id");
			$item_title = get_translation($db->f("item_title"));
			$friendly_url = $db->f("friendly_url");
			$total_views = $db->f("total_views");
			$short_description = get_translation($db->f("short_description"));
			if ($friendly_urls && $friendly_url) {
				$t->set_var("ads_details_url", $friendly_url . $friendly_extension);
			} else {
				$t->set_var("ads_details_url", "ads_details.php?item_id=" . $item_id);
			}
		
			$t->set_var("top_position", $top_number);
			$t->set_var("item_id", $item_id);
			$t->set_var("item_title", $item_title);
			$t->set_var("total_views", $total_views);
			$t->set_var("short_description", $short_description);

			$t->parse("top_viewed_cols");
			if($top_number % $top_columns == 0)
			{
				$t->parse("top_viewed_rows");
				$t->set_var("top_viewed_cols", "");
			}
			
		} while ($db->next_record());              	

		if ($top_number % $top_columns != 0) {
			$t->parse("top_viewed_rows");
		}

		$t->parse("block_body", false);
		$t->parse($block_name, true);
	}

}

?>