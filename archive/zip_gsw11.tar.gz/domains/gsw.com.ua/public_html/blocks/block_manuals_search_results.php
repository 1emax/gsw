<?php

function manuals_search_results($block_name) {
	global $t, $db, $table_prefix;
	global $site_id, $db_type;
	global $settings;

	// Global friendly url settings
	$friendly_urls = get_setting_value($settings, "friendly_urls", 0);
	$friendly_extension = get_setting_value($settings, "friendly_extension", "");

	$search_string = get_param("manuals_search");
	$manual_id = intval(get_param("manual_id"));
	$t->set_file("block_body", "block_manuals_search_results.html");
	
	$manuals_search_href  = "manuals_search.php";
	$article_details_href = "manuals_article_details.php";
	
	$n = new VA_Navigator($settings["templates_dir"], "navigator.html", $manuals_search_href);
	$n->set_parameters(false, true, false);
	
	if ($search_string != "") {
		$sql_where  = " WHERE ma.manual_id = ml.manual_id ";				
		$search_string_sql = "'%".$db->tosql($search_string, TEXT, false) ."%'";
		$sql_where .= " AND ( ma.article_title LIKE " . $search_string_sql ;	
		$sql_where .= " OR ma.short_description LIKE " . $search_string_sql ;	
		$sql_where .= " OR ma.full_description LIKE " . $search_string_sql ;
		$sql_where .= " ) ";			
		if ($manual_id != 0) {
			$sql_where .= " AND ma.manual_id = ";
			$sql_where .= $db->tosql($manual_id, INTEGER);
		}
		$sql_where .= " AND ml.allowed_view = 1 AND ma.allowed_view = 1 AND mc.allowed_view=1 ";		
		if (isset($site_id))  {
			$sql_where .= " AND (mc.sites_all=1 OR mcs.site_id=". $db->tosql($site_id, INTEGER, true, false) . ") ";
		} else {
			$sql_where .= " AND mc.sites_all=1 ";					
		}		
		
		$counter = 0;
		$sql  = " SELECT COUNT(*) ";
		$sql .= " FROM (((" . $table_prefix . "manuals_articles ma ";
		$sql .= " INNER JOIN " . $table_prefix . "manuals_list ml ON ml.manual_id = ma.manual_id)";
		$sql .= " INNER JOIN " . $table_prefix . "manuals_categories mc ON mc.category_id = ml.category_id)";
		if (isset($site_id))  {
			$sql .= " LEFT JOIN " . $table_prefix . "manuals_categories_sites mcs ON mcs.category_id=mc.category_id)";
		} else {
			$sql .= ")";
		}		
		$sql .= $sql_where;
		
		// set up variables for navigator
		$db->query($sql);

		if ($db->next_record()) {
			$counter = $db->f(0);
		}
		
		$pass_parameters["manuals_search"] = $search_string;
		if ($manual_id) {
			$pass_parameters["manual_id"] = $manual_id;
		}
		$total_records = $db->f(0);
		$records_per_page = 25;
		$pages_number = 10;
		$page_number = $n->set_navigator("navigator", "page", CENTERED, $pages_number, $records_per_page, $total_records, false, $pass_parameters);
		
		$sql  = " SELECT ma.article_id, ma.article_title, ma.manual_id, ma.short_description, ma.friendly_url, ma.section_number,";
		$sql .= " ml.manual_id, ml.allowed_view ";
		$sql .= " FROM (((" . $table_prefix . "manuals_articles ma ";
		$sql .= " INNER JOIN " . $table_prefix . "manuals_list ml ON ml.manual_id = ma.manual_id)";
		$sql .= " INNER JOIN " . $table_prefix . "manuals_categories mc ON mc.category_id = ml.category_id)";
		if (isset($site_id))  {
			$sql .= " LEFT JOIN " . $table_prefix . "manuals_categories_sites mcs ON mcs.category_id=mc.category_id)";
		} else {
			$sql .= ")";
		}		
		$sql .= $sql_where;
		if (isset($site_id))  {
			$sql .= " GROUP BY ma.article_id,ml.manual_id,mc.category_id";
			if ($db_type == "access" || $db_type == "db2"  || $db_type == "postgre") {				
				$sql .= " GROUP BY ma.article_id,ml.manual_id,mc.category_id,ma.manual_id,ml.category_id,ma.article_title,ma.short_description,ma.friendly_url,ma.section_number,ml.allowed_view ";
			} else {
				$sql .= " GROUP BY ma.article_id,ml.manual_id,mc.category_id";
			}
		}

		function bi($matches) { 
		  	return str_replace($matches[1], "<b>" . $matches[1] . "</b>", $matches[0]);
		}

		$db->RecordsPerPage = $records_per_page;
		$db->PageNumber = $page_number;
		$db->query($sql);
		if ($db->next_record()) {
			//$counter = 0;
			do {
				//$counter++;
				$article_id = $db->f("article_id");
				$section_number = $db->f("section_number");
				$t->set_var("article_title", $db->f("article_title"));
				$t->set_var("short_description",preg_replace_callback("/[^a-zA-Z]($search_string)[^a-zA-Z]/i", "bi", $db->f("short_description")));
				$friendly_url = $db->f("friendly_url");

				if ($friendly_urls && $friendly_url != "") {
					$article_href = $friendly_url . $friendly_extension;
				} else {
					$article_href = $article_details_href."?article_id=".$article_id;
				}

				//$article_href .= "&highlight=".$search_string;
				$t->set_var("section_number", $section_number);
				$t->set_var("article_href", $article_href);
				//$t->set_var("counter", ($page_number - 1)*$records_per_page + $counter);
				$t->parse("record", true);
			} while ($db->next_record());
			$found_message = str_replace("{results_number}", $counter, MANUALS_SEARCH_RESULTS_INFO);
			$found_message = str_replace("{search_string}", $search_string, $found_message);

			$t->set_var("found_message", $found_message);
			$t->set_var("search_string", $search_string);
			$t->parse("results_number_block", false);
		} else {
			$not_found_message = str_replace("{search_string}", $search_string, MANUALS_NOT_FOUND_ANYTHING);

			$t->set_var("not_found_message", $not_found_message);
			$t->set_var("results_number_block", "");
			$t->set_var("search_string", $search_string);
			$t->parse("no_results", false);
		}
	}
	
	$t->parse("block_body", false);
	$t->parse($block_name, true);
}
?> 