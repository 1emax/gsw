<?php

function manufacturers($block_name)
{
	global $t, $db, $db_type, $site_id, $table_prefix;
	global $settings, $page_settings, $language_code;

	if (get_setting_value($page_settings, $block_name . "_column_hide", 0)) {
		return;
	}
	
	$user_id = get_session("session_user_id");
	$user_type_id = get_session("session_user_type_id");

	$friendly_urls = get_setting_value($settings, "friendly_urls", 0);
	$friendly_extension = get_setting_value($settings, "friendly_extension", "");
	
	$manufacturers_selection = get_setting_value($page_settings, "manufacturers_selection", 1);
	$manufacturers_image     = get_setting_value($page_settings, "manufacturers_image", 1);
	$manufacturers_desc      = get_setting_value($page_settings, "manufacturers_desc", 1);
	$manufacturers_order     = get_setting_value($page_settings, "manufacturers_order", 1);
	$manufacturers_direction = get_setting_value($page_settings, "manufacturers_direction", 1);
	
	
	$category_id = get_param("category_id");
	$search_category_id = get_param("search_category_id");
	$manf = get_param("manf");
	if ($search_category_id) { $category_id = $search_category_id; }

	$t->set_file("block_body", "block_manufacturers.html");
	$t->set_var("products_href", get_custom_friendly_url("products.php"));
	$t->set_var("category_id", htmlspecialchars($category_id));

	$list_page = get_custom_friendly_url("products.php");
	$manf_url = new VA_URL($list_page);
	$manf_url->add_parameter("category_id", CONSTANT, $category_id);

	$search_tree = new VA_Tree("category_id", "category_name", "parent_category_id", $table_prefix . "categories", "tree", TOP_CATEGORY_MSG);

	$manufacturers = array();
	$sql  = " SELECT i.manufacturer_id, COUNT(*) AS manufacturer_products FROM ";
	if ($category_id > 0) {
		$sql .= "((";
	}
	$sql .= $table_prefix . "items i ";
	if ($category_id > 0) {
		$sql .=	" INNER JOIN " . $table_prefix . "items_categories ic ON ic.item_id=i.item_id) ";
		$sql .=	" INNER JOIN " . $table_prefix . "categories c ON ic.category_id=c.category_id) ";
	}
	$sql .= " WHERE i.is_showing=1 AND i.is_approved=1 AND manufacturer_id IS NOT NULL ";
	$sql .= " AND ((i.hide_out_of_stock=1 AND i.stock_level > 0) OR i.hide_out_of_stock=0 OR i.hide_out_of_stock IS NULL)";
	$sql .= " AND (i.language_code IS NULL OR i.language_code='' OR i.language_code=" . $db->tosql($language_code, TEXT) . ")";
	if ($category_id > 0) {
		$sql .= " AND (c.category_id=" . $db->tosql($category_id, INTEGER);
		$sql .= " OR c.category_path LIKE '%" . $db->tosql($search_tree->get_path($category_id), TEXT, false) . "%')";
	}
	$sql .= " AND i.sites_all=1 AND i.user_types_all=1";	
	$sql .= " GROUP BY i.manufacturer_id ";
	$db->query($sql);
	while ($db->next_record()) {
		$manufacturer_id = $db->f("manufacturer_id");
		$manufacturer_products = $db->f("manufacturer_products");
		$manufacturers[$manufacturer_id] = $manufacturer_products;
	}	
	if (isset($site_id)) {
		$sql  = " SELECT i.manufacturer_id, COUNT(*) AS manufacturer_products FROM (";
		if ($category_id > 0) {
			$sql .= "((";
		}
		$sql .= $table_prefix . "items i ";
		if ($category_id > 0) {
			$sql .=	" INNER JOIN " . $table_prefix . "items_categories ic ON ic.item_id=i.item_id) ";
			$sql .=	" INNER JOIN " . $table_prefix . "categories c ON ic.category_id=c.category_id) ";
		}
		$sql .= " LEFT JOIN " . $table_prefix . "items_sites s ON s.item_id = i.item_id) ";		
		$sql .= " WHERE i.is_showing=1 AND i.is_approved=1 AND manufacturer_id IS NOT NULL ";
		$sql .= " AND ((i.hide_out_of_stock=1 AND i.stock_level > 0) OR i.hide_out_of_stock=0 OR i.hide_out_of_stock IS NULL)";
		$sql .= " AND (i.language_code IS NULL OR i.language_code='' OR i.language_code=" . $db->tosql($language_code, TEXT) . ")";
		if ($category_id > 0) {
			$sql .= " AND (c.category_id=" . $db->tosql($category_id, INTEGER);
			$sql .= " OR c.category_path LIKE '%" . $db->tosql($search_tree->get_path($category_id), TEXT, false) . "%')";
		}
		$sql .= " AND i.user_types_all=1 AND i.sites_all=0 AND s.site_id=" . $db->tosql($site_id, INTEGER, true, false);
		$sql .= " GROUP BY i.manufacturer_id ";
		$db->query($sql);	
		while ($db->next_record()) {
			$manufacturer_id = $db->f("manufacturer_id");
			$manufacturer_products = $db->f("manufacturer_products");
			if (isset($manufacturers[$manufacturer_id])) {
				$manufacturers[$manufacturer_id] += $manufacturer_products;
			} else {
				$manufacturers[$manufacturer_id]  = $manufacturer_products;
			}
		}
	}
	if (strlen($user_id)) {
		$sql  = " SELECT i.manufacturer_id, COUNT(*) AS manufacturer_products FROM (";
		if ($category_id > 0) {
			$sql .= "((";
		}
		$sql .= $table_prefix . "items i ";
		if ($category_id > 0) {
			$sql .=	" INNER JOIN " . $table_prefix . "items_categories ic ON ic.item_id=i.item_id) ";
			$sql .=	" INNER JOIN " . $table_prefix . "categories c ON ic.category_id=c.category_id) ";
		}
		$sql .= " LEFT JOIN " . $table_prefix . "items_user_types ut ON ut.item_id=i.item_id) ";		
		$sql .= " WHERE i.is_showing=1 AND i.is_approved=1 AND manufacturer_id IS NOT NULL ";
		$sql .= " AND ((i.hide_out_of_stock=1 AND i.stock_level > 0) OR i.hide_out_of_stock=0 OR i.hide_out_of_stock IS NULL)";
		$sql .= " AND (i.language_code IS NULL OR i.language_code='' OR i.language_code=" . $db->tosql($language_code, TEXT) . ")";
		if ($category_id > 0) {
			$sql .= " AND (c.category_id=" . $db->tosql($category_id, INTEGER);
			$sql .= " OR c.category_path LIKE '%" . $db->tosql($search_tree->get_path($category_id), TEXT, false) . "%')";
		}
		$sql .= " AND i.sites_all=1 AND i.user_types_all=0 AND ut.user_type_id=". $db->tosql($user_type_id, INTEGER, true. false);
		$sql .= " GROUP BY i.manufacturer_id ";
		$db->query($sql);	
		while ($db->next_record()) {
			$manufacturer_id = $db->f("manufacturer_id");
			$manufacturer_products = $db->f("manufacturer_products");
			if (isset($manufacturers[$manufacturer_id])) {
				$manufacturers[$manufacturer_id] += $manufacturer_products;
			} else {
				$manufacturers[$manufacturer_id]  = $manufacturer_products;
			}
		}		
	}
	if (isset($site_id)&&strlen($user_id)) {
		$sql  = " SELECT i.manufacturer_id, COUNT(*) AS manufacturer_products FROM ((";
		if ($category_id > 0) {
			$sql .= "((";
		}
		$sql .= $table_prefix . "items i ";
		if ($category_id > 0) {
			$sql .=	" INNER JOIN " . $table_prefix . "items_categories ic ON ic.item_id=i.item_id) ";
			$sql .=	" INNER JOIN " . $table_prefix . "categories c ON ic.category_id=c.category_id) ";
		}
		$sql .= " LEFT JOIN " . $table_prefix . "items_sites s ON s.item_id = i.item_id) ";		
		$sql .= " LEFT JOIN " . $table_prefix . "items_user_types ut ON ut.item_id=i.item_id) ";		
		$sql .= " WHERE i.is_showing=1 AND i.is_approved=1 AND manufacturer_id IS NOT NULL ";
		$sql .= " AND ((i.hide_out_of_stock=1 AND i.stock_level > 0) OR i.hide_out_of_stock=0 OR i.hide_out_of_stock IS NULL)";
		$sql .= " AND (i.language_code IS NULL OR i.language_code='' OR i.language_code=" . $db->tosql($language_code, TEXT) . ")";
		if ($category_id > 0) {
			$sql .= " AND (c.category_id=" . $db->tosql($category_id, INTEGER);
			$sql .= " OR c.category_path LIKE '%" . $db->tosql($search_tree->get_path($category_id), TEXT, false) . "%')";
		}
		$sql .= " AND i.sites_all=0 AND i.user_types_all=0 ";
		$sql .= " AND ut.user_type_id=". $db->tosql($user_type_id, INTEGER, true, false);
		$sql .= " AND s.site_id=" . $db->tosql($site_id, INTEGER, true, false);
		$sql .= " GROUP BY i.manufacturer_id ";
		$db->query($sql);	
		while ($db->next_record()) {
			$manufacturer_id = $db->f("manufacturer_id");
			$manufacturer_products = $db->f("manufacturer_products");
			if (isset($manufacturers[$manufacturer_id])) {
				$manufacturers[$manufacturer_id] += $manufacturer_products;
			} else {
				$manufacturers[$manufacturer_id]  = $manufacturer_products;
			}
		}	
	}

	if (sizeof($manufacturers) > 0) {
		$manufacturers_ids = implode(",", array_keys($manufacturers));
		
		$sql_fields = "";
		if ($manufacturers_selection == 1) {		
			if ($manufacturers_desc == 1) {
				$sql_fields .= ", short_description AS description ";
			} elseif ($manufacturers_desc == 2) {
				$sql_fields .= ", full_description AS description ";
			}
			if ($manufacturers_image == 2) {
				$sql_fields .= ", image_small_alt AS image_alt, image_small AS image ";
			} elseif ($manufacturers_image == 3) {
				$sql_fields .= ", image_large_alt AS image_alt, image_large AS image  ";
			}			
		}
		$sql  = " SELECT manufacturer_id, manufacturer_name, friendly_url ";
		$sql .= $sql_fields;
		$sql .=	" FROM " . $table_prefix . "manufacturers  ";
		$sql .= " WHERE manufacturer_id IN (" . $manufacturers_ids . ") ";
		if ($manufacturers_order == 2)
			$sql .= " ORDER BY manufacturer_order ";
		else 
			$sql .= " ORDER BY manufacturer_name ";
		if ($manufacturers_direction == 2) 
			$sql .= " DESC ";
		else
			$sql .= " ASC ";
		$db->query($sql);
		while ($db->next_record()) {
			$manufacturer_id = $db->f("manufacturer_id");
			$manufacturer_name = $db->f("manufacturer_name");
			$friendly_url = $db->f("friendly_url");
			$manufacturer_products = $manufacturers[$manufacturer_id];
			$description = get_translation($db->f("description"));
			$image_alt = get_translation($db->f("image_alt"));
			$image = $db->f("image");
			
			if ($friendly_urls && $friendly_url) {
				$manf_url->remove_parameter("manf");
				$manufacturer_href = $manf_url->get_url($friendly_url. $friendly_extension);
			} else {
				$manf_url->add_parameter("manf", CONSTANT, $manufacturer_id);
				$manufacturer_href = $manf_url->get_url($list_page);
			}

			//$manufacturer_href = "products.php?category_id=" . urlencode($category_id) . "&manf=" . $manufacturer_id;
			$manufacturer_selected = ($manf == $manufacturer_id) ? "selected" : "";

			$t->set_var("manufacturer_id", $manufacturer_id);
			$t->set_var("manufacturer_name", $manufacturer_name);
			$t->set_var("manufacturer_href", $manufacturer_href);
			$t->set_var("manufacturer_selected", $manufacturer_selected);
			$t->set_var("manufacturer_products", $manufacturer_products);
			
			if ($description) {
				$t->set_var("desc_text", $description);
				$t->sparse("desc", false);
			} else {
				$t->set_var("desc", "");
			}
			if ($image) {
				if (preg_match("/^http\:\/\//", $image)) {
					$image_size = "";
				} else {
					$image_size = @GetImageSize($image);					
				}
				if(is_array($image_size)) {
					$t->set_var("width", "width=\"" . $image_size[0] . "\"");
					$t->set_var("height", "height=\"" . $image_size[1] . "\"");
				} else {
					$t->set_var("width", "");
					$t->set_var("height", "");
				}
				$t->set_var("alt", $image_alt);
				$t->set_var("src", $image);
				$t->sparse("image", false);
			} else {
				$t->set_var("image", "");
			}
			
			$t->sparse("manufacturers", true);
			$t->sparse("manufacturers_options", true);			

		}

		if ($manufacturers_selection == 2) {
			$t->sparse("manufacturers_select", false);
		} else {
			$t->sparse("manufacturers_list", false);
		}

		$t->parse("block_body", false);
		$t->parse($block_name, true);
	}
}

?>