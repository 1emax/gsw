<?php

function articles_top_viewed($block_name, $top_id, $top_name)
{
	global $t, $db, $db_type, $table_prefix;
	global $settings, $page_settings;
	global $datetime_show_format;
	global $site_id;
	
	$user_id = get_session("session_user_id");		
	$user_info = get_session("session_user_info");
	$user_type_id = get_setting_value($user_info, "user_type_id", "");

	if(get_setting_value($page_settings, $block_name . "_column_hide", 0)) {
		return;
	}
		
	if (!strlen($top_name)) {
		$sql = $table_prefix . "articles_categories ac ";
		if (isset($site_id)) {
			$sql = " ( " . $sql . " LEFT JOIN " . $table_prefix . "articles_categories_sites acs ON acs.category_id=ac.category_id)";
		}
		if (strlen($user_id)) {
			$sql = " ( " . $sql . " LEFT JOIN " . $table_prefix . "articles_categories_types ut ON ut.category_id=ac.category_id)";
		}		
		$sql  = " SELECT ac.category_name FROM " . $sql;
		$sql .= " WHERE ac.category_id=" . $db->tosql($top_id, INTEGER);	
		if (isset($site_id)) {
			$sql .= " AND (ac.sites_all=1 OR acs.site_id=". $db->tosql($site_id, INTEGER, true, false) . ") ";
		} else {
			$sql .= " AND ac.sites_all=1 ";					
		}
		if (strlen($user_id)) {
			$sql .= " AND ( ac.user_types_all=1 OR ut.user_type_id=". $db->tosql($user_type_id , INTEGER) . " )";
		} else {
			$sql .= " AND ac.user_types_all=1 ";
		}
		
		$db->query($sql);
		if ($db->next_record()) {
			$top_name = get_translation($db->f("category_name"));
		} else {
			return false;
		}
	}
	
	$friendly_urls = get_setting_value($settings, "friendly_urls", 0);
	$friendly_extension = get_setting_value($settings, "friendly_extension", "");

	$t->set_file("block_body", "block_articles_top_viewed.html");
	$t->set_var("top_viewed_rows", "");
	$t->set_var("top_viewed_rows", "");
	$t->set_var("top_category_name",$top_name);
	
	if ($db->DBType != "db2"){
		$sql  = " SELECT a.article_id, a.article_title, a.total_views, a.friendly_url, a.article_date, a.short_description, a.is_remote_rss, a.details_remote_url ";
		$sql .= " FROM " . $table_prefix . "articles a ";
		$sql .= " , " . $table_prefix . "articles_statuses st ";
		$sql .= " , " . $table_prefix . "articles_assigned aa ";
		$sql .= " , " . $table_prefix . "articles_categories ac ";
		
		$sql_where = " WHERE a.status_id=st.status_id AND a.article_id=aa.article_id AND aa.category_id=ac.category_id ";
		
		if (isset($site_id))  {
			$sql .= " LEFT JOIN " . $table_prefix . "articles_categories_sites AS acs ON acs.category_id=ac.category_id";
			$sql_where .= " AND (ac.sites_all=1 OR acs.site_id=". $db->tosql($site_id, INTEGER, true, false) . ") ";
		} else {
			$sql_where .= " AND ac.sites_all=1 ";					
		}
		
		if (strlen($user_id)) {
			$sql .= " LEFT JOIN " . $table_prefix . "articles_categories_types AS ut ON ut.category_id=ac.category_id";
			$sql_where .= " AND ( ac.user_types_all=1 OR ut.user_type_id=". $db->tosql($user_type_id , INTEGER) . " )";
		} else {
			$sql_where .= " AND ac.user_types_all=1 ";
		}			
		$sql_where .= " AND (ac.category_id=" . $db->tosql($top_id, INTEGER);
		$sql_where .= " OR ac.category_path LIKE '0," . $top_id . ",%') ";
		$sql_where .= " AND st.allowed_view=1 ";
				
		$sql .= $sql_where . " GROUP BY a.article_id, a.total_views, a.image_small, a.short_description, a.article_date, a.date_end, a.article_title, a.friendly_url, a.article_order, a.date_added, a.date_updated, a.is_remote_rss, a.details_remote_url ";
		$sql .= " ORDER BY a.total_views DESC, a.article_order, a.article_title ";
	} else {
		$sql  = " SELECT a.article_id, a.article_title, a.total_views, a.friendly_url, a.article_date, a.short_description, a.is_remote_rss, a.details_remote_url ";
		$sql .= " FROM " . $table_prefix . "articles a, ";
		$sql .= " (SELECT a.article_id AS id, a.article_title, a.total_views ";
		$sql .= " FROM " . $table_prefix . "articles a ";
		$sql .= " , " . $table_prefix . "articles_statuses st ";
		$sql .= " , " . $table_prefix . "articles_assigned aa ";
		$sql .= " , " . $table_prefix . "articles_categories ac ";
		
		$sql_where = " WHERE a.status_id=st.status_id AND a.article_id=aa.article_id AND aa.category_id=ac.category_id ";		
		if (isset($site_id))  {
			$sql .= " LEFT JOIN " . $table_prefix . "articles_categories_sites AS acs ON acs.category_id=ac.category_id";
			$sql_where .= " AND (ac.sites_all=1 OR acs.site_id=". $db->tosql($site_id, INTEGER, true, false) . ") ";
		} else {
			$sql_where .= " AND ac.sites_all=1 ";
		}
		if (strlen($user_id)) {
			$sql .= " LEFT JOIN " . $table_prefix . "articles_categories_types AS ut ON ut.category_id=ac.category_id";
			$sql_where .= " AND ( ac.user_types_all=1 OR ut.user_type_id=". $db->tosql($user_type_id , INTEGER) . " )";
		} else {
			$sql_where .= " AND ac.user_types_all=1 ";
		}
		$sql_where .= " AND (ac.category_id=" . $db->tosql($top_id, INTEGER);
		$sql_where .= " OR ac.category_path LIKE '0," . $top_id . ",%') ";
		$sql_where .= " AND st.allowed_view=1 ";
		 
		$sql .= $sql_where . " GROUP BY a.article_id, a.total_views, a.article_date, a.article_title, a.article_order ";
		$sql .= " ORDER BY a.total_views DESC, a.article_order, a.article_title) AS article ";
		$sql .= " WHERE article.id = a.article_id";
	}

	$records_per_page = get_setting_value($page_settings, "a_top_viewed_recs_" . $top_id, 10);
	$db->RecordsPerPage = $records_per_page;
	$db->PageNumber = 1;
	$db->query($sql);
	if($db->next_record())
	{
		$top_columns = get_setting_value($page_settings, "a_top_viewed_cols_" . $top_id, 1);
		$t->set_var("top_viewed_column", (100 / $top_columns) . "%");
		$top_number = 0;
		do
		{
			$top_number++;
			$article_id = $db->f("article_id");
			$article_title = get_translation($db->f("article_title"));
			$friendly_url = $db->f("friendly_url");
			$is_remote_rss = $db->f("is_remote_rss");
			$details_remote_url = $db->f("details_remote_url");
			$total_views = $db->f("total_views");
			$short_description = get_translation($db->f("short_description"));

			if ($is_remote_rss == 0){
				if ($friendly_urls && $friendly_url) {
					$t->set_var("article_url", $friendly_url . $friendly_extension);
				} else {
					$t->set_var("article_url", "article.php?article_id=" . $article_id);
				}
			} else {
				$t->set_var("article_url", $details_remote_url);
			}

			$t->set_var("top_position", $top_number);
			$t->set_var("article_id", $article_id);
			$t->set_var("article_title", $article_title);
			$t->set_var("total_views", $total_views);
			$t->set_var("short_description", $short_description);

			$article_date = $db->f("article_date", DATETIME);
			$article_date_string  = va_date($datetime_show_format, $article_date);
			$t->set_var("article_date", $article_date_string);

			$t->parse("top_viewed_cols");
			if($top_number % $top_columns == 0)
			{
				$t->parse("top_viewed_rows");
				$t->set_var("top_viewed_cols", "");
			}
			
		} while ($db->next_record());              	

		if ($top_number % $top_columns != 0) {
			$t->parse("top_viewed_rows");
		}

		$t->parse("block_body", false);
		$t->parse($block_name, true);
	}

}

?>