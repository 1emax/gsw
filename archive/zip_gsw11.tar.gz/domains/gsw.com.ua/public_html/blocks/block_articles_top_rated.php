<?php

function articles_top_rated($block_name, $top_id, $top_name)
{

	global $t, $db, $table_prefix;
	global $settings, $page_settings;
	global $category_id;
	global $site_id;
	
	$user_id = get_session("session_user_id");		
	$user_info = get_session("session_user_info");
	$user_type_id = get_setting_value($user_info, "user_type_id", "");

	if(get_setting_value($page_settings, $block_name . "_column_hide", 0)) {
		return;
	}

	if (!strlen($top_name)) {
		$sql  = $table_prefix . "articles_categories ac ";
		if (isset($site_id)) {
			$sql = " (" . $sql . " LEFT JOIN " . $table_prefix . "articles_categories_sites acs ON acs.category_id=ac.category_id)";
		}
		if (strlen($user_id)) {
			$sql = " (" . $sql . " LEFT JOIN " . $table_prefix . "articles_categories_types ut ON ut.category_id=ac.category_id)";
		}
		$sql  = " SELECT ac.category_name FROM " . $sql;		
		$sql .= " WHERE ac.category_id=" . $db->tosql($top_id, INTEGER);		
		if (isset($site_id))  {
			$sql .= " AND (ac.sites_all=1 OR acs.site_id=". $db->tosql($site_id, INTEGER, true, false) . ") ";
		} else {
			$sql .= " AND ac.sites_all=1 ";					
		}		
		if (strlen($user_id)) {
			$sql .= " AND (ac.user_types_all=1 OR ut.user_type_id=". $db->tosql($user_type_id , INTEGER) . " )";
		} else {
			$sql .= " AND ac.user_types_all=1 ";
		}
		
		$db->query($sql);
		if ($db->next_record()) {
			$top_name = get_translation($db->f("category_name"));
		} else {
			return false;
		}
	}
	

	$friendly_urls = get_setting_value($settings, "friendly_urls", 0);
	$friendly_extension = get_setting_value($settings, "friendly_extension", "");

	$t->set_file("block_body", "block_top_rated.html");
	$t->set_var("top_category_name",$top_name);
	$t->set_var("TOP_RATED_TITLE",  TOP_RATED_TITLE);
	$t->set_var("top_rated_items",  "");
	$t->set_var("top_image", "");
	$t->set_var("top_desc", "");

	$sql  = " (((" . $table_prefix . "articles a ";
	$sql .= " LEFT JOIN " . $table_prefix . "articles_statuses st ON a.status_id=st.status_id)";
	$sql .= " LEFT JOIN " . $table_prefix . "articles_assigned aa  ON aa.article_id=a.article_id)";
	$sql .= " LEFT JOIN " . $table_prefix . "articles_categories ac  ON aa.category_id=ac.category_id)";
	if (isset($site_id)) {
		$sql = " (" . $sql . " LEFT JOIN " . $table_prefix . "articles_categories_sites acs ON acs.category_id=ac.category_id)";
	}
	if (strlen($user_id)) {
		$sql = " (" . $sql . " LEFT JOIN " . $table_prefix . "articles_categories_types ut ON ut.category_id=ac.category_id)";
	}		
	$sql  = " SELECT a.article_id, a.article_title, a.friendly_url, a.rating, a.is_remote_rss, a.details_remote_url "
	      . " FROM " . $sql; 
	$sql .= " WHERE (ac.category_id=" . $db->tosql($top_id, INTEGER);
	$sql .= " OR ac.category_path LIKE '0," . $top_id . ",%') ";
	$sql .= " AND st.allowed_view=1 ";
	$sql .= " AND a.total_votes>=" . $db->tosql(get_setting_value($settings, "min_votes", 10), INTEGER);
	$sql .= " AND a.rating>=" . $db->tosql(get_setting_value($settings, "min_rating", 1), FLOAT);
	if (isset($site_id))  {
		$sql .= " AND (ac.sites_all=1 OR acs.site_id=". $db->tosql($site_id, INTEGER, true, false) . ") ";
	} else {
		$sql .= " AND ac.sites_all=1 ";					
	}	
	if (strlen($user_id)) {
		$sql .= " AND ( ac.user_types_all=1 OR ut.user_type_id=". $db->tosql($user_type_id , INTEGER) . " )";
	} else {
		$sql .= " AND ac.user_types_all=1 ";
	}
	$sql .= " GROUP BY a.article_id, a.article_order, a.article_title, a.friendly_url, a.total_points, a.rating, a.is_remote_rss, a.details_remote_url ";
	$sql .= " ORDER BY a.rating DESC, a.article_order, a.article_title ";

	$db->RecordsPerPage = 10;
	$db->PageNumber = 1;
	$db->query($sql);
	if($db->next_record())
	{
		$item_number = 0;
		do
		{
			$item_number++;
			$article_id = $db->f("article_id");
			$friendly_url = $db->f("friendly_url");
			$is_remote_rss = $db->f("is_remote_rss");
			$details_remote_url = $db->f("details_remote_url");

			$top_rating = $db->f("rating");

			if ($is_remote_rss == 0){
				if ($friendly_urls && $friendly_url) {
					$t->set_var("details_href", $friendly_url . $friendly_extension);
				} else {
					$t->set_var("details_href", "article.php?article_id=" . $article_id);
				}
			} else {
				$t->set_var("details_href", $details_remote_url);
			}
			
			$t->set_var("top_position", $item_number);
			$t->set_var("top_name", get_translation($db->f("article_title")));
			$t->set_var("top_rating", number_format($top_rating, 2));

			$t->parse("top_rated_items", true);
		} while ($db->next_record());              	
		$t->parse("block_body", false);
		$t->parse($block_name, true);
	}

}

?>