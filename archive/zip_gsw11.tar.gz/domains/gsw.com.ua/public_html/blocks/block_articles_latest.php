<?php

function articles_latest($block_name, $top_id, $top_name)
{
	global $t, $db, $site_id, $db_type, $table_prefix;
	global $settings, $page_settings;
	global $datetime_show_format;
	
	$user_id = get_session("session_user_id");		
	$user_info = get_session("session_user_info");
	$user_type_id = get_setting_value($user_info, "user_type_id", "");

	if(get_setting_value($page_settings, $block_name . "_column_hide", 0)) {
		return;
	}

	if (!strlen($top_name)) {
		$sql  = $table_prefix . "articles_categories ac ";		
		if (isset($site_id))  {
			$sql = "(" . $sql . " LEFT JOIN " . $table_prefix . "articles_categories_sites acs ON acs.category_id=ac.category_id)";				
		}
		if (strlen($user_id)) {
			$sql =  "(" . $sql . " LEFT JOIN " . $table_prefix . "articles_categories_types ut ON ut.category_id=ac.category_id)";
		}
		$sql  = " SELECT ac.category_name, ac.friendly_url FROM " . $sql;		
		$sql .= " WHERE ac.category_id=" . $db->tosql($top_id, INTEGER);				
		if (isset($site_id))  {
			$sql .= " AND (ac.sites_all=1 OR acs.site_id=". $db->tosql($site_id, INTEGER, true, false) . ") ";
		} else {
			$sql .= " AND ac.sites_all=1 ";					
		}
		if (strlen($user_id)) {
			$sql .= " AND ( ac.user_types_all=1 OR ut.user_type_id=". $db->tosql($user_type_id , INTEGER) . " )";
		} else {
			$sql .= " AND ac.user_types_all=1 ";
		}		
		$db->query($sql);
		if ($db->next_record()) {
			$top_name = get_translation($db->f("category_name"));
			$top_friendly_url = $db->f("friendly_url");
		} else {
			return false;
		}
	} else {
		$top_friendly_url = "";
	}

	$friendly_urls = get_setting_value($settings, "friendly_urls", 0);
	$friendly_extension = get_setting_value($settings, "friendly_extension", "");

	$t->set_file("block_body", "block_articles_latest.html");
	$t->set_var("latest_rows", "");
	$t->set_var("latest_cols", "");
	$t->set_var("articles_category", "");
	$t->set_var("articles_top", "");
	$t->set_var("articles_sub", "");

	$t->set_var("top_category_name",$top_name);

	$latest_group = get_setting_value($page_settings, "a_latest_group_by_" . $top_id, 0);
	$latest_cats = get_setting_value($page_settings, "a_latest_cats_" . $top_id, "");
	$latest_subcats = get_setting_value($page_settings, "a_latest_subcats_" . $top_id, 0);
	$latest_recs = get_setting_value($page_settings, "a_latest_recs_" . $top_id, 1);
	$latest_subrecs = get_setting_value($page_settings, "a_latest_subrecs_" . $top_id, 0);
	$latest_columns = get_setting_value($page_settings, "a_latest_cols_" . $top_id, 1);
	$latest_image = get_setting_value($page_settings, "a_latest_image_" . $top_id,  0);
	$latest_desc = get_setting_value($page_settings, "a_latest_desc_" . $top_id, 1);
	$t->set_var("latest_column", (100 / $latest_columns) . "%");
	$category_number = 0;

	$image_field = ""; $image_alt_field = ""; $desc_field = "";
	if ($latest_image == 1) {
		$image_field = "image_tiny";
		$image_alt_field = "image_tiny_alt";
	} else if ($latest_image == 2) {
		$image_field = "image_small";
		$image_alt_field = "image_small_alt";
	} else if ($latest_image == 3) {
		$image_field = "image_large";
		$image_alt_field = "image_large_alt";
	} else if ($latest_image == 4) {
		$image_field = "image_super";
		$image_alt_field = "image_large_alt";
	}
	if ($latest_desc == 1) {
		$desc_field = "short_description";
	} else if ($latest_desc == 2) {
		$desc_field = "full_description";
	} else if ($latest_desc == 3) {
		$desc_field = "hot_description";
	}

	$categories = array();
	if ($latest_group) {
		if ($latest_group == 3) {
			$cats_ids = explode(",", $latest_cats);
		} else {
			$cats_ids = array($top_id);
		}
		for ($i = 0; $i < sizeof($cats_ids); $i++) {
			$sql  =  $table_prefix . "articles_categories ac ";
			if (isset($site_id)) {			
				$sql = "(" . $sql . " LEFT JOIN " . $table_prefix . "articles_categories_sites acs ON acs.category_id=ac.category_id) ";
			}
			if (strlen($user_id)) {			
				$sql = "(" . $sql . " LEFT JOIN " . $table_prefix . "articles_categories_types ut ON ut.category_id=ac.category_id) ";
			}
			$sql  = " SELECT ac.category_id, ac.category_name, ac.category_path, ac.friendly_url FROM " . $sql;
			if ($latest_group == 1) {
				$sql .= " WHERE ac.category_path LIKE '0," . $cats_ids[$i] . ",' ";
			} else if ($latest_group == 2) {
				$sql .= " WHERE ac.category_path LIKE '0," . $cats_ids[$i] . ",%' ";
			} else if ($latest_group == 3) {
				$sql .= " WHERE ac.category_id=" . $db->tosql($cats_ids[$i], INTEGER);
			}
			if (isset($site_id))  {
				$sql .= " AND (ac.sites_all=1 OR acs.site_id=". $db->tosql($site_id, INTEGER, true, false) . ") ";
			} else {
				$sql .= " AND ac.sites_all=1 ";					
			}
			if (strlen($user_id)) {
				$sql .= " AND (ac.user_types_all=1 OR ut.user_type_id=". $db->tosql($user_type_id , INTEGER) . " )";
			} else {
				$sql .= " AND ac.user_types_all=1 ";
			}
			$sql .= " ORDER BY ac.category_order, ac.category_id ";
			$db->query($sql);
			if ($db->next_record()) {
				do {
					$category_id = $db->f("category_id");
					$category_name = $db->f("category_name");
					$category_path = $db->f("category_path");
					$category_friendly_url = $db->f("friendly_url");
					$categories[$category_id] = array($category_name, $category_path, $category_friendly_url);
				} while ($db->next_record());
			}
		}
	} else {
		$categories[$top_id] = array($top_name, "0,", $top_friendly_url);
		$latest_subcats = 1; // for simple list always include articles from sub categories
	}

	foreach ($categories as $category_id => $category_info) {
		list($category_name, $category_path, $category_friendly_url) = $category_info;
		
		if ($db->DBType != "db2"){
			$sql  = " SELECT a.article_id, a.article_title, a.friendly_url, a.article_date, a.is_remote_rss, a.details_remote_url ";
			if ($image_field) { $sql .= " , a." . $image_field; }
			if ($image_alt_field) { $sql .= " , a." . $image_alt_field; }
			if ($desc_field) { $sql .= " , a." . $desc_field; }
			//$sql .= " FROM " . $table_prefix . "articles a ";
			//$sql .= " , " . $table_prefix . "articles_statuses st ";
			//$sql .= " , " . $table_prefix . "articles_assigned aa ";
			//$sql .= " , " . $table_prefix . "articles_categories ac ";
			//$sql_where  = " WHERE a.status_id=st.status_id AND a.article_id=aa.article_id AND aa.category_id=ac.category_id ";
			
			$sql .= " FROM (((((" . $table_prefix . "articles a ";
			$sql .= " INNER JOIN " . $table_prefix . "articles_statuses st ON a.status_id=st.status_id)";
			$sql .= " INNER JOIN " . $table_prefix . "articles_assigned aa ON a.article_id=aa.article_id)";
			$sql .= " INNER JOIN " . $table_prefix . "articles_categories ac ON aa.category_id=ac.category_id)";

			$sql_where  = " WHERE st.allowed_view=1 ";
			$sql_where .= " AND (ac.category_id=" . $db->tosql($category_id, INTEGER);
			if ($latest_subcats) {
				$sql_where .= " OR ac.category_path LIKE '" . $category_path . $category_id . ",%') ";
			} else {
				$sql_where .= " ) ";
			}
			if (isset($site_id))  {
				$sql .= " LEFT JOIN " . $table_prefix . "articles_categories_sites acs ON acs.category_id=ac.category_id) ";
				$sql_where .= " AND (ac.sites_all=1 OR acs.site_id=". $db->tosql($site_id, INTEGER, true, false) . ") ";
			} else {
				$sql .= " ) ";
				$sql_where .= " AND ac.sites_all=1 ";					
			}
			if (strlen($user_id)) {
				$sql .= " LEFT JOIN " . $table_prefix . "articles_categories_types ut ON ut.category_id=ac.category_id) ";
				$sql_where .= " AND ( ac.user_types_all=1 OR ut.user_type_id=". $db->tosql($user_type_id , INTEGER) . " )";
			} else {
				$sql .= " ) ";
				$sql_where .= " AND ac.user_types_all=1 ";
			}
			$sql .= $sql_where;
			$sql .= " GROUP BY a.article_id, a.article_date, a.article_title, a.friendly_url, a.article_order, a.is_remote_rss, a.details_remote_url ";
			if ($image_field) { $sql .= " , a." . $image_field; }
			if ($image_alt_field) { $sql .= " , a." . $image_alt_field; }
			if ($desc_field) { $sql .= " , a." . $desc_field; }
			$sql .= " ORDER BY a.article_date DESC, a.article_order ";
		} else {
			$sql  = " SELECT a.article_id, a.article_title, a.friendly_url, a.article_date, a.is_remote_rss, a.details_remote_url ";
			if ($image_field) { $sql .= " , a." . $image_field; }
			if ($image_alt_field) { $sql .= " , a." . $image_alt_field; }
			if ($desc_field) { $sql .= " , a." . $desc_field; }
			$sql .= " FROM " . $table_prefix . "articles a, ";
			$sql .= " (SELECT a.article_id AS id, a.article_date, a.article_order ";
			$sql .= " FROM " . $table_prefix . "articles a ";
			$sql .= " , " . $table_prefix . "articles_statuses st ";
			$sql .= " , " . $table_prefix . "articles_assigned aa ";
			$sql .= " , " . $table_prefix . "articles_categories ac ";
			
			$sql_where  = " WHERE a.status_id=st.status_id AND a.article_id=aa.article_id AND aa.category_id=ac.category_id ";
			$sql_where .= " AND st.allowed_view=1 ";
			$sql_where .= " AND (ac.category_id=" . $db->tosql($category_id, INTEGER);
			if ($latest_subcats) {
				$sql_where .= " OR ac.category_path LIKE '" . $category_path . $category_id . ",%') ";
			} else {
				$sql_where .= " ) ";
			}
			if (isset($site_id))  {
				$sql .= " LEFT JOIN " . $table_prefix . "articles_categories_sites acs ON acs.category_id=ac.category_id";
				$sql_where .= " AND (ac.sites_all=1 OR acs.site_id=". $db->tosql($site_id, INTEGER, true, false) . ") ";
			} else {
				$sql_where .= " AND ac.sites_all=1 ";					
			}
			if (strlen($user_id)) {
				$sql .= " LEFT JOIN " . $table_prefix . "articles_categories_types ut ON ut.category_id=ac.category_id";
				$sql_where .= " AND ( ac.user_types_all=1 OR ut.user_type_id=". $db->tosql($user_type_id , INTEGER) . " )";
			} else {
				$sql_where .= " AND ac.user_types_all=1 ";
			}			
			
			$sql .= $sql_where . " GROUP BY a.article_id, a.article_date, a.article_order ";
			$sql .= " ORDER BY a.article_date DESC, a.article_order ) AS article ";
			$sql .= " WHERE article.id = a.article_id ";
		}
  
		$db->RecordsPerPage = $latest_recs + $latest_subrecs;
		$db->PageNumber = 1;
		$db->query($sql);
		if($db->next_record())
		{
			$category_number++;
			$latest_number = 0;
			if ($friendly_urls && $category_friendly_url) {
				$t->set_var("list_url", $category_friendly_url . $friendly_extension);
			} else {
				$t->set_var("list_url", "articles.php?category_id=" . $category_id);
			}
			$t->set_var("articles_top", "");
			$t->set_var("articles_sub", "");
			do
			{
				$latest_number++;
				$article_id = $db->f("article_id");
				$article_title = get_translation($db->f("article_title"));
				$friendly_url = $db->f("friendly_url");
				$is_remote_rss = $db->f("is_remote_rss");
				$details_remote_url = $db->f("details_remote_url");

				if ($is_remote_rss == 0){
					if ($friendly_urls && $friendly_url) {
						$t->set_var("details_url", $friendly_url . $friendly_extension);
					} else {
						$t->set_var("details_url", "article.php?article_id=" . $article_id);
					}
				} else {
					$t->set_var("details_url", $details_remote_url);
				}
			
				$t->set_var("article_id", $article_id);
				$t->set_var("latest_item_name", $article_title);

				$article_image = ""; $article_image_alt = ""; $article_desc = "";
				if ($image_field) {
					$article_image = $db->f($image_field);	
					$article_image_alt = $db->f($image_alt_field);	
				}
				if ($desc_field) {
					$article_desc = get_translation($db->f($desc_field));
				}

				if (strlen($article_image)) {
					if (preg_match("/^http\:\/\//", $article_image)) {
						$image_size = "";
					} else {
	          $image_size = @GetImageSize($article_image);
						if (isset($restrict_articles_images) && $restrict_articles_images) { $article_image = "image_show.php?article_id=".$article_id."&type=small"; }
					}
					if (!strlen($article_image_alt)) { $article_image_alt = $article_title; }
          $t->set_var("alt", htmlspecialchars($article_image_alt));
          $t->set_var("src", htmlspecialchars($article_image));
					if(is_array($image_size)) {
	          $t->set_var("width", "width=\"" . $image_size[0] . "\"");
  		      $t->set_var("height", "height=\"" . $image_size[1] . "\"");
					} else {
	          $t->set_var("width", "");
  		      $t->set_var("height", "");
					}
					$t->sparse("image_small_block", false);
				} else {
					$t->set_var("image_small_block", "");
				}
				if ($article_desc) {
					$t->set_var("short_description", $article_desc);
					$t->set_var("desc_text", $article_desc);
					$t->sparse("article_desc", false);
				} else {
					$t->set_var("article_desc", "");
				}

  
				$article_date = $db->f("article_date", DATETIME);
				$article_date_string  = va_date($datetime_show_format, $article_date);
				$t->set_var("article_date", $article_date_string);
				if ($latest_number <= $latest_recs) {
					$t->parse("articles_top", true);
				} else {
					$t->parse("articles_sub", true);
				}
  
				if (!$latest_group) { // parse columns for simple list
					$t->parse("latest_cols");
					$t->set_var("articles_top", "");
					$t->set_var("articles_sub", "");
					if ($latest_number % $latest_columns == 0) {
						$t->parse("latest_rows");
						$t->set_var("latest_cols", "");
					}
				}

			} while ($db->next_record());              	

			if ($latest_group) {
				$t->set_var("category_name", $category_name);
				$t->parse("articles_category", false);

				// parse categories columns
				$t->parse("latest_cols");
				if($category_number % $latest_columns == 0)
				{
					$t->parse("latest_rows");
					$t->set_var("latest_cols", "");
				}
			} else {	
				if ($latest_number % $latest_columns != 0) {
					$t->parse("latest_rows");
				}
			}


		}
	}

	if ($latest_group && $category_number % $latest_columns != 0) {
		$t->parse("latest_rows");
	}

	if ($category_number) {
			$t->parse("block_body", false);
			$t->parse($block_name, true);
	}

}

?>