<?php

function articles_related($block_name, $article_id, $list_fields)
{
	global $t, $db, $table_prefix;
	global $settings, $page_settings;
	global $datetime_show_format;
	global $site_id, $db_type;
	
	$user_id = get_session("session_user_id");		
	$user_info = get_session("session_user_info");
	$user_type_id = get_setting_value($user_info, "user_type_id", "");


	if(get_setting_value($page_settings, $block_name . "_column_hide", 0)) {
		return;
	}

	$t->set_file("block_body",           "block_related.html");
	$t->set_var("RELATED_TITLE",          RELATED_TITLE);
	$t->set_var("MORE_MSG",               MORE_MSG);
	$t->set_var("READ_MORE_MSG",          READ_MORE_MSG);
	$t->set_var("CLICK_HERE_MSG",         CLICK_HERE_MSG);

	$friendly_urls = get_setting_value($settings, "friendly_urls", 0);
	$friendly_extension = get_setting_value($settings, "friendly_extension", "");

	$list_fields = ",," . $list_fields . ",,";

	$sql = " SELECT a.article_id, a.article_title, a.friendly_url, a.article_date FROM ((((";	
	if (isset($site_id)) {
		$sql .= "(";
	}
	if (strlen($user_id)) {
		$sql .= "(";
	}
	$sql .= $table_prefix . "articles a ";
	$sql .= " INNER JOIN " . $table_prefix . "articles_statuses st ON st.status_id=a.status_id)";
	$sql .= " INNER JOIN " . $table_prefix . "articles_related ar ON ar.related_id=a.article_id)";
	$sql .= " LEFT JOIN " . $table_prefix . "articles_assigned aac ON aac.article_id=a.article_id)";
	$sql .= " LEFT JOIN " . $table_prefix . "articles_categories ac ON ac.category_id=aac.category_id)";
	if (isset($site_id)) {
		$sql .= " LEFT JOIN " . $table_prefix . "articles_categories_sites acs ON acs.category_id=ac.category_id)";
	}
	if (strlen($user_id)) {
		$sql .= " LEFT JOIN " . $table_prefix . "articles_categories_types AS ut ON ut.category_id=ac.category_id)";
	}
	$sql .= " WHERE a.status_id=st.status_id AND ar.related_id=a.article_id ";	
	$sql .= " AND ar.article_id=" . $db->tosql($article_id, INTEGER);
	$sql .= " AND st.allowed_view=1 ";	
	if (isset($site_id))  {
		$sql .= " AND (ac.sites_all=1 OR acs.site_id=". $db->tosql($site_id, INTEGER, true, false) . ") ";
	} else {
		$sql .= " AND ac.sites_all=1 ";					
	}	
	if (strlen($user_id)) {
		$sql .= " AND ( ac.user_types_all=1 OR ut.user_type_id=". $db->tosql($user_type_id , INTEGER) . " )";
	} else {
		$sql .= " AND ac.user_types_all=1 ";
	}
	if ($db_type == "access" || $db_type == "db2"  || $db_type == "postgre") {
		$sql .= " GROUP BY a.article_id, a.article_title, a.friendly_url, a.article_date, ar.related_order ";		
	} else {
		$sql .= " GROUP BY a.article_id ";
	}
	$sql .= " ORDER BY ar.related_order ";

	$db->RecordsPerPage = 10;
	$db->PageNumber = 1;
	$db->query($sql);
	if($db->next_record())
	{
		$item_number = 0;
		do
		{
			$item_number++;
			$article_id = $db->f("article_id");
			$friendly_url = $db->f("friendly_url");

			if ($friendly_urls && $friendly_url) {
				$t->set_var("details_href", $friendly_url . $friendly_extension);
			} else {
				$t->set_var("details_href", "article.php?article_id=" . $article_id);
			}

			if (strpos($list_fields, ",article_date,")) {
				$article_date = $db->f("article_date", DATETIME);
				$article_date_string  = va_date($datetime_show_format, $article_date);
				$t->set_var("article_date", $article_date_string);
				$t->global_parse("article_date_block", false, false, true);
			} else {
				$t->set_var("article_date_block", "");
			}

			$t->set_var("related_item_name", get_translation($db->f("article_title")));

			$t->parse("related_items", true);
		} while ($db->next_record());              	
		$t->parse("block_body", false);
		$t->parse($block_name, true);
	}

}

?>