<?php
mysql_connect('10.0.0.2', 'xuzcom_sc', 'W5lKC4WN');
mysql_select_db('xuzcom_sc');

mysql_query("SET NAMES cp1251");

$csv = file_get_contents('to_parse.csv');
$csv_strings = explode("\n", trim($csv));
foreach($csv_strings as $key => $string){
    if($key > 0){
        $fields = explode(";", $string);

        $item_code       = trim($fields[1]);
        $item_name       = trim($fields[3]);
        $item_category   = trim($fields[4]);
        $manufacturer_id = 2;
        $weight          = trim($fields[6]);
        $material        = trim($fields[7]);
        $insertion_1     = trim($fields[8]);
        $insertion_2     = trim($fields[9]);
        $price           = trim($fields[10]);

        $sql = "SELECT `item_id`, `item_name` FROM `va_items` WHERE `item_name` = '".$item_name."' AND `item_code` LIKE '%".$item_code."'";

        $query = mysql_query($sql);

        if(mysql_num_rows($query)){
            $row = mysql_fetch_assoc($query);
            echo "Item {$row['item_name']} already exists<BR><BR>";
        }
        else{
            echo $item_name . " is a new item<BR>";

            //----------------- Get a category ID ---------------

            $category = explode(">", $item_category);                                                                      
            $category_id[0] = @mysql_result(mysql_query("SELECT `category_id` FROM `va_categories` WHERE `category_name` = '" . trim($category[0]) . "'"), 0);
            $category_id[1] = @mysql_result(mysql_query("SELECT `category_id` 
                                                          FROM `va_categories` 
                                                         WHERE `category_name` = '" . trim($category[1]) . "' AND 
                                                               `parent_category_id` = '" . $category_id[0] . "'"), 0);

            echo "<B>Values:</B> &nbsp;&nbsp;&nbsp; Parent category: " . (!empty($category[0]) ? $category[0] : ' - ') . ", child category: " . (!empty($category[1]) ? $category[1] : ' - ') . "<BR>";
            echo "<B>Identifiers:</B> &nbsp;&nbsp;&nbsp; Parent category: " . (!empty($category_id[0]) ? $category_id[0] : ' - ') . ", child category: " . (!empty($category_id[1]) ? $category_id[1] : ' - ') . "<BR><BR>";

            //------------------------ END ----------------------            

            $sql = "INSERT INTO `va_items` 
                               (`item_code`,
                                `item_name`,
                                `manufacturer_id`,
                                `weight`,
                                `price`)
                        VALUES ('" . $item_code . "',
                                '" . $item_name . "',
                                '" . $manufacturer_id . "',
                                '" . $weight . "',
                                '" . $price . "')";

            mysql_query($sql);

            $item_id = mysql_insert_id();

            mysql_query("INSERT INTO `va_items_categories` 
                                    (`item_id`, `category_id`) 
                             VALUES ('" . $item_id . "', 
                                     '" . (!empty($category_id[1]) ? $category_id[1] : $category_id[0]) . "')");
            echo mysql_error() . "<BR>";

            $features_sql = "INSERT INTO `va_features`
                                        (`item_id`,
                                         `group_id`,
                                         `feature_name`,
                                         `feature_value`)
                                 VALUES ('".$item_id."',
                                         '4',
                                         '%s',
                                         '%s')";            
            
            if(!empty($material)){
                $sql_with_vals = sprintf($features_sql, "��������(�)", $material);
                mysql_query($sql_with_vals); echo mysql_error() . "<BR>";
            }

            if(!empty($insertion_1)){
                $sql_with_vals = sprintf($features_sql, "������� 1", $insertion_1);
                mysql_query($sql_with_vals); echo mysql_error() . "<BR>";
            }

            if(!empty($insertion_2)){
                $sql_with_vals = sprintf($features_sql, "������� 2", $insertion_2);
                mysql_query($sql_with_vals); echo mysql_error() . "<BR>";
            }
        }
    }
}
?>