CREATE TABLE `va_categories` (
  `category_id` int(11) NOT NULL auto_increment,
  `parent_category_id` int(11) NOT NULL default '0',
  `google_base_type_id` int(11) default '0',
  `category_path` varchar(255) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `friendly_url` varchar(255) default NULL,
  `category_order` int(11) NOT NULL default '1',
  `sites_all` tinyint(4) default '1',
  `user_types_all` tinyint(4) default '1',
  `is_showing` tinyint(4) NOT NULL default '0',
  `allowed_post` tinyint(4) default '0',
  `allowed_post_subcategories` tinyint(4) default '0',
  `allowed_post_types_all` tinyint(4) default '1',
  `show_sub_products` tinyint(4) default '0',
  `short_description` text,
  `full_description` text,
  `image` varchar(255) default NULL,
  `image_alt` varchar(255) default NULL,
  `image_large` varchar(255) default NULL,
  `image_large_alt` varchar(255) default NULL,
  `list_template` varchar(128) default NULL,
  `details_template` varchar(128) default NULL,
  `meta_title` varchar(255) default NULL,
  `meta_keywords` varchar(255) default NULL,
  `meta_description` varchar(255) default NULL,
  `total_views` int(11) default '0',
  `admin_id_added_by` int(11) default '0',
  `admin_id_modified_by` int(11) default '0',
  `date_added` datetime default NULL,
  `date_modified` datetime default NULL,
  PRIMARY KEY  (`category_id`),
  KEY `category_path` (`category_path`),
  KEY `friendly_url` (`friendly_url`),
  KEY `google_base_type_id` (`google_base_type_id`),
  KEY `is_showing` (`is_showing`),
  KEY `parent_category_id` (`parent_category_id`),
  KEY `sites_all` (`sites_all`),
  KEY `user_types_all` (`user_types_all`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=141 ;

--
-- ���� ������ ������� `va_categories`
--

INSERT INTO `va_categories` VALUES(136, 95, 17, '0,95,', '������', '', 10, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 77, 1, 1, '2009-07-13 15:20:23', '2009-07-13 15:20:23');
INSERT INTO `va_categories` VALUES(137, 95, 17, '0,95,', '�����', '', 11, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 27, 1, 1, '2009-07-13 15:20:40', '2009-07-13 15:20:40');
INSERT INTO `va_categories` VALUES(138, 95, 17, '0,95,', '��������', '', 12, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 81, 1, 1, '2009-07-13 15:21:05', '2009-07-13 15:21:05');
INSERT INTO `va_categories` VALUES(139, 95, 17, '0,95,', '������', '', 13, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 98, 1, 1, '2009-07-13 15:21:21', '2009-07-13 15:21:21');
INSERT INTO `va_categories` VALUES(127, 95, 17, '0,95,', '��������', '', 1, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 107, 1, 1, '2009-07-13 15:17:45', '2009-07-13 15:17:45');
INSERT INTO `va_categories` VALUES(95, 0, 17, '0,', '���������� ���������', '', 2, 1, 1, 1, 0, 0, 1, 1, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 358, 1, 1, '2009-07-13 15:01:46', '2009-07-13 15:01:46');
INSERT INTO `va_categories` VALUES(96, 0, 17, '0,', '���������� ����, ��������', '', 3, 1, 1, 1, 0, 0, 1, 1, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 152, 1, 1, '2009-07-13 15:02:32', '2009-07-13 15:02:32');
INSERT INTO `va_categories` VALUES(97, 0, 17, '0,', '�������� �� �������', '', 4, 1, 1, 1, 0, 0, 1, 1, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 98, 1, 1, '2009-07-13 15:02:54', '2009-07-13 15:02:54');
INSERT INTO `va_categories` VALUES(98, 0, 17, '0,', '���������� ��� ����', '', 5, 1, 1, 1, 0, 0, 1, 1, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 87, 1, 1, '2009-07-13 15:04:22', '2009-07-13 15:04:22');
INSERT INTO `va_categories` VALUES(99, 0, -1, '0,', '���������� ��������', '', 6, 1, 1, 1, 0, 0, 1, 1, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 23, 1, 1, '2009-07-13 15:05:05', '2009-07-13 15:05:05');
INSERT INTO `va_categories` VALUES(100, 94, 17, '0,94,', '������� ������', '', 1, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 120, 1, 1, '2009-07-13 15:05:43', '2009-07-13 15:05:43');
INSERT INTO `va_categories` VALUES(101, 94, 17, '0,94,', '������', '', 2, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 90, 1, 1, '2009-07-13 15:06:25', '2009-07-13 15:06:25');
INSERT INTO `va_categories` VALUES(102, 94, 17, '0,94,', '������', '', 3, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 106, 1, 1, '2009-07-13 15:06:44', '2009-07-13 15:06:44');
INSERT INTO `va_categories` VALUES(103, 94, 17, '0,94,', '��������', '', 4, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 95, 1, 1, '2009-07-13 15:07:08', '2009-07-13 15:07:08');
INSERT INTO `va_categories` VALUES(104, 94, 17, '0,94,', '���������', '', 5, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 76, 1, 1, '2009-07-13 15:07:25', '2009-07-13 15:07:25');
INSERT INTO `va_categories` VALUES(105, 94, 17, '0,94,', '��������', '', 6, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 70, 1, 1, '2009-07-13 15:07:41', '2009-07-13 15:07:41');
INSERT INTO `va_categories` VALUES(106, 94, 17, '0,94,', '������', '', 7, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 93, 1, 1, '2009-07-13 15:07:58', '2009-07-13 15:07:58');
INSERT INTO `va_categories` VALUES(107, 94, 17, '0,94,', '�����', '', 8, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 76, 1, 1, '2009-07-13 15:08:41', '2009-07-13 15:08:41');
INSERT INTO `va_categories` VALUES(108, 94, 17, '0,94,', '�������', '', 9, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 91, 1, 1, '2009-07-13 15:10:10', '2009-07-13 15:10:10');
INSERT INTO `va_categories` VALUES(109, 94, 17, '0,94,', '�����', '', 10, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 98, 1, 1, '2009-07-13 15:10:32', '2009-07-13 15:10:32');
INSERT INTO `va_categories` VALUES(110, 94, 17, '0,94,', '���������', '', 11, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 62, 1, 1, '2009-07-13 15:10:48', '2009-07-13 15:10:48');
INSERT INTO `va_categories` VALUES(111, 94, 15, '0,94,', '�������', '', 12, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 70, 1, 1, '2009-07-13 15:11:01', '2009-07-13 15:11:01');
INSERT INTO `va_categories` VALUES(112, 94, 17, '0,94,', '�����������', '', 13, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 67, 1, 1, '2009-07-13 15:11:16', '2009-07-13 15:11:32');
INSERT INTO `va_categories` VALUES(113, 94, 17, '0,94,', '���������', '', 14, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 77, 1, 1, '2009-07-13 15:11:44', '2009-07-13 15:11:44');
INSERT INTO `va_categories` VALUES(114, 94, 17, '0,94,', '�������������', '', 15, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 68, 1, 1, '2009-07-13 15:11:57', '2009-07-13 15:11:57');
INSERT INTO `va_categories` VALUES(115, 94, 17, '0,94,', '�����', '', 16, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 92, 1, 1, '2009-07-13 15:12:13', '2009-07-13 15:12:13');
INSERT INTO `va_categories` VALUES(116, 94, 17, '0,94,', '����������', '', 17, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 75, 1, 1, '2009-07-13 15:12:32', '2009-07-13 15:12:32');
INSERT INTO `va_categories` VALUES(117, 94, 17, '0,94,', '���������', '', 18, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 68, 1, 1, '2009-07-13 15:12:52', '2009-07-13 15:12:52');
INSERT INTO `va_categories` VALUES(118, 94, 17, '0,94,', '�������', '', 19, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 67, 1, 1, '2009-07-13 15:13:10', '2009-07-13 15:13:10');
INSERT INTO `va_categories` VALUES(119, 94, 17, '0,94,', '������', '', 20, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 80, 1, 1, '2009-07-13 15:13:29', '2009-07-13 15:13:29');
INSERT INTO `va_categories` VALUES(120, 94, 17, '0,94,', '�������', '', 21, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 22, 1, 1, '2009-07-13 15:14:10', '2009-07-13 15:14:10');
INSERT INTO `va_categories` VALUES(121, 94, 17, '0,94,', '�����', '', 22, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 83, 1, 1, '2009-07-13 15:14:22', '2009-07-13 15:14:22');
INSERT INTO `va_categories` VALUES(122, 94, 17, '0,94,', '�����', '', 23, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 96, 1, 1, '2009-07-13 15:14:38', '2009-07-13 15:14:38');
INSERT INTO `va_categories` VALUES(123, 94, 17, '0,94,', '�����������', '', 24, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 26, 1, 1, '2009-07-13 15:14:57', '2009-07-13 15:14:57');
INSERT INTO `va_categories` VALUES(124, 94, 17, '0,94,', '�������', '', 25, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 63, 1, 1, '2009-07-13 15:15:20', '2009-07-13 15:15:20');
INSERT INTO `va_categories` VALUES(125, 94, 17, '0,94,', '����', '', 26, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 72, 1, 1, '2009-07-13 15:15:40', '2009-07-13 15:15:40');
INSERT INTO `va_categories` VALUES(126, 94, 17, '0,94,', '�����', '', 27, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 86, 1, 1, '2009-07-13 15:16:01', '2009-07-13 15:16:01');
INSERT INTO `va_categories` VALUES(128, 95, 17, '0,95,', '�������', '', 2, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 82, 1, 1, '2009-07-13 15:18:00', '2009-07-13 15:18:00');
INSERT INTO `va_categories` VALUES(129, 95, 17, '0,95,', '�����', '', 3, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 76, 1, 1, '2009-07-13 15:18:14', '2009-07-13 15:18:14');
INSERT INTO `va_categories` VALUES(130, 95, 17, '0,95,', '������ ��� ��������', '', 4, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 76, 1, 1, '2009-07-13 15:18:28', '2009-07-13 15:18:28');
INSERT INTO `va_categories` VALUES(131, 95, 17, '0,95,', '�������', '', 5, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 22, 1, 1, '2009-07-13 15:18:45', '2009-07-13 15:18:45');
INSERT INTO `va_categories` VALUES(132, 95, 17, '0,95,', '������ �������', '', 6, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 93, 1, 1, '2009-07-13 15:19:19', '2009-07-13 15:19:19');
INSERT INTO `va_categories` VALUES(133, 95, 17, '0,95,', '������ �������', '', 7, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 35, 1, 1, '2009-07-13 15:19:35', '2009-07-13 15:19:35');
INSERT INTO `va_categories` VALUES(134, 95, 17, '0,95,', '������', '', 8, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 88, 1, 1, '2009-07-13 15:19:52', '2009-07-13 15:19:52');
INSERT INTO `va_categories` VALUES(135, 95, 17, '0,95,', '�������', '', 9, 1, 1, 1, 0, 0, 1, 0, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 97, 1, 1, '2009-07-13 15:20:08', '2009-07-13 15:20:08');
INSERT INTO `va_categories` VALUES(94, 0, 17, '0,', '���������� ������', '', 1, 1, 1, 1, 0, 0, 1, 1, '<br>', '<br>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 680, 1, 1, '2009-07-13 14:59:53', '2009-07-13 14:59:53');

-- --------------------------------------------------------

--
-- ��������� ������� `va_features`
--

CREATE TABLE `va_features` (
  `feature_id` int(11) NOT NULL auto_increment,
  `item_id` int(11) default '0',
  `group_id` int(11) default '0',
  `google_base_attribute_id` int(11) default '0',
  `feature_name` varchar(255) character set utf8 default NULL,
  `feature_value` varchar(255) default NULL,
  PRIMARY KEY  (`feature_id`),
  KEY `google_base_attribute_id` (`google_base_attribute_id`),
  KEY `group_id` (`group_id`),
  KEY `item_id` (`item_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=394 ;

--
-- ���� ������ ������� `va_features`
--

INSERT INTO `va_features` VALUES(57, 2, 4, NULL, '��������(�)', '������� 925�, ������� �����');
INSERT INTO `va_features` VALUES(58, 2, 4, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(59, 2, 4, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(60, 3, 4, NULL, '��������(�)', '������� 925�, ������� �����');
INSERT INTO `va_features` VALUES(63, 4, 4, NULL, '��������(�)', '������� 925�, ������� �����');
INSERT INTO `va_features` VALUES(54, 1, 4, NULL, '��������(�)', '������� 925�, ������� �����');
INSERT INTO `va_features` VALUES(66, 5, 4, NULL, '��������(�)', '������� 925�, ������� �����');
INSERT INTO `va_features` VALUES(69, 6, 4, NULL, '��������(�)', '������� 925�, ������� �����');
INSERT INTO `va_features` VALUES(72, 7, 4, NULL, '��������(�)', '������� 925�, ������� �����');
INSERT INTO `va_features` VALUES(75, 8, 4, NULL, '��������(�)', '������� 925�, ������� �����');
INSERT INTO `va_features` VALUES(78, 9, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(81, 10, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(84, 11, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(87, 12, 4, NULL, '��������(�)', '������� 925�, ������� �����');
INSERT INTO `va_features` VALUES(90, 13, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(93, 14, 4, NULL, '��������(�)', '������� 925�, ������� �����');
INSERT INTO `va_features` VALUES(96, 15, 4, NULL, '��������(�)', '������� 925�, ������� �����');
INSERT INTO `va_features` VALUES(99, 16, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(102, 17, 4, NULL, '��������(�)', '������� 925�, ������� �����');
INSERT INTO `va_features` VALUES(105, 18, 4, NULL, '��������(�)', '������� 925�, ������� �����');
INSERT INTO `va_features` VALUES(108, 19, 4, NULL, '��������(�)', '������� 925�, ������� �����');
INSERT INTO `va_features` VALUES(111, 20, 4, NULL, '��������(�)', '������� 925�, ������� �����');
INSERT INTO `va_features` VALUES(114, 21, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(115, 21, 4, NULL, '������� 1', '�������');
INSERT INTO `va_features` VALUES(117, 22, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(118, 22, 4, NULL, '������� 1', '������ ����.');
INSERT INTO `va_features` VALUES(120, 23, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(121, 23, 4, NULL, '������� 1', '������ ����.');
INSERT INTO `va_features` VALUES(123, 24, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(126, 25, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(129, 26, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(130, 27, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(131, 27, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(132, 27, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(133, 30, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(134, 30, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(135, 30, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(136, 29, 4, NULL, '��������(�)', '������� 925�, ������� �����');
INSERT INTO `va_features` VALUES(137, 29, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(138, 29, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(139, 31, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(140, 31, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(141, 31, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(142, 32, 4, NULL, '��������(�)', '������� 925�, ������� �����');
INSERT INTO `va_features` VALUES(143, 32, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(144, 32, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(145, 33, 4, NULL, '��������(�)', '������� 925�, ������� �����');
INSERT INTO `va_features` VALUES(146, 33, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(147, 33, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(148, 34, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(149, 34, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(150, 34, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(151, 35, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(152, 35, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(153, 35, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(154, 36, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(155, 36, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(156, 36, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(157, 37, 4, NULL, '��������(�)', '������� 925�, ������� �����');
INSERT INTO `va_features` VALUES(158, 37, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(159, 37, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(160, 38, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(161, 38, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(162, 38, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(163, 39, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(164, 39, 4, NULL, '������� 1', '������ ����.');
INSERT INTO `va_features` VALUES(165, 39, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(166, 40, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(167, 40, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(168, 40, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(169, 41, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(170, 41, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(171, 41, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(172, 42, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(173, 42, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(174, 42, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(175, 43, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(176, 43, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(177, 43, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(178, 44, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(179, 44, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(180, 44, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(181, 45, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(182, 45, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(183, 45, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(184, 46, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(185, 46, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(186, 46, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(187, 47, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(188, 47, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(189, 47, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(190, 48, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(191, 48, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(192, 48, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(193, 49, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(194, 49, 4, NULL, '������� 1', '������ ����.');
INSERT INTO `va_features` VALUES(195, 49, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(196, 50, 4, NULL, '��������(�)', '������� 925�, ������� �����');
INSERT INTO `va_features` VALUES(197, 50, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(198, 50, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(199, 51, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(200, 51, 4, NULL, '������� 1', '������ ����.');
INSERT INTO `va_features` VALUES(201, 51, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(202, 52, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(203, 52, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(204, 52, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(205, 53, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(206, 53, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(207, 53, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(208, 54, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(209, 54, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(210, 54, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(211, 55, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(212, 55, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(213, 55, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(214, 56, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(215, 56, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(216, 56, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(217, 57, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(218, 57, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(219, 57, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(220, 58, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(221, 58, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(222, 58, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(223, 59, 4, NULL, '��������(�)', '������� 925�, ������');
INSERT INTO `va_features` VALUES(224, 59, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(225, 59, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(226, 60, 4, NULL, '��������(�)', '������� 925�, ������� �����, ������');
INSERT INTO `va_features` VALUES(227, 60, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(228, 60, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(229, 61, 4, NULL, '��������(�)', '������� 925�, ������');
INSERT INTO `va_features` VALUES(230, 61, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(231, 61, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(232, 62, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(233, 62, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(234, 62, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(235, 63, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(236, 63, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(237, 63, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(238, 64, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(239, 64, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(240, 64, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(241, 65, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(242, 65, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(243, 65, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(244, 66, 4, NULL, '��������(�)', '������� 925�, ������� �����');
INSERT INTO `va_features` VALUES(245, 66, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(246, 66, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(247, 67, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(248, 67, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(249, 67, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(250, 68, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(251, 68, 4, NULL, '������� 1', '������ ����.');
INSERT INTO `va_features` VALUES(252, 68, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(253, 69, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(254, 69, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(255, 69, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(256, 70, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(257, 70, 4, NULL, '������� 1', '������ ����.');
INSERT INTO `va_features` VALUES(258, 70, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(259, 71, 4, NULL, '��������(�)', '������� 925�, ������� �����');
INSERT INTO `va_features` VALUES(260, 71, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(261, 71, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(262, 72, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(263, 72, 4, NULL, '������� 1', '������ ����.');
INSERT INTO `va_features` VALUES(264, 72, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(265, 73, 4, NULL, '��������(�)', '������� 925�, ������� �����');
INSERT INTO `va_features` VALUES(266, 73, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(267, 73, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(268, 74, 4, NULL, '��������(�)', '������� 925�, ������� �����');
INSERT INTO `va_features` VALUES(269, 74, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(270, 74, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(271, 75, 4, NULL, '��������(�)', '������� 925�, ������� ������� 850�');
INSERT INTO `va_features` VALUES(272, 75, 4, NULL, '������� 1', '��� ��������');
INSERT INTO `va_features` VALUES(273, 75, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(274, 76, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(275, 76, 4, NULL, '������� 1', '��� ��������');
INSERT INTO `va_features` VALUES(276, 76, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(277, 77, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(278, 77, 4, NULL, '������� 1', '��� ��������');
INSERT INTO `va_features` VALUES(279, 77, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(280, 78, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(281, 78, 4, NULL, '������� 1', '��� ��������');
INSERT INTO `va_features` VALUES(282, 78, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(283, 79, 4, NULL, '��������(�)', '������� 925�, ������� �����');
INSERT INTO `va_features` VALUES(284, 79, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(285, 79, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(286, 80, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(287, 80, 4, NULL, '������� 1', '��� ��������');
INSERT INTO `va_features` VALUES(288, 80, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(289, 82, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(290, 82, 4, NULL, '������� 1', '��� ��������');
INSERT INTO `va_features` VALUES(291, 82, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(292, 83, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(293, 83, 4, NULL, '������� 1', '��� ��������');
INSERT INTO `va_features` VALUES(294, 83, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(295, 84, 4, NULL, '��������(�)', '������� 925�, ������� �����');
INSERT INTO `va_features` VALUES(296, 84, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(297, 84, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(298, 85, 4, NULL, '��������(�)', '������� 925�, ������� ������� 850�');
INSERT INTO `va_features` VALUES(299, 85, 4, NULL, '������� 1', '������ ����.');
INSERT INTO `va_features` VALUES(300, 85, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(301, 86, 4, NULL, '��������(�)', '������� 925�, ������� ������� 850�');
INSERT INTO `va_features` VALUES(302, 86, 4, NULL, '������� 1', '��� ��������');
INSERT INTO `va_features` VALUES(303, 86, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(304, 87, 4, NULL, '��������(�)', '������� 925�, ������� ������� 850�');
INSERT INTO `va_features` VALUES(305, 87, 4, NULL, '������� 1', '������� ����.');
INSERT INTO `va_features` VALUES(306, 87, 4, NULL, '������� 2', '��� ��������');
INSERT INTO `va_features` VALUES(307, 89, 4, NULL, '��������(�)', '������� 925�, ������� ������� 850�');
INSERT INTO `va_features` VALUES(308, 89, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(309, 89, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(310, 90, 4, NULL, '��������(�)', '������� 925�, ������� ������� 850�');
INSERT INTO `va_features` VALUES(311, 90, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(312, 90, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(317, 91, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(316, 91, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(318, 91, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(319, 92, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(320, 92, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(321, 92, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(322, 93, 4, NULL, '��������(�)', '������� 925�, ������� ������� 850�');
INSERT INTO `va_features` VALUES(323, 93, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(324, 93, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(325, 94, 4, 0, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(326, 94, NULL, 0, '������� 1', NULL);
INSERT INTO `va_features` VALUES(327, 94, NULL, 0, '������� 2', NULL);
INSERT INTO `va_features` VALUES(328, 95, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(329, 95, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(330, 95, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(331, 96, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(332, 96, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(333, 96, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(334, 97, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(335, 97, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(336, 97, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(337, 98, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(338, 98, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(339, 98, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(340, 99, 4, NULL, '��������(�)', '������� 925�, ������� ������� 850�');
INSERT INTO `va_features` VALUES(341, 99, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(342, 99, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(343, 100, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(344, 100, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(345, 100, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(346, 101, 4, NULL, '��������(�)', '������� 925�, ������� ������� 850�');
INSERT INTO `va_features` VALUES(347, 101, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(348, 101, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(349, 102, 4, NULL, '��������(�)', '������� 925�, ������� ������� 850�');
INSERT INTO `va_features` VALUES(350, 102, 4, NULL, '������� 1', '������ ����.');
INSERT INTO `va_features` VALUES(351, 102, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(352, 103, 4, NULL, '��������(�)', '������� 925�, ������� ������� 850�');
INSERT INTO `va_features` VALUES(353, 103, 4, NULL, '������� 1', '��� ��������');
INSERT INTO `va_features` VALUES(354, 103, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(355, 104, 4, NULL, '��������(�)', '������� 925�, ������� ������� 850�');
INSERT INTO `va_features` VALUES(356, 104, 4, NULL, '������� 1', '��� ��������');
INSERT INTO `va_features` VALUES(357, 104, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(358, 107, 4, NULL, '��������(�)', '������� 925�, ������� ������� 850�');
INSERT INTO `va_features` VALUES(359, 107, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(360, 107, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(361, 108, 4, NULL, '��������(�)', '������� 925�, ������� ������� 850�');
INSERT INTO `va_features` VALUES(362, 108, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(363, 108, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(364, 109, 4, NULL, '��������(�)', '������� 925�, ������� ������� 850�');
INSERT INTO `va_features` VALUES(365, 109, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(366, 109, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(367, 110, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(368, 110, 4, NULL, '������� 1', '������');
INSERT INTO `va_features` VALUES(369, 110, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(370, 111, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(371, 111, 4, NULL, '������� 1', '������');
INSERT INTO `va_features` VALUES(372, 111, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(373, 112, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(374, 112, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(375, 112, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(376, 113, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(377, 113, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(378, 113, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(379, 114, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(380, 114, 4, NULL, '������� 1', '������');
INSERT INTO `va_features` VALUES(381, 114, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(382, 115, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(383, 115, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(384, 115, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(385, 116, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(386, 116, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(387, 116, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(388, 117, 4, NULL, '��������(�)', '������� 925�');
INSERT INTO `va_features` VALUES(389, 117, NULL, NULL, '������� 1', NULL);
INSERT INTO `va_features` VALUES(390, 117, NULL, NULL, '������� 2', NULL);
INSERT INTO `va_features` VALUES(391, 118, 4, 0, '��������(�)', '������� 925�, ������� ������� 850�');
INSERT INTO `va_features` VALUES(392, 118, 4, 0, '������� 1', '������');
INSERT INTO `va_features` VALUES(393, 118, NULL, 0, '������� 2', NULL);

-- --------------------------------------------------------

--
-- ��������� ������� `va_items`
--

CREATE TABLE `va_items` (
  `item_id` int(11) NOT NULL auto_increment,
  `item_code` varchar(64) default NULL,
  `item_name` varchar(255) NOT NULL,
  `friendly_url` varchar(255) default NULL,
  `item_order` int(11) NOT NULL default '1',
  `item_type_id` int(11) NOT NULL default '0',
  `google_base_type_id` int(11) default '0',
  `issue_date` datetime default NULL,
  `language_code` varchar(4) default NULL,
  `manufacturer_id` int(11) default NULL,
  `manufacturer_code` varchar(255) default NULL,
  `author_id` int(11) default NULL,
  `template_name` varchar(255) default NULL,
  `hide_add_list` tinyint(4) default '0',
  `hide_add_table` tinyint(4) default '0',
  `hide_add_grid` tinyint(4) default '0',
  `hide_add_details` tinyint(4) default '0',
  `features` text,
  `short_description` text,
  `full_desc_type` tinyint(4) default NULL,
  `full_description` text,
  `is_special_offer` tinyint(4) NOT NULL default '0',
  `special_offer` text,
  `notes` text,
  `tiny_image` varchar(255) default NULL,
  `tiny_image_alt` varchar(255) default NULL,
  `small_image` varchar(255) default NULL,
  `small_image_alt` varchar(255) default NULL,
  `big_image` varchar(255) default NULL,
  `big_image_alt` varchar(255) default NULL,
  `super_image` varchar(255) default NULL,
  `preview_url` varchar(255) default NULL,
  `preview_width` int(11) default NULL,
  `preview_height` int(11) default NULL,
  `specification` varchar(255) default NULL,
  `buying_price` double(16,2) default '0.00',
  `buying_price_id` int(11) default '0',
  `price` double(16,2) NOT NULL default '0.00',
  `price_id` int(11) default '0',
  `trade_price` double(16,2) NOT NULL default '0.00',
  `trade_price_id` int(11) default '0',
  `is_price_edit` tinyint(4) default '0',
  `properties_price` double(16,2) default '0.00',
  `properties_price_id` int(11) default '0',
  `tax_free` tinyint(4) default '0',
  `width` double(16,4) default '0.0000',
  `height` double(16,4) default '0.0000',
  `length` double(16,4) default '0.0000',
  `weight` double(16,4) default NULL,
  `min_quantity` int(11) default NULL,
  `max_quantity` int(11) default NULL,
  `quantity_increment` int(11) default NULL,
  `stock_level` int(11) default NULL,
  `use_stock_level` int(11) NOT NULL default '0',
  `hide_out_of_stock` tinyint(4) NOT NULL default '0',
  `disable_out_of_stock` tinyint(4) default '0',
  `is_shipping_free` tinyint(4) default '0',
  `shipping_in_stock` int(11) default NULL,
  `shipping_out_stock` int(11) default '0',
  `shipping_rule_id` int(11) default NULL,
  `shipping_cost` double(16,2) default NULL,
  `shipping_trade_cost` double(16,2) default NULL,
  `is_sales` tinyint(4) default NULL,
  `sales_price` double(16,2) NOT NULL default '0.00',
  `sales_price_id` int(11) default '0',
  `trade_sales` double(16,2) NOT NULL default '0.00',
  `trade_sales_id` int(11) default '0',
  `discount_percent` double(16,2) default NULL,
  `is_points_price` tinyint(4) default '0',
  `points_price` double(16,4) default NULL,
  `reward_type` int(11) default NULL,
  `reward_amount` double(16,4) default NULL,
  `credit_reward_type` tinyint(4) default NULL,
  `credit_reward_amount` double(16,2) default NULL,
  `is_recurring` tinyint(4) default '0',
  `recurring_period` int(11) default NULL,
  `recurring_interval` int(11) default NULL,
  `recurring_payments_total` int(11) default NULL,
  `recurring_start_date` datetime default NULL,
  `recurring_end_date` datetime default NULL,
  `affiliate_commission_type` int(11) default NULL,
  `affiliate_commission_amount` double(16,2) default NULL,
  `merchant_fee_type` int(11) default NULL,
  `merchant_fee_amount` double(16,2) default NULL,
  `downloadable` tinyint(4) default NULL,
  `download_period` int(11) default NULL,
  `download_path` text,
  `download_show_terms` int(11) default '0',
  `download_terms_text` text,
  `generate_serial` int(11) default '0',
  `serial_period` int(11) default NULL,
  `activations_number` int(11) default '0',
  `is_showing` tinyint(4) NOT NULL default '1',
  `is_approved` tinyint(4) NOT NULL default '1',
  `sites_all` tinyint(4) default '1',
  `user_types_all` tinyint(4) default '1',
  `is_compared` tinyint(4) default '0',
  `buy_link` varchar(255) default NULL,
  `total_views` int(11) default '0',
  `votes` int(11) default NULL,
  `points` int(11) default NULL,
  `rating` double(16,4) default NULL,
  `meta_title` varchar(255) default NULL,
  `meta_keywords` varchar(255) default NULL,
  `meta_description` varchar(255) default NULL,
  `mail_notify` int(11) default '0',
  `mail_to` varchar(255) default NULL,
  `mail_from` varchar(64) default NULL,
  `mail_cc` varchar(255) default NULL,
  `mail_bcc` varchar(255) default NULL,
  `mail_reply_to` varchar(64) default NULL,
  `mail_return_path` varchar(64) default NULL,
  `mail_type` int(11) default '0',
  `mail_subject` varchar(255) default NULL,
  `mail_body` text,
  `sms_notify` int(11) default '0',
  `sms_recipient` varchar(255) default NULL,
  `sms_originator` varchar(64) default NULL,
  `sms_message` text,
  `user_id` int(11) default '0',
  `admin_id_added_by` int(11) default '0',
  `admin_id_modified_by` int(11) default '0',
  `date_added` datetime default NULL,
  `date_modified` datetime default NULL,
  PRIMARY KEY  (`item_id`),
  KEY `buying_price_id` (`buying_price_id`),
  KEY `friendly_url` (`friendly_url`),
  KEY `google_base_type_id` (`google_base_type_id`),
  KEY `hide_out_of_stock` (`hide_out_of_stock`),
  KEY `is_approved` (`is_approved`),
  KEY `is_showing` (`is_showing`),
  KEY `is_special_offer` (`is_special_offer`),
  KEY `item_code` (`item_code`),
  KEY `item_name` (`item_name`),
  KEY `language_code` (`language_code`),
  KEY `price` (`price`),
  KEY `price_id` (`price_id`),
  KEY `properties_price_id` (`properties_price_id`),
  KEY `sales_price` (`sales_price`),
  KEY `sales_price_id` (`sales_price_id`),
  KEY `sites_all` (`sites_all`),
  KEY `trade_price` (`trade_price`),
  KEY `trade_price_id` (`trade_price_id`),
  KEY `trade_sales` (`trade_sales`),
  KEY `trade_sales_id` (`trade_sales_id`),
  KEY `user_id` (`user_id`),
  KEY `user_types_all` (`user_types_all`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=125 ;

--
-- ���� ������ ������� `va_items`
--

INSERT INTO `va_items` VALUES(9, '080332', '����� 080332', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Bokal 080332.jpg', NULL, 'images/small/Bokal 080332.jpg', NULL, 'images/big/Bokal 080332.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1091.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 88.9000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 32, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-16 09:59:31', '2009-07-16 09:59:31');
INSERT INTO `va_items` VALUES(8, '080318', '������ �������� 080318', '', 4, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Blyudze kofeynoe - 080318.jpg', NULL, 'images/small/Blyudze kofeynoe - 080318.jpg', NULL, 'images/big/Blyudze kofeynoe - 080318.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 557.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 34.1000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 16, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-16 09:56:48', '2009-07-16 09:56:48');
INSERT INTO `va_items` VALUES(1, '080500', '������ ������� "���������" 080500', '', 1, 8, 17, NULL, '', 3, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Blyudze detskoe - Klubnichka - 080500.jpg', NULL, 'images/small/Blyudze detskoe - Klubnichka - 080500.jpg', NULL, 'images/big/Blyudze detskoe - Klubnichka - 080500.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 838.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 64.2000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 52, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-13 15:48:57', '2009-07-21 13:55:24');
INSERT INTO `va_items` VALUES(2, '080502', '������ ������� "��������" 080502', '', 2, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Blyudze detskoe - Tzvetochek - 080502.jpg', NULL, 'images/small/Blyudze detskoe - Tzvetochek - 080502.jpg', NULL, 'images/big/Blyudze detskoe - Tzvetochek - 080502.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 838.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 60.4000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 21, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-16 09:35:18', '2009-07-16 09:35:18');
INSERT INTO `va_items` VALUES(3, '080358', '����� ������� "�������" 080358', '', 3, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Lojka detskaya - Bulldog - 080358.jpg', NULL, 'images/small/Lojka detskaya - Bulldog - 080358.jpg', NULL, 'images/big/Lojka detskaya - Bulldog - 080358.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 309.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 19.0000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 23, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-16 09:40:31', '2009-07-16 09:40:31');
INSERT INTO `va_items` VALUES(4, '080356', '����� ������� "����������" 080356', '', 4, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Lojka detskaya - Dalmatinetz - 080356.jpg', NULL, 'images/small/Lojka detskaya - Dalmatinetz - 080356.jpg', NULL, 'images/big/Lojka detskaya - Dalmatinetz - 080356.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 326.00, 0, 0.00, 0, 1, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 21.1000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 24, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-16 09:43:01', '2009-07-16 09:43:01');
INSERT INTO `va_items` VALUES(5, '080382', '������ "�������" 080382', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Blyudze Babochki 080382-Big.jpg', NULL, 'images/small/Blyudze Babochki 080382-Big.jpg', NULL, 'images/big/Blyudze Babochki 080382-Big.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 823.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 63.7000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 19, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-16 09:47:07', '2009-07-16 09:47:07');
INSERT INTO `va_items` VALUES(6, '080386', '������ "�������" 080386', '', 2, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Blyudze  - Delfin - 080386.jpg', NULL, 'images/small/Blyudze  - Delfin - 080386.jpg', NULL, 'images/big/Blyudze  - Delfin - 080386.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 803.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 64.2000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 17, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-16 09:49:51', '2009-07-16 09:49:51');
INSERT INTO `va_items` VALUES(7, '080388', '������ "��������" 080388', '', 3, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Blyudze  - Korablik - 080388.jpg', NULL, 'images/small/Blyudze  - Korablik - 080388.jpg', NULL, 'images/big/Blyudze  - Korablik - 080388.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 811.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 64.3000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-16 09:52:57', '2009-07-16 09:52:57');
INSERT INTO `va_items` VALUES(10, '080352', '����� 080352', '', 2, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Bokal 080352.jpg', NULL, 'images/small/Bokal 080352.jpg', NULL, 'images/big/Bokal 080352.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1269.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 90.4000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 27, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-16 10:09:50', '2009-07-16 10:09:50');
INSERT INTO `va_items` VALUES(11, '080368', '����� 080368', '', 3, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Bokal 080368.jpg', NULL, 'images/small/Bokal 080368.jpg', NULL, 'images/big/Bokal 080368.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1291.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 89.7000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 18, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-16 10:11:33', '2009-07-16 10:11:33');
INSERT INTO `va_items` VALUES(12, '080436', '����� 080436', '', 4, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Bokal 080436.jpg', NULL, 'images/small/Bokal 080436.jpg', NULL, 'images/big/Bokal 080436.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1370.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 120.1000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 17, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-16 10:13:33', '2009-07-16 10:13:33');
INSERT INTO `va_items` VALUES(13, '080620', '�������� 080620', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, '<br>', '\r\n   \r\n\r\n    \r\n        \r\n            �������� ������� �� ���� ��������: ������ ������������� ��� ����, ����� ��������� ����, ����������� � ������� �������.', 1, '\r\n   \r\n\r\n    \r\n        \r\n            �������� ������� �� ���� ��������: ������ ������������� ��� ����, ����� ��������� ����, ����������� � ������� �������.', 0, NULL, NULL, 'images/tiny/Ikornitza 080620.jpg', NULL, 'images/small/Ikornitza 080620.jpg', NULL, 'images/big/Ikornitza 080620.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 2950.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 206.0000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 30, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-16 10:16:30', '2009-07-16 10:16:30');
INSERT INTO `va_items` VALUES(14, '080178', '�������� 080178', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Kofeynik 080178.jpg', NULL, 'images/small/Kofeynik 080178.jpg', NULL, 'images/big/Kofeynik 080178.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 5796.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 438.0000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 16, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-16 10:19:07', '2009-07-16 10:19:07');
INSERT INTO `va_items` VALUES(15, '080480', '�������� 080480', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Kremanka 080480.jpg', NULL, 'images/small/Kremanka 080480.jpg', NULL, 'images/big/Kremanka 080480.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 2105.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 180.2000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 20, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-16 10:21:47', '2009-07-16 10:21:47');
INSERT INTO `va_items` VALUES(16, '080518', '�������� 080518', '', 2, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Kremanka 080518.jpg', NULL, 'images/small/Kremanka 080518.jpg', NULL, 'images/big/Kremanka 080518.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 2357.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 200.5000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 17, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-16 10:31:54', '2009-07-16 10:31:54');
INSERT INTO `va_items` VALUES(17, '080130', '������ 080130', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Krujka 080130.jpg', NULL, 'images/small/Krujka 080130.jpg', NULL, 'images/big/Krujka 080130.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1283.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 105.7000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-16 10:34:35', '2009-07-16 10:34:35');
INSERT INTO `va_items` VALUES(18, '080132', '������ 080132', '', 2, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Krujka 080132.jpg', NULL, 'images/small/Krujka 080132.jpg', NULL, 'images/big/Krujka 080132.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1231.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 103.1000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-16 10:36:41', '2009-07-16 10:36:41');
INSERT INTO `va_items` VALUES(19, '080172', '������ 080172', '', 3, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Krujka 080172.jpg', NULL, 'images/small/Krujka 080172.jpg', NULL, 'images/big/Krujka 080172.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1217.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 109.8000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 17, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-16 10:38:49', '2009-07-16 10:38:49');
INSERT INTO `va_items` VALUES(20, '080174', '������ 080174', '', 4, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Krujka 080174.jpg', NULL, 'images/small/Krujka 080174.jpg', NULL, 'images/big/Krujka 080174.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1128.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 106.0000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 19, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-16 10:41:01', '2009-07-16 10:41:01');
INSERT INTO `va_items` VALUES(21, '040016', '����� 040016', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Kubok 040016.jpg', NULL, 'images/small/Kubok 040016.jpg', NULL, 'images/big/Kubok 040016.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 8086.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 366.5000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-16 10:43:21', '2009-07-16 10:43:21');
INSERT INTO `va_items` VALUES(22, '120002', '����� 120002', '', 2, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Kubok 120002.jpg', NULL, 'images/small/Kubok 120002.jpg', NULL, 'images/big/Kubok 120002.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 8605.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 430.0000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 14, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-16 10:45:19', '2009-07-16 10:45:19');
INSERT INTO `va_items` VALUES(23, '120004', '����� 120004', '', 3, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Kubok 120004.jpg', NULL, 'images/small/Kubok 120004.jpg', NULL, 'images/big/Kubok 120004.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 8524.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 410.8000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 16, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-16 10:47:05', '2009-07-16 10:47:05');
INSERT INTO `va_items` VALUES(24, '080516', '������ 080516', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Kuvshin 080516.jpg', NULL, 'images/small/Kuvshin 080516.jpg', NULL, 'images/big/Kuvshin 080516.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 4413.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 380.0000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 18, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-16 10:49:14', '2009-07-16 10:49:14');
INSERT INTO `va_items` VALUES(25, '090022', '������ 090022', '', 2, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Kuvshin 090022.jpg', NULL, 'images/small/Kuvshin 090022.jpg', NULL, 'images/big/Kuvshin 090022.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 6283.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 412.4000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 20, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-16 10:51:11', '2009-07-16 10:51:11');
INSERT INTO `va_items` VALUES(26, '090023', '������ 090023', '', 3, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Kuvshin 090023.jpg', NULL, 'images/small/Kuvshin 090023.jpg', NULL, 'images/big/Kuvshin 090023.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 6958.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 371.0000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-16 10:52:41', '2009-07-16 10:52:41');
INSERT INTO `va_items` VALUES(27, '090025', '������ 090025', '', 4, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Kuvshin 090025.jpg', NULL, 'images/small/Kuvshin 090025.jpg', NULL, 'images/big/Kuvshin 090025.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 3324.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 183.2000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 20, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-16 10:54:50', '2009-07-16 10:54:50');
INSERT INTO `va_items` VALUES(28, '080704', '����� "�������" 080704', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Lojka - Streletz- 080704.jpg', NULL, 'images/small/Lojka - Streletz- 080704.jpg', NULL, 'images/big/Lojka - Streletz- 080704.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 441.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 25.6000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 22, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-17 18:03:25', '2009-07-19 10:03:45');
INSERT INTO `va_items` VALUES(29, '080530', '����� "������� �������" 080530', '', 2, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Lojka - Hristos Voskres - 080350.jpg', NULL, 'images/small/Lojka - Hristos Voskres - 080350.jpg', NULL, 'images/big/Lojka - Hristos Voskres - 080350.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 262.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 23.2000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 19, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-19 10:27:46', '2009-07-19 10:27:46');
INSERT INTO `va_items` VALUES(30, '080025', '����� 080025', '', 3, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Lojka - 080025.jpg', NULL, 'images/small/Lojka - 080025.jpg', NULL, 'images/big/Lojka - 080025.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 242.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 10.6000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 17, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-19 14:04:04', '2009-07-19 14:04:04');
INSERT INTO `va_items` VALUES(31, '080026', '����� 080026', '', 4, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Lojka - 080026.jpg', NULL, 'images/small/Lojka - 080026.jpg', NULL, 'images/big/Lojka - 080026.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 248.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 9.5000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 19, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 08:38:40', '2009-07-20 08:38:40');
INSERT INTO `va_items` VALUES(32, '080166', '�������� 080166', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Molochnik 080166.jpg', NULL, 'images/small/Molochnik 080166.jpg', NULL, 'images/big/Molochnik 080166.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 4491.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 296.8000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 19, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 08:41:30', '2009-07-20 08:41:30');
INSERT INTO `va_items` VALUES(33, '080298', '�������� 080298', '', 2, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Molochnik 080298.jpg', NULL, 'images/small/Molochnik 080298.jpg', NULL, 'images/big/Molochnik 080298.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 4566.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 295.0000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 08:43:24', '2009-07-20 08:43:24');
INSERT INTO `va_items` VALUES(34, '090017', '������ 090017', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Podnos 090017.jpg', NULL, 'images/small/Podnos 090017.jpg', NULL, 'images/big/Podnos 090017.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 2365.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 269.2000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 19, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 08:45:57', '2009-07-20 08:45:57');
INSERT INTO `va_items` VALUES(35, '090018', '������ 090018', '', 2, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Podnos 090018.jpg', NULL, 'images/small/Podnos 090018.jpg', NULL, 'images/big/Podnos 090018.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 2211.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 246.2000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 14, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 08:48:20', '2009-07-20 08:48:20');
INSERT INTO `va_items` VALUES(36, '090036', '������ 090036', '', 3, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Podnos 090036.jpg', NULL, 'images/small/Podnos 090036.jpg', NULL, 'images/big/Podnos 090036.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 4720.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 510.0000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 16, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 08:54:14', '2009-07-20 08:54:14');
INSERT INTO `va_items` VALUES(37, '080482', '���������� 080482', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Podsvechnik 080482.jpg', NULL, 'images/small/Podsvechnik 080482.jpg', NULL, 'images/big/Podsvechnik 080482.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1219.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 117.6000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 16, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 08:56:48', '2009-07-20 08:56:48');
INSERT INTO `va_items` VALUES(38, '090070', '���������� 090070', '', 2, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Podsvechnik 090070.jpg', NULL, 'images/small/Podsvechnik 090070.jpg', NULL, 'images/big/Podsvechnik 090070.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1601.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 119.3000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 16, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 08:58:57', '2009-07-20 08:58:57');
INSERT INTO `va_items` VALUES(39, '100002', '���������� 100002', '', 3, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Podsvechnik 100002.jpg', NULL, 'images/small/Podsvechnik 100002.jpg', NULL, 'images/big/Podsvechnik 100002.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 5160.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 313.8000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 14, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 09:00:47', '2009-07-20 09:00:47');
INSERT INTO `va_items` VALUES(40, '080370', '��������� ��� ���� 080370', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Podstavka dlya yaytza 080370.jpg', NULL, 'images/small/Podstavka dlya yaytza 080370.jpg', NULL, 'images/big/Podstavka dlya yaytza 080370.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 486.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 40.6000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 24, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 09:55:21', '2009-07-20 09:55:21');
INSERT INTO `va_items` VALUES(41, '080506', '������������ 080506', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Podstakannik 080506.jpg', NULL, 'images/small/Podstakannik 080506.jpg', NULL, 'images/big/Podstakannik 080506.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1199.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 105.2000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 21, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 09:57:33', '2009-07-20 09:57:33');
INSERT INTO `va_items` VALUES(42, '080170', '����� 080170', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Ryumka 080170.jpg', NULL, 'images/small/Ryumka 080170.jpg', NULL, 'images/big/Ryumka 080170.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 991.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 72.8000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 21, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 09:59:51', '2009-07-20 09:59:51');
INSERT INTO `va_items` VALUES(43, '080328', '����� 080328', '', 2, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Ryumka 080328.jpg', NULL, 'images/small/Ryumka 080328.jpg', NULL, 'images/big/Ryumka 080328.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 592.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 49.2000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 21, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 10:02:28', '2009-07-20 10:02:28');
INSERT INTO `va_items` VALUES(44, '080336', '����� 080336', '', 3, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Ryumka 080336.jpg', NULL, 'images/small/Ryumka 080336.jpg', NULL, 'images/big/Ryumka 080336.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 356.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 51.5000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 18, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 10:04:49', '2009-07-20 10:04:49');
INSERT INTO `va_items` VALUES(45, '080378', '����� 080378', '', 4, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Ryumka 080378.jpg', NULL, 'images/small/Ryumka 080378.jpg', NULL, 'images/big/Ryumka 080378.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1089.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 81.3000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 14, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 10:07:18', '2009-07-20 10:07:18');
INSERT INTO `va_items` VALUES(46, '080396', '���������� 080396', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Salfetnitza 080396.jpg', NULL, 'images/small/Salfetnitza 080396.jpg', NULL, 'images/big/Salfetnitza 080396.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 148.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 8.9000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 16, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 10:09:11', '2009-07-20 10:09:29');
INSERT INTO `va_items` VALUES(47, '080400', '���������� 080400', '', 2, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 256.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 22.6000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 16, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 10:10:33', '2009-07-20 10:10:33');
INSERT INTO `va_items` VALUES(48, '080536', '���������� 080536', '', 3, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Salfetnitza 080536.jpg', NULL, 'images/small/Salfetnitza 080536.jpg', NULL, 'images/big/Salfetnitza 080536.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 174.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 9.2000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 10:12:02', '2009-07-20 10:12:02');
INSERT INTO `va_items` VALUES(49, '040012', '��������� 040012', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Saharnitza 040012.jpg', NULL, 'images/small/Saharnitza 040012.jpg', NULL, 'images/big/Saharnitza 040012.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 4043.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 257.0000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 16, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 10:14:00', '2009-07-20 10:14:00');
INSERT INTO `va_items` VALUES(50, '080162', '��������� 080162', '', 2, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Saharnitza 080162.jpg', NULL, 'images/small/Saharnitza 080162.jpg', NULL, 'images/big/Saharnitza 080162.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 3098.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 266.5000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 16, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 10:15:26', '2009-07-20 10:15:26');
INSERT INTO `va_items` VALUES(51, '020004', '������ 020004', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Stakan 020004.jpg', NULL, 'images/small/Stakan 020004.jpg', NULL, 'images/big/Stakan 020004.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1432.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 117.4000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 16, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 10:26:10', '2009-07-20 10:26:10');
INSERT INTO `va_items` VALUES(52, '080126', '������ 080126', '', 2, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Stakan 080126.jpg', NULL, 'images/small/Stakan 080126.jpg', NULL, 'images/big/Stakan 080126.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 889.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 53.1000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 18, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 10:29:34', '2009-07-20 10:29:34');
INSERT INTO `va_items` VALUES(53, '080514', '������ 080514', '', 3, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 870.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 72.7000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 18, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 10:30:38', '2009-07-20 10:30:38');
INSERT INTO `va_items` VALUES(54, '080334', '������ "��������" 080334', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Stopka Vinograd 080334.jpg', NULL, 'images/small/Stopka Vinograd 080334.jpg', NULL, 'images/big/Stopka Vinograd 080334.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 494.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 39.1000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 18, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 10:32:52', '2009-07-20 10:32:52');
INSERT INTO `va_items` VALUES(55, '080342', '������ "�������" 080342', '', 2, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Stopka Kharkov 080342.jpg', NULL, 'images/small/Stopka Kharkov 080342.jpg', NULL, 'images/big/Stopka Kharkov 080342.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 503.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 37.0000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 18, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 10:34:48', '2009-07-20 10:34:48');
INSERT INTO `va_items` VALUES(56, '080120', '������ 080120', '', 3, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Stopka 080120.jpg', NULL, 'images/small/Stopka 080120.jpg', NULL, 'images/big/Stopka 080120.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 925.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 81.9000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 17, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 10:36:04', '2009-07-20 10:38:32');
INSERT INTO `va_items` VALUES(57, '080510', '������ 080510', '', 4, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Stopka 080510.jpg', NULL, 'images/small/Stopka 080510.jpg', NULL, 'images/big/Stopka 080510.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 510.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 41.7000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 17, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 10:37:33', '2009-07-20 10:37:33');
INSERT INTO `va_items` VALUES(58, '080216', '����� 080216', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/turka 080216.jpg', NULL, 'images/small/turka 080216.jpg', NULL, 'images/big/turka 080216.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1838.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 150.9000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 10:46:36', '2009-07-20 10:46:36');
INSERT INTO `va_items` VALUES(59, '080266', '����� 080266', '', 2, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/turka 080266.jpg', NULL, 'images/small/turka 080266.jpg', NULL, 'images/big/turka 080266.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1953.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 182.8000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 16, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 11:06:58', '2009-07-20 11:06:58');
INSERT INTO `va_items` VALUES(60, '080296', '����� 080296', '', 3, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/turka 080296.jpg', NULL, 'images/small/turka 080296.jpg', NULL, 'images/big/turka 080296.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 5247.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 379.0000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 14, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 11:11:48', '2009-07-20 11:11:48');
INSERT INTO `va_items` VALUES(61, '080596', '����� 080596', '', 4, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/turka 080596.jpg', NULL, 'images/small/turka 080596.jpg', NULL, 'images/big/turka 080596.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 2955.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 191.1000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 11:13:42', '2009-07-20 11:13:42');
INSERT INTO `va_items` VALUES(62, '080118', '����� 080118', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Flyaga 080118.jpg', NULL, 'images/small/Flyaga 080118.jpg', NULL, 'images/big/Flyaga 080118.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 4557.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 302.0000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 11:16:01', '2009-07-20 11:16:01');
INSERT INTO `va_items` VALUES(63, '080148', '����� 080148', '', 2, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Flyaga 080148.jpg', NULL, 'images/small/Flyaga 080148.jpg', NULL, 'images/big/Flyaga 080148.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 4454.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 254.0000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 18, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 11:18:10', '2009-07-20 11:18:10');
INSERT INTO `va_items` VALUES(64, '080280', '����� 080280', '', 3, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Flyaga 080280.jpg', NULL, 'images/small/Flyaga 080280.jpg', NULL, 'images/big/Flyaga 080280.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 4654.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 342.2000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 21, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 11:20:27', '2009-07-20 11:20:27');
INSERT INTO `va_items` VALUES(65, '080282', '����� 080282', '', 4, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Flyaga 080282.jpg', NULL, 'images/small/Flyaga 080282.jpg', NULL, 'images/big/Flyaga 080282.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 4601.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 353.7000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 11:22:01', '2009-07-20 11:22:01');
INSERT INTO `va_items` VALUES(66, '080152', '������ 080152', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Chaynik 080152.jpg', NULL, 'images/small/Chaynik 080152.jpg', NULL, 'images/big/Chaynik 080152.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 4414.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 295.2000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 14, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 11:25:01', '2009-07-20 11:25:01');
INSERT INTO `va_items` VALUES(67, '080184', '������ 080184', '', 2, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Chaynik 080184.jpg', NULL, 'images/small/Chaynik 080184.jpg', NULL, 'images/big/Chaynik 080184.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 6760.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 392.0000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 11:26:20', '2009-07-20 11:26:53');
INSERT INTO `va_items` VALUES(68, '020003', '���� 020003', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Chasha 020003.jpg', NULL, 'images/small/Chasha 020003.jpg', NULL, 'images/big/Chasha 020003.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1992.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 178.6000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 14, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 11:30:28', '2009-07-20 11:30:28');
INSERT INTO `va_items` VALUES(69, '090046', '���� 090046', '', 2, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Chasha 090046.jpg', NULL, 'images/small/Chasha 090046.jpg', NULL, 'images/big/Chasha 090046.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 822.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 69.3000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 11:32:11', '2009-07-20 11:32:11');
INSERT INTO `va_items` VALUES(70, '120006', '���� 120006', '', 3, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Chasha 120006.jpg', NULL, 'images/small/Chasha 120006.jpg', NULL, 'images/big/Chasha 120006.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 2146.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 157.3000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 14, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 11:35:23', '2009-07-20 11:35:23');
INSERT INTO `va_items` VALUES(71, '080320', '����� "������" 080320', '', 2, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Chashka Siren 080320.jpg', NULL, 'images/small/Chashka Siren 080320.jpg', NULL, 'images/big/Chashka Siren 080320.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 777.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 62.8000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 20, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 11:38:56', '2009-07-20 11:38:56');
INSERT INTO `va_items` VALUES(72, '040014', '����� 040014', '', 3, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Chashka 040014.jpg', NULL, 'images/small/Chashka 040014.jpg', NULL, 'images/big/Chashka 040014.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1155.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 88.8000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 17, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 11:40:30', '2009-07-20 11:40:30');
INSERT INTO `va_items` VALUES(73, '080364', '����� "�������" 080364', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Chashka Belochka 080364.jpg', NULL, 'images/small/Chashka Belochka 080364.jpg', NULL, 'images/big/Chashka Belochka 080364.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 741.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 86.4000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 11:42:20', '2009-07-20 11:42:20');
INSERT INTO `va_items` VALUES(74, '080154', '����� 080154', '', 4, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Chashka 080154.jpg', NULL, 'images/small/Chashka 080154.jpg', NULL, 'images/big/Chashka 080154.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1089.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 89.5000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 18, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 11:45:27', '2009-07-20 11:45:27');
INSERT INTO `va_items` VALUES(75, '018012', '������� 018012', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Braslet 018012.jpg', NULL, 'images/small/Braslet 018012.jpg', NULL, 'images/big/Braslet 018012.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 264.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 12.5000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 30, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 11:56:47', '2009-07-20 11:56:47');
INSERT INTO `va_items` VALUES(76, '028028', '������� 028028', '', 2, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Braslet 028028.jpg', NULL, 'images/small/Braslet 028028.jpg', NULL, 'images/big/Braslet 028028.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 460.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 31.3000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 23, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 11:58:27', '2009-07-20 11:58:27');
INSERT INTO `va_items` VALUES(77, '028098', '������� 028098', '', 3, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Braslet 028098.jpg', NULL, 'images/small/Braslet 028098.jpg', NULL, 'images/big/Braslet 028098.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 541.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 29.1000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 21, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 12:00:56', '2009-07-20 12:00:56');
INSERT INTO `va_items` VALUES(78, '028130', '������� 028130', '', 4, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Braslet 028130.jpg', NULL, 'images/small/Braslet 028130.jpg', NULL, 'images/big/Braslet 028130.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 243.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 12.4000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 23, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 12:02:17', '2009-07-20 12:28:55');
INSERT INTO `va_items` VALUES(79, '085192', '������� 085192', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Bulavka 085192.jpg', NULL, 'images/small/Bulavka 085192.jpg', NULL, 'images/big/Bulavka 085192.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 59.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 22, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 13:11:39', '2009-07-20 13:11:39');
INSERT INTO `va_items` VALUES(80, '023038', '����� 023038', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Brosh 023038.jpg', NULL, 'images/small/Brosh 023038.jpg', NULL, 'images/big/Brosh 023038.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 175.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 16, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 13:18:53', '2009-07-20 16:00:48');
INSERT INTO `va_items` VALUES(81, '023039', '����� 023039', '', 2, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Brosh 023039_1.jpg', NULL, 'images/small/Brosh 023039_1.jpg', NULL, 'images/big/Brosh 023039_1.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 149.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 16, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 14:28:17', '2009-07-20 14:28:17');
INSERT INTO `va_items` VALUES(82, '023041', '����� 023041', '', 3, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Brosh 023041.jpg', NULL, 'images/small/Brosh 023041.jpg', NULL, 'images/big/Brosh 023041.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 147.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 3.9000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 16:44:02', '2009-07-20 16:44:02');
INSERT INTO `va_items` VALUES(83, '025032', '����� 025032', '', 4, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Brosh 025032.jpg', NULL, 'images/small/Brosh 025032.jpg', NULL, 'images/big/Brosh 025032.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 99.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 17:09:44', '2009-07-20 17:09:44');
INSERT INTO `va_items` VALUES(84, '085206', '����� ��� �������� 085206', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Zajim dlya galstuka 085206.jpg', NULL, 'images/small/Zajim dlya galstuka 085206.jpg', NULL, 'images/big/Zajim dlya galstuka 085206.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 206.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 8.9000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 19, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 17:23:44', '2009-07-20 17:23:44');
INSERT INTO `va_items` VALUES(85, '011198', '������ 011198', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Koltzo 011198.jpg', NULL, 'images/small/Koltzo 011198.jpg', NULL, 'images/big/Koltzo 011198.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 100.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 2.6000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 18:06:47', '2009-07-20 18:06:47');
INSERT INTO `va_items` VALUES(86, '011278', '������ 011278', '', 2, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Koltzo 011278.jpg', NULL, 'images/small/Koltzo 011278.jpg', NULL, 'images/big/Koltzo 011278.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 121.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 4.0000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 18:09:35', '2009-07-20 18:09:35');
INSERT INTO `va_items` VALUES(87, '011281', '������ 011281', '', 3, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Koltzo 011281.jpg', NULL, 'images/small/Koltzo 011281.jpg', NULL, 'images/big/Koltzo 011281.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 150.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 4.9000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 18:12:05', '2009-07-20 18:12:05');
INSERT INTO `va_items` VALUES(88, '011320', '������ 011320', '', 4, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Koltzo 011320.jpg', NULL, 'images/small/Koltzo 011320.jpg', NULL, 'images/big/Koltzo 011320.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 88.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 4.0000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 18:14:49', '2009-07-20 18:14:49');
INSERT INTO `va_items` VALUES(89, '079121', '����� 079121', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Krest 079121.jpg', NULL, 'images/small/Krest 079121.jpg', NULL, 'images/big/Krest 079121.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 44.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 2.6000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-20 18:18:14', '2009-07-20 18:18:14');
INSERT INTO `va_items` VALUES(90, '079123', '����� 079123', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Krest 079123.jpg', NULL, 'images/small/Krest 079123.jpg', NULL, 'images/big/Krest 079123.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 168.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 11.0000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 19, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-21 11:14:32', '2009-07-21 11:14:38');
INSERT INTO `va_items` VALUES(91, '089036', '����� 089036', '', 2, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Krest 089036.jpg', NULL, 'images/small/Krest 089036.jpg', NULL, 'images/big/Krest 089036.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 35.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 1.4000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-21 13:09:16', '2009-07-21 13:09:16');
INSERT INTO `va_items` VALUES(92, '089071', '����� 089071', '', 3, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Krest 089071.jpg', NULL, 'images/small/Krest 089071.jpg', NULL, 'images/big/Krest 089071.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 37.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 3.0000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 22, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-21 13:11:27', '2009-07-21 13:11:27');
INSERT INTO `va_items` VALUES(93, '079114', '������� 079114 "�.�. ��������� �������"', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, '<br>', '<br>', 1, '����� ������ ������ ���������� �������� - ������� � ������ �� ���������\r\n������� �������� ����� ������ ����� ��������� ���������\r\n����������.��������� � ���� ����� � ������ ����������� ���� � ��������\r\n� ���� � ������������ � �������������� � ���.', 0, NULL, NULL, 'images/tiny/Ladanka 079114 -B.M. Nechayannaya Radost.jpg', NULL, 'images/small/Ladanka 079114 -B.M. Nechayannaya Radost.jpg', NULL, 'images/big/Ladanka 079114 -B.M. Nechayannaya Radost.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 221.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 15.4000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 18, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-21 13:14:50', '2009-07-21 13:14:50');
INSERT INTO `va_items` VALUES(94, '089180', '������� 089180 "��. ������� ����������"', '', 2, 8, -1, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, '<br>', '<br>', 1, '��������� ������� - ����� ������� � ������ ������. ��. ������� ����� �\r\n�������������� �����������, �������� ��������, ������� ����������. ��\r\n�������� ���� ������������ � ���� � ����� � ��������: ��������,\r\n��������������, ������� � ���������, �������� �������, ������������\r\n����������, ������� ��������� � ���� ���������� �������.', 0, NULL, NULL, 'images/tiny/Ladanka 089180 - Sv. Nikolay Chudotvoretz.jpg', NULL, 'images/small/Ladanka 089180 - Sv. Nikolay Chudotvoretz.jpg', NULL, 'images/big/Ladanka 089180 - Sv. Nikolay Chudotvoretz.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 45.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 3.5000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 17, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-21 13:23:12', '2009-07-21 13:23:12');
INSERT INTO `va_items` VALUES(95, '089322', '������� 089322 "�.�.�������������"', '', 3, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, '<br>', '<br>', 1, '���� �����, ���������� ������ ��������� ���������� ������������\r\n���������� ������� ������, ������� ����� ������ ���������� � ������\r\n����� . ����� ������ ������� �� ��������� ������, �������� ������� ��\r\n����� ������, � � ����� ����������� �� �������� ���������, ����������\r\n���������� ���������, ������� ����� ������� ����������.', 0, NULL, NULL, 'images/tiny/Ladanka 089322 -B.M. Semistrelnaya.jpg', NULL, 'images/small/Ladanka 089322 -B.M. Semistrelnaya.jpg', NULL, 'images/big/Ladanka 089322 -B.M. Semistrelnaya.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 56.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 4.4000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 20, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-21 13:48:25', '2009-07-21 13:48:25');
INSERT INTO `va_items` VALUES(96, '089343', '������� 089343 "�.�. ��������� �������"', '', 4, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, '<br>', '<br>', 1, '����� ������ ������ ���������� �������� - ������� � ������ �� ���������\r\n������� �������� ����� ������ ����� ��������� ���������\r\n����������.��������� � ���� ����� � ������ ����������� ���� � ��������\r\n� ���� � ������������ � �������������� � ���.', 0, NULL, NULL, 'images/tiny/Ladanka 089343 -B.M. Nechayannaya Radost.jpg', NULL, 'images/small/Ladanka 089343 -B.M. Nechayannaya Radost.jpg', NULL, 'images/big/Ladanka 089343 -B.M. Nechayannaya Radost.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 199.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 15.4000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 21, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-21 13:51:30', '2009-07-21 13:51:30');
INSERT INTO `va_items` VALUES(97, '084073', '����� 084073', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Kulon 084073.jpg', NULL, 'images/small/Kulon 084073.jpg', NULL, 'images/big/Kulon 084073.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 243.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 20, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-21 14:04:32', '2009-07-21 14:04:32');
INSERT INTO `va_items` VALUES(98, '089421', '�������� "��������" 089421', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Podveska -Bliznetzy- 089421.jpg', NULL, 'images/small/Podveska -Bliznetzy- 089421.jpg', NULL, 'images/big/Podveska -Bliznetzy- 089421.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 58.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 3.8000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 13, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-22 09:48:51', '2009-07-22 09:48:51');
INSERT INTO `va_items` VALUES(99, '079189', '�������� "����" 079189', '', 2, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Podveska -Vesy- 079189.jpg', NULL, 'images/small/Podveska -Vesy- 079189.jpg', NULL, 'images/big/Podveska -Vesy- 079189.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 62.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 3.8000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 14, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-22 09:50:40', '2009-07-22 09:50:40');
INSERT INTO `va_items` VALUES(100, '089358', '�������� "����" 089358', '', 3, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Podveska -Vesy- 089358.jpg', NULL, 'images/small/Podveska -Vesy- 089358.jpg', NULL, 'images/big/Podveska -Vesy- 089358.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 58.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 3.8000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 16, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-22 09:52:31', '2009-07-22 09:52:31');
INSERT INTO `va_items` VALUES(101, '079195', '�������� "�������" 079195', '', 4, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Podveska -Vodoley- 079195.jpg', NULL, 'images/small/Podveska -Vodoley- 079195.jpg', NULL, 'images/big/Podveska -Vodoley- 079195.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 62.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 3.8000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 13, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-22 09:54:41', '2009-07-22 09:54:41');
INSERT INTO `va_items` VALUES(102, '012020', '������ 012020', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Sergi 012020.jpg', NULL, 'images/small/Sergi 012020.jpg', NULL, 'images/big/Sergi 012020.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 80.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 2.2000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 14, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-22 09:58:03', '2009-07-22 09:58:03');
INSERT INTO `va_items` VALUES(103, '012160', '������ 012160', '', 2, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Sergi 012160.jpg', NULL, 'images/small/Sergi 012160.jpg', NULL, 'images/big/Sergi 012160.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 56.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 2.3000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 14, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-22 10:02:56', '2009-07-22 10:02:56');
INSERT INTO `va_items` VALUES(104, '012171', '������ 012171', '', 3, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Sergi 012171.jpg', NULL, 'images/small/Sergi 012171.jpg', NULL, 'images/big/Sergi 012171.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 48.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 1.5000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 16, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-22 10:04:28', '2009-07-22 10:04:28');
INSERT INTO `va_items` VALUES(105, '012246', '������ 012246', '', 4, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Sergi 012246.jpg', NULL, 'images/small/Sergi 012246.jpg', NULL, 'images/big/Sergi 012246.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 143.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 4.5000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 20, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-22 10:05:57', '2009-07-22 10:05:57');
INSERT INTO `va_items` VALUES(106, '077343', '���� "�������� ��������" 077343', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Tzep -Arabskiy Bissmark- 077343.jpg', NULL, 'images/small/Tzep -Arabskiy Bissmark- 077343.jpg', NULL, 'images/big/Tzep -Arabskiy Bissmark- 077343.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 442.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 15.4000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 25, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-22 10:09:25', '2009-07-22 10:09:25');
INSERT INTO `va_items` VALUES(107, '077007', '���� "������������" 077007', '', 2, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Tzep -Venetzianskaya- 077007.jpg', NULL, 'images/small/Tzep -Venetzianskaya- 077007.jpg', NULL, 'images/big/Tzep -Venetzianskaya- 077007.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 122.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 2.5000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-22 11:46:14', '2009-07-22 11:46:14');
INSERT INTO `va_items` VALUES(108, '077009', '���� "������������" 077009', '', 3, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Tzep -Venetzianskaya- 077009.jpg', NULL, 'images/small/Tzep -Venetzianskaya- 077009.jpg', NULL, 'images/big/Tzep -Venetzianskaya- 077009.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 142.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 3.1000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 12, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-22 11:49:35', '2009-07-22 11:49:35');
INSERT INTO `va_items` VALUES(109, '077319', '���� "�����������" 077319', '', 4, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Tzep -Garribaldi- 077319.jpg', NULL, 'images/small/Tzep -Garribaldi- 077319.jpg', NULL, 'images/big/Tzep -Garribaldi- 077319.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 421.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 15.4000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 31, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-22 11:51:31', '2009-07-22 11:51:31');
INSERT INTO `va_items` VALUES(110, '080181', '������� "������" 080181', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Suvenir - Boxer - 080181.jpg', NULL, 'images/small/Suvenir - Boxer - 080181.jpg', NULL, 'images/big/Suvenir - Boxer - 080181.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 389.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 8, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-22 11:54:22', '2009-07-22 11:54:22');
INSERT INTO `va_items` VALUES(111, '080207', '������� "���� �.�. ��������" 080207', '', 2, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Suvenir - Bust TG Schevchenko - 080207.jpg', NULL, 'images/small/Suvenir - Bust TG Schevchenko - 080207.jpg', NULL, 'images/big/Suvenir - Bust TG Schevchenko - 080207.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 534.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 7, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-22 11:57:11', '2009-07-22 11:57:11');
INSERT INTO `va_items` VALUES(112, '080294 ', '��������� 080294', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/080294_1.jpg', NULL, 'images/small/080294.jpg', NULL, 'images/big/080294.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 140.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 5.6000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 11, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-22 12:01:42', '2009-07-22 12:58:43');
INSERT INTO `va_items` VALUES(113, '080191', '������� "�����������" 080191', '', 1, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, '<br>', '<br>', 1, '<br>', 0, NULL, NULL, 'images/tiny/Suvenir - Kolokolchik - 080191.jpg', NULL, 'images/small/Suvenir - Kolokolchik - 080191.jpg', NULL, 'images/big/Suvenir - Kolokolchik - 080191.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 81.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 17, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-22 12:40:20', '2009-07-22 12:40:20');
INSERT INTO `va_items` VALUES(114, '080105', '������� "��������" 080105', '', 3, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Suvenir - Mercuriy - 080105.jpg', NULL, 'images/small/Suvenir - Mercuriy - 080105.jpg', NULL, 'images/big/Suvenir - Mercuriy - 080105.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 560.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 11, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-22 12:43:12', '2009-07-22 12:43:12');
INSERT INTO `va_items` VALUES(115, '080300 ', '��������� 080300 ', '', 2, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Ionizator 080300.jpg', NULL, 'images/small/Ionizator 080300.jpg', NULL, 'images/big/Ionizator 080300.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 175.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 8.7000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 41, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-22 13:00:35', '2009-07-22 13:00:35');
INSERT INTO `va_items` VALUES(116, '080306', '��������� 080306 ', '', 3, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Ionizator 080306.jpg', NULL, 'images/small/Ionizator 080306.jpg', NULL, 'images/big/Ionizator 080306.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 186.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 10.1000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 23, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-22 16:09:27', '2009-07-22 16:09:27');
INSERT INTO `va_items` VALUES(117, '080308 ', '��������� 080308 ', '', 4, 8, 17, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 0, NULL, NULL, 'images/tiny/Ionizator 080308.jpg', NULL, 'images/small/Ionizator 080308.jpg', NULL, 'images/big/Ionizator 080308.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 167.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 8.3000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 23, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-22 16:14:29', '2009-07-22 16:14:29');
INSERT INTO `va_items` VALUES(118, '080520', '����� ������� "���������" 080520', '', 5, 8, -1, NULL, '', 2, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, 1, NULL, 1, '<P><FONT style="BACKGROUND-COLOR: #d2d2d2" color=red><STRONG>������ 10%</STRONG></FONT></P>', NULL, 'images/tiny/011656.jpg', NULL, 'images/small/011656.jpg', NULL, 'images/big/011656.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 359.00, 0, 0.00, 0, 0, 0.00, 0, 0, 0.0000, 0.0000, 0.0000, 6.7000, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0.00, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, NULL, 89, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 1, 1, '2009-07-23 15:18:19', '2009-07-23 15:18:19');

-- --------------------------------------------------------

--
-- ��������� ������� `va_items_categories`
--

CREATE TABLE `va_items_categories` (
  `item_id` int(11) NOT NULL default '0',
  `category_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`item_id`,`category_id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- ���� ������ ������� `va_items_categories`
--

INSERT INTO `va_items_categories` VALUES(1, 100);
INSERT INTO `va_items_categories` VALUES(2, 100);
INSERT INTO `va_items_categories` VALUES(3, 100);
INSERT INTO `va_items_categories` VALUES(4, 100);
INSERT INTO `va_items_categories` VALUES(5, 101);
INSERT INTO `va_items_categories` VALUES(6, 101);
INSERT INTO `va_items_categories` VALUES(7, 101);
INSERT INTO `va_items_categories` VALUES(8, 101);
INSERT INTO `va_items_categories` VALUES(9, 102);
INSERT INTO `va_items_categories` VALUES(10, 102);
INSERT INTO `va_items_categories` VALUES(11, 102);
INSERT INTO `va_items_categories` VALUES(12, 102);
INSERT INTO `va_items_categories` VALUES(13, 103);
INSERT INTO `va_items_categories` VALUES(14, 104);
INSERT INTO `va_items_categories` VALUES(15, 105);
INSERT INTO `va_items_categories` VALUES(16, 105);
INSERT INTO `va_items_categories` VALUES(17, 106);
INSERT INTO `va_items_categories` VALUES(18, 106);
INSERT INTO `va_items_categories` VALUES(19, 106);
INSERT INTO `va_items_categories` VALUES(20, 106);
INSERT INTO `va_items_categories` VALUES(21, 107);
INSERT INTO `va_items_categories` VALUES(22, 107);
INSERT INTO `va_items_categories` VALUES(23, 107);
INSERT INTO `va_items_categories` VALUES(24, 108);
INSERT INTO `va_items_categories` VALUES(25, 108);
INSERT INTO `va_items_categories` VALUES(26, 108);
INSERT INTO `va_items_categories` VALUES(27, 108);
INSERT INTO `va_items_categories` VALUES(28, 109);
INSERT INTO `va_items_categories` VALUES(29, 109);
INSERT INTO `va_items_categories` VALUES(30, 109);
INSERT INTO `va_items_categories` VALUES(31, 109);
INSERT INTO `va_items_categories` VALUES(32, 110);
INSERT INTO `va_items_categories` VALUES(33, 110);
INSERT INTO `va_items_categories` VALUES(34, 111);
INSERT INTO `va_items_categories` VALUES(35, 111);
INSERT INTO `va_items_categories` VALUES(36, 111);
INSERT INTO `va_items_categories` VALUES(37, 112);
INSERT INTO `va_items_categories` VALUES(38, 112);
INSERT INTO `va_items_categories` VALUES(39, 112);
INSERT INTO `va_items_categories` VALUES(40, 113);
INSERT INTO `va_items_categories` VALUES(41, 114);
INSERT INTO `va_items_categories` VALUES(42, 115);
INSERT INTO `va_items_categories` VALUES(43, 115);
INSERT INTO `va_items_categories` VALUES(44, 115);
INSERT INTO `va_items_categories` VALUES(45, 115);
INSERT INTO `va_items_categories` VALUES(46, 116);
INSERT INTO `va_items_categories` VALUES(47, 116);
INSERT INTO `va_items_categories` VALUES(48, 116);
INSERT INTO `va_items_categories` VALUES(49, 117);
INSERT INTO `va_items_categories` VALUES(50, 117);
INSERT INTO `va_items_categories` VALUES(51, 118);
INSERT INTO `va_items_categories` VALUES(52, 118);
INSERT INTO `va_items_categories` VALUES(53, 118);
INSERT INTO `va_items_categories` VALUES(54, 119);
INSERT INTO `va_items_categories` VALUES(55, 119);
INSERT INTO `va_items_categories` VALUES(56, 119);
INSERT INTO `va_items_categories` VALUES(57, 119);
INSERT INTO `va_items_categories` VALUES(58, 121);
INSERT INTO `va_items_categories` VALUES(59, 121);
INSERT INTO `va_items_categories` VALUES(60, 121);
INSERT INTO `va_items_categories` VALUES(61, 121);
INSERT INTO `va_items_categories` VALUES(62, 122);
INSERT INTO `va_items_categories` VALUES(63, 122);
INSERT INTO `va_items_categories` VALUES(64, 122);
INSERT INTO `va_items_categories` VALUES(65, 122);
INSERT INTO `va_items_categories` VALUES(66, 124);
INSERT INTO `va_items_categories` VALUES(67, 124);
INSERT INTO `va_items_categories` VALUES(68, 125);
INSERT INTO `va_items_categories` VALUES(69, 125);
INSERT INTO `va_items_categories` VALUES(70, 125);
INSERT INTO `va_items_categories` VALUES(71, 126);
INSERT INTO `va_items_categories` VALUES(72, 126);
INSERT INTO `va_items_categories` VALUES(73, 126);
INSERT INTO `va_items_categories` VALUES(74, 126);
INSERT INTO `va_items_categories` VALUES(75, 127);
INSERT INTO `va_items_categories` VALUES(76, 127);
INSERT INTO `va_items_categories` VALUES(77, 127);
INSERT INTO `va_items_categories` VALUES(78, 127);
INSERT INTO `va_items_categories` VALUES(79, 128);
INSERT INTO `va_items_categories` VALUES(80, 129);
INSERT INTO `va_items_categories` VALUES(81, 129);
INSERT INTO `va_items_categories` VALUES(82, 129);
INSERT INTO `va_items_categories` VALUES(83, 129);
INSERT INTO `va_items_categories` VALUES(84, 130);
INSERT INTO `va_items_categories` VALUES(85, 132);
INSERT INTO `va_items_categories` VALUES(86, 132);
INSERT INTO `va_items_categories` VALUES(87, 132);
INSERT INTO `va_items_categories` VALUES(88, 132);
INSERT INTO `va_items_categories` VALUES(89, 134);
INSERT INTO `va_items_categories` VALUES(90, 134);
INSERT INTO `va_items_categories` VALUES(91, 134);
INSERT INTO `va_items_categories` VALUES(92, 134);
INSERT INTO `va_items_categories` VALUES(93, 135);
INSERT INTO `va_items_categories` VALUES(94, 135);
INSERT INTO `va_items_categories` VALUES(95, 135);
INSERT INTO `va_items_categories` VALUES(96, 135);
INSERT INTO `va_items_categories` VALUES(97, 136);
INSERT INTO `va_items_categories` VALUES(98, 138);
INSERT INTO `va_items_categories` VALUES(99, 138);
INSERT INTO `va_items_categories` VALUES(100, 138);
INSERT INTO `va_items_categories` VALUES(101, 138);
INSERT INTO `va_items_categories` VALUES(102, 139);
INSERT INTO `va_items_categories` VALUES(103, 139);
INSERT INTO `va_items_categories` VALUES(104, 139);
INSERT INTO `va_items_categories` VALUES(105, 139);
INSERT INTO `va_items_categories` VALUES(106, 96);
INSERT INTO `va_items_categories` VALUES(107, 96);
INSERT INTO `va_items_categories` VALUES(108, 96);
INSERT INTO `va_items_categories` VALUES(109, 96);
INSERT INTO `va_items_categories` VALUES(110, 97);
INSERT INTO `va_items_categories` VALUES(111, 97);
INSERT INTO `va_items_categories` VALUES(112, 98);
INSERT INTO `va_items_categories` VALUES(113, 97);
INSERT INTO `va_items_categories` VALUES(114, 97);
INSERT INTO `va_items_categories` VALUES(115, 98);
INSERT INTO `va_items_categories` VALUES(116, 98);
INSERT INTO `va_items_categories` VALUES(117, 98);
INSERT INTO `va_items_categories` VALUES(118, 100);