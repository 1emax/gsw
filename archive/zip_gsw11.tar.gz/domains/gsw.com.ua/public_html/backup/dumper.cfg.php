<?php
$this->SET = array(
'last_action' => '0',
'last_db_backup' => 'gswcomua_db',
'tables' => '',
'comp_method' => '1',
'comp_level' => '9',
'last_db_restore' => 'gswcomua_test',
'tables_exclude' => '0',
)
?>