<?php
/*
  ****************************************************************************
  ***                                                                      ***
  ***      ViArt Shop 3.5                                                  ***
  ***      File:  admin_upgrade.php                                        ***
  ***      Built: Fri Jun 20 19:43:16 2008                                 ***
  ***                                                 ***
  ***                                                                      ***
  ****************************************************************************
*/


	@set_time_limit(600);
	include_once("./admin_config.php");
	include_once($root_folder_path . "includes/common.php");
	include_once($root_folder_path . "includes/record.php");
	include_once($root_folder_path . "messages/" . $language_code . "/install_messages.php");
	include_once("./admin_common.php");

	check_admin_security("site_settings");

	$eol = get_eol();
	$operation = get_param("operation");

	// secondary connection to perform DB upgrade
	$dbs = new VA_SQL();
	$dbs->DBType      = $db_type;
	$dbs->DBDatabase  = $db_name;
	$dbs->DBUser      = $db_user;
	$dbs->DBPassword  = $db_password;
	$dbs->DBHost      = $db_host;
	$dbs->DBPort      = $db_port;
	$dbs->DBPersistent= $db_persistent;

	$t = new VA_Template($settings["admin_templates_dir"]);
	$t->set_file("main", "admin_upgrade.html");
	$t->set_var("admin_upgrade_href", "admin_upgrade.php");
	$upgrade_button = str_replace("{version_number}", VA_RELEASE, UPGRADE_BUTTON);

	include_once("./admin_header.php");
	include_once("./admin_footer.php");


	// end $last_version find out


	$version = array();

	$sql  = " SELECT setting_name, setting_value FROM " . $table_prefix . "global_settings ";
	$sql .= " WHERE setting_type='version' ";
	$db->query($sql);

	while ($db->next_record()) {
		$setting_name = $db->f("setting_name");
		$setting_value = $db->f("setting_value");
		$version[$setting_name] = $setting_value;
	}

	if (isset($version["number"])) {
		$current_db_version = $version["number"];
	} elseif (defined("VA_RELEASE")) {
		$current_db_version = VA_RELEASE;
	} else {
		$current_db_version = "2.5";
	}

	if ($operation == "upgrade") 
	{
		$ct = get_param("ct");
		$session_ct = get_session("session_ct");
		if ($ct != $session_ct) {
			set_session("session_ct", $ct);
			$sqls = array();

			// output information step by step during upgrade process
			$t->set_var("latest_version", VA_RELEASE);
			$t->parse("upgrade_result", false);
			$t->pparse("main");
			// start upgrading process
			echo "<script language=\"JavaScript\" type=\"text/javascript\">".$eol."<!--".$eol."upgradingProcess();".$eol."//-->".$eol."</script>".$eol;
			flush();

			// prepare some variables
			$errors = "";
			$db->HaltOnError = "no";
			$queries_success = 0;
			$queries_failed  = 0;

			if (comp_vers("2.5.1", $current_db_version) == 1) {
				$sqls[] = "ALTER TABLE " . $table_prefix . "users ADD COLUMN reset_password_code VARCHAR(64) ";
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "users ADD COLUMN reset_password_date DATETIME ",
					"postgre" => "ALTER TABLE " . $table_prefix . "users ADD COLUMN reset_password_date TIMESTAMP ",
					"access"  => "ALTER TABLE " . $table_prefix . "users ADD COLUMN reset_password_date DATETIME "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN order_id INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN order_id INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN order_id INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN order_item_id INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN order_item_id INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN order_item_id INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN failure_action INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN failure_action INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN failure_action INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$mysql_sql   = "CREATE TABLE " . $table_prefix . "items_prices (";
				$mysql_sql  .= "  `price_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql  .= "  `item_id` INT(11) default '0',";
				$mysql_sql  .= "  `is_active` INT(11) default '0',";
				$mysql_sql  .= "  `min_quantity` INT(11) default '1',";
				$mysql_sql  .= "  `max_quantity` INT(11) default '1',";
				$mysql_sql  .= "  `price` DOUBLE(16,2) default '0',";
				$mysql_sql  .= "  `discount_action` INT(11) default '0'";
				$mysql_sql  .= "  ,KEY item_id (item_id)";
				$mysql_sql  .= "  ,PRIMARY KEY (price_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "shipping_modules_parameters START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "items_prices (";
				$postgre_sql .= "  price_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "items_prices'),";
				$postgre_sql .= "  item_id INT4 default '0',";
				$postgre_sql .= "  is_active INT4 default '0',";
				$postgre_sql .= "  min_quantity INT4 default '1',";
				$postgre_sql .= "  max_quantity INT4 default '1',";
				$postgre_sql .= "  price FLOAT4 default '0',";
				$postgre_sql .= "  discount_action INT4 default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (price_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "items_prices (";
				$access_sql .= "  [price_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [item_id] INTEGER,";
				$access_sql .= "  [is_active] INTEGER,";
				$access_sql .= "  [min_quantity] INTEGER,";
				$access_sql .= "  [max_quantity] INTEGER,";
				$access_sql .= "  [price] FLOAT,";
				$access_sql .= "  [discount_action] INTEGER";
				$access_sql .= "  ,PRIMARY KEY (price_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "items_prices_item_id ON " . $table_prefix . "items_prices (item_id)";
				}

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN hide_add_list INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN hide_add_list INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN hide_add_list INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN hide_add_details INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN hide_add_details INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN hide_add_details INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = "ALTER TABLE " . $table_prefix . "pages ADD COLUMN meta_title VARCHAR(255) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "pages ADD COLUMN meta_description VARCHAR(255) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "pages ADD COLUMN meta_keywords VARCHAR(255) ";
			}

			if (comp_vers("2.5.3", $current_db_version) == 1) {
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "shipping_times ADD COLUMN availability_time INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "shipping_times ADD COLUMN availability_time INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "shipping_times ADD COLUMN availability_time INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "shipping_types ADD COLUMN shipping_order INT(11) default '1' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "shipping_types ADD COLUMN shipping_order INT4 default '1' ",
					"access"  => "ALTER TABLE " . $table_prefix . "shipping_types ADD COLUMN shipping_order INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "shipping_types ADD COLUMN shipping_time INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "shipping_types ADD COLUMN shipping_time INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "shipping_types ADD COLUMN shipping_time INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = "UPDATE " . $table_prefix . "shipping_types SET shipping_order=1 ";


				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN processing_time INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN processing_time INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN processing_time INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN shipping_expecting_date DATETIME ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN shipping_expecting_date TIMESTAMP ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN shipping_expecting_date DATETIME "
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN shipping_tracking_id VARCHAR(255) ";
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN shipping_expecting_date DATETIME ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN shipping_expecting_date TIMESTAMP ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN shipping_expecting_date DATETIME "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN is_rss INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN is_rss INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN is_rss INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN rss_limit INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN rss_limit INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN rss_limit INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN rss_on_breadcrumb INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN rss_on_breadcrumb INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN rss_on_breadcrumb INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN rss_on_list INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN rss_on_list INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN rss_on_list INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN admin_id_added_by INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN admin_id_added_by INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN admin_id_added_by INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN admin_id_modified_by INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN admin_id_modified_by INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN admin_id_modified_by INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN date_added DATETIME ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN date_added TIMESTAMP ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN date_added DATETIME "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN date_modified DATETIME ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN date_modified TIMESTAMP ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN date_modified DATETIME "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN admin_id_added_by INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN admin_id_added_by INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN admin_id_added_by INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN admin_id_modified_by INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN admin_id_modified_by INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN admin_id_modified_by INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN date_added DATETIME ",
					"postgre" => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN date_added TIMESTAMP ",
					"access"  => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN date_added DATETIME "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN date_modified DATETIME ",
					"postgre" => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN date_modified TIMESTAMP ",
					"access"  => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN date_modified DATETIME "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "support_priorities ADD COLUMN priority_rank INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "support_priorities ADD COLUMN priority_rank INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "support_priorities ADD COLUMN priority_rank INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "support_priorities ADD COLUMN is_default INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "support_priorities ADD COLUMN is_default INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "support_priorities ADD COLUMN is_default INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "support_priorities ADD COLUMN admin_html TEXT ",
					"postgre" => "ALTER TABLE " . $table_prefix . "support_priorities ADD COLUMN admin_html TEXT",
					"access"  => "ALTER TABLE " . $table_prefix . "support_priorities ADD COLUMN admin_html LONGTEXT"
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = "UPDATE " . $table_prefix . "support_priorities SET priority_rank=2 ";
				$sqls[] = "UPDATE " . $table_prefix . "support SET support_priority_id=2 WHERE support_priority_id IS NULL ";
				$sqls[] = "UPDATE " . $table_prefix . "support_priorities SET is_default=0, priority_rank=1, admin_html='<img src=\"../images/high.gif\" width=\"8\" height=\"12\" border=\"0\">' WHERE priority_id=1 ";
				$sqls[] = "UPDATE " . $table_prefix . "support_priorities SET is_default=1, priority_rank=2 WHERE priority_id=2 ";
				$sqls[] = "UPDATE " . $table_prefix . "support_priorities SET is_default=0, priority_rank=3, admin_html='<img src=\"../images/low.gif\" width=\"8\" height=\"12\" border=\"0\">' WHERE priority_id=3 ";


				$mysql_sql   = "CREATE TABLE " . $table_prefix . "banners (";
				$mysql_sql  .= "  `banner_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql  .= "  `banner_rank` INT(11) default '1',";
				$mysql_sql  .= "  `banner_title` VARCHAR(255),";
				$mysql_sql  .= "  `show_title` INT(11) default '0',";
				$mysql_sql  .= "  `image_src` VARCHAR(255),";
				$mysql_sql  .= "  `image_alt` VARCHAR(255),";
				$mysql_sql  .= "  `html_text` TEXT,";
				$mysql_sql  .= "  `target_url` VARCHAR(255),";
				$mysql_sql  .= "  `is_new_window` INT(11) default '0',";
				$mysql_sql  .= "  `is_active` INT(11) default '0',";
				$mysql_sql  .= "  `show_on_ssl` INT(11) default '0',";
				$mysql_sql  .= "  `max_impressions` INT(11) default '0',";
				$mysql_sql  .= "  `max_clicks` INT(11) default '0',";
				$mysql_sql  .= "  `expiry_date` DATETIME,";
				$mysql_sql  .= "  `total_impressions` INT(11) default '0',";
				$mysql_sql  .= "  `total_clicks` INT(11) default '0'";
				$mysql_sql  .= "  ,KEY is_active (is_active)";
				$mysql_sql  .= "  ,KEY max_clicks (max_clicks)";
				$mysql_sql  .= "  ,KEY max_impressions (max_impressions)";
				$mysql_sql  .= "  ,PRIMARY KEY (banner_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "banners START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "banners (";
				$postgre_sql .= "  banner_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "banners'),";
				$postgre_sql .= "  banner_rank INT4 default '1',";
				$postgre_sql .= "  banner_title VARCHAR(255),";
				$postgre_sql .= "  show_title INT4 default '0',";
				$postgre_sql .= "  image_src VARCHAR(255),";
				$postgre_sql .= "  image_alt VARCHAR(255),";
				$postgre_sql .= "  html_text TEXT,";
				$postgre_sql .= "  target_url VARCHAR(255),";
				$postgre_sql .= "  is_new_window INT4 default '0',";
				$postgre_sql .= "  is_active INT4 default '0',";
				$postgre_sql .= "  show_on_ssl INT4 default '0',";
				$postgre_sql .= "  max_impressions INT4 default '0',";
				$postgre_sql .= "  max_clicks INT4 default '0',";
				$postgre_sql .= "  expiry_date TIMESTAMP,";
				$postgre_sql .= "  total_impressions INT4 default '0',";
				$postgre_sql .= "  total_clicks INT4 default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (banner_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "banners (";
				$access_sql .= "  [banner_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [banner_rank] INTEGER,";
				$access_sql .= "  [banner_title] VARCHAR(255),";
				$access_sql .= "  [show_title] INTEGER,";
				$access_sql .= "  [image_src] VARCHAR(255),";
				$access_sql .= "  [image_alt] VARCHAR(255),";
				$access_sql .= "  [html_text] LONGTEXT,";
				$access_sql .= "  [target_url] VARCHAR(255),";
				$access_sql .= "  [is_new_window] INTEGER,";
				$access_sql .= "  [is_active] INTEGER,";
				$access_sql .= "  [show_on_ssl] INTEGER,";
				$access_sql .= "  [max_impressions] INTEGER,";
				$access_sql .= "  [max_clicks] INTEGER,";
				$access_sql .= "  [expiry_date] DATETIME,";
				$access_sql .= "  [total_impressions] INTEGER,";
				$access_sql .= "  [total_clicks] INTEGER";
				$access_sql .= "  ,PRIMARY KEY (banner_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "banners_is_active ON " . $table_prefix . "banners (is_active)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "banners_max_clicks ON " . $table_prefix . "banners (max_clicks)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "banners_max_impressions ON " . $table_prefix . "banners (max_impressions)";
				}


				$mysql_sql   = "CREATE TABLE " . $table_prefix . "banners_assigned (";
				$mysql_sql  .= "  `banner_id` INT(11) NOT NULL default '0',";
				$mysql_sql  .= "  `group_id` INT(11) NOT NULL default '0'";
				$mysql_sql  .= "  ,PRIMARY KEY (banner_id,group_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "banners_assigned START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "banners_assigned (";
				$postgre_sql .= "  banner_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  group_id INT4 NOT NULL default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (banner_id,group_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "banners_assigned (";
				$access_sql .= "  [banner_id] INTEGER NOT NULL,";
				$access_sql .= "  [group_id] INTEGER NOT NULL";
				$access_sql .= "  ,PRIMARY KEY (banner_id,group_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];


				$mysql_sql   = "CREATE TABLE " . $table_prefix . "banners_groups (";
				$mysql_sql  .= "  `group_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql  .= "  `group_name` VARCHAR(128),";
				$mysql_sql  .= "  `group_desc` TEXT,";
				$mysql_sql  .= "  `is_active` INT(11) default '0'";
				$mysql_sql  .= "  ,KEY is_active (is_active)";
				$mysql_sql  .= "  ,PRIMARY KEY (group_id))";

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "banners_groups_is_active ON " . $table_prefix . "banners_groups (is_active)";
				}

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "banners_groups START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "banners_groups (";
				$postgre_sql .= "  group_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "banners_groups'),";
				$postgre_sql .= "  group_name VARCHAR(128),";
				$postgre_sql .= "  group_desc TEXT,";
				$postgre_sql .= "  is_active INT4 default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (group_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "banners_groups (";
				$access_sql .= "  [group_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [group_name] VARCHAR(128),";
				$access_sql .= "  [group_desc] LONGTEXT,";
				$access_sql .= "  [is_active] INTEGER";
				$access_sql .= "  ,PRIMARY KEY (group_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				$mysql_sql   = "CREATE TABLE " . $table_prefix . "banners_clicks (";
				$mysql_sql  .= "  `click_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql  .= "  `banner_id` INT(11) default '0',";
				$mysql_sql  .= "  `user_id` INT(11) default '0',";
				$mysql_sql  .= "  `remote_address` VARCHAR(50),";
				$mysql_sql  .= "  `click_date` DATETIME NOT NULL";
				$mysql_sql  .= "  ,KEY banner_id (banner_id)";
				$mysql_sql  .= "  ,KEY click_date (click_date)";
				$mysql_sql  .= "  ,PRIMARY KEY (click_id)";
				$mysql_sql  .= "  ,KEY user_id (user_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "banners_clicks START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "banners_clicks (";
				$postgre_sql .= "  click_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "banners_clicks'),";
				$postgre_sql .= "  banner_id INT4 default '0',";
				$postgre_sql .= "  user_id INT4 default '0',";
				$postgre_sql .= "  remote_address VARCHAR(50),";
				$postgre_sql .= "  click_date TIMESTAMP NOT NULL";
				$postgre_sql .= "  ,PRIMARY KEY (click_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "banners_clicks (";
				$access_sql .= "  [click_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [banner_id] INTEGER,";
				$access_sql .= "  [user_id] INTEGER,";
				$access_sql .= "  [remote_address] VARCHAR(50),";
				$access_sql .= "  [click_date] DATETIME";
				$access_sql .= "  ,PRIMARY KEY (click_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "banners_clicks_banner_id ON " . $table_prefix . "banners_clicks (banner_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "banners_clicks_click_date ON " . $table_prefix . "banners_clicks (click_date)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "banners_clicks_user_id ON " . $table_prefix . "banners_clicks (user_id)";
				}

				$mysql_sql   = "CREATE TABLE " . $table_prefix . "support_users_priorities (";
				$mysql_sql  .= "  `user_priority_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql  .= "  `priority_id` INT(11) default '0',";
				$mysql_sql  .= "  `user_id` INT(11) default '0',";
				$mysql_sql  .= "  `user_email` VARCHAR(255)";
				$mysql_sql  .= "  ,PRIMARY KEY (user_priority_id)";
				$mysql_sql  .= "  ,KEY priority_id (priority_id)";
				$mysql_sql  .= "  ,KEY user_id (user_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "support_users_priorities START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "support_users_priorities (";
				$postgre_sql .= "  user_priority_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "support_users_priorities'),";
				$postgre_sql .= "  priority_id INT4 default '0',";
				$postgre_sql .= "  user_id INT4 default '0',";
				$postgre_sql .= "  user_email VARCHAR(255)";
				$postgre_sql .= "  ,PRIMARY KEY (user_priority_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "support_users_priorities (";
				$access_sql .= "  [user_priority_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [priority_id] INTEGER,";
				$access_sql .= "  [user_id] INTEGER,";
				$access_sql .= "  [user_email] VARCHAR(255)";
				$access_sql .= "  ,PRIMARY KEY (user_priority_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "support_users_priorities_31 ON " . $table_prefix . "support_users_priorities (priority_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "support_users_priorities_32 ON " . $table_prefix . "support_users_priorities (user_id)";
				}

				$sqls[] = "ALTER TABLE " . $table_prefix . "categories ADD COLUMN list_template VARCHAR(128) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "categories ADD COLUMN details_template VARCHAR(128) ";

				// update home page layout
				$layout_id = get_setting_value($settings, "layout_id");
				if (!strlen($layout_id)) {
					$sql = " SELECT MIN(layout_id) FROM " . $table_prefix . "layouts ";
					$db->query($sql);
					if ($db->next_record()) {
						$layout_id = $db->f("layout_id");
					}
				}
				$sql = "SELECT * FROM " . $table_prefix . "page_settings WHERE page_name='index' AND layout_id=" . $db->tosql($layout_id, INTEGER);
				$db->query($sql);
				while ($db->next_record()) {
					$setting_name = $db->f("setting_name");
					$setting_order = $db->f("setting_order");
					$setting_value = $db->f("setting_value");
					$sql  = " INSERT INTO " . $table_prefix . "page_settings (layout_id, page_name, setting_name, setting_order, setting_value) VALUES (0, 'index', ";
					$sql .= $db->tosql($setting_name, TEXT, true, false) . ",";
					$sql .= $db->tosql($setting_order, INTEGER) . ",";
					$sql .= $db->tosql($setting_value, TEXT, true, false) . ")";
					$sqls[] = $sql;
				}

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items_properties_values ADD COLUMN buying_price DOUBLE(16,2) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items_properties_values ADD COLUMN buying_price FLOAT4 default '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "items_properties_values ADD COLUMN buying_price FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items_properties_values ADD COLUMN `use_stock_level` INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items_properties_values ADD COLUMN use_stock_level INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "items_properties_values ADD COLUMN [use_stock_level] INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = "UPDATE " . $table_prefix . "items_properties_values SET hide_out_of_stock=0 ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN `pending_status_id` INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN pending_status_id INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN [pending_status_id] INTEGER "
				);
				$sqls[] = $sql_types[$db_type];
			}

			if (comp_vers("2.5.4", $current_db_version) == 1) {
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items_prices ADD COLUMN user_type_id INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items_prices ADD COLUMN user_type_id INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "items_prices ADD COLUMN user_type_id INTEGER "
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = "UPDATE " . $table_prefix . "items_prices SET user_type_id=0 ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN item_type_id INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN item_type_id INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN item_type_id INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "support_departments ADD COLUMN incoming_type_id INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "support_departments ADD COLUMN incoming_type_id INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "support_departments ADD COLUMN incoming_type_id INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "support_departments ADD COLUMN incoming_product_id INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "support_departments ADD COLUMN incoming_product_id INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "support_departments ADD COLUMN incoming_product_id INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = "ALTER TABLE " . $table_prefix . "support_attachments ADD COLUMN file_path VARCHAR(255) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "support_departments ADD COLUMN attachments_dir VARCHAR(255) ";
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "support_departments ADD COLUMN attachments_mask TEXT ",
					"postgre" => "ALTER TABLE " . $table_prefix . "support_departments ADD COLUMN attachments_mask TEXT ",
					"access"  => "ALTER TABLE " . $table_prefix . "support_departments ADD COLUMN attachments_mask LONGTEXT "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "languages ADD COLUMN language_order INT(11) default '1' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "languages ADD COLUMN language_order INT4 default '1' ",
					"access"  => "ALTER TABLE " . $table_prefix . "languages ADD COLUMN language_order INTEGER "
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = "UPDATE " . $table_prefix . "languages SET language_order=1 ";

			}

			if (comp_vers("2.5.5", $current_db_version) == 1) {

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "support ADD COLUMN admin_id_modified_by INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "support ADD COLUMN admin_id_modified_by INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "support ADD COLUMN admin_id_modified_by INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "support ADD COLUMN date_viewed DATETIME ",
					"postgre" => "ALTER TABLE " . $table_prefix . "support ADD COLUMN date_viewed TIMESTAMP ",
					"access"  => "ALTER TABLE " . $table_prefix . "support ADD COLUMN date_viewed DATETIME "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "support_messages ADD COLUMN date_modified DATETIME ",
					"postgre" => "ALTER TABLE " . $table_prefix . "support_messages ADD COLUMN date_modified TIMESTAMP ",
					"access"  => "ALTER TABLE " . $table_prefix . "support_messages ADD COLUMN date_modified DATETIME "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "support_messages ADD COLUMN admin_id_modified_by INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "support_messages ADD COLUMN admin_id_modified_by INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "support_messages ADD COLUMN admin_id_modified_by INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = "ALTER TABLE " . $table_prefix . "custom_blocks ADD COLUMN block_name VARCHAR(255) ";
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "custom_blocks ADD COLUMN block_notes TEXT ",
					"postgre" => "ALTER TABLE " . $table_prefix . "custom_blocks ADD COLUMN block_notes TEXT ",
					"access"  => "ALTER TABLE " . $table_prefix . "custom_blocks ADD COLUMN block_notes LONGTEXT "
				);
				$sqls[] = $sql_types[$db_type];
				$sql = " SELECT * FROM " . $table_prefix . "custom_blocks ";
				$db->query($sql);
				while ($db->next_record()) {
					$block_id = $db->f("block_id");
					$block_name = strip_tags(get_translation($db->f("block_title")));
					if (!$block_name) {
						$block_name = trim(strip_tags(get_translation($db->f("block_desc"))));
					}
					$words = explode(" ", $block_name);
					if (sizeof($words) > 5) {
						$block_name = "";
						for ($i = 0; $i < 5; $i++) {
							$block_name .= $words[$i] . " ";
						}
					}
					$sqls[] = "UPDATE " . $table_prefix . "custom_blocks SET block_name=" . $db->tosql($block_name, TEXT) . " WHERE block_id=" . $db->tosql($block_id, INTEGER);
				}

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN show_sub_products INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN show_sub_products INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN show_sub_products INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items_prices ADD COLUMN properties_discount DOUBLE(16,2) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items_prices ADD COLUMN properties_discount FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "items_prices ADD COLUMN properties_discount FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN use_on_second INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN use_on_second INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN use_on_second INTEGER "
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "items_properties SET use_on_second=0 ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN `is_list` INT(11) default '1' ",
					"postgre"  => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN is_list INT4 default '1' ",
					"access" => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN [is_list] INTEGER"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "order_statuses SET is_list=1 ";


				// update menu links for new structure
				$header_links = array();
				$sql = "SELECT * FROM " . $table_prefix . "header_links ";
				$db->query($sql);
				while ($db->next_record()) {
					$menu_id = $db->f("menu_id");
					$parent_menu_id = $db->f("parent_menu_id");
					$header_links[$menu_id] = $parent_menu_id;
				}
				foreach ($header_links as $menu_id => $parent_menu_id) {
					if (!$parent_menu_id || $parent_menu_id == $menu_id) {
						$parent_menu_id = 0;
					}
					$menu_path = ""; $current_parent_id = $parent_menu_id;
					while ($current_parent_id) {
						$menu_path = $current_parent_id.",".$menu_path;
						$sql = "SELECT parent_menu_id FROM " . $table_prefix . "header_links WHERE menu_id=".$db->tosql($current_parent_id, INTEGER);
						$db->query($sql);
						if ($db->next_record()) {
							$parent_id = $db->f("parent_menu_id");
							if ($parent_id == $current_parent_id) {
								$current_parent_id = 0;
							} else {
								$current_parent_id = $parent_id;
							}
						} else {
							$current_parent_id = 0;
						}
					}
					$sql  = " UPDATE " . $table_prefix . "header_links SET ";
					$sql .= " parent_menu_id=" . $db->tosql($parent_menu_id, INTEGER) . ", ";
					$sql .= " menu_path=" . $db->tosql($menu_path, TEXT);
					$sql .= " WHERE menu_id=" . $db->tosql($menu_id, INTEGER);
					$sqls[] = $sql;
				}


				//update for forum

				//create table forum_list
			  $mysql_sql = "CREATE TABLE `" . $table_prefix . "forum_list` (";
			  $mysql_sql .= "`forum_id` int(11) NOT NULL auto_increment,";
			  $mysql_sql .= "`category_id` int(11) NOT NULL,";
			  $mysql_sql .= "`forum_name` varchar(255) NOT NULL,";
			  $mysql_sql .= "`forum_order` int(11) default '0',";
			  $mysql_sql .= "`short_description` text,";
			  $mysql_sql .= "`full_description` text,";
			  $mysql_sql .= "`small_image` varchar(255),";
			  $mysql_sql .= "`large_image` varchar(255),";
			  $mysql_sql .= "`date_added` datetime NOT NULL default '0000-00-00 00:00:00',";
			  $mysql_sql .= "`threads_number` int(11) NOT NULL default '0',";
			  $mysql_sql .= "`messages_number` int(11) NOT NULL default '0',";
			  $mysql_sql .= "`last_post_added` datetime,";
			  $mysql_sql .= "`last_post_user_id` int(11) default '0',";
			  $mysql_sql .= "`last_post_thread_id` int(11) default '0',";
			  $mysql_sql .= "`allowed_view` int(11) default '0',";
			  $mysql_sql .= "PRIMARY KEY (`forum_id`),";
			  $mysql_sql .= "KEY `category_id` (`category_id`))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "forum_list START 1";
				}
			  $postgre_sql = "CREATE TABLE `" . $table_prefix . "forum_list` (";
			  $postgre_sql .= "`forum_id` INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "forum_list'),";
			  $postgre_sql .= "`category_id` INT4 NOT NULL,";
			  $postgre_sql .= "`forum_name` VARCHAR(255) NOT NULL,";
			  $postgre_sql .= "`forum_order` INT4 default '0',";
			  $postgre_sql .= "`short_description` TEXT,";
			  $postgre_sql .= "`full_description` TEXT,";
			  $postgre_sql .= "`small_image` VARCHAR(255),";
			  $postgre_sql .= "`large_image` VARCHAR(255),";
			  $postgre_sql .= "`date_added` TIMESTAMP NOT NULL,";
			  $postgre_sql .= "`threads_number` INT4 NOT NULL default '0',";
			  $postgre_sql .= "`messages_number` INT4 NOT NULL default '0',";
			  $postgre_sql .= "`last_post_added` TIMESTAMP ,";
			  $postgre_sql .= "`last_post_user_id` INT4 default '0',";
			  $postgre_sql .= "`last_post_thread_id` INT4 default '0',";
			  $postgre_sql .= "`allowed_view` INT4 default '0',";
			  $postgre_sql .= "PRIMARY KEY (`forum_id`))";

			  $access_sql = "CREATE TABLE " . $table_prefix . "forum_list (";
			  $access_sql .= "[forum_id] COUNTER NOT NULL,";
			  $access_sql .= "[category_id] INTEGER NOT NULL,";
			  $access_sql .= "[forum_name] VARCHAR(255) NOT NULL,";
			  $access_sql .= "[forum_order] INTEGER NOT NULL,";
			  $access_sql .= "[short_description] LONGTEXT,";
			  $access_sql .= "[full_description] LONGTEXT,";
			  $access_sql .= "[small_image] VARCHAR(255),";
			  $access_sql .= "[large_image] VARCHAR(255),";
			  $access_sql .= "[date_added] DATETIME NOT NULL,";
			  $access_sql .= "[threads_number] INTEGER NOT NULL,";
			  $access_sql .= "[messages_number] INTEGER NOT NULL,";
			  $access_sql .= "[last_post_added] DATETIME ,";
			  $access_sql .= "[last_post_user_id] INTEGER,";
			  $access_sql .= "[last_post_thread_id] INTEGER,";
			  $access_sql .= "[allowed_view] INTEGER NOT NULL,";
			  $access_sql .= "PRIMARY KEY (forum_id))";

			  $sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
			  $sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "forum_list_category_id ON " . $table_prefix . "forum_list (category_id)";
				}

				//create table forum_categories
			  $mysql_sql = "CREATE TABLE `" . $table_prefix . "forum_categories` (";
			  $mysql_sql .= "`category_id` int(11) NOT NULL auto_increment,";
			  $mysql_sql .= "`category_name` varchar(255) NOT NULL,";
			  $mysql_sql .= "`category_order` int(11) default '0',";
			  $mysql_sql .= "`short_description` text,";
			  $mysql_sql .= "`full_description` text,";
			  $mysql_sql .= "`allowed_view` int(11) default '0',";
			  $mysql_sql .= "PRIMARY KEY (`category_id`))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "forum_categories START 1";
				}
			  $postgre_sql = "CREATE TABLE `" . $table_prefix . "forum_categories` (";
			  $postgre_sql .= "`category_id` INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "forum_categories'),";
			  $postgre_sql .= "`category_name` VARCHAR(255) NOT NULL,";
			  $postgre_sql .= "`category_order` INT4 default '0',";
			  $postgre_sql .= "`short_description` TEXT,";
			  $postgre_sql .= "`full_description` TEXT,";
			  $postgre_sql .= "`allowed_view` INT4 default '0',";
			  $postgre_sql .= "PRIMARY KEY (`category_id`))";

			  $access_sql  = "CREATE TABLE `" . $table_prefix . "forum_categories` (";
			  $access_sql .= "[category_id] COUNTER  NOT NULL,";
			  $access_sql .= "[category_name] VARCHAR(255) NOT NULL,";
			  $access_sql .= "[category_order] INTEGER NOT NULL,";
			  $access_sql .= "[short_description] LONGTEXT,";
			  $access_sql .= "[full_description] LONGTEXT,";
			  $access_sql .= "[allowed_view] INTEGER NOT NULL,";
			  $access_sql .= "PRIMARY KEY (category_id))";

			  $sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
			  $sqls[] = $sql_types[$db_type];

				//create table forum_moderators
			  $mysql_sql  = "CREATE TABLE " . $table_prefix . "forum_moderators (";
			  $mysql_sql .= " `admin_id` INT(11) NOT NULL default '0',";
			  $mysql_sql .= " `forum_id` INT(11) NOT NULL default '0',";
			  $mysql_sql .= " `is_default_forum` INT(11) default '0'";
			  $mysql_sql .= " ,PRIMARY KEY (admin_id,forum_id))";

			  $postgre_sql  = "CREATE TABLE " . $table_prefix . "forum_moderators (";
			  $postgre_sql .= "  admin_id INT4 NOT NULL default '0',";
			  $postgre_sql .= "  forum_id INT4 NOT NULL default '0',";
			  $postgre_sql .= "  is_default_forum INT4 default '0'";
			  $postgre_sql .= "  ,PRIMARY KEY (admin_id,forum_id))";

			  $access_sql  = "CREATE TABLE " . $table_prefix . "forum_moderators (";
			  $access_sql .= "  [admin_id] INTEGER NOT NULL,";
			  $access_sql .= "  [forum_id] INTEGER NOT NULL,";
			  $access_sql .= "  [is_default_forum] INTEGER";
			  $access_sql .= "  ,PRIMARY KEY (admin_id,forum_id))";

			  $sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
			  $sqls[] = $sql_types[$db_type];

				//add field forum_id
			  $sql_types = array(
			  	"mysql"   => "ALTER TABLE " . $table_prefix . "forum ADD COLUMN forum_id INT(11) NOT NULL",
			  	"postgre" => "ALTER TABLE " . $table_prefix . "forum ADD COLUMN forum_id INT4 NOT NULL",
			  	"access"  => "ALTER TABLE " . $table_prefix . "forum ADD COLUMN forum_id INTEGER "
			  );
			  $sqls[] = $sql_types[$db_type];

				//add field user_id
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "forum_messages ADD COLUMN user_id INT(11) NULL ",
					"postgre" => "ALTER TABLE " . $table_prefix . "forum_messages ADD COLUMN user_id INT4 NULL",
					"access"  => "ALTER TABLE " . $table_prefix . "forum_messages ADD COLUMN user_id INTEGER "
				);
			  $sqls[] = $sql_types[$db_type];

				//make content for forum
				$sqls[] = "INSERT INTO " . $table_prefix . "forum_categories (category_name, category_order, short_description, full_description, allowed_view) VALUES ('General', 1, 'General category', 'General category', 1)";

				$date_added = va_time();
				$sql = "SELECT count(*) FROM " . $table_prefix . "forum";
				$threads_number = get_db_value($sql);
				$sql = "SELECT count(*) FROM " . $table_prefix . "forum_messages";
				$messages_number = get_db_value($sql);
				$sql = " SELECT thread_id, date_added, user_id FROM " . $table_prefix . "forum ORDER BY date_added DESC ";
				$db->RecordsPerPage = 1;
				$db->PageNumber = 1;
				if ($db->query($sql)) {
					if ($db->next_record()) {
						$last_post_added = $db->f("date_added");
						$last_post_user_id = $db->f("user_id");
						$last_post_thread_id = $db->f("thread_id");
					} else {
						$last_post_added = va_date();
						$last_post_user_id = 0;
						$last_post_thread_id = 0;
					}
				}

				$sql  = " INSERT INTO " . $table_prefix . "forum_list (category_id, forum_name, forum_order, date_added, threads_number, messages_number, last_post_added, last_post_user_id, last_post_thread_id, allowed_view) VALUES ";
				$sql .= " (1, 'Forum', 1, " . $db->tosql($date_added, DATETIME)  . ", " . $threads_number . ", " . $messages_number . ", " . $db->tosql($last_post_added, DATETIME) . ", " . $last_post_user_id . ", " . $last_post_thread_id . ", 1)";
				$sqls[] = $sql;

				$sqls[] = "UPDATE " . $table_prefix . "forum SET forum_id = 1";


				// create forum_topic list layout
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id, page_name, setting_name, setting_order, setting_value) VALUES (0, 'forum_topic', 'left_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id, page_name, setting_name, setting_order, setting_value) VALUES (0, 'forum_topic', 'left_column_width', NULL, '')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id, page_name, setting_name, setting_order, setting_value) VALUES (0, 'forum_topic', 'middle_column_hide', NULL, '0')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id, page_name, setting_name, setting_order, setting_value) VALUES (0, 'forum_topic', 'middle_column_width', NULL, '100%')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id, page_name, setting_name, setting_order, setting_value) VALUES (0, 'forum_topic', 'right_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id, page_name, setting_name, setting_order, setting_value) VALUES (0, 'forum_topic', 'right_column_width', NULL, '')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id, page_name, setting_name, setting_order, setting_value) VALUES (0, 'forum_topic', 'forum_view_topic', 0, 'middle')";

				// create forum_list list layout
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id, page_name, setting_name, setting_order, setting_value) VALUES (0, 'forum_list', 'left_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id, page_name, setting_name, setting_order, setting_value) VALUES (0, 'forum_list', 'left_column_width', NULL, '')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id, page_name, setting_name, setting_order, setting_value) VALUES (0, 'forum_list', 'middle_column_hide', NULL, '0')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id, page_name, setting_name, setting_order, setting_value) VALUES (0, 'forum_list', 'middle_column_width', NULL, '100%')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id, page_name, setting_name, setting_order, setting_value) VALUES (0, 'forum_list', 'right_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id, page_name, setting_name, setting_order, setting_value) VALUES (0, 'forum_list', 'right_column_width', NULL, '')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id, page_name, setting_name, setting_order, setting_value) VALUES (0, 'forum_list', 'forum_list', 0, 'middle')";

				// create forum_topics list layout
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id, page_name, setting_name, setting_order, setting_value) VALUES (0, 'forum_topics', 'left_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id, page_name, setting_name, setting_order, setting_value) VALUES (0, 'forum_topics', 'left_column_width', NULL, '')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id, page_name, setting_name, setting_order, setting_value) VALUES (0, 'forum_topics', 'middle_column_hide', NULL, '0')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id, page_name, setting_name, setting_order, setting_value) VALUES (0, 'forum_topics', 'middle_column_width', NULL, '100%')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id, page_name, setting_name, setting_order, setting_value) VALUES (0, 'forum_topics', 'right_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id, page_name, setting_name, setting_order, setting_value) VALUES (0, 'forum_topics', 'right_column_width', NULL, '')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id, page_name, setting_name, setting_order, setting_value) VALUES (0, 'forum_topics', 'forum_topics_block', 0, 'middle')";

				$sqls[] = " UPDATE " . $table_prefix . "header_links SET menu_url='forums.php' WHERE menu_url='forum.php'";
				//end update for forum

				//begin changes related to Knowledge Base settings
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "support_statuses ADD COLUMN is_add_knowledge INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "support_statuses ADD COLUMN is_add_knowledge INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "support_statuses ADD COLUMN is_add_knowledge INTEGER "
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = "INSERT INTO " . $table_prefix . "support_statuses (status_name, status_caption, is_internal, is_add_knowledge) VALUES ('Added to Knowledge Base', 'Add to KB', 1, 1)";
				$sql  = " INSERT INTO " . $table_prefix . "articles_categories (category_path, category_name, category_order, allowed_view, allowed_rate, article_list_fields, article_details_fields, article_required_fields) VALUES ";
				$sql .= " ('0,', 'Knowledge Base', 1, 1, 1, 'article_date,article_title,short_description', 'article_date,article_title,full_description', 'article_date,article_title,full_description')";
				$sqls[] = $sql;

				$sql = "SELECT max(category_id) FROM " . $table_prefix . "articles_categories";
				$category_id = get_db_value($sql) + 1;
				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (setting_type, setting_name, setting_value) VALUES ('support', 'knowledge_category', '$category_id')";

				$sql = "SELECT min(status_id) FROM " . $table_prefix . "articles_statuses";
				$article_status_id = get_db_value($sql);
				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (setting_type, setting_name, setting_value) VALUES ('support', 'knowledge_article_status', '$article_status_id')";
				//end changes related to Knowledge Base settings
			}


			if (comp_vers("2.6", $current_db_version) == 1) {
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN is_price_edit INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN is_price_edit INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN is_price_edit INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN issue_date DATETIME ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN issue_date TIMESTAMP ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN issue_date DATETIME "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN properties_price DOUBLE(16,2) default '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN properties_price FLOAT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN properties_price FLOAT"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "items SET properties_price=0 ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN processing_fee DOUBLE(16,2) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN processing_fee FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN processing_fee FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN fee_type INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN fee_type INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN fee_type INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN processing_fee DOUBLE(16,2) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN processing_fee FLOAT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN processing_fee FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = " ALTER TABLE ". $table_prefix . "black_ips DROP COLUMN adress_action ";
				$sqls[] = " ALTER TABLE ". $table_prefix . "black_ips DROP COLUMN adress_notes ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "black_ips ADD COLUMN address_action INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "black_ips ADD COLUMN address_action INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "black_ips ADD COLUMN address_action INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "black_ips ADD COLUMN address_notes TEXT ",
					"postgre" => "ALTER TABLE " . $table_prefix . "black_ips ADD COLUMN address_notes TEXT ",
					"access"  => "ALTER TABLE " . $table_prefix . "black_ips ADD COLUMN address_notes LONGTEXT "
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "black_ips SET address_action=1 ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN property_type_id INT(11) default '1' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN property_type_id INT4 default '1' ",
					"access"  => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN property_type_id INTEGER "
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "items_properties SET property_type_id=1 ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN sub_item_id INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN sub_item_id INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN sub_item_id INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN additional_price DOUBLE(16,2) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN additional_price FLOAT4 default '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN additional_price FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items_properties_values ADD COLUMN sub_item_id INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items_properties_values ADD COLUMN sub_item_id INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "items_properties_values ADD COLUMN sub_item_id INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$mysql_sql  = "CREATE TABLE ".$table_prefix."banned_contents (";
				$mysql_sql .= "  `content_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `content_text` VARCHAR(255) NOT NULL";
				$mysql_sql .= "  ,PRIMARY KEY (content_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "banned_contents START 1";
				}
				$postgre_sql  = "CREATE TABLE ".$table_prefix."banned_contents (";
				$postgre_sql .= "  content_id INT4 NOT NULL DEFAULT nextval('seq_".$table_prefix."banned_contents'),";
				$postgre_sql .= "  content_text VARCHAR(255) NOT NULL";
				$postgre_sql .= "  ,PRIMARY KEY (content_id))";

				$access_sql  = "CREATE TABLE ".$table_prefix."banned_contents (";
				$access_sql .= "  [content_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [content_text] VARCHAR(255)";
				$access_sql .= "  ,PRIMARY KEY (content_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "item_types ADD COLUMN is_bundle INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "item_types ADD COLUMN is_bundle INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "item_types ADD COLUMN is_bundle INTEGER "
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "item_types SET is_bundle=0 ";
				$sqls[] = " INSERT INTO " . $table_prefix . "item_types (item_type_name, is_gift_voucher, is_bundle) VALUES ('Bundle', 0, 1) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN parent_item_id INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN parent_item_id INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN parent_item_id INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN sms_notify INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN sms_notify INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN sms_notify INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN sms_recipient VARCHAR(255) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN sms_recipient VARCHAR(255) ",
					"access"  => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN sms_recipient VARCHAR(255) "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN sms_originator VARCHAR(64) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN sms_originator VARCHAR(64) ",
					"access"  => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN sms_originator VARCHAR(64) "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN sms_message TEXT",
					"postgre" => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN sms_message TEXT",
					"access"  => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN sms_message LONGTEXT"
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = " UPDATE " . $table_prefix . "page_settings SET setting_name='prod_offers_recs' WHERE page_name='index' AND setting_name='products_per_page'";
				$sqls[] = " UPDATE " . $table_prefix . "page_settings SET setting_name='prod_offers_cols' WHERE page_name='index' AND setting_name='products_columns'";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "admins ADD COLUMN edited_item_fields TEXT ",
					"postgre" => "ALTER TABLE " . $table_prefix . "admins ADD COLUMN edited_item_fields TEXT ",
					"access"  => "ALTER TABLE " . $table_prefix . "admins ADD COLUMN edited_item_fields LONGTEXT "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "shipping_modules ADD COLUMN tracking_url VARCHAR(255) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "shipping_modules ADD COLUMN tracking_url VARCHAR(255) ",
					"access"  => "ALTER TABLE " . $table_prefix . "shipping_modules ADD COLUMN tracking_url VARCHAR(255) "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "custom_blocks ADD COLUMN block_path VARCHAR(255) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "custom_blocks ADD COLUMN block_path VARCHAR(255) ",
					"access"  => "ALTER TABLE " . $table_prefix . "custom_blocks ADD COLUMN block_path VARCHAR(255) "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN preview_url VARCHAR(255) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN preview_url VARCHAR(255) ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN preview_url VARCHAR(255) "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN preview_width INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN preview_width INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN preview_width INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN preview_height INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN preview_height INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN preview_height INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items_properties ADD COLUMN property_values_ids TEXT ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items_properties ADD COLUMN property_values_ids TEXT ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items_properties ADD COLUMN property_values_ids LONGTEXT "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "currencies ADD COLUMN currency_image VARCHAR(255) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "currencies ADD COLUMN currency_image VARCHAR(255) ",
					"access"  => "ALTER TABLE " . $table_prefix . "currencies ADD COLUMN currency_image VARCHAR(255) "
				);
				$sqls[] = $sql_types[$db_type];
			}

			if (comp_vers("2.7", $current_db_version) == 1)
      {
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "admins ADD COLUMN is_generate_small_image INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "admins ADD COLUMN is_generate_small_image INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "admins ADD COLUMN is_generate_small_image INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "admins ADD COLUMN is_generate_big_image INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "admins ADD COLUMN is_generate_big_image INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "admins ADD COLUMN is_generate_big_image INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = " DELETE FROM " . $table_prefix . "global_settings WHERE setting_type='products' ";

				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (setting_type, setting_name, setting_value) VALUES ('products', 'resize_small_image', '0')";
				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (setting_type, setting_name, setting_value) VALUES ('products', 'resize_big_image', '0')";
				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (setting_type, setting_name, setting_value) VALUES ('products', 'resize_super_image', '0')";
				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (setting_type, setting_name, setting_value) VALUES ('products', 'small_image_max_width', '100')";
				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (setting_type, setting_name, setting_value) VALUES ('products', 'small_image_max_height', '100')";
				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (setting_type, setting_name, setting_value) VALUES ('products', 'big_image_max_width', '300')";
				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (setting_type, setting_name, setting_value) VALUES ('products', 'big_image_max_height', '300')";
				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (setting_type, setting_name, setting_value) VALUES ('products', 'super_image_max_width', '800')";
				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (setting_type, setting_name, setting_value) VALUES ('products', 'super_image_max_height', '600')";

				$sqls[] = "ALTER TABLE " . $table_prefix . "countries ADD COLUMN country_iso_number VARCHAR(4) ";

				$sql = "SELECT setting_name,setting_value FROM " . $table_prefix . "global_settings WHERE setting_type='global' ";
				$sc_sql = " AND setting_name IN ('product_quantity', 'quantity_control', 'confirm_add', 'redirect_to_cart', 'coupons_enable', 'user_registration', 'display_products', 'default_tax', 'default_tax_note', 'logout_cart_clear', 'reviews_availability') ";
				$db->query($sql . $sc_sql);
				while ($db->next_record()) {
					$setting_name = $db->f("setting_name");
					$setting_value = $db->f("setting_value");
					if ($setting_name == "default_tax_note") {
						$setting_name = "tax_note";
					} elseif ($setting_name == "default_tax") {
						$setting_name = "tax_prices";
						if ($setting_value) {
							$setting_value = 1;
						}
					}

					$sql  = " INSERT INTO " . $table_prefix . "global_settings (setting_type,setting_name,setting_value) VALUES (";
					$sql .= $db->tosql("products", TEXT) . ",";
					$sql .= $db->tosql($setting_name, TEXT) . ", ";
					$sql .= $db->tosql($setting_value, TEXT) . ") ";
					$sqls[] = $sql;
				}

				$sqls[] = " DELETE FROM " . $table_prefix . "global_settings WHERE setting_type='global' " . $sc_sql;

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "tax_rates_items (";
				$mysql_sql .= "  `tax_item_id` INT(11) NOT NULL auto_increment,";
				$mysql_sql .= "  `tax_id` INT(11) default '0',";
				$mysql_sql .= "  `item_type_id` INT(11) default '0',";
				$mysql_sql .= "  `tax_percent` DOUBLE(16,3)";
				$mysql_sql .= "  ,KEY item_type_id (item_type_id)";
				$mysql_sql .= "  ,PRIMARY KEY (tax_item_id)";
				$mysql_sql .= "  ,KEY tax_id (tax_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "tax_rates_items START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "tax_rates_items (";
				$postgre_sql .= "  tax_item_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "tax_rates_items'),";
				$postgre_sql .= "  tax_id INT4 default '0',";
				$postgre_sql .= "  item_type_id INT4 default '0',";
				$postgre_sql .= "  tax_percent FLOAT4";
				$postgre_sql .= "  ,PRIMARY KEY (tax_item_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "tax_rates_items (";
				$access_sql .= "  [tax_item_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [tax_id] INTEGER,";
				$access_sql .= "  [item_type_id] INTEGER,";
				$access_sql .= "  [tax_percent] FLOAT";
				$access_sql .= "  ,PRIMARY KEY (tax_item_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "tax_rates_items_item_type_id ON " . $table_prefix . "tax_rates_items (item_type_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "tax_rates_items_tax_id ON " . $table_prefix . "tax_rates_items (tax_id)";
				}

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN tax_percent DOUBLE(16,3) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN tax_percent FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN tax_percent FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN total_discount_tax DOUBLE(16,2) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN total_discount_tax FLOAT4 default '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN total_discount_tax FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = "ALTER TABLE " . $table_prefix . "orders ADD COLUMN initial_ip VARCHAR(32) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "orders ADD COLUMN cookie_ip VARCHAR(32) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN discount_tax_free INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN discount_tax_free INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN discount_tax_free INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = "ALTER TABLE " . $table_prefix . "users ADD COLUMN registration_ip VARCHAR(32) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "users ADD COLUMN modified_ip VARCHAR(32) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "users ADD COLUMN last_visit_ip VARCHAR(32) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN item_notify INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN item_notify INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN item_notify INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN `mail_notify` INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN mail_notify INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN [mail_notify] INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = "ALTER TABLE " . $table_prefix . "items ADD COLUMN mail_to VARCHAR(255) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "items ADD COLUMN mail_from VARCHAR(64) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "items ADD COLUMN mail_cc VARCHAR(255) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "items ADD COLUMN mail_bcc VARCHAR(255) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "items ADD COLUMN mail_reply_to VARCHAR(64) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "items ADD COLUMN mail_return_path VARCHAR(64) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN `mail_type` INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN mail_type INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN [mail_type] INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = "ALTER TABLE " . $table_prefix . "items ADD COLUMN mail_subject VARCHAR(255) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN mail_body TEXT",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN mail_body TEXT",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN mail_body LONGTEXT"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN sms_notify INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN sms_notify INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN sms_notify INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = "ALTER TABLE " . $table_prefix . "items ADD COLUMN sms_recipient VARCHAR(255) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "items ADD COLUMN sms_originator VARCHAR(64) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN sms_message TEXT",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN sms_message TEXT",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN sms_message LONGTEXT"
				);
				$sqls[] = $sql_types[$db_type];


				$mysql_sql  = "CREATE TABLE " . $table_prefix . "items_serials (";
				$mysql_sql .= "  `serial_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `item_id` INT(11) default '0',";
				$mysql_sql .= "  `serial_number` VARCHAR(128),";
				$mysql_sql .= "  `used` INT(11) default '0'";
				$mysql_sql .= "  ,KEY item_id (item_id)";
				$mysql_sql .= "  ,PRIMARY KEY (serial_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "items_serials START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "items_serials (";
				$postgre_sql .= "  serial_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "items_serials'),";
				$postgre_sql .= "  item_id INT4 default '0',";
				$postgre_sql .= "  serial_number VARCHAR(128),";
				$postgre_sql .= "  used INT4 default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (serial_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "items_serials (";
				$access_sql .= "  [serial_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [item_id] INTEGER,";
				$access_sql .= "  [serial_number] VARCHAR(128),";
				$access_sql .= "  [used] INTEGER";
				$access_sql .= "  ,PRIMARY KEY (serial_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "items_serials_item_id ON " . $table_prefix . "items_serials (item_id)";
				}

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN allowed_view_topics INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN allowed_view_topics INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN allowed_view_topics INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN allowed_view_topic INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN allowed_view_topic INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN allowed_view_topic INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN allowed_post_topics INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN allowed_post_topics INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN allowed_post_topics INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN allowed_post_replies INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN allowed_post_replies INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN allowed_post_replies INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = " UPDATE " . $table_prefix . "forum_list SET allowed_view_topics=1 ";
				$sqls[] = " UPDATE " . $table_prefix . "forum_list SET allowed_view_topic=1 ";
				$sqls[] = " UPDATE " . $table_prefix . "forum_list SET allowed_post_topics=1 ";
				$sqls[] = " UPDATE " . $table_prefix . "forum_list SET allowed_post_replies=1 ";

				$sqls[] = "ALTER TABLE " . $table_prefix . "admins ADD COLUMN personal_image VARCHAR(255) ";

				// update categories settings
				$sql  = " SELECT * FROM " . $table_prefix . "page_settings ";
				$sql .= " WHERE (setting_name='categories_type' OR setting_name='ads_categories_type' OR setting_name LIKE 'a_cats_type_%') ";
				$sql .= " AND (setting_value='1' OR setting_value='2') ";
				$db->query($sql);
				while ($db->next_record()) {
					$page_name = $db->f("page_name");
					$setting_name = $db->f("setting_name");
					if ($setting_name == "categories_type") {
						$sql  = " UPDATE " . $table_prefix . "page_settings SET setting_name='subcategories_type' ";
						$sql .= " WHERE page_name=" . $db->tosql($page_name, TEXT);
						$sql .= " AND setting_name='categories_type'";
						$sqls[] = $sql;
						$sql  = " UPDATE " . $table_prefix . "page_settings SET setting_name='subcategories_columns' ";
						$sql .= " WHERE page_name=" . $db->tosql($page_name, TEXT);
						$sql .= " AND setting_name='categories_columns'";
						$sqls[] = $sql;
						$sql  = " UPDATE " . $table_prefix . "page_settings SET setting_name='subcategories_subs' ";
						$sql .= " WHERE page_name=" . $db->tosql($page_name, TEXT);
						$sql .= " AND setting_name='categories_subs'";
						$sqls[] = $sql;
					} elseif ($setting_name == "ads_categories_type") {
						$sql  = " UPDATE " . $table_prefix . "page_settings SET setting_name='ads_subcategories_type' ";
						$sql .= " WHERE page_name=" . $db->tosql($page_name, TEXT);
						$sql .= " AND setting_name='ads_categories_type'";
						$sqls[] = $sql;
						$sql  = " UPDATE " . $table_prefix . "page_settings SET setting_name='ads_subcategories_columns' ";
						$sql .= " WHERE page_name=" . $db->tosql($page_name, TEXT);
						$sql .= " AND setting_name='ads_categories_columns'";
						$sqls[] = $sql;
						$sql  = " UPDATE " . $table_prefix . "page_settings SET setting_name='ads_subcategories_subs' ";
						$sql .= " WHERE page_name=" . $db->tosql($page_name, TEXT);
						$sql .= " AND setting_name='ads_categories_subs'";
						$sqls[] = $sql;
					} elseif (preg_match("/^a_cats_type_(\d+)$/", $setting_name, $matches)) {
						$top_id = $matches[1];
						$sql  = " UPDATE " . $table_prefix . "page_settings ";
						$sql .= " SET setting_name=" . $db->tosql("a_subcats_type_" . $top_id, TEXT);
						$sql .= " WHERE page_name=" . $db->tosql($page_name, TEXT);
						$sql .= " AND setting_name=" . $db->tosql("a_cats_type_" . $top_id, TEXT);
						$sqls[] = $sql;
						$sql  = " UPDATE " . $table_prefix . "page_settings ";
						$sql .= " SET setting_name=" . $db->tosql("a_subcats_cols_" . $top_id, TEXT);
						$sql .= " WHERE page_name=" . $db->tosql($page_name, TEXT);
						$sql .= " AND setting_name=" . $db->tosql("a_cats_cols_" . $top_id, TEXT);
						$sqls[] = $sql;
						$sql  = " UPDATE " . $table_prefix . "page_settings ";
						$sql .= " SET setting_name=" . $db->tosql("a_subcats_subs_" . $top_id, TEXT);
						$sql .= " WHERE page_name=" . $db->tosql($page_name, TEXT);
						$sql .= " AND setting_name=" . $db->tosql("a_cats_subs_" . $top_id, TEXT);
						$sqls[] = $sql;
					}
				}

			}

			if (comp_vers("2.7.1", $current_db_version) == 1)
			{
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "support_attachments ADD COLUMN message_id INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "support_attachments ADD COLUMN message_id INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "support_attachments ADD COLUMN message_id INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "support_attachments ADD COLUMN admin_id INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "support_attachments ADD COLUMN admin_id INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "support_attachments ADD COLUMN admin_id INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "support_attachments ADD COLUMN attachment_status INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "support_attachments ADD COLUMN attachment_status INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "support_attachments ADD COLUMN attachment_status INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = " UPDATE " . $table_prefix . "support_attachments SET attachment_status=1, message_id=0, admin_id=0 ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "forum ADD COLUMN admin_id_added_by INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "forum ADD COLUMN admin_id_added_by INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "forum ADD COLUMN admin_id_added_by INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "forum ADD COLUMN admin_id_modified_by INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "forum ADD COLUMN admin_id_modified_by INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "forum ADD COLUMN admin_id_modified_by INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "mysql") {
					$sqls[] = "ALTER TABLE " . $table_prefix . "orders MODIFY COLUMN state_code VARCHAR(8) ";
					$sqls[] = "ALTER TABLE " . $table_prefix . "orders MODIFY COLUMN delivery_state_code VARCHAR(8) ";
					$sqls[] = "ALTER TABLE " . $table_prefix . "users MODIFY COLUMN state_code VARCHAR(8) ";
					$sqls[] = "ALTER TABLE " . $table_prefix . "users MODIFY COLUMN delivery_state_code VARCHAR(8) ";
				} elseif ($db_type == "access") {
					$sqls[] = "ALTER TABLE " . $table_prefix . "orders ALTER COLUMN state_code VARCHAR(8) ";
					$sqls[] = "ALTER TABLE " . $table_prefix . "orders ALTER COLUMN delivery_state_code VARCHAR(8) ";
					$sqls[] = "ALTER TABLE " . $table_prefix . "users ALTER COLUMN state_code VARCHAR(8) ";
					$sqls[] = "ALTER TABLE " . $table_prefix . "users ALTER COLUMN delivery_state_code VARCHAR(8) ";
				}

			}

			if (comp_vers("2.8", $current_db_version) == 1)
			{
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN trade_price DOUBLE(16,2) NOT NULL default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN trade_price FLOAT4 NOT NULL default '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN trade_price FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN trade_sales DOUBLE(16,2) NOT NULL default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN trade_sales FLOAT4 NOT NULL default '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN trade_sales FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = "UPDATE " . $table_prefix . "items SET trade_price=0, trade_sales=0 ";

				$sqls[] = "CREATE INDEX " . $table_prefix . "items_trade_price ON " . $table_prefix . "items (trade_price) ";
				$sqls[] = "CREATE INDEX " . $table_prefix . "items_trade_sales ON " . $table_prefix . "items (trade_sales) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN price_type INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN price_type INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN price_type INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = "UPDATE " . $table_prefix . "user_types SET price_type=0 ";

				$sqls[] = "ALTER TABLE " . $table_prefix . "categories ADD COLUMN friendly_url VARCHAR(255) NOT NULL ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "items ADD COLUMN friendly_url VARCHAR(255) NOT NULL ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "manufacturers ADD COLUMN friendly_url VARCHAR(255) NOT NULL ";

				$sqls[] = "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN friendly_url VARCHAR(255) NOT NULL ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "articles ADD COLUMN friendly_url VARCHAR(255) NOT NULL ";

				$sqls[] = "ALTER TABLE " . $table_prefix . "forum_categories ADD COLUMN friendly_url VARCHAR(255) NOT NULL ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN friendly_url VARCHAR(255) NOT NULL ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "forum ADD COLUMN friendly_url VARCHAR(255) NOT NULL ";

				$sqls[] = "ALTER TABLE " . $table_prefix . "ads_categories ADD COLUMN friendly_url VARCHAR(255) NOT NULL ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "ads_items ADD COLUMN friendly_url VARCHAR(255) NOT NULL ";

				$sqls[] = "ALTER TABLE " . $table_prefix . "users ADD COLUMN friendly_url VARCHAR(255) NOT NULL ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "pages ADD COLUMN friendly_url VARCHAR(255) NOT NULL ";

				$sqls[] = "CREATE INDEX " . $table_prefix . "categories_friendly_url ON " . $table_prefix . "categories (friendly_url) ";
				$sqls[] = "CREATE INDEX " . $table_prefix . "items_friendly_url ON " . $table_prefix . "items (friendly_url) ";
				$sqls[] = "CREATE INDEX " . $table_prefix . "manufacturers_friendly_url ON " . $table_prefix . "manufacturers (friendly_url) ";

				$sqls[] = "CREATE INDEX " . $table_prefix . "articles_categories_friendly_url ON " . $table_prefix . "articles_categories (friendly_url) ";
				$sqls[] = "CREATE INDEX " . $table_prefix . "articles_friendly_url ON " . $table_prefix . "articles (friendly_url) ";

				$sqls[] = "CREATE INDEX " . $table_prefix . "forum_categories_friendly_url ON " . $table_prefix . "forum_categories (friendly_url) ";
				$sqls[] = "CREATE INDEX " . $table_prefix . "forum_list_friendly_url ON " . $table_prefix . "forum_list (friendly_url) ";
				$sqls[] = "CREATE INDEX " . $table_prefix . "forum_friendly_url ON " . $table_prefix . "forum (friendly_url) ";

				$sqls[] = "CREATE INDEX " . $table_prefix . "ads_categories_friendly_url ON " . $table_prefix . "ads_categories (friendly_url) ";
				$sqls[] = "CREATE INDEX " . $table_prefix . "ads_items_friendly_url ON " . $table_prefix . "ads_items (friendly_url) ";

				$sqls[] = "CREATE INDEX " . $table_prefix . "users_friendly_url ON " . $table_prefix . "users (friendly_url) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "manufacturers ADD COLUMN short_description TEXT",
					"postgre" => "ALTER TABLE " . $table_prefix . "manufacturers ADD COLUMN short_description TEXT",
					"access"  => "ALTER TABLE " . $table_prefix . "manufacturers ADD COLUMN short_description LONGTEXT"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "manufacturers ADD COLUMN full_description TEXT",
					"postgre" => "ALTER TABLE " . $table_prefix . "manufacturers ADD COLUMN full_description TEXT",
					"access"  => "ALTER TABLE " . $table_prefix . "manufacturers ADD COLUMN full_description LONGTEXT"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN fee_min_goods DOUBLE(16,2) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN fee_min_goods FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN fee_min_goods FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN fee_max_goods DOUBLE(16,2) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN fee_max_goods FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN fee_max_goods FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				// affiliate and merchants commissions fields
				$sqls[] = "ALTER TABLE " . $table_prefix . "users ADD COLUMN affiliate_code VARCHAR(64) NOT NULL ";
				$sqls[] = "CREATE INDEX " . $table_prefix . "users_affiliate_code ON " . $table_prefix . "users (affiliate_code) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "users ADD COLUMN short_description TEXT",
					"postgre" => "ALTER TABLE " . $table_prefix . "users ADD COLUMN short_description TEXT",
					"access"  => "ALTER TABLE " . $table_prefix . "users ADD COLUMN short_description LONGTEXT"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "users ADD COLUMN full_description TEXT",
					"postgre" => "ALTER TABLE " . $table_prefix . "users ADD COLUMN full_description TEXT",
					"access"  => "ALTER TABLE " . $table_prefix . "users ADD COLUMN full_description LONGTEXT"
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = "ALTER TABLE " . $table_prefix . "users ADD COLUMN paypal_account VARCHAR(128) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "users ADD COLUMN tax_id VARCHAR(128) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN user_id INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN user_id INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN user_id INTEGER "
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = "UPDATE " . $table_prefix . "items SET user_id=0 ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN item_user_id INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN item_user_id INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN item_user_id INTEGER "
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = "UPDATE " . $table_prefix . "orders_items SET item_user_id=0 ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN commission_action INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN commission_action INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN commission_action INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN affiliate_commission DOUBLE(16,2) NOT NULL default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN affiliate_commission FLOAT4 NOT NULL default '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN affiliate_commission FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN merchant_commission DOUBLE(16,2) NOT NULL default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN merchant_commission FLOAT4 NOT NULL default '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN merchant_commission FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = "UPDATE " . $table_prefix . "orders_items SET affiliate_commission=0, merchant_commission=0 ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "users ADD COLUMN affiliate_commission_type INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "users ADD COLUMN affiliate_commission_type INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "users ADD COLUMN affiliate_commission_type INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "users ADD COLUMN affiliate_commission_amount DOUBLE(16,2) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "users ADD COLUMN affiliate_commission_amount FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "users ADD COLUMN affiliate_commission_amount FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "users ADD COLUMN merchant_fee_type INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "users ADD COLUMN merchant_fee_type INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "users ADD COLUMN merchant_fee_type INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "users ADD COLUMN merchant_fee_amount DOUBLE(16,2) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "users ADD COLUMN merchant_fee_amount FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "users ADD COLUMN merchant_fee_amount FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN affiliate_commission_type INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN affiliate_commission_type INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN affiliate_commission_type INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN affiliate_commission_amount DOUBLE(16,2) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN affiliate_commission_amount FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN affiliate_commission_amount FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN merchant_fee_type INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN merchant_fee_type INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN merchant_fee_type INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN merchant_fee_amount DOUBLE(16,2) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN merchant_fee_amount FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN merchant_fee_amount FLOAT"
				);
				$sqls[] = $sql_types[$db_type];


				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN affiliate_commission_type INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN affiliate_commission_type INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN affiliate_commission_type INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN affiliate_commission_amount DOUBLE(16,2) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN affiliate_commission_amount FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN affiliate_commission_amount FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN merchant_fee_type INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN merchant_fee_type INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN merchant_fee_type INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN merchant_fee_amount DOUBLE(16,2) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN merchant_fee_amount FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN merchant_fee_amount FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "item_types ADD COLUMN affiliate_commission_type INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "item_types ADD COLUMN affiliate_commission_type INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "item_types ADD COLUMN affiliate_commission_type INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "item_types ADD COLUMN affiliate_commission_amount DOUBLE(16,2) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "item_types ADD COLUMN affiliate_commission_amount FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "item_types ADD COLUMN affiliate_commission_amount FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "item_types ADD COLUMN merchant_fee_type INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "item_types ADD COLUMN merchant_fee_type INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "item_types ADD COLUMN merchant_fee_type INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "item_types ADD COLUMN merchant_fee_amount DOUBLE(16,2) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "item_types ADD COLUMN merchant_fee_amount FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "item_types ADD COLUMN merchant_fee_amount FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "users_commissions (";
				$mysql_sql .= "  `commission_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `payment_id` INT(11) default '0',";
				$mysql_sql .= "  `user_id` INT(11) default '0',";
				$mysql_sql .= "  `order_id` INT(11) default '0',";
				$mysql_sql .= "  `order_item_id` INT(11) default '0',";
				$mysql_sql .= "  `commission_amount` DOUBLE(16,2) default '0',";
				$mysql_sql .= "  `commission_action` INT(11) default '0',";
				$mysql_sql .= "  `commission_type` INT(11) default '0',";
				$mysql_sql .= "  `date_added` DATETIME NOT NULL";
				$mysql_sql .= "  ,KEY date_added (date_added)";
				$mysql_sql .= "  ,KEY order_id (order_id)";
				$mysql_sql .= "  ,KEY order_item_id (order_item_id)";
				$mysql_sql .= "  ,KEY payment_id (payment_id)";
				$mysql_sql .= "  ,PRIMARY KEY (commission_id)";
				$mysql_sql .= "  ,KEY user_id (user_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "users_commissions START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "users_commissions (";
				$postgre_sql .= "  commission_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "users_commissions'),";
				$postgre_sql .= "  payment_id INT4 default '0',";
				$postgre_sql .= "  user_id INT4 default '0',";
				$postgre_sql .= "  order_id INT4 default '0',";
				$postgre_sql .= "  order_item_id INT4 default '0',";
				$postgre_sql .= "  commission_amount FLOAT4 default '0',";
				$postgre_sql .= "  commission_action INT4 default '0',";
				$postgre_sql .= "  commission_type INT4 default '0',";
				$postgre_sql .= "  date_added TIMESTAMP NOT NULL";
				$postgre_sql .= "  ,PRIMARY KEY (commission_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "users_commissions (";
				$access_sql .= "  [commission_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [payment_id] INTEGER,";
				$access_sql .= "  [user_id] INTEGER,";
				$access_sql .= "  [order_id] INTEGER,";
				$access_sql .= "  [order_item_id] INTEGER,";
				$access_sql .= "  [commission_amount] FLOAT,";
				$access_sql .= "  [commission_action] INTEGER,";
				$access_sql .= "  [commission_type] INTEGER,";
				$access_sql .= "  [date_added] DATETIME";
				$access_sql .= "  ,PRIMARY KEY (commission_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "users_commissions_date_added ON " . $table_prefix . "users_commissions (date_added)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "users_commissions_order_id ON " . $table_prefix . "users_commissions (order_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "users_commissions_order__39 ON " . $table_prefix . "users_commissions (order_item_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "users_commissions_payment_id ON " . $table_prefix . "users_commissions (payment_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "users_commissions_user_id ON " . $table_prefix . "users_commissions (user_id)";
				}

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "users_payments (";
				$mysql_sql .= "  `payment_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `user_id` INT(11) default '0',";
				$mysql_sql .= "  `is_paid` INT(11) default '0',";
				$mysql_sql .= "  `transaction_id` VARCHAR(128),";
				$mysql_sql .= "  `payment_total` DOUBLE(16,2) default '0',";
				$mysql_sql .= "  `payment_name` VARCHAR(255),";
				$mysql_sql .= "  `payment_notes` TEXT,";
				$mysql_sql .= "  `date_added` DATETIME,";
				$mysql_sql .= "  `date_modified` DATETIME,";
				$mysql_sql .= "  `date_paid` DATETIME,";
				$mysql_sql .= "  `admin_id_added_by` INT(11) default '0',";
				$mysql_sql .= "  `admin_id_modified_by` INT(11) default '0'";
				$mysql_sql .= "  ,KEY date_paid (date_paid)";
				$mysql_sql .= "  ,KEY is_paid (is_paid)";
				$mysql_sql .= "  ,PRIMARY KEY (payment_id)";
				$mysql_sql .= "  ,KEY user_id (user_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "users_payments START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "users_payments (";
				$postgre_sql .= "  payment_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "users_payments'),";
				$postgre_sql .= "  user_id INT4 default '0',";
				$postgre_sql .= "  is_paid INT4 default '0',";
				$postgre_sql .= "  transaction_id VARCHAR(128),";
				$postgre_sql .= "  payment_total FLOAT4 default '0',";
				$postgre_sql .= "  payment_name VARCHAR(255),";
				$postgre_sql .= "  payment_notes TEXT,";
				$postgre_sql .= "  date_added TIMESTAMP,";
				$postgre_sql .= "  date_modified TIMESTAMP,";
				$postgre_sql .= "  date_paid TIMESTAMP,";
				$postgre_sql .= "  admin_id_added_by INT4 default '0',";
				$postgre_sql .= "  admin_id_modified_by INT4 default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (payment_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "users_payments (";
				$access_sql .= "  [payment_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [user_id] INTEGER,";
				$access_sql .= "  [is_paid] INTEGER,";
				$access_sql .= "  [transaction_id] VARCHAR(128),";
				$access_sql .= "  [payment_total] FLOAT,";
				$access_sql .= "  [payment_name] VARCHAR(255),";
				$access_sql .= "  [payment_notes] LONGTEXT,";
				$access_sql .= "  [date_added] DATETIME,";
				$access_sql .= "  [date_modified] DATETIME,";
				$access_sql .= "  [date_paid] DATETIME,";
				$access_sql .= "  [admin_id_added_by] INTEGER,";
				$access_sql .= "  [admin_id_modified_by] INTEGER";
				$access_sql .= "  ,PRIMARY KEY (payment_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "users_payments_date_paid ON " . $table_prefix . "users_payments (date_paid)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "users_payments_is_paid ON " . $table_prefix . "users_payments (is_paid)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "users_payments_user_id ON " . $table_prefix . "users_payments (user_id)";
				}

				// menus tables
				$mysql_sql  = "CREATE TABLE " . $table_prefix . "menus (";
				$mysql_sql .= "  `menu_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `menu_title` VARCHAR(255),";
				$mysql_sql .= "  `menu_name` VARCHAR(128),";
				$mysql_sql .= "  `menu_notes` TEXT";
				$mysql_sql .= "  ,PRIMARY KEY (menu_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "menus START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "menus (";
				$postgre_sql .= "  menu_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "menus'),";
				$postgre_sql .= "  menu_title VARCHAR(255),";
				$postgre_sql .= "  menu_name VARCHAR(128),";
				$postgre_sql .= "  menu_notes TEXT";
				$postgre_sql .= "  ,PRIMARY KEY (menu_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "menus (";
				$access_sql .= "  [menu_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [menu_title] VARCHAR(255),";
				$access_sql .= "  [menu_name] VARCHAR(128),";
				$access_sql .= "  [menu_notes] LONGTEXT";
				$access_sql .= "  ,PRIMARY KEY (menu_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "menus_items (";
				$mysql_sql .= "  `menu_item_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `menu_id` INT(11) default '0',";
				$mysql_sql .= "  `parent_menu_item_id` INT(11) default '0',";
				$mysql_sql .= "  `menu_path` VARCHAR(255),";
				$mysql_sql .= "  `menu_title` VARCHAR(255),";
				$mysql_sql .= "  `menu_url` VARCHAR(255),";
				$mysql_sql .= "  `menu_target` VARCHAR(32),";
				$mysql_sql .= "  `menu_image` VARCHAR(255),";
				$mysql_sql .= "  `menu_image_active` VARCHAR(255),";
				$mysql_sql .= "  `menu_prefix` VARCHAR(255),";
				$mysql_sql .= "  `menu_prefix_active` VARCHAR(255),";
				$mysql_sql .= "  `menu_order` INT(11) default '0',";
				$mysql_sql .= "  `show_non_logged` INT(11) default '0',";
				$mysql_sql .= "  `show_logged` INT(11) default '0'";
				$mysql_sql .= "  ,KEY menu_id (menu_id)";
				$mysql_sql .= "  ,KEY menu_item_id (menu_item_id)";
				$mysql_sql .= "  ,KEY parent_menu_item_id (parent_menu_item_id)";
				$mysql_sql .= "  ,PRIMARY KEY (menu_item_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "menus_items START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "menus_items (";
				$postgre_sql .= "  menu_item_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "menus_items'),";
				$postgre_sql .= "  menu_id INT4 default '0',";
				$postgre_sql .= "  parent_menu_item_id INT4 default '0',";
				$postgre_sql .= "  menu_path VARCHAR(255),";
				$postgre_sql .= "  menu_title VARCHAR(255),";
				$postgre_sql .= "  menu_url VARCHAR(255),";
				$postgre_sql .= "  menu_target VARCHAR(32),";
				$postgre_sql .= "  menu_image VARCHAR(255),";
				$postgre_sql .= "  menu_image_active VARCHAR(255),";
				$postgre_sql .= "  menu_prefix VARCHAR(255),";
				$postgre_sql .= "  menu_prefix_active VARCHAR(255),";
				$postgre_sql .= "  menu_order INT4 default '0',";
				$postgre_sql .= "  show_non_logged INT4 default '0',";
				$postgre_sql .= "  show_logged INT4 default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (menu_item_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "menus_items (";
				$access_sql .= "  [menu_item_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [menu_id] INTEGER,";
				$access_sql .= "  [parent_menu_item_id] INTEGER,";
				$access_sql .= "  [menu_path] VARCHAR(255),";
				$access_sql .= "  [menu_title] VARCHAR(255),";
				$access_sql .= "  [menu_url] VARCHAR(255),";
				$access_sql .= "  [menu_target] VARCHAR(32),";
				$access_sql .= "  [menu_image] VARCHAR(255),";
				$access_sql .= "  [menu_image_active] VARCHAR(255),";
				$access_sql .= "  [menu_prefix] VARCHAR(255),";
				$access_sql .= "  [menu_prefix_active] VARCHAR(255),";
				$access_sql .= "  [menu_order] INTEGER,";
				$access_sql .= "  [show_non_logged] INTEGER,";
				$access_sql .= "  [show_logged] INTEGER";
				$access_sql .= "  ,PRIMARY KEY (menu_item_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "menus_items_menu_id ON " . $table_prefix . "menus_items (menu_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "menus_items_parent_menu__15 ON " . $table_prefix . "menus_items (parent_menu_item_id)";
				}

				// add tracking tables
				$mysql_sql  = "CREATE TABLE " . $table_prefix . "tracking_visits (";
				$mysql_sql .= "  `visit_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `parent_visit_id` INT(11) default '0',";
				$mysql_sql .= "  `visit_number` INT(11) default '1',";
				$mysql_sql .= "  `ip_long` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `ip_text` VARCHAR(32) NOT NULL,";
				$mysql_sql .= "  `forwarded_ips` VARCHAR(50),";
				$mysql_sql .= "  `affiliate_code` VARCHAR(64),";
				$mysql_sql .= "  `keywords` VARCHAR(255),";
				$mysql_sql .= "  `user_agent` VARCHAR(255),";
				$mysql_sql .= "  `request_uri` VARCHAR(255),";
				$mysql_sql .= "  `request_page` VARCHAR(255),";
				$mysql_sql .= "  `referer` VARCHAR(255),";
				$mysql_sql .= "  `referer_host` VARCHAR(255),";
				$mysql_sql .= "  `referer_engine_id` INT(11) default '0',";
				$mysql_sql .= "  `robot_engine_id` INT(11) default '0',";
				$mysql_sql .= "  `date_added` DATETIME NOT NULL,";
				$mysql_sql .= "  `year_added` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `month_added` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `week_added` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `day_added` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `hour_added` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `site_id` INT(11) NOT NULL default '0'";
				$mysql_sql .= "  ,KEY affiliate_code (affiliate_code)";
				$mysql_sql .= "  ,KEY date_added (date_added)";
				$mysql_sql .= "  ,KEY day_added (day_added)";
				$mysql_sql .= "  ,KEY hour_added (hour_added)";
				$mysql_sql .= "  ,KEY keyword_phrase (keywords)";
				$mysql_sql .= "  ,KEY month_added (month_added)";
				$mysql_sql .= "  ,KEY week_added (week_added)";
				$mysql_sql .= "  ,KEY parent_visit_id (parent_visit_id)";
				$mysql_sql .= "  ,PRIMARY KEY (visit_id)";
				$mysql_sql .= "  ,KEY referer_engine_id (referer_engine_id)";
				$mysql_sql .= "  ,KEY referer_host (referer_host)";
				$mysql_sql .= "  ,KEY remote_ip_long (ip_long)";
				$mysql_sql .= "  ,KEY robot_engine_id (robot_engine_id)";
				$mysql_sql .= "  ,KEY site_id (site_id)";
				$mysql_sql .= "  ,KEY year_added (year_added))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "tracking_visits START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "tracking_visits (";
				$postgre_sql .= "  visit_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "tracking_visits'),";
				$postgre_sql .= "  parent_visit_id INT4 default '0',";
				$postgre_sql .= "  visit_number INT4 default '1',";
				$postgre_sql .= "  ip_long INT4 NOT NULL default '0',";
				$postgre_sql .= "  ip_text VARCHAR(32) NOT NULL,";
				$postgre_sql .= "  forwarded_ips VARCHAR(50),";
				$postgre_sql .= "  affiliate_code VARCHAR(64),";
				$postgre_sql .= "  keywords VARCHAR(255),";
				$postgre_sql .= "  user_agent VARCHAR(255),";
				$postgre_sql .= "  request_uri VARCHAR(255),";
				$postgre_sql .= "  request_page VARCHAR(255),";
				$postgre_sql .= "  referer VARCHAR(255),";
				$postgre_sql .= "  referer_host VARCHAR(255),";
				$postgre_sql .= "  referer_engine_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  robot_engine_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  date_added TIMESTAMP NOT NULL,";
				$postgre_sql .= "  year_added INT4 NOT NULL default '0',";
				$postgre_sql .= "  month_added INT4 NOT NULL default '0',";
				$postgre_sql .= "  week_added INT4 NOT NULL default '0',";
				$postgre_sql .= "  day_added INT4 NOT NULL default '0',";
				$postgre_sql .= "  hour_added INT4 NOT NULL default '0',";
				$postgre_sql .= "  site_id INT4 NOT NULL default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (visit_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "tracking_visits (";
				$access_sql .= "  [visit_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [parent_visit_id] INTEGER,";
				$access_sql .= "  [visit_number] INTEGER,";
				$access_sql .= "  [ip_long] INTEGER,";
				$access_sql .= "  [ip_text] VARCHAR(32),";
				$access_sql .= "  [forwarded_ips] VARCHAR(50),";
				$access_sql .= "  [affiliate_code] VARCHAR(64),";
				$access_sql .= "  [keywords] VARCHAR(255),";
				$access_sql .= "  [user_agent] VARCHAR(255),";
				$access_sql .= "  [request_uri] VARCHAR(255),";
				$access_sql .= "  [request_page] VARCHAR(255),";
				$access_sql .= "  [referer] VARCHAR(255),";
				$access_sql .= "  [referer_host] VARCHAR(255),";
				$access_sql .= "  [referer_engine_id] INTEGER,";
				$access_sql .= "  [robot_engine_id] INTEGER,";
				$access_sql .= "  [date_added] DATETIME,";
				$access_sql .= "  [year_added] INTEGER,";
				$access_sql .= "  [month_added] INTEGER,";
				$access_sql .= "  [week_added] INTEGER,";
				$access_sql .= "  [day_added] INTEGER,";
				$access_sql .= "  [hour_added] INTEGER,";
				$access_sql .= "  [site_id] INTEGER";
				$access_sql .= "  ,PRIMARY KEY (visit_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];


				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "tracking_visits_affiliat_40 ON " . $table_prefix . "tracking_visits (affiliate_code)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "tracking_visits_date_added ON " . $table_prefix . "tracking_visits (date_added)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "tracking_visits_day_added ON " . $table_prefix . "tracking_visits (day_added)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "tracking_visits_hour_added ON " . $table_prefix . "tracking_visits (hour_added)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "tracking_visits_keyword__41 ON " . $table_prefix . "tracking_visits (keywords)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "tracking_visits_month_added ON " . $table_prefix . "tracking_visits (month_added)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "tracking_visits_week_added ON " . $table_prefix . "tracking_visits (week_added)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "tracking_visits_parent_v_42 ON " . $table_prefix . "tracking_visits (parent_visit_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "tracking_visits_referer__47 ON " . $table_prefix . "tracking_visits (referer_engine_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "tracking_visits_referer_host ON " . $table_prefix . "tracking_visits (referer_host)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "tracking_visits_remote_i_43 ON " . $table_prefix . "tracking_visits (ip_long)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "tracking_visits_robot_en_49 ON " . $table_prefix . "tracking_visits (robot_engine_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "tracking_visits_site_id ON " . $table_prefix . "tracking_visits (site_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "tracking_visits_year_added ON " . $table_prefix . "tracking_visits (year_added)";
				}

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "tracking_pages (";
				$mysql_sql .= "  `page_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `visit_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `ip_long` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `ip_text` VARCHAR(32),";
				$mysql_sql .= "  `forwarded_ips` VARCHAR(255),";
				$mysql_sql .= "  `request_uri` VARCHAR(255),";
				$mysql_sql .= "  `request_page` VARCHAR(255),";
				$mysql_sql .= "  `date_added` DATETIME NOT NULL,";
				$mysql_sql .= "  `year_added` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `month_added` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `day_added` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `hour_added` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `site_id` INT(11) NOT NULL default '0'";
				$mysql_sql .= "  ,KEY date_added (date_added)";
				$mysql_sql .= "  ,KEY day_added (day_added)";
				$mysql_sql .= "  ,KEY hour_added (hour_added)";
				$mysql_sql .= "  ,KEY ip_long (ip_long)";
				$mysql_sql .= "  ,KEY month_added (month_added)";
				$mysql_sql .= "  ,PRIMARY KEY (page_id)";
				$mysql_sql .= "  ,KEY site_id (site_id)";
				$mysql_sql .= "  ,KEY visit_id (visit_id)";
				$mysql_sql .= "  ,KEY year_added (year_added))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "tracking_pages START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "tracking_pages (";
				$postgre_sql .= "  page_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "tracking_pages'),";
				$postgre_sql .= "  visit_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  ip_long INT4 NOT NULL default '0',";
				$postgre_sql .= "  ip_text VARCHAR(32),";
				$postgre_sql .= "  forwarded_ips VARCHAR(255),";
				$postgre_sql .= "  request_uri VARCHAR(255),";
				$postgre_sql .= "  request_page VARCHAR(255),";
				$postgre_sql .= "  date_added TIMESTAMP NOT NULL,";
				$postgre_sql .= "  year_added INT4 NOT NULL default '0',";
				$postgre_sql .= "  month_added INT4 NOT NULL default '0',";
				$postgre_sql .= "  day_added INT4 NOT NULL default '0',";
				$postgre_sql .= "  hour_added INT4 NOT NULL default '0',";
				$postgre_sql .= "  site_id INT4 NOT NULL default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (page_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "tracking_pages (";
				$access_sql .= "  [page_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [visit_id] INTEGER,";
				$access_sql .= "  [ip_long] INTEGER,";
				$access_sql .= "  [ip_text] VARCHAR(32),";
				$access_sql .= "  [forwarded_ips] VARCHAR(255),";
				$access_sql .= "  [request_uri] VARCHAR(255),";
				$access_sql .= "  [request_page] VARCHAR(255),";
				$access_sql .= "  [date_added] DATETIME,";
				$access_sql .= "  [year_added] INTEGER,";
				$access_sql .= "  [month_added] INTEGER,";
				$access_sql .= "  [day_added] INTEGER,";
				$access_sql .= "  [hour_added] INTEGER,";
				$access_sql .= "  [site_id] INTEGER";
				$access_sql .= "  ,PRIMARY KEY (page_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "tracking_pages_date_added ON " . $table_prefix . "tracking_pages (date_added)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "tracking_pages_day_added ON " . $table_prefix . "tracking_pages (day_added)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "tracking_pages_hour_added ON " . $table_prefix . "tracking_pages (hour_added)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "tracking_pages_ip_long ON " . $table_prefix . "tracking_pages (ip_long)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "tracking_pages_month_added ON " . $table_prefix . "tracking_pages (month_added)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "tracking_pages_site_id ON " . $table_prefix . "tracking_pages (site_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "tracking_pages_visit_id ON " . $table_prefix . "tracking_pages (visit_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "tracking_pages_year_added ON " . $table_prefix . "tracking_pages (year_added)";
				}

				// Call Center changes
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN is_call_center INT(11) default '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN is_call_center INT4 default '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN is_call_center INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "order_custom_properties ADD COLUMN property_show INT(11) default '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "order_custom_properties ADD COLUMN property_show INT4 default '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "order_custom_properties ADD COLUMN property_show INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				// Currency active image
				$sqls[] = "ALTER TABLE " . $table_prefix . "currencies ADD COLUMN currency_image_active VARCHAR(255)";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN visit_id INT(11) default '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN visit_id INT4 default '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN visit_id INTEGER"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = "UPDATE " . $table_prefix . "orders SET visit_id=0 ";

				$sqls[] = "ALTER TABLE " . $table_prefix . "orders ADD COLUMN keywords VARCHAR(255)";

				// create support page layout
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id, page_name, setting_name, setting_order, setting_value) VALUES (0, 'support_new', 'left_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id, page_name, setting_name, setting_order, setting_value) VALUES (0, 'support_new', 'left_column_width', NULL, NULL)";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id, page_name, setting_name, setting_order, setting_value) VALUES (0, 'support_new', 'middle_column_hide', NULL, '0')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id, page_name, setting_name, setting_order, setting_value) VALUES (0, 'support_new', 'middle_column_width', NULL, '100%')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id, page_name, setting_name, setting_order, setting_value) VALUES (0, 'support_new', 'right_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id, page_name, setting_name, setting_order, setting_value) VALUES (0, 'support_new', 'right_column_width', NULL, NULL)";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id, page_name, setting_name, setting_order, setting_value) VALUES (0, 'support_new', 'support_block', 0, 'middle')";

				// distributors/merchants fields
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN is_approved INT(11) NOT NULL default '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN is_approved INT4 NOT NULL default '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN is_approved INTEGER NOT NULL "
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = "UPDATE " . $table_prefix . "items SET is_approved=1 ";
				$sqls[] = "CREATE INDEX " . $table_prefix . "items_is_approved ON " . $table_prefix . "items (is_approved) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN allowed_post INT(11) default '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN allowed_post INT4 default '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN allowed_post INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN affiliate_user_id INT(11) NOT NULL default '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN affiliate_user_id INT4 NOT NULL default '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN affiliate_user_id INTEGER NOT NULL "
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = "UPDATE " . $table_prefix . "orders SET affiliate_user_id=0 ";
				$sqls[] = "CREATE INDEX " . $table_prefix . "orders_affiliate_user_id ON " . $table_prefix . "orders (affiliate_user_id) ";

				$sqls[] = "ALTER TABLE " . $table_prefix . "header_links ADD COLUMN menu_target VARCHAR(32)";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN total_merchants_commission DOUBLE(16,2) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN total_merchants_commission FLOAT4 default '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN total_merchants_commission FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN total_affiliate_commission DOUBLE(16,2) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN total_affiliate_commission FLOAT4 default '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN total_affiliate_commission FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = " UPDATE " . $table_prefix . "orders SET total_merchants_commission=0, total_affiliate_commission=0 ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN affiliate_user_id INT(11) NOT NULL default '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN affiliate_user_id INT4 NOT NULL default '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN affiliate_user_id INTEGER NOT NULL "
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = "UPDATE " . $table_prefix . "orders_items SET affiliate_user_id=0 ";
				$sqls[] = "CREATE INDEX " . $table_prefix . "orders_items_affiliate_user ON " . $table_prefix . "orders_items (affiliate_user_id) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN show_for_user INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN show_for_user INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN show_for_user INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = " UPDATE " . $table_prefix . "order_statuses SET show_for_user=1, commission_action=1 WHERE status_name LIKE '%Paid%' ";
				$sqls[] = " UPDATE " . $table_prefix . "order_statuses SET show_for_user=1, commission_action=-1 WHERE status_name LIKE '%Cancelled%' ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "item_types ADD COLUMN is_user INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "item_types ADD COLUMN is_user INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "item_types ADD COLUMN is_user INTEGER "
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = "UPDATE " . $table_prefix . "item_types SET is_user=1 WHERE item_type_name LIKE '%Product%' OR item_type_name LIKE '%Accessory%' ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN is_active INT(11) default '1' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN is_active INT4 default '1' ",
					"access"  => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN is_active INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN show_for_user INT(11) default '1' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN show_for_user INT4 default '1' ",
					"access"  => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN show_for_user INTEGER "
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = "UPDATE " . $table_prefix . "user_types SET is_active=1, show_for_user=1  ";

				$sqls[] = "ALTER TABLE " . $table_prefix . "layouts ADD COLUMN scheme_name VARCHAR(64)";


				$mysql_sql  = "CREATE TABLE " . $table_prefix . "manuals_categories (";
				$mysql_sql .= "  `category_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `category_name` VARCHAR(255),";
				$mysql_sql .= "  `friendly_url` VARCHAR(255),";
				$mysql_sql .= "  `category_order` INT(11) default '0',";
				$mysql_sql .= "  `short_description` TEXT,";
				$mysql_sql .= "  `full_description` TEXT,";
				$mysql_sql .= "  `allowed_view` INT(11) default '0',";
				$mysql_sql .= "  `meta_title` VARCHAR(255),";
				$mysql_sql .= "  `meta_keywords` VARCHAR(255),";
				$mysql_sql .= "  `meta_description` VARCHAR(255),";
				$mysql_sql .= "  `date_added` DATETIME,";
				$mysql_sql .= "  `date_modified` DATETIME,";
				$mysql_sql .= "  `admin_id_added_by` INT(11) default '0',";
				$mysql_sql .= "  `admin_id_modified_by` INT(11) default '0'";
				$mysql_sql .= "  ,KEY friendly_url (friendly_url)";
				$mysql_sql .= "  ,PRIMARY KEY (category_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "manuals_categories START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "manuals_categories (";
				$postgre_sql .= "  category_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "manuals_categories'),";
				$postgre_sql .= "  category_name VARCHAR(255),";
				$postgre_sql .= "  friendly_url VARCHAR(255),";
				$postgre_sql .= "  category_order INT4 default '0',";
				$postgre_sql .= "  short_description TEXT,";
				$postgre_sql .= "  full_description TEXT,";
				$postgre_sql .= "  allowed_view INT4 default '0',";
				$postgre_sql .= "  meta_title VARCHAR(255),";
				$postgre_sql .= "  meta_keywords VARCHAR(255),";
				$postgre_sql .= "  meta_description VARCHAR(255),";
				$postgre_sql .= "  date_added TIMESTAMP,";
				$postgre_sql .= "  date_modified TIMESTAMP,";
				$postgre_sql .= "  admin_id_added_by INT4 default '0',";
				$postgre_sql .= "  admin_id_modified_by INT4 default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (category_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "manuals_categories (";
				$access_sql .= "  [category_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [category_name] VARCHAR(255),";
				$access_sql .= "  [friendly_url] VARCHAR(255),";
				$access_sql .= "  [category_order] INTEGER,";
				$access_sql .= "  [short_description] LONGTEXT,";
				$access_sql .= "  [full_description] LONGTEXT,";
				$access_sql .= "  [allowed_view] INTEGER,";
				$access_sql .= "  [meta_title] VARCHAR(255),";
				$access_sql .= "  [meta_keywords] VARCHAR(255),";
				$access_sql .= "  [meta_description] VARCHAR(255),";
				$access_sql .= "  [date_added] DATETIME,";
				$access_sql .= "  [date_modified] DATETIME,";
				$access_sql .= "  [admin_id_added_by] INTEGER,";
				$access_sql .= "  [admin_id_modified_by] INTEGER";
				$access_sql .= "  ,PRIMARY KEY (category_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "manuals_categories_frien_17 ON " . $table_prefix . "manuals_categories (friendly_url)";
				}

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "manuals_list (";
				$mysql_sql .= "  `manual_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `category_id` INT(11) default '0',";
				$mysql_sql .= "  `alias_manual_id` INT(11) default '0',";
				$mysql_sql .= "  `manual_order` INT(11) default '0',";
				$mysql_sql .= "  `manual_title` VARCHAR(255),";
				$mysql_sql .= "  `friendly_url` VARCHAR(255),";
				$mysql_sql .= "  `short_description` TEXT,";
				$mysql_sql .= "  `full_description` TEXT,";
				$mysql_sql .= "  `allowed_view` INT(11) default '0',";
				$mysql_sql .= "  `meta_title` VARCHAR(255),";
				$mysql_sql .= "  `meta_keywords` VARCHAR(255),";
				$mysql_sql .= "  `meta_description` VARCHAR(255),";
				$mysql_sql .= "  `date_added` DATETIME,";
				$mysql_sql .= "  `date_modified` DATETIME,";
				$mysql_sql .= "  `admin_id_added_by` INT(11) default '0',";
				$mysql_sql .= "  `admin_id_modified_by` INT(11) default '0'";
				$mysql_sql .= "  ,KEY alias_manual_id (alias_manual_id)";
				$mysql_sql .= "  ,KEY category_id (category_id)";
				$mysql_sql .= "  ,KEY friendly_url (friendly_url)";
				$mysql_sql .= "  ,PRIMARY KEY (manual_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "manuals_list START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "manuals_list (";
				$postgre_sql .= "  manual_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "manuals_list'),";
				$postgre_sql .= "  category_id INT4 default '0',";
				$postgre_sql .= "  alias_manual_id INT4 default '0',";
				$postgre_sql .= "  manual_order INT4 default '0',";
				$postgre_sql .= "  manual_title VARCHAR(255),";
				$postgre_sql .= "  friendly_url VARCHAR(255),";
				$postgre_sql .= "  short_description TEXT,";
				$postgre_sql .= "  full_description TEXT,";
				$postgre_sql .= "  allowed_view INT4 default '0',";
				$postgre_sql .= "  meta_title VARCHAR(255),";
				$postgre_sql .= "  meta_keywords VARCHAR(255),";
				$postgre_sql .= "  meta_description VARCHAR(255),";
				$postgre_sql .= "  date_added TIMESTAMP,";
				$postgre_sql .= "  date_modified TIMESTAMP,";
				$postgre_sql .= "  admin_id_added_by INT4 default '0',";
				$postgre_sql .= "  admin_id_modified_by INT4 default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (manual_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "manuals_list (";
				$access_sql .= "  [manual_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [category_id] INTEGER,";
				$access_sql .= "  [alias_manual_id] INTEGER,";
				$access_sql .= "  [manual_order] INTEGER,";
				$access_sql .= "  [manual_title] VARCHAR(255),";
				$access_sql .= "  [friendly_url] VARCHAR(255),";
				$access_sql .= "  [short_description] LONGTEXT,";
				$access_sql .= "  [full_description] LONGTEXT,";
				$access_sql .= "  [allowed_view] INTEGER,";
				$access_sql .= "  [meta_title] VARCHAR(255),";
				$access_sql .= "  [meta_keywords] VARCHAR(255),";
				$access_sql .= "  [meta_description] VARCHAR(255),";
				$access_sql .= "  [date_added] DATETIME,";
				$access_sql .= "  [date_modified] DATETIME,";
				$access_sql .= "  [admin_id_added_by] INTEGER,";
				$access_sql .= "  [admin_id_modified_by] INTEGER";
				$access_sql .= "  ,PRIMARY KEY (manual_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "manuals_list_alias_manual_id ON " . $table_prefix . "manuals_list (alias_manual_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "manuals_list_category_id ON " . $table_prefix . "manuals_list (category_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "manuals_list_friendly_url ON " . $table_prefix . "manuals_list (friendly_url)";
				}

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "manuals_articles (";
				$mysql_sql .= "  `article_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `manual_id` INT(11) default '0',";
				$mysql_sql .= "  `parent_article_id` INT(11) default '0',";
				$mysql_sql .= "  `alias_article_id` INT(11) default '0',";
				$mysql_sql .= "  `article_path` VARCHAR(255) NOT NULL,";
				$mysql_sql .= "  `article_title` VARCHAR(255),";
				$mysql_sql .= "  `friendly_url` VARCHAR(255),";
				$mysql_sql .= "  `article_order` INT(11) default '0',";
				$mysql_sql .= "  `section_number` VARCHAR(255),";
				$mysql_sql .= "  `image_small` VARCHAR(255),";
				$mysql_sql .= "  `image_small_alt` VARCHAR(255),";
				$mysql_sql .= "  `image_large` VARCHAR(255),";
				$mysql_sql .= "  `image_large_alt` VARCHAR(255),";
				$mysql_sql .= "  `short_description` TEXT,";
				$mysql_sql .= "  `full_description` TEXT,";
				$mysql_sql .= "  `allowed_view` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `shown_in_contents` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `meta_title` VARCHAR(255),";
				$mysql_sql .= "  `meta_keywords` VARCHAR(255),";
				$mysql_sql .= "  `meta_description` VARCHAR(255),";
				$mysql_sql .= "  `date_added` DATETIME,";
				$mysql_sql .= "  `date_modified` DATETIME,";
				$mysql_sql .= "  `admin_id_added_by` INT(11) default '0',";
				$mysql_sql .= "  `admin_id_modified_by` INT(11) default '0'";
				$mysql_sql .= "  ,KEY alias_article_id (alias_article_id)";
				$mysql_sql .= "  ,KEY article_path (article_path)";
				$mysql_sql .= "  ,KEY friendly_url (friendly_url)";
				$mysql_sql .= "  ,KEY manual_id (manual_id)";
				$mysql_sql .= "  ,KEY parent_article_id (parent_article_id)";
				$mysql_sql .= "  ,PRIMARY KEY (article_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "manuals_articles START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "manuals_articles (";
				$postgre_sql .= "  article_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "manuals_articles'),";
				$postgre_sql .= "  manual_id INT4 default '0',";
				$postgre_sql .= "  parent_article_id INT4 default '0',";
				$postgre_sql .= "  alias_article_id INT4 default '0',";
				$postgre_sql .= "  article_path VARCHAR(255) NOT NULL,";
				$postgre_sql .= "  article_title VARCHAR(255),";
				$postgre_sql .= "  friendly_url VARCHAR(255),";
				$postgre_sql .= "  article_order INT4 default '0',";
				$postgre_sql .= "  section_number VARCHAR(255),";
				$postgre_sql .= "  image_small VARCHAR(255),";
				$postgre_sql .= "  image_small_alt VARCHAR(255),";
				$postgre_sql .= "  image_large VARCHAR(255),";
				$postgre_sql .= "  image_large_alt VARCHAR(255),";
				$postgre_sql .= "  short_description TEXT,";
				$postgre_sql .= "  full_description LONGTEXT,";
				$postgre_sql .= "  allowed_view INT4 NOT NULL default '0',";
				$postgre_sql .= "  shown_in_contents INT4 NOT NULL default '0',";
				$postgre_sql .= "  meta_title VARCHAR(255),";
				$postgre_sql .= "  meta_keywords VARCHAR(255),";
				$postgre_sql .= "  meta_description VARCHAR(255),";
				$postgre_sql .= "  date_added TIMESTAMP,";
				$postgre_sql .= "  date_modified TIMESTAMP,";
				$postgre_sql .= "  admin_id_added_by INT4 default '0',";
				$postgre_sql .= "  admin_id_modified_by INT4 default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (article_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "manuals_articles (";
				$access_sql .= "  [article_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [manual_id] INTEGER,";
				$access_sql .= "  [parent_article_id] INTEGER,";
				$access_sql .= "  [alias_article_id] INTEGER,";
				$access_sql .= "  [article_path] VARCHAR(255),";
				$access_sql .= "  [article_title] VARCHAR(255),";
				$access_sql .= "  [friendly_url] VARCHAR(255),";
				$access_sql .= "  [article_order] INTEGER,";
				$access_sql .= "  [section_number] VARCHAR(255),";
				$access_sql .= "  [image_small] VARCHAR(255),";
				$access_sql .= "  [image_small_alt] VARCHAR(255),";
				$access_sql .= "  [image_large] VARCHAR(255),";
				$access_sql .= "  [image_large_alt] VARCHAR(255),";
				$access_sql .= "  [short_description] LONGTEXT,";
				$access_sql .= "  [full_description] LONGTEXT,";
				$access_sql .= "  [allowed_view] INTEGER,";
				$access_sql .= "  [shown_in_contents] INTEGER,";
				$access_sql .= "  [meta_title] VARCHAR(255),";
				$access_sql .= "  [meta_keywords] VARCHAR(255),";
				$access_sql .= "  [meta_description] VARCHAR(255),";
				$access_sql .= "  [date_added] DATETIME,";
				$access_sql .= "  [date_modified] DATETIME,";
				$access_sql .= "  [admin_id_added_by] INTEGER,";
				$access_sql .= "  [admin_id_modified_by] INTEGER";
				$access_sql .= "  ,PRIMARY KEY (article_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "manuals_articles_alias_a_15 ON " . $table_prefix . "manuals_articles (alias_article_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "manuals_articles_article_path ON " . $table_prefix . "manuals_articles (article_path)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "manuals_articles_friendly_url ON " . $table_prefix . "manuals_articles (friendly_url)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "manuals_articles_manual_id ON " . $table_prefix . "manuals_articles (manual_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "manuals_articles_parent__16 ON " . $table_prefix . "manuals_articles (parent_article_id)";
				}


				$mysql_sql  = "CREATE TABLE " . $table_prefix . "search_engines (";
				$mysql_sql .= "  `engine_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `engine_name` VARCHAR(64),";
				$mysql_sql .= "  `keywords_parameter` VARCHAR(32),";
				$mysql_sql .= "  `referer_regexp` TEXT,";
				$mysql_sql .= "  `user_agent_regexp` TEXT,";
				$mysql_sql .= "  `ip_regexp` TEXT";
				$mysql_sql .= "  ,PRIMARY KEY (engine_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "search_engines START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "search_engines (";
				$postgre_sql .= "  engine_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "search_engines'),";
				$postgre_sql .= "  engine_name VARCHAR(64),";
				$postgre_sql .= "  keywords_parameter VARCHAR(32),";
				$postgre_sql .= "  referer_regexp TEXT,";
				$postgre_sql .= "  user_agent_regexp TEXT,";
				$postgre_sql .= "  ip_regexp TEXT";
				$postgre_sql .= "  ,PRIMARY KEY (engine_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "search_engines (";
				$access_sql .= "  [engine_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [engine_name] VARCHAR(64),";
				$access_sql .= "  [keywords_parameter] VARCHAR(32),";
				$access_sql .= "  [referer_regexp] LONGTEXT,";
				$access_sql .= "  [user_agent_regexp] LONGTEXT,";
				$access_sql .= "  [ip_regexp] LONGTEXT";
				$access_sql .= "  ,PRIMARY KEY (engine_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "users_files (";
				$mysql_sql .= "  `file_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `user_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `file_type` VARCHAR(32),";
				$mysql_sql .= "  `file_name` VARCHAR(255),";
				$mysql_sql .= "  `file_path` VARCHAR(255)";
				$mysql_sql .= "  ,PRIMARY KEY (file_id)";
				$mysql_sql .= "  ,KEY user_id (user_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "users_files START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "users_files (";
				$postgre_sql .= "  file_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "users_files'),";
				$postgre_sql .= "  user_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  file_type VARCHAR(32),";
				$postgre_sql .= "  file_name VARCHAR(255),";
				$postgre_sql .= "  file_path VARCHAR(255)";
				$postgre_sql .= "  ,PRIMARY KEY (file_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "users_files (";
				$access_sql .= "  [file_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [user_id] INTEGER,";
				$access_sql .= "  [file_type] VARCHAR(32),";
				$access_sql .= "  [file_name] VARCHAR(255),";
				$access_sql .= "  [file_path] VARCHAR(255)";
				$access_sql .= "  ,PRIMARY KEY (file_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "users_files_user_id ON " . $table_prefix . "users_files (user_id)";
				}

				// Copy products_list page settings to new products_search page
				$sql = "SELECT * FROM " . $table_prefix . "page_settings WHERE page_name='products_list'";
				$db->query($sql);
				while ($db->next_record()) {
					$setting_name = $db->f("setting_name");
					$setting_order = $db->f("setting_order");
					$setting_value = $db->f("setting_value");
					$sql  = " INSERT INTO " . $table_prefix . "page_settings (layout_id, page_name, setting_name, setting_order, setting_value) VALUES (0, 'products_search', ";
					$sql .= $db->tosql($setting_name, TEXT, true, false) . ",";
					$sql .= $db->tosql($setting_order, INTEGER) . ",";
					$sql .= $db->tosql($setting_value, TEXT, true, false) . ")";
					$sqls[] = $sql;
				}

				if ($db_type == "mysql") {
					$sqls[] = " INSERT INTO " . $table_prefix . "search_engines (engine_id, engine_name, keywords_parameter, referer_regexp, user_agent_regexp) VALUES (1, 'Google', 'q', '/http:\\\\/\\\\/www\\\\.google\\\\.\\\\w{2,4}(\\\\.\\\\w{2})?\\\\//i', '/Googlebot.*google\\\\.com/i')";
					$sqls[] = " INSERT INTO " . $table_prefix . "search_engines (engine_id, engine_name, keywords_parameter, referer_regexp, user_agent_regexp) VALUES (2, 'Yahoo', 'p', '/search\\\\.yahoo\\\\.com\\\\//i', '/Yahoo.*Slurp.*yahoo\\\\.com/i')";
					$sqls[] = " INSERT INTO " . $table_prefix . "search_engines (engine_id, engine_name, keywords_parameter, referer_regexp, user_agent_regexp) VALUES (3, 'MSN', 'q', '/search(\\\\.\\\\w+)?\\\\.msn\\\\.\\\\w{2,4}(\\\\.\\\\w{2})?\\\\//i', '/msnbot.*msn\\\\.com/i')";
					$sqls[] = " INSERT INTO " . $table_prefix . "search_engines (engine_id, engine_name, keywords_parameter, referer_regexp, user_agent_regexp) VALUES (4, 'Ask.com', 'q', '/\\\\.ask\\\\.com\\\\//i', '/Ask.*Jeeves\\\\/Teoma.*ask\\\\.com/i')";
					$sqls[] = " INSERT INTO " . $table_prefix . "search_engines (engine_id, engine_name, keywords_parameter, referer_regexp, user_agent_regexp) VALUES (5, 'Gigablast', 'q', '/gigablast\\\\.com\\\\//i', '/Gigabot.*gigablast\\\\.com/i')";
					$sqls[] = " INSERT INTO " . $table_prefix . "search_engines (engine_id, engine_name, keywords_parameter, referer_regexp, user_agent_regexp) VALUES (6, 'Exalead', 'q', '/exalead\\\\.com\\\\//i', '/Exabot/i')";
					$sqls[] = " INSERT INTO " . $table_prefix . "search_engines (engine_id, engine_name, keywords_parameter, referer_regexp, user_agent_regexp) VALUES (7, 'LookSmart', 'qt', '/looksmart\\\\.(com|net)\\\\//i', '/ZyBorg.*looksmart.*WISEnutbot\\\\.com/i')";
					$sqls[] = " INSERT INTO " . $table_prefix . "search_engines (engine_id, engine_name, keywords_parameter, referer_regexp, user_agent_regexp) VALUES (8, 'Zibb', 'q', '/zibb\\\\.com\\\\//i', '/Zibber.*zibb\\\\.com/i')";
					$sqls[] = " INSERT INTO " . $table_prefix . "search_engines (engine_id, engine_name, keywords_parameter, referer_regexp, user_agent_regexp) VALUES (9, 'Entireweb', 'q', '/entireweb\\\\.com\\\\//i', '/Speedy.*Spider.*entireweb\\\\.com/i')";
					$sqls[] = " INSERT INTO " . $table_prefix . "search_engines (engine_id, engine_name, keywords_parameter, referer_regexp, user_agent_regexp) VALUES (10, 'Seekport', 'query', '/seekport\\\\.\\\\w{2,4}(\\\\.\\\\w{2})?\\\\//i', '/Seekbot.*Seekbot\\\\.net/i')";
					$sqls[] = " INSERT INTO " . $table_prefix . "search_engines (engine_id, engine_name, keywords_parameter, referer_regexp, user_agent_regexp) VALUES (11, 'Become', 'q', '/become\\\\.com\\\\//i', '/BecomeBot.*become\\\\.com/i')";
				} elseif ($db_type == "postgre") {
					$sqls[] = " INSERT INTO " . $table_prefix . "search_engines (engine_id, engine_name, keywords_parameter, referer_regexp, user_agent_regexp) VALUES (1, 'Google', 'q', '/http:\\\\/\\\\/www\\\\.google\\\\.\\\\w{2,4}(\\\\.\\\\w{2})?\\\\//i', '/Googlebot.*google\\\\.com/i')";
					$sqls[] = " INSERT INTO " . $table_prefix . "search_engines (engine_id, engine_name, keywords_parameter, referer_regexp, user_agent_regexp) VALUES (2, 'Yahoo', 'p', '/search\\\\.yahoo\\\\.com\\\\//i', '/Yahoo.*Slurp.*yahoo\\\\.com/i')";
					$sqls[] = " INSERT INTO " . $table_prefix . "search_engines (engine_id, engine_name, keywords_parameter, referer_regexp, user_agent_regexp) VALUES (3, 'MSN', 'q', '/search(\\\\.\\\\w+)?\\\\.msn\\\\.\\\\w{2,4}(\\\\.\\\\w{2})?\\\\//i', '/msnbot.*msn\\\\.com/i')";
					$sqls[] = " INSERT INTO " . $table_prefix . "search_engines (engine_id, engine_name, keywords_parameter, referer_regexp, user_agent_regexp) VALUES (4, 'Ask.com', 'q', '/\\\\.ask\\\\.com\\\\//i', '/Ask.*Jeeves\\\\/Teoma.*ask\\\\.com/i')";
					$sqls[] = " INSERT INTO " . $table_prefix . "search_engines (engine_id, engine_name, keywords_parameter, referer_regexp, user_agent_regexp) VALUES (5, 'Gigablast', 'q', '/gigablast\\\\.com\\\\//i', '/Gigabot.*gigablast\\\\.com/i')";
					$sqls[] = " INSERT INTO " . $table_prefix . "search_engines (engine_id, engine_name, keywords_parameter, referer_regexp, user_agent_regexp) VALUES (6, 'Exalead', 'q', '/exalead\\\\.com\\\\//i', '/Exabot/i')";
					$sqls[] = " INSERT INTO " . $table_prefix . "search_engines (engine_id, engine_name, keywords_parameter, referer_regexp, user_agent_regexp) VALUES (7, 'LookSmart', 'qt', '/looksmart\\\\.(com|net)\\\\//i', '/ZyBorg.*looksmart.*WISEnutbot\\\\.com/i')";
					$sqls[] = " INSERT INTO " . $table_prefix . "search_engines (engine_id, engine_name, keywords_parameter, referer_regexp, user_agent_regexp) VALUES (8, 'Zibb', 'q', '/zibb\\\\.com\\\\//i', '/Zibber.*zibb\\\\.com/i')";
					$sqls[] = " INSERT INTO " . $table_prefix . "search_engines (engine_id, engine_name, keywords_parameter, referer_regexp, user_agent_regexp) VALUES (9, 'Entireweb', 'q', '/entireweb\\\\.com\\\\//i', '/Speedy.*Spider.*entireweb\\\\.com/i')";
					$sqls[] = " INSERT INTO " . $table_prefix . "search_engines (engine_id, engine_name, keywords_parameter, referer_regexp, user_agent_regexp) VALUES (10, 'Seekport', 'query', '/seekport\\\\.\\\\w{2,4}(\\\\.\\\\w{2})?\\\\//i', '/Seekbot.*Seekbot\\\\.net/i')";
					$sqls[] = " INSERT INTO " . $table_prefix . "search_engines (engine_id, engine_name, keywords_parameter, referer_regexp, user_agent_regexp) VALUES (11, 'Become', 'q', '/become\\\\.com\\\\//i', '/BecomeBot.*become\\\\.com/i')";
				} elseif ($db_type == "access") {
					$sqls[] = " INSERT INTO " . $table_prefix . "search_engines (engine_id, engine_name, keywords_parameter, referer_regexp, user_agent_regexp) VALUES (1, 'Google', 'q', '/http:\/\/www\.google\.\w{2,4}(\.\w{2})?\//i', '/Googlebot.*google\.com/i')";
					$sqls[] = " INSERT INTO " . $table_prefix . "search_engines (engine_id, engine_name, keywords_parameter, referer_regexp, user_agent_regexp) VALUES (2, 'Yahoo', 'p', '/search\.yahoo\.com\//i', '/Yahoo.*Slurp.*yahoo\.com/i')";
					$sqls[] = " INSERT INTO " . $table_prefix . "search_engines (engine_id, engine_name, keywords_parameter, referer_regexp, user_agent_regexp) VALUES (3, 'MSN', 'q', '/search(\.\w+)?\.msn\.\w{2,4}(\.\w{2})?\//i', '/msnbot.*msn\.com/i')";
					$sqls[] = " INSERT INTO " . $table_prefix . "search_engines (engine_id, engine_name, keywords_parameter, referer_regexp, user_agent_regexp) VALUES (4, 'Ask.com', 'q', '/\.ask\.com\//i', '/Ask.*Jeeves\/Teoma.*ask\.com/i')";
					$sqls[] = " INSERT INTO " . $table_prefix . "search_engines (engine_id, engine_name, keywords_parameter, referer_regexp, user_agent_regexp) VALUES (5, 'Gigablast', 'q', '/gigablast\.com\//i', '/Gigabot.*gigablast\.com/i')";
					$sqls[] = " INSERT INTO " . $table_prefix . "search_engines (engine_id, engine_name, keywords_parameter, referer_regexp, user_agent_regexp) VALUES (6, 'Exalead', 'q', '/exalead\.com\//i', '/Exabot/i')";
					$sqls[] = " INSERT INTO " . $table_prefix . "search_engines (engine_id, engine_name, keywords_parameter, referer_regexp, user_agent_regexp) VALUES (7, 'LookSmart', 'qt', '/looksmart\.(com|net)\//i', '/ZyBorg.*looksmart.*WISEnutbot\.com/i')";
					$sqls[] = " INSERT INTO " . $table_prefix . "search_engines (engine_id, engine_name, keywords_parameter, referer_regexp, user_agent_regexp) VALUES (8, 'Zibb', 'q', '/zibb\.com\//i', '/Zibber.*zibb\.com/i')";
					$sqls[] = " INSERT INTO " . $table_prefix . "search_engines (engine_id, engine_name, keywords_parameter, referer_regexp, user_agent_regexp) VALUES (9, 'Entireweb', 'q', '/entireweb\.com\//i', '/Speedy.*Spider.*entireweb\.com/i')";
					$sqls[] = " INSERT INTO " . $table_prefix . "search_engines (engine_id, engine_name, keywords_parameter, referer_regexp, user_agent_regexp) VALUES (10, 'Seekport', 'query', '/seekport\.\w{2,4}(\.\w{2})?\//i', '/Seekbot.*Seekbot\.net/i')";
					$sqls[] = " INSERT INTO " . $table_prefix . "search_engines (engine_id, engine_name, keywords_parameter, referer_regexp, user_agent_regexp) VALUES (11, 'Become', 'q', '/become.com\//i', '/BecomeBot.*become\.com/i')";
				}

				// Add default parameters for manuals pages
				$sqls[] = " INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0 , 'manuals_article_details' , 'left_column_hide' , NULL , '0' )";
				$sqls[] = " INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0 , 'manuals_article_details' , 'left_column_width' , NULL , '25%' )";
				$sqls[] = " INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0 , 'manuals_article_details' , 'manuals_article_details' , 0 , 'middle' )";
				$sqls[] = " INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0 , 'manuals_article_details' , 'manuals_search' , 0 , 'left' )";
				$sqls[] = " INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0 , 'manuals_article_details' , 'middle_column_hide' , NULL , '0' )";
				$sqls[] = " INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0 , 'manuals_article_details' , 'middle_column_width' , NULL , '75%' )";
				$sqls[] = " INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0 , 'manuals_article_details' , 'right_column_hide' , NULL , '1' )";
				$sqls[] = " INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0 , 'manuals_articles' , 'left_column_hide' , NULL , '0' )";
				$sqls[] = " INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0 , 'manuals_articles' , 'left_column_width' , NULL , '25%' )";
				$sqls[] = " INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0 , 'manuals_articles' , 'manuals_articles' , 0 , 'middle' )";
				$sqls[] = " INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0 , 'manuals_articles' , 'manuals_search' , 0 , 'left' )";
				$sqls[] = " INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0 , 'manuals_articles' , 'middle_column_hide' , NULL , '0' )";
				$sqls[] = " INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0 , 'manuals_articles' , 'middle_column_width' , NULL , '75%' )";
				$sqls[] = " INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0 , 'manuals_articles' , 'right_column_hide' , NULL , '1' )";
				$sqls[] = " INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0 , 'manuals_articles' , 'right_column_width' , NULL , '0%' )";
				$sqls[] = " INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0 , 'manuals_list' , 'left_column_hide' , NULL , '0' )";
				$sqls[] = " INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0 , 'manuals_list' , 'left_column_width' , NULL , '25%' )";
				$sqls[] = " INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0 , 'manuals_list' , 'manuals_list' , 0 , 'middle' )";
				$sqls[] = " INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0 , 'manuals_list' , 'manuals_search' , 0 , 'left' )";
				$sqls[] = " INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0 , 'manuals_list' , 'middle_column_hide' , NULL , '0' )";
				$sqls[] = " INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0 , 'manuals_list' , 'middle_column_width' , NULL , '75%' )";
				$sqls[] = " INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0 , 'manuals_list' , 'right_column_hide' , NULL , '1' )";
				$sqls[] = " INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0 , 'manuals_search' , 'left_column_hide' , NULL , '0' )";
				$sqls[] = " INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0 , 'manuals_search' , 'left_column_width' , NULL , '25%' )";
				$sqls[] = " INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0 , 'manuals_search' , 'manuals_search' , 0 , 'left' )";
				$sqls[] = " INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0 , 'manuals_search' , 'manuals_search_results' , 0 , 'middle' )";
				$sqls[] = " INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0 , 'manuals_search' , 'middle_column_hide' , NULL , '0' )";
				$sqls[] = " INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0 , 'manuals_search' , 'middle_column_width' , NULL , '75%' )";
				$sqls[] = " INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0 , 'manuals_search' , 'right_column_hide' , NULL , '1' )";

				// add new permission for admin
				$permissions = array("admins_groups", "admins_login", "add_admins", "update_admins", "remove_admins");
				$sql = " SELECT privilege_id FROM  " . $table_prefix . "admin_privileges_settings WHERE block_name='admin_users' AND permission=1 ";
				$db->query($sql);
				while ($db->next_record()) {
					$privilege_id = $db->f("privilege_id");
					for ($i = 0; $i < sizeof($permissions); $i++) {
						$sql  = " INSERT INTO " . $table_prefix . "admin_privileges_settings (privilege_id, block_name, permission) VALUES (";
						$sql .= $db->tosql($privilege_id, INTEGER) . ", '" . $permissions[$i] . "',1)";
						$sqls[] = $sql;
					}
				}

				// add new permission for customer
				$user_permissions = array("my_orders", "my_details", "my_support", "my_forum");
				$sql = " SELECT type_id FROM  " . $table_prefix . "user_types ";
				$db->query($sql);
				while ($db->next_record()) {
					$type_id = $db->f("type_id");
					for ($i = 0; $i < sizeof($user_permissions); $i++) {
						$sql  = " INSERT INTO " . $table_prefix . "user_types_settings (type_id, setting_name, setting_value) VALUES (";
						$sql .= $db->tosql($type_id, INTEGER) . ", '" . $user_permissions[$i] . "','1')";
						$sqls[] = $sql;
					}
				}
			}

			if (comp_vers("2.8.1", $current_db_version) == 1)
			{
				$mysql_sql  = "CREATE TABLE " . $table_prefix . "bookmarks (";
				$mysql_sql .= "  `bookmark_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `title` VARCHAR(50) NOT NULL,";
				$mysql_sql .= "  `url` VARCHAR(255) NOT NULL,";
				$mysql_sql .= "  `admin_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `image_path` VARCHAR(255),";
				$mysql_sql .= "  `is_start_page` INT(11) default '0',";
				$mysql_sql .= "  `is_popup` INT(11) default '0',";
				$mysql_sql .= "  `notes` VARCHAR(255)";
				$mysql_sql .= "  ,PRIMARY KEY (bookmark_id)";
				$mysql_sql .= "  ,KEY admin_id (admin_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "bookmarks START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "bookmarks (";
				$postgre_sql .= "  bookmark_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "bookmarks'),";
				$postgre_sql .= "  title VARCHAR(50) NOT NULL,";
				$postgre_sql .= "  url VARCHAR(255) NOT NULL,";
				$postgre_sql .= "  admin_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  image_path VARCHAR(255),";
				$postgre_sql .= "  is_start_page INT4 default '0',";
				$postgre_sql .= "  is_popup INT4 default '0',";
				$postgre_sql .= "  notes VARCHAR(255)";
				$postgre_sql .= "  ,PRIMARY KEY (bookmark_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "bookmarks (";
				$access_sql .= "  [bookmark_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [title] VARCHAR(50),";
				$access_sql .= "  [url] VARCHAR(255),";
				$access_sql .= "  [admin_id] INTEGER,";
				$access_sql .= "  [image_path] VARCHAR(255),";
				$access_sql .= "  [is_start_page] INTEGER,";
				$access_sql .= "  [is_popup] INTEGER,";
				$access_sql .= "  [notes] VARCHAR(255)";
				$access_sql .= "  ,PRIMARY KEY (bookmark_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "bookmarks_admin_id ON " . $table_prefix . "bookmarks (admin_id)";
				}

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN total_views INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN total_views INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN total_views INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN total_views INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN total_views INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN total_views INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN total_views INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN total_views INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN total_views INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "ads_categories ADD COLUMN total_views INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "ads_categories ADD COLUMN total_views INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "ads_categories ADD COLUMN total_views INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "ads_items ADD COLUMN total_views INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "ads_items ADD COLUMN total_views INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "ads_items ADD COLUMN total_views INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = "INSERT INTO " . $table_prefix . "issue_numbers (issue_number) VALUES (0)";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "users ADD COLUMN tax_free INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "users ADD COLUMN tax_free INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "users ADD COLUMN tax_free INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN tax_free INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN tax_free INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN tax_free INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "mysql") {
					$sqls[] = "ALTER TABLE " . $table_prefix . "orders_items_properties MODIFY COLUMN property_value TEXT DEFAULT NULL ";
				} elseif ($db_type == "access") {
					$sqls[] = "ALTER TABLE " . $table_prefix . "orders_items_properties ALTER COLUMN property_value LONGTEXT ";
				}

				if ($db_type == "mysql") {
					$sqls[] = "ALTER TABLE " . $table_prefix . "orders MODIFY COLUMN country_code VARCHAR(8) ";
					$sqls[] = "ALTER TABLE " . $table_prefix . "orders MODIFY COLUMN delivery_country_code VARCHAR(8) ";
					$sqls[] = "ALTER TABLE " . $table_prefix . "users MODIFY COLUMN country_code VARCHAR(8) ";
					$sqls[] = "ALTER TABLE " . $table_prefix . "users MODIFY COLUMN delivery_country_code VARCHAR(8) ";
				} elseif ($db_type == "access") {
					$sqls[] = "ALTER TABLE " . $table_prefix . "orders ALTER COLUMN country_code VARCHAR(8) ";
					$sqls[] = "ALTER TABLE " . $table_prefix . "orders ALTER COLUMN delivery_country_code VARCHAR(8) ";
					$sqls[] = "ALTER TABLE " . $table_prefix . "users ALTER COLUMN country_code VARCHAR(8) ";
					$sqls[] = "ALTER TABLE " . $table_prefix . "users ALTER COLUMN delivery_country_code VARCHAR(8) ";
				}

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "shipping_rules ADD COLUMN is_country_restriction INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "shipping_rules ADD COLUMN is_country_restriction INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "shipping_rules ADD COLUMN is_country_restriction INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "shipping_rules_countries (";
				$mysql_sql .= "  `shipping_rule_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `country_code` VARCHAR(4)";
				$mysql_sql .= "  ,KEY country_code (country_code)";
				$mysql_sql .= "  ,KEY shipping_rule_id (shipping_rule_id))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "shipping_rules_countries (";
				$postgre_sql .= "  shipping_rule_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  country_code VARCHAR(4))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "shipping_rules_countries (";
				$access_sql .= "  [shipping_rule_id] INTEGER,";
				$access_sql .= "  [country_code] VARCHAR(4))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "shipping_rules_countries_34 ON " . $table_prefix . "shipping_rules_countries (country_code)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "shipping_rules_countries_35 ON " . $table_prefix . "shipping_rules_countries (shipping_rule_id)";
				}

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN recurring_method INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN recurring_method INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN recurring_method INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN is_recurring INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN is_recurring INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN is_recurring INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN recurring_period INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN recurring_period INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN recurring_period INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN recurring_payments_total INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN recurring_payments_total INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN recurring_payments_total INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN parent_order_item_id INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN parent_order_item_id INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN parent_order_item_id INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN is_recurring INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN is_recurring INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN is_recurring INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN recurring_period INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN recurring_period INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN recurring_period INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN recurring_payments_total INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN recurring_payments_total INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN recurring_payments_total INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN recurring_last_payment DATETIME ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN recurring_last_payment TIMESTAMP ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN recurring_last_payment DATETIME "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN recurring_next_payment DATETIME ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN recurring_next_payment TIMESTAMP ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN recurring_next_payment DATETIME "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN is_recurring INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN is_recurring INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN is_recurring INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN parent_order_id INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN parent_order_id INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN parent_order_id INTEGER "
				);
				$sqls[] = $sql_types[$db_type];


				// add new permission for admin
				$permissions = array("product_types", "manufacturers", "shipping_methods", "shipping_times", "shipping_rules");
				$sql = " SELECT privilege_id FROM  " . $table_prefix . "admin_privileges_settings WHERE block_name='static_tables' AND permission=1 ";
				$db->query($sql);
				while ($db->next_record()) {
					$privilege_id = $db->f("privilege_id");
					for ($i = 0; $i < sizeof($permissions); $i++) {
						$sql  = " INSERT INTO " . $table_prefix . "admin_privileges_settings (privilege_id, block_name, permission) VALUES (";
						$sql .= $db->tosql($privilege_id, INTEGER) . ", '" . $permissions[$i] . "',1)";
						$sqls[] = $sql;
					}
				}
			}

			if (comp_vers("2.8.2", $current_db_version) == 1)
			{
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items_properties_values ADD COLUMN percentage_price DOUBLE(16,2) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items_properties_values ADD COLUMN percentage_price FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "items_properties_values ADD COLUMN percentage_price FLOAT"
				);
				$sqls[] = $sql_types[$db_type];
			}

			if (comp_vers("2.8.3", $current_db_version) == 1)
			{
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "forum ADD COLUMN thread_updated DATETIME default '0000-00-00 00:00:00' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "forum ADD COLUMN thread_updated TIMESTAMP ",
					"access"  => "ALTER TABLE " . $table_prefix . "forum ADD COLUMN thread_updated DATETIME "
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "forum SET thread_updated=date_modified ";
			}


			if (comp_vers("2.8.4", $current_db_version) == 1)
			{
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN author_id INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN author_id INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN author_id INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "authors (";
				$mysql_sql .= "  `author_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `author_name` VARCHAR(255),";
				$mysql_sql .= "  `friendly_url` VARCHAR(255),";
				$mysql_sql .= "  `short_description` TEXT,";
				$mysql_sql .= "  `full_description` TEXT";
				$mysql_sql .= "  ,KEY friendly_url (friendly_url)";
				$mysql_sql .= "  ,PRIMARY KEY (author_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "authors START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "authors (";
				$postgre_sql .= "  author_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "authors'),";
				$postgre_sql .= "  author_name VARCHAR(255),";
				$postgre_sql .= "  friendly_url VARCHAR(255),";
				$postgre_sql .= "  short_description TEXT,";
				$postgre_sql .= "  full_description TEXT";
				$postgre_sql .= "  ,PRIMARY KEY (author_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "authors (";
				$access_sql .= "  [author_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [author_name] VARCHAR(255),";
				$access_sql .= "  [friendly_url] VARCHAR(255),";
				$access_sql .= "  [short_description] LONGTEXT,";
				$access_sql .= "  [full_description] LONGTEXT";
				$access_sql .= "  ,PRIMARY KEY (author_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "authors_friendly_url ON " . $table_prefix . "authors (friendly_url)";
				}

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "saved_carts (";
				$mysql_sql .= "  `cart_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `user_id` INT(11) default '0',";
				$mysql_sql .= "  `cart_name` VARCHAR(255),";
				$mysql_sql .= "  `cart_total` DOUBLE(16,2) default '0',";
				$mysql_sql .= "  `cart_added` DATETIME";
				$mysql_sql .= "  ,PRIMARY KEY (cart_id)";
				$mysql_sql .= "  ,KEY user_id (user_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "saved_carts START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "saved_carts (";
				$postgre_sql .= "  cart_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "saved_carts'),";
				$postgre_sql .= "  user_id INT4 default '0',";
				$postgre_sql .= "  cart_name VARCHAR(255),";
				$postgre_sql .= "  cart_total FLOAT4 default '0',";
				$postgre_sql .= "  cart_added TIMESTAMP";
				$postgre_sql .= "  ,PRIMARY KEY (cart_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "saved_carts (";
				$access_sql .= "  [cart_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [user_id] INTEGER,";
				$access_sql .= "  [cart_name] VARCHAR(255),";
				$access_sql .= "  [cart_total] FLOAT,";
				$access_sql .= "  [cart_added] DATETIME";
				$access_sql .= "  ,PRIMARY KEY (cart_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "saved_carts_user_id ON " . $table_prefix . "saved_carts (user_id)";
				}

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "saved_items (";
				$mysql_sql .= "  `cart_item_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `item_id` INT(11) default '0',";
				$mysql_sql .= "  `cart_id` INT(11) default '0',";
				$mysql_sql .= "  `user_id` INT(11) default '0',";
				$mysql_sql .= "  `item_name` VARCHAR(255),";
				$mysql_sql .= "  `quantity` INT(11) default '0',";
				$mysql_sql .= "  `price` INT(11) default '0',";
				$mysql_sql .= "  `date_added` DATETIME";
				$mysql_sql .= "  ,KEY cart_id (cart_id)";
				$mysql_sql .= "  ,KEY item_id (item_id)";
				$mysql_sql .= "  ,PRIMARY KEY (cart_item_id)";
				$mysql_sql .= "  ,KEY user_id (user_id))";
				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "saved_items START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "saved_items (";
				$postgre_sql .= "  cart_item_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "saved_items'),";
				$postgre_sql .= "  item_id INT4 default '0',";
				$postgre_sql .= "  cart_id INT4 default '0',";
				$postgre_sql .= "  user_id INT4 default '0',";
				$postgre_sql .= "  item_name VARCHAR(255),";
				$postgre_sql .= "  quantity INT4 default '0',";
				$postgre_sql .= "  price INT4 default '0',";
				$postgre_sql .= "  date_added TIMESTAMP";
				$postgre_sql .= "  ,PRIMARY KEY (cart_item_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "saved_items (";
				$access_sql .= "  [cart_item_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [item_id] INTEGER,";
				$access_sql .= "  [cart_id] INTEGER,";
				$access_sql .= "  [user_id] INTEGER,";
				$access_sql .= "  [item_name] VARCHAR(255),";
				$access_sql .= "  [quantity] INTEGER,";
				$access_sql .= "  [price] INTEGER,";
				$access_sql .= "  [date_added] DATETIME";
				$access_sql .= "  ,PRIMARY KEY (cart_item_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "saved_items_cart_id ON " . $table_prefix . "saved_items (cart_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "saved_items_item_id ON " . $table_prefix . "saved_items (item_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "saved_items_user_id ON " . $table_prefix . "saved_items (user_id)";
				}

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "saved_items_properties (";
				$mysql_sql .= "  `item_property_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `cart_item_id` INT(11) default '0',";
				$mysql_sql .= "  `cart_id` INT(11) default '0',";
				$mysql_sql .= "  `property_id` INT(11) default '0',";
				$mysql_sql .= "  `property_value` TEXT,";
				$mysql_sql .= "  `property_values_ids` TEXT";
				$mysql_sql .= "  ,KEY bakset_id (cart_item_id)";
				$mysql_sql .= "  ,KEY bakset_id1 (cart_id)";
				$mysql_sql .= "  ,PRIMARY KEY (item_property_id)";
				$mysql_sql .= "  ,KEY property_id (property_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "saved_items_properties START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "saved_items_properties (";
				$postgre_sql .= "  item_property_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "saved_items_properties'),";
				$postgre_sql .= "  cart_item_id INT4 default '0',";
				$postgre_sql .= "  cart_id INT4 default '0',";
				$postgre_sql .= "  property_id INT4 default '0',";
				$postgre_sql .= "  property_value TEXT,";
				$postgre_sql .= "  property_values_ids TEXT";
				$postgre_sql .= "  ,PRIMARY KEY (item_property_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "saved_items_properties (";
				$access_sql .= "  [item_property_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [cart_item_id] INTEGER,";
				$access_sql .= "  [cart_id] INTEGER,";
				$access_sql .= "  [property_id] INTEGER,";
				$access_sql .= "  [property_value] LONGTEXT,";
				$access_sql .= "  [property_values_ids] LONGTEXT";
				$access_sql .= "  ,PRIMARY KEY (item_property_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "saved_items_properties_b_33 ON " . $table_prefix . "saved_items_properties (cart_item_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "saved_items_properties_b_34 ON " . $table_prefix . "saved_items_properties (cart_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "saved_items_properties_p_35 ON " . $table_prefix . "saved_items_properties (property_id)";
				}


				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN recurring_interval INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN recurring_interval INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN recurring_interval INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN recurring_start_date DATETIME ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN recurring_start_date TIMESTAMP ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN recurring_start_date DATETIME "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN recurring_end_date DATETIME ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN recurring_end_date TIMESTAMP ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN recurring_end_date DATETIME "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN recurring_interval INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN recurring_interval INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN recurring_interval INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN recurring_payments_made INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN recurring_payments_made INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN recurring_payments_made INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN recurring_end_date DATETIME ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN recurring_end_date TIMESTAMP ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN recurring_end_date DATETIME "
				);
				$sqls[] = $sql_types[$db_type];


			}

			if (comp_vers("2.8.5", $current_db_version) == 1)
			{
				// begin quotes
				$mysql_sql  = "  CREATE TABLE " . $table_prefix . "quotes (";
				$mysql_sql .= "  `quote_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `user_id` INT(11) default '0',";
				$mysql_sql .= "  `user_name` VARCHAR(255),";
				$mysql_sql .= "  `user_email` VARCHAR(255),";
				$mysql_sql .= "  `order_id` INT(11) default '0',";
				$mysql_sql .= "  `quoted_price` DOUBLE(16,2) default '0',";
				$mysql_sql .= "  `quote_status_id` INT(11) default '0',";
				$mysql_sql .= "  `quoted_by_admin_id` INT(11) default '0',";
				$mysql_sql .= "  `is_paid` INT(11) default '0',";
				$mysql_sql .= "  `is_closed` INT(11) default '0',";
				$mysql_sql .= "  `date_added` DATETIME,";
				$mysql_sql .= "  `date_due` DATETIME,";
				$mysql_sql .= "  `request_summary` TEXT,";
				$mysql_sql .= "  `request_description` TEXT";
				$mysql_sql .= "  ,PRIMARY KEY (quote_id)";
				$mysql_sql .= "  ,KEY is_paid (is_paid)";
				$mysql_sql .= "  ,KEY order_id (order_id)";
				$mysql_sql .= "  ,KEY quote_status_id (quote_status_id)";
				$mysql_sql .= "  ,KEY quoted_by_admin_id (quoted_by_admin_id)";
				$mysql_sql .= "  ,KEY user_id (user_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "quotes START 1";
				}

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "quotes (";
				$postgre_sql .= "  quote_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "quotes'),";
				$postgre_sql .= "  user_id INT4 default '0',";
				$postgre_sql .= "  user_name VARCHAR(255),";
				$postgre_sql .= "  user_email VARCHAR(255),";
				$postgre_sql .= "  order_id INT4 default '0',";
				$postgre_sql .= "  quoted_price FLOAT4 default '0',";
				$postgre_sql .= "  quote_status_id INT4 default '0',";
				$postgre_sql .= "  quoted_by_admin_id INT4 default '0',";
				$postgre_sql .= "  is_paid INT4 default '0',";
				$postgre_sql .= "  is_closed INT4 default '0',";
				$postgre_sql .= "  date_added TIMESTAMP,";
				$postgre_sql .= "  date_due TIMESTAMP,";
				$postgre_sql .= "  request_summary TEXT,";
				$postgre_sql .= "  request_description TEXT";
				$postgre_sql .= "  ,PRIMARY KEY (quote_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "quotes (";
				$access_sql .= "  [quote_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [user_id] INTEGER,";
				$access_sql .= "  [user_name] VARCHAR(255),";
				$access_sql .= "  [user_email] VARCHAR(255),";
				$access_sql .= "  [order_id] INTEGER,";
				$access_sql .= "  [quoted_price] FLOAT,";
				$access_sql .= "  [quote_status_id] INTEGER,";
				$access_sql .= "  [quoted_by_admin_id] INTEGER,";
				$access_sql .= "  [is_paid] INTEGER,";
				$access_sql .= "  [is_closed] INTEGER,";
				$access_sql .= "  [date_added] DATETIME,";
				$access_sql .= "  [date_due] DATETIME,";
				$access_sql .= "  [request_summary] LONGTEXT,";
				$access_sql .= "  [request_description] LONGTEXT";
				$access_sql .= "  ,PRIMARY KEY (quote_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "quotes_is_paid ON " . $table_prefix . "quotes (is_paid)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "quotes_order_id ON " . $table_prefix . "quotes (order_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "quotes_quote_status_id ON " . $table_prefix . "quotes (quote_status_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "quotes_quoted_by_admin_id ON " . $table_prefix . "quotes (quoted_by_admin_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "quotes_user_id ON " . $table_prefix . "quotes (user_id)";
				}
				// end quotes

				// begin quotes_features
				$mysql_sql  = "  CREATE TABLE " . $table_prefix . "quotes_features (";
				$mysql_sql .= "  `feature_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `quote_id` INT(11) default '0',";
				$mysql_sql .= "  `feature_description` TEXT,";
				$mysql_sql .= "  `price` DOUBLE(16,2) default '0',";
				$mysql_sql .= "  `date_due` DATETIME";
				$mysql_sql .= "  ,PRIMARY KEY (feature_id)";
				$mysql_sql .= "  ,KEY quote_id (quote_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "quotes_features START 1";
				}

				$postgre_sql  = "  CREATE TABLE " . $table_prefix . "quotes_features (";
				$postgre_sql .= " feature_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "quotes_features'),";
				$postgre_sql .= " quote_id INT4 default '0',";
				$postgre_sql .= " feature_description TEXT,";
				$postgre_sql .= " price FLOAT4 default '0',";
				$postgre_sql .= " date_due TIMESTAMP";
				$postgre_sql .= " ,PRIMARY KEY (feature_id))";

				$access_sql  = "  CREATE TABLE " . $table_prefix . "quotes_features (";
				$access_sql .= " [feature_id]  COUNTER  NOT NULL,";
				$access_sql .= " [quote_id] INTEGER,";
				$access_sql .= " [feature_description] LONGTEXT,";
				$access_sql .= " [price] FLOAT,";
				$access_sql .= " [date_due] DATETIME";
				$access_sql .= " ,PRIMARY KEY (feature_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "quotes_features_quote_id ON " . $table_prefix . "quotes_features (quote_id)";
				}
				// end quotes_features

				// begin quotes_history
				$mysql_sql  = " CREATE TABLE " . $table_prefix . "quotes_history (";
				$mysql_sql .= " `quote_id` INT(11) default '0',";
				$mysql_sql .= " `quote_status_id_old` INT(11) default '0',";
				$mysql_sql .= " `quote_status_id_new` INT(11) default '0',";
				$mysql_sql .= " `action` VARCHAR(255),";
				$mysql_sql .= " `date_added` DATETIME,";
				$mysql_sql .= " `admin_id` INT(11) default '0'";
				$mysql_sql .= " ,KEY admin_id (admin_id)";
				$mysql_sql .= " ,KEY quote_id (quote_id))";

				$postgre_sql  = "  CREATE TABLE " . $table_prefix . "quotes_history (";
				$postgre_sql .= " quote_id INT4 default '0',";
				$postgre_sql .= " quote_status_id_old INT4 default '0',";
				$postgre_sql .= " quote_status_id_new INT4 default '0',";
				$postgre_sql .= " action VARCHAR(255),";
				$postgre_sql .= " date_added TIMESTAMP,";
				$postgre_sql .= " admin_id INT4 default '0')";

				$access_sql  = "  CREATE TABLE " . $table_prefix . "quotes_history (";
				$access_sql .= " [quote_id] INTEGER,";
				$access_sql .= " [quote_status_id_old] INTEGER,";
				$access_sql .= " [quote_status_id_new] INTEGER,";
				$access_sql .= " [action] VARCHAR(255),";
				$access_sql .= " [date_added] DATETIME,";
				$access_sql .= " [admin_id] INTEGER)";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "quotes_history_admin_id ON " . $table_prefix . "quotes_history (admin_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "quotes_history_quote_id ON " . $table_prefix . "quotes_history (quote_id)";
				}
				// end quotes_history

				// begin quotes_statuses
				$mysql_sql  = "  CREATE TABLE ". $table_prefix . "quotes_statuses (";
				$mysql_sql .= "  `quote_status_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `quote_status` VARCHAR(255),";
				$mysql_sql .= "  `start_tag` VARCHAR(255),";
				$mysql_sql .= "  `end_tag` VARCHAR(255),";
				$mysql_sql .= "  `image_path` VARCHAR(255),";
				$mysql_sql .= "  `notes` TEXT";
				$mysql_sql .= "  ,PRIMARY KEY (quote_status_id)";
				$mysql_sql .= "  ,KEY quote_status_id (quote_status_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "quotes_statuses START 1";
				}

				$postgre_sql  = "  CREATE TABLE ". $table_prefix . "quotes_statuses (";
				$postgre_sql .= " quote_status_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "quotes_statuses'),";
				$postgre_sql .= " quote_status VARCHAR(255),";
				$postgre_sql .= " start_tag VARCHAR(255),";
				$postgre_sql .= " end_tag VARCHAR(255),";
				$postgre_sql .= " image_path VARCHAR(255),";
				$postgre_sql .= " notes TEXT";
				$postgre_sql .= " ,PRIMARY KEY (quote_status_id))";

				$access_sql  = "  CREATE TABLE ". $table_prefix . "quotes_statuses (";
				$access_sql .= " [quote_status_id]  COUNTER  NOT NULL,";
				$access_sql .= " [quote_status] VARCHAR(255),";
				$access_sql .= " [start_tag] VARCHAR(255),";
				$access_sql .= " [end_tag] VARCHAR(255),";
				$access_sql .= " [image_path] VARCHAR(255),";
				$access_sql .= " [notes] LONGTEXT";
				$access_sql .= " ,PRIMARY KEY (quote_status_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "quotes_statuses_quote_st_33 ON " . $table_prefix . "quotes_statuses (quote_status_id)";
				}

				$sqls[] = " INSERT INTO " . $table_prefix . "quotes_statuses (quote_status_id, quote_status) VALUES ('1', 'New') ";
				$sqls[] = " INSERT INTO " . $table_prefix . "quotes_statuses (quote_status_id, quote_status) VALUES ('2', 'Quoted') ";
				$sqls[] = " INSERT INTO " . $table_prefix . "quotes_statuses (quote_status_id, quote_status) VALUES ('3', 'Paid') ";
				$sqls[] = " INSERT INTO " . $table_prefix . "quotes_statuses (quote_status_id, quote_status) VALUES ('4', 'In progress') ";
				// end quotes_statuses

				// begin Call Center fields
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN is_call_center INT(11) default '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN is_call_center INT4 default '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN is_call_center INTEGER"
				);
				$sqls[] = $sql_types[$db_type];
				// end Call Center fields

				// recurring fields
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN recurring_payments_failed INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN recurring_payments_failed INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN recurring_payments_failed INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN recurring_plan_payment DATETIME ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN recurring_plan_payment TIMESTAMP ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN recurring_plan_payment DATETIME "
				);
				$sqls[] = $sql_types[$db_type];
			}

			if (comp_vers("2.8.7", $current_db_version) == 1)
			{
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN paid_status INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN paid_status INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN paid_status INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql  = " UPDATE " . $table_prefix . "order_statuses SET paid_status=1 WHERE status_name LIKE '%Paid%' ";
				$sql .= " OR status_name LIKE '%shipped%' OR status_name LIKE '%Closed%' ";
				$sql .= " OR status_name LIKE '%Validated%' OR status_name LIKE '%Dispatched%' ";
				$sqls[] = $sql;
			}

			if (comp_vers("3.1.1", $current_db_version) == 1)
			{
				// profile custom fields
				$mysql_sql  = "CREATE TABLE " . $table_prefix . "user_profile_properties (";
				$mysql_sql .= "  `property_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `user_type_id` INT(11) default '0',";
				$mysql_sql .= "  `property_order` INT(11) default '0',";
				$mysql_sql .= "  `property_name` VARCHAR(255),";
				$mysql_sql .= "  `property_description` TEXT,";
				$mysql_sql .= "  `default_value` TEXT,";
				$mysql_sql .= "  `property_style` VARCHAR(255),";
				$mysql_sql .= "  `section_id` INT(11) default '0',";
				$mysql_sql .= "  `property_show` INT(11) default '0',";
				$mysql_sql .= "  `control_type` VARCHAR(16),";
				$mysql_sql .= "  `control_style` VARCHAR(255),";
				$mysql_sql .= "  `control_code` TEXT,";
				$mysql_sql .= "  `onchange_code` TEXT,";
				$mysql_sql .= "  `onclick_code` TEXT,";
				$mysql_sql .= "  `required` INT(11) default '0',";
				$mysql_sql .= "  `before_name_html` TEXT,";
				$mysql_sql .= "  `after_name_html` TEXT,";
				$mysql_sql .= "  `before_control_html` TEXT,";
				$mysql_sql .= "  `after_control_html` TEXT";
				$mysql_sql .= "  ,KEY payment_id (user_type_id)";
				$mysql_sql .= "  ,PRIMARY KEY (property_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "user_profile_properties START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "user_profile_properties (";
				$postgre_sql .= "  property_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "user_profile_properties'),";
				$postgre_sql .= "  user_type_id INT4 default '0',";
				$postgre_sql .= "  property_order INT4 default '0',";
				$postgre_sql .= "  property_name VARCHAR(255),";
				$postgre_sql .= "  property_description TEXT,";
				$postgre_sql .= "  default_value TEXT,";
				$postgre_sql .= "  property_style VARCHAR(255),";
				$postgre_sql .= "  section_id INT4 default '0',";
				$postgre_sql .= "  property_show INT4 default '0',";
				$postgre_sql .= "  control_type VARCHAR(16),";
				$postgre_sql .= "  control_style VARCHAR(255),";
				$postgre_sql .= "  control_code TEXT,";
				$postgre_sql .= "  onchange_code TEXT,";
				$postgre_sql .= "  onclick_code TEXT,";
				$postgre_sql .= "  required INT4 default '0',";
				$postgre_sql .= "  before_name_html TEXT,";
				$postgre_sql .= "  after_name_html TEXT,";
				$postgre_sql .= "  before_control_html TEXT,";
				$postgre_sql .= "  after_control_html TEXT";
				$postgre_sql .= "  ,PRIMARY KEY (property_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "user_profile_properties (";
				$access_sql .= "  [property_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [user_type_id] INTEGER,";
				$access_sql .= "  [property_order] INTEGER,";
				$access_sql .= "  [property_name] VARCHAR(255),";
				$access_sql .= "  [property_description] LONGTEXT,";
				$access_sql .= "  [default_value] LONGTEXT,";
				$access_sql .= "  [property_style] VARCHAR(255),";
				$access_sql .= "  [section_id] INTEGER,";
				$access_sql .= "  [property_show] INTEGER,";
				$access_sql .= "  [control_type] VARCHAR(16),";
				$access_sql .= "  [control_style] VARCHAR(255),";
				$access_sql .= "  [control_code] LONGTEXT,";
				$access_sql .= "  [onchange_code] LONGTEXT,";
				$access_sql .= "  [onclick_code] LONGTEXT,";
				$access_sql .= "  [required] INTEGER,";
				$access_sql .= "  [before_name_html] LONGTEXT,";
				$access_sql .= "  [after_name_html] LONGTEXT,";
				$access_sql .= "  [before_control_html] LONGTEXT,";
				$access_sql .= "  [after_control_html] LONGTEXT";
				$access_sql .= "  ,PRIMARY KEY (property_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "user_profile_properties__61 ON " . $table_prefix . "user_profile_properties (user_type_id)";
				}


				$mysql_sql  = "CREATE TABLE " . $table_prefix . "user_profile_sections (";
				$mysql_sql .= "  `section_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `section_order` INT(11) default '0',";
				$mysql_sql .= "  `section_name` VARCHAR(64)";
				$mysql_sql .= "  ,PRIMARY KEY (section_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "user_profile_sections START 5";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "user_profile_sections (";
				$postgre_sql .= "  section_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "user_profile_sections'),";
				$postgre_sql .= "  section_order INT4 default '0',";
				$postgre_sql .= "  section_name VARCHAR(64)";
				$postgre_sql .= "  ,PRIMARY KEY (section_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "user_profile_sections (";
				$access_sql .= "  [section_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [section_order] INTEGER,";
				$access_sql .= "  [section_name] VARCHAR(64)";
				$access_sql .= "  ,PRIMARY KEY (section_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "user_profile_values (";
				$mysql_sql .= "  `property_value_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `property_id` INT(11) default '0',";
				$mysql_sql .= "  `property_value` VARCHAR(255),";
				$mysql_sql .= "  `hide_value` INT(11) default '0',";
				$mysql_sql .= "  `is_default_value` INT(11) default '0'";
				$mysql_sql .= "  ,PRIMARY KEY (property_value_id)";
				$mysql_sql .= "  ,KEY property_id (property_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "user_profile_values START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "user_profile_values (";
				$postgre_sql .= "  property_value_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "user_profile_values'),";
				$postgre_sql .= "  property_id INT4 default '0',";
				$postgre_sql .= "  property_value VARCHAR(255),";
				$postgre_sql .= "  hide_value INT4 default '0',";
				$postgre_sql .= "  is_default_value INT4 default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (property_value_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "user_profile_values (";
				$access_sql .= "  [property_value_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [property_id] INTEGER,";
				$access_sql .= "  [property_value] VARCHAR(255),";
				$access_sql .= "  [hide_value] INTEGER,";
				$access_sql .= "  [is_default_value] INTEGER";
				$access_sql .= "  ,PRIMARY KEY (property_value_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "user_profile_values_prop_62 ON " . $table_prefix . "user_profile_values (property_id)";
				}


				$mysql_sql  = "CREATE TABLE " . $table_prefix . "users_properties (";
				$mysql_sql .= "  `user_property_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `user_id` INT(11) default '0',";
				$mysql_sql .= "  `property_id` INT(11) default '0',";
				$mysql_sql .= "  `property_value` TEXT";
				$mysql_sql .= "  ,KEY order_id (user_id)";
				$mysql_sql .= "  ,KEY order_property_id (user_property_id)";
				$mysql_sql .= "  ,PRIMARY KEY (user_property_id)";
				$mysql_sql .= "  ,KEY property_id (property_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "users_properties START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "users_properties (";
				$postgre_sql .= "  user_property_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "users_properties'),";
				$postgre_sql .= "  user_id INT4 default '0',";
				$postgre_sql .= "  property_id INT4 default '0',";
				$postgre_sql .= "  property_value TEXT";
				$postgre_sql .= "  ,PRIMARY KEY (user_property_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "users_properties (";
				$access_sql .= "  [user_property_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [user_id] INTEGER,";
				$access_sql .= "  [property_id] INTEGER,";
				$access_sql .= "  [property_value] LONGTEXT";
				$access_sql .= "  ,PRIMARY KEY (user_property_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "users_properties_order_id ON " . $table_prefix . "users_properties (user_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "users_properties_property_id ON " . $table_prefix . "users_properties (property_id)";
				}

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "admins ADD COLUMN is_hidden INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "admins ADD COLUMN is_hidden INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "admins ADD COLUMN is_hidden INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "users ADD COLUMN is_sms_allowed INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "users ADD COLUMN is_sms_allowed INT4 default '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "users ADD COLUMN is_sms_allowed INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "users ADD COLUMN birth_year INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "users ADD COLUMN birth_year INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "users ADD COLUMN birth_year INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "users ADD COLUMN birth_month INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "users ADD COLUMN birth_month INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "users ADD COLUMN birth_month INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "users ADD COLUMN birth_day INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "users ADD COLUMN birth_day INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "users ADD COLUMN birth_day INTEGER"
				);
				$sqls[] = $sql_types[$db_type];
			}

			if (comp_vers("3.1.2", $current_db_version) == 1)
			{
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "menus ADD COLUMN show_title INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "menus ADD COLUMN show_title INT4 default '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "menus ADD COLUMN show_title INTEGER"
				);
				$sqls[] = $sql_types[$db_type];
			}

			if (comp_vers("3.1.3", $current_db_version) == 1)
			{
				$sqls[] = " INSERT INTO " . $table_prefix . "user_profile_sections (section_id,section_order,section_name) VALUES (1, 1, 'LOGIN_INFO_MSG')";
				$sqls[] = " INSERT INTO " . $table_prefix . "user_profile_sections (section_id,section_order,section_name) VALUES (2, 2, 'PERSONAL_DETAILS_MSG')";
				$sqls[] = " INSERT INTO " . $table_prefix . "user_profile_sections (section_id,section_order,section_name) VALUES (3, 3, 'DELIVERY_DETAILS_MSG')";
				$sqls[] = " INSERT INTO " . $table_prefix . "user_profile_sections (section_id,section_order,section_name) VALUES (4, 4, 'ADDITIONAL_DETAILS_MSG')";
			}

			if (comp_vers("3.1.4", $current_db_version) == 1)
			{
				if ($db_type == "access") {
					$sqls[] = " ALTER TABLE " . $table_prefix . "order_custom_properties ADD COLUMN validation_regexp LONGTEXT";
					$sqls[] = " ALTER TABLE " . $table_prefix . "order_custom_properties ADD COLUMN regexp_error LONGTEXT";
				} else {
					$sqls[] = " ALTER TABLE " . $table_prefix . "order_custom_properties ADD COLUMN validation_regexp TEXT";
					$sqls[] = " ALTER TABLE " . $table_prefix . "order_custom_properties ADD COLUMN regexp_error TEXT";
				}
			}

			if (comp_vers("3.1.5", $current_db_version) == 1)
			{
				if ($db_type == "access") {
					$sqls[] = " ALTER TABLE " . $table_prefix . "order_custom_properties ADD COLUMN options_values_sql LONGTEXT";
					$sqls[] = " ALTER TABLE " . $table_prefix . "user_profile_properties ADD COLUMN validation_regexp LONGTEXT";
					$sqls[] = " ALTER TABLE " . $table_prefix . "user_profile_properties ADD COLUMN regexp_error LONGTEXT";
					$sqls[] = " ALTER TABLE " . $table_prefix . "user_profile_properties ADD COLUMN options_values_sql LONGTEXT";
				} else {
					$sqls[] = " ALTER TABLE " . $table_prefix . "order_custom_properties ADD COLUMN options_values_sql TEXT";
					$sqls[] = " ALTER TABLE " . $table_prefix . "user_profile_properties ADD COLUMN validation_regexp TEXT";
					$sqls[] = " ALTER TABLE " . $table_prefix . "user_profile_properties ADD COLUMN regexp_error TEXT";
					$sqls[] = " ALTER TABLE " . $table_prefix . "user_profile_properties ADD COLUMN options_values_sql TEXT";
				}
			}

			if (comp_vers("3.1.6", $current_db_version) == 1)
			{
				$sqls[] = " ALTER TABLE " . $table_prefix . "manufacturers ADD COLUMN image_small VARCHAR(255)";
				$sqls[] = " ALTER TABLE " . $table_prefix . "manufacturers ADD COLUMN image_small_alt VARCHAR(255)";
				$sqls[] = " ALTER TABLE " . $table_prefix . "manufacturers ADD COLUMN image_large VARCHAR(255)";
				$sqls[] = " ALTER TABLE " . $table_prefix . "manufacturers ADD COLUMN image_large_alt VARCHAR(255)";
			}

			if (comp_vers("3.1.7", $current_db_version) == 1)
			{
				// add fields for subscriptions
				$sqls[] = "ALTER TABLE " . $table_prefix . "users ADD COLUMN admin_modified_ip VARCHAR(32) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "users ADD COLUMN admin_modified_date DATETIME ",
					"postgre" => "ALTER TABLE " . $table_prefix . "users ADD COLUMN admin_modified_date TIMESTAMP ",
					"access"  => "ALTER TABLE " . $table_prefix . "users ADD COLUMN admin_modified_date DATETIME "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "users ADD COLUMN expiry_date DATETIME ",
					"postgre" => "ALTER TABLE " . $table_prefix . "users ADD COLUMN expiry_date TIMESTAMP ",
					"access"  => "ALTER TABLE " . $table_prefix . "users ADD COLUMN expiry_date DATETIME "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "users ADD COLUMN suspend_date DATETIME ",
					"postgre" => "ALTER TABLE " . $table_prefix . "users ADD COLUMN suspend_date TIMESTAMP ",
					"access"  => "ALTER TABLE " . $table_prefix . "users ADD COLUMN suspend_date DATETIME "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "users ADD COLUMN registration_last_step INT(11) default '1' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "users ADD COLUMN registration_last_step INT4 default '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "users ADD COLUMN registration_last_step INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "users ADD COLUMN registration_total_steps INT(11) default '1' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "users ADD COLUMN registration_total_steps INT4 default '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "users ADD COLUMN registration_total_steps INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN is_subscription INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN is_subscription INT4 default '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN is_subscription INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN subscription_period INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN subscription_period INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN subscription_period INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN subscription_interval INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN subscription_interval INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN subscription_interval INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN subscription_suspend INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN subscription_suspend INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN subscription_suspend INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN is_subscription INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN is_subscription INT4 default '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN is_subscription INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN is_subscription_recurring INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN is_subscription_recurring INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN is_subscription_recurring INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_name VARCHAR(32) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_fee DOUBLE(16,2) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_fee FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_fee FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_period INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_period INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_period INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_interval INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_interval INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_interval INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_suspend INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_suspend INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_suspend INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

			}

			if (comp_vers("3.1.8", $current_db_version) == 1)
			{
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "user_profile_sections ADD COLUMN is_active INT(11) default '1' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "user_profile_sections ADD COLUMN is_active INT4 default '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "user_profile_sections ADD COLUMN is_active INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "user_profile_sections ADD COLUMN step_number INT(11) default '1' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "user_profile_sections ADD COLUMN step_number INT4 default '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "user_profile_sections ADD COLUMN step_number INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = " UPDATE " . $table_prefix . "user_profile_sections SET is_active=1, step_number=1 ";

			}

			if (comp_vers("3.1.9", $current_db_version) == 1)
			{
				// add new hidden permission for admin
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "admin_privileges ADD COLUMN is_hidden INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "admin_privileges ADD COLUMN is_hidden INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "admin_privileges ADD COLUMN is_hidden INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sql = " SELECT privilege_id FROM  " . $table_prefix . "admin_privileges_settings WHERE block_name='admins_groups' AND permission=1 ";
				$db->query($sql);
				while ($db->next_record()) {
					$privilege_id = $db->f("privilege_id");
					$sql  = " INSERT INTO " . $table_prefix . "admin_privileges_settings (privilege_id, block_name, permission) VALUES (";
					$sql .= $db->tosql($privilege_id, INTEGER) . ", 'admins_hidden', 1)";
					$sqls[] = $sql;
				}
			}

			if (comp_vers("3.1.10", $current_db_version) == 1)
			{
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN user_type_id INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN user_type_id INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN user_type_id INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = "CREATE INDEX " . $table_prefix . "orders_user_type_id ON " . $table_prefix . "orders (user_type_id) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN user_id INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN user_id INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN user_id INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN user_type_id INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN user_type_id INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN user_type_id INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = "CREATE INDEX " . $table_prefix . "orders_items_user_id ON " . $table_prefix . "orders_items (user_id) ";
				$sqls[] = "CREATE INDEX " . $table_prefix . "orders_items_user_type_id ON " . $table_prefix . "orders_items (user_type_id) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN download_show_terms INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN download_show_terms INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN download_show_terms INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "access") {
					$sqls[] = " ALTER TABLE " . $table_prefix . "items ADD COLUMN download_terms_text LONGTEXT";
				} else {
					$sqls[] = " ALTER TABLE " . $table_prefix . "items ADD COLUMN download_terms_text TEXT";
				}
			}

			if (comp_vers("3.1.11", $current_db_version) == 1)
			{
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN is_sms_allowed INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN is_sms_allowed INT4 default '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN is_sms_allowed INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = " UPDATE " . $table_prefix . "users SET is_sms_allowed=1 ";
				$sqls[] = " UPDATE " . $table_prefix . "user_types SET is_sms_allowed=1 ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "layouts ADD COLUMN top_menu_type INT(11) default '1' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "layouts ADD COLUMN top_menu_type INT4 default '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "layouts ADD COLUMN top_menu_type INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = " UPDATE " . $table_prefix . "layouts SET top_menu_type=1 ";
				$sqls[] = " UPDATE " . $table_prefix . "layouts SET top_menu_type=3 WHERE layout_name LIKE '%Curved%' ";
			}

			if (comp_vers("3.1.12", $current_db_version) == 1)
			{
				// add new fields to the users table
				$sqls[] = "ALTER TABLE " . $table_prefix . "users ADD COLUMN nickname VARCHAR(32) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "users ADD COLUMN msn_account VARCHAR(128) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "users ADD COLUMN icq_number VARCHAR(32) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "users ADD COLUMN user_site_url VARCHAR(255) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "users ADD COLUMN last_visit_page VARCHAR(255) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "users ADD COLUMN last_logged_ip VARCHAR(32) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "users ADD COLUMN last_logged_date DATETIME ",
					"postgre" => "ALTER TABLE " . $table_prefix . "users ADD COLUMN last_logged_date TIMESTAMP ",
					"access"  => "ALTER TABLE " . $table_prefix . "users ADD COLUMN last_logged_date DATETIME "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "users ADD COLUMN is_hidden INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "users ADD COLUMN is_hidden INT4 default '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "users ADD COLUMN is_hidden INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				// update users table
				$last_visit_date = va_timestamp() - 8640000;
				$sqls[] = " UPDATE " . $table_prefix . "users SET nickname=login ";
				$sqls[] = " UPDATE " . $table_prefix . "users SET is_hidden=0 ";
				$sqls[] = "CREATE INDEX " . $table_prefix . "users_nickname ON " . $table_prefix . "users (nickname)";
				$sqls[] = "CREATE INDEX " . $table_prefix . "users_last_visit_date ON " . $table_prefix . "users (last_visit_date)";

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "allowed_cell_phones (";
				$mysql_sql .= "  `cell_phone_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `cell_phone_number` VARCHAR(32)";
				$mysql_sql .= "  ,KEY cell_phone_number (cell_phone_number)";
				$mysql_sql .= "  ,PRIMARY KEY (cell_phone_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "allowed_cell_phones START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "allowed_cell_phones (";
				$postgre_sql .= "  cell_phone_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "allowed_cell_phones'),";
				$postgre_sql .= "  cell_phone_number VARCHAR(32)";
				$postgre_sql .= "  ,PRIMARY KEY (cell_phone_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "allowed_cell_phones (";
				$access_sql .= "  [cell_phone_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [cell_phone_number] VARCHAR(32)";
				$access_sql .= "  ,PRIMARY KEY (cell_phone_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "allowed_cell_phones_cell_4 ON " . $table_prefix . "allowed_cell_phones (cell_phone_number)";
				}

				// forum_list
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN last_post_message_id INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN last_post_message_id INT4 default '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN last_post_message_id INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				// forum changes
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "forum ADD COLUMN last_post_added DATETIME ",
					"postgre" => "ALTER TABLE " . $table_prefix . "forum ADD COLUMN last_post_added TIMESTAMP ",
					"access"  => "ALTER TABLE " . $table_prefix . "forum ADD COLUMN last_post_added DATETIME "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "forum ADD COLUMN last_post_user_id INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "forum ADD COLUMN last_post_user_id INT4 default '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "forum ADD COLUMN last_post_user_id INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "forum ADD COLUMN last_post_message_id INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "forum ADD COLUMN last_post_message_id INT4 default '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "forum ADD COLUMN last_post_message_id INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				// forum_messages
				$sqls[] = " UPDATE " . $table_prefix . "forum_messages SET user_id=0 ";
				$sqls[] = "CREATE INDEX " . $table_prefix . "forum_messages_user_id ON " . $table_prefix . "forum_messages (user_id)";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "forum_messages ADD COLUMN date_modified DATETIME ",
					"postgre" => "ALTER TABLE " . $table_prefix . "forum_messages ADD COLUMN date_modified TIMESTAMP ",
					"access"  => "ALTER TABLE " . $table_prefix . "forum_messages ADD COLUMN date_modified DATETIME "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "forum_messages ADD COLUMN admin_id_modified_by INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "forum_messages ADD COLUMN admin_id_modified_by INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "forum_messages ADD COLUMN admin_id_modified_by INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				// update support
				$sqls[] = "ALTER TABLE " . $table_prefix . "support ADD COLUMN affiliate_code VARCHAR(64) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "support ADD COLUMN mail_cc VARCHAR(255) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "support ADD COLUMN mail_bcc VARCHAR(255) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "support_messages ADD COLUMN mail_cc VARCHAR(255) ";
 				if ($db_type == "access") {
					$sqls[] = " ALTER TABLE " . $table_prefix . "support ADD COLUMN mail_headers LONGTEXT";
					$sqls[] = " ALTER TABLE " . $table_prefix . "support ADD COLUMN mail_body_text LONGTEXT";
					$sqls[] = " ALTER TABLE " . $table_prefix . "support ADD COLUMN mail_body_html LONGTEXT";
					$sqls[] = " ALTER TABLE " . $table_prefix . "support_messages ADD COLUMN mail_headers LONGTEXT";
					$sqls[] = " ALTER TABLE " . $table_prefix . "support_messages ADD COLUMN mail_body_text LONGTEXT";
					$sqls[] = " ALTER TABLE " . $table_prefix . "support_messages ADD COLUMN mail_body_html LONGTEXT";
				} else {
					$sqls[] = " ALTER TABLE " . $table_prefix . "support ADD COLUMN mail_headers TEXT";
					$sqls[] = " ALTER TABLE " . $table_prefix . "support ADD COLUMN mail_body_text TEXT";
					$sqls[] = " ALTER TABLE " . $table_prefix . "support ADD COLUMN mail_body_html LONGTEXT";
					$sqls[] = " ALTER TABLE " . $table_prefix . "support_messages ADD COLUMN mail_headers LONGTEXT";
					$sqls[] = " ALTER TABLE " . $table_prefix . "support_messages ADD COLUMN mail_body_text LONGTEXT";
					$sqls[] = " ALTER TABLE " . $table_prefix . "support_messages ADD COLUMN mail_body_html LONGTEXT";
				}

				// serial fields
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN serial_period INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN serial_period INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN serial_period INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items_serials ADD COLUMN serial_expiry DATETIME ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items_serials ADD COLUMN serial_expiry TIMESTAMP ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items_serials ADD COLUMN serial_expiry DATETIME "
				);
				$sqls[] = $sql_types[$db_type];

			}

			if (comp_vers("3.1.13", $current_db_version) == 1)
			{
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "forum ADD COLUMN last_post_admin_id INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "forum ADD COLUMN last_post_admin_id INT4 default '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "forum ADD COLUMN last_post_admin_id INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN last_post_admin_id INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN last_post_admin_id INT4 default '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN last_post_admin_id INTEGER"
				);
				$sqls[] = $sql_types[$db_type];
			}

			if (comp_vers("3.1.14", $current_db_version) == 1)
			{
				$sqls[] = "ALTER TABLE " . $table_prefix . "admins ADD COLUMN nickname VARCHAR(32) ";
			}

			if (comp_vers("3.1.15", $current_db_version) == 1)
			{
				// add layout setting for Basket page
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0, 'basket', 'basket_block', 0, 'middle')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0, 'basket', 'basket_recommended_block', 1, 'middle')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0, 'basket', 'left_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0, 'basket', 'left_column_width', NULL, NULL)";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0, 'basket', 'middle_column_hide', NULL, '0')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0, 'basket', 'middle_column_width', NULL, '100%')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0, 'basket', 'right_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0, 'basket', 'right_column_width', NULL, NULL)";

				// add layout setting for Sitemap page
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0, 'site_map', 'site_map_block', 0, 'middle')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0, 'site_map', 'left_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0, 'site_map', 'left_column_width', NULL, NULL)";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0, 'site_map', 'middle_column_hide', NULL, '0')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0, 'site_map', 'middle_column_width', NULL, '100%')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0, 'site_map', 'right_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (layout_id,page_name,setting_name,setting_order,setting_value) VALUES (0, 'site_map', 'right_column_width', NULL, NULL)";
			}

			if (is_array($sqls) && sizeof($sqls) > 0) {
				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.2");
			}

			if (comp_vers("3.2.1", $current_db_version) == 1)
			{
				if ($db_type == "mysql") {
					$sqls[] = "ALTER TABLE " . $table_prefix . "payment_parameters MODIFY COLUMN parameter_source TEXT DEFAULT NULL";
				} elseif ($db_type == "access") {
					$sqls[] = "ALTER TABLE " . $table_prefix . "payment_parameters ALTER COLUMN parameter_source LONGTEXT";
				}

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.2.1");
			}

			if (comp_vers("3.2.2", $current_db_version) == 1)
			{
				// new libraries to handle capture, refund and void requests
				$sqls[] = "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN capture_php_lib VARCHAR(255) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN refund_php_lib VARCHAR(255) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN void_php_lib VARCHAR(255) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN status_type VARCHAR(16) ";

				// new orders authorization fields
				$sqls[] = "ALTER TABLE " . $table_prefix . "orders ADD COLUMN authorization_code VARCHAR(128) ";

				$sqls[] = "ALTER TABLE " . $table_prefix . "orders ADD COLUMN avs_response_code VARCHAR(64) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "orders ADD COLUMN avs_message VARCHAR(255) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "orders ADD COLUMN avs_address_match VARCHAR(16) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "orders ADD COLUMN avs_zip_match VARCHAR(16) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "orders ADD COLUMN cvv2_match VARCHAR(16) ";

				$sqls[] = "ALTER TABLE " . $table_prefix . "orders ADD COLUMN secure_3d_check VARCHAR(16) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "orders ADD COLUMN secure_3d_status VARCHAR(128) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "orders ADD COLUMN secure_3d_eci VARCHAR(16) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "orders ADD COLUMN secure_3d_cavv VARCHAR(128) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "orders ADD COLUMN secure_3d_xid VARCHAR(128) ";

				$sqls[] = "ALTER TABLE " . $table_prefix . "orders ADD COLUMN shipping_type_code VARCHAR(64) ";

				// restrictions by user types
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN user_types_all INT(11) DEFAULT '1' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN user_types_all INT4 DEFAULT '1' ",
					"access"  => "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN user_types_all INTEGER"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "payment_systems SET user_types_all=1 ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "shipping_types ADD COLUMN user_types_all INT(11) DEFAULT '1' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "shipping_types ADD COLUMN user_types_all INT4 DEFAULT '1' ",
					"access"  => "ALTER TABLE " . $table_prefix . "shipping_types ADD COLUMN user_types_all INTEGER"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "shipping_types SET user_types_all=1 ";

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "payment_user_types (";
				$mysql_sql .= "  `payment_id` INT(11) default '0',";
				$mysql_sql .= "  `user_type_id` INT(11) default '0'";
				$mysql_sql .= "  ,KEY payment_id (payment_id)";
				$mysql_sql .= "  ,KEY user_type_id (user_type_id))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "payment_user_types (";
				$postgre_sql .= "  payment_id INT4 default '0',";
				$postgre_sql .= "  user_type_id INT4 default '0')";

				$access_sql  = "CREATE TABLE " . $table_prefix . "payment_user_types (";
				$access_sql .= "  [payment_id] INTEGER,";
				$access_sql .= "  [user_type_id] INTEGER)";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "payment_user_types_payment_id ON " . $table_prefix . "payment_user_types (payment_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "payment_user_types_user__34 ON " . $table_prefix . "payment_user_types (user_type_id)";
				}

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "shipping_types_users (";
				$mysql_sql .= "  `shipping_type_id` INT(11) default '0',";
				$mysql_sql .= "  `user_type_id` INT(11) default '0'";
				$mysql_sql .= "  ,KEY shipping_type_id (shipping_type_id)";
				$mysql_sql .= "  ,KEY user_type_id (user_type_id))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "shipping_types_users (";
				$postgre_sql .= "  shipping_type_id INT4 default '0',";
				$postgre_sql .= "  user_type_id INT4 default '0')";

				$access_sql  = "CREATE TABLE " . $table_prefix . "shipping_types_users (";
				$access_sql .= "  [shipping_type_id] INTEGER,";
				$access_sql .= "  [user_type_id] INTEGER)";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "shipping_types_users_shi_46 ON " . $table_prefix . "shipping_types_users (shipping_type_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "shipping_types_users_use_47 ON " . $table_prefix . "shipping_types_users (user_type_id)";
				}

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.2.2");
			}

			if (comp_vers("3.2.3", $current_db_version) == 1)
			{
				$sqls[] = "ALTER TABLE " . $table_prefix . "orders ADD COLUMN secure_3d_md VARCHAR(255) ";

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.2.3");
			}

			if (comp_vers("3.2.4", $current_db_version) == 1)
			{
				$mysql_sql  = "CREATE TABLE " . $table_prefix . "icons (";
				$mysql_sql .= "  `icon_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `is_active` INT(11) default '1',";
				$mysql_sql .= "  `show_for_user` INT(11) default '1',";
				$mysql_sql .= "  `icon_order` INT(11) default '1',";
				$mysql_sql .= "  `icon_code` VARCHAR(32),";
				$mysql_sql .= "  `icon_image` VARCHAR(255),";
				$mysql_sql .= "  `icon_width` INT(11),";
				$mysql_sql .= "  `icon_height` INT(11),";
				$mysql_sql .= "  `icon_name` VARCHAR(255)";
				$mysql_sql .= "  ,PRIMARY KEY (icon_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "icons START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "icons (";
				$postgre_sql .= "  icon_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "icons'),";
				$postgre_sql .= "  is_active INT4 default '1',";
				$postgre_sql .= "  show_for_user INT4 default '1',";
				$postgre_sql .= "  icon_order INT4 default '1',";
				$postgre_sql .= "  icon_code VARCHAR(32),";
				$postgre_sql .= "  icon_image VARCHAR(255),";
				$postgre_sql .= "  icon_width INT4,";
				$postgre_sql .= "  icon_height INT4,";
				$postgre_sql .= "  icon_name VARCHAR(255)";
				$postgre_sql .= "  ,PRIMARY KEY (icon_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "icons (";
				$access_sql .= "  [icon_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [is_active] INTEGER,";
				$access_sql .= "  [show_for_user] INTEGER,";
				$access_sql .= "  [icon_order] INTEGER,";
				$access_sql .= "  [icon_code] VARCHAR(32),";
				$access_sql .= "  [icon_image] VARCHAR(255),";
				$access_sql .= "  [icon_width] INTEGER,";
				$access_sql .= "  [icon_height] INTEGER,";
				$access_sql .= "  [icon_name] VARCHAR(255)";
				$access_sql .= "  ,PRIMARY KEY (icon_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.2.4");
			}

			if (comp_vers("3.2.5", $current_db_version) == 1)
			{
				$sqls[] = "ALTER TABLE " . $table_prefix . "items ADD COLUMN tiny_image VARCHAR(255) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "items ADD COLUMN tiny_image_alt VARCHAR(255) ";

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.2.5");
			}

			if (comp_vers("3.2.6", $current_db_version) == 1)
			{
				
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "articles ADD COLUMN stream_video VARCHAR(255) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "articles ADD COLUMN stream_video VARCHAR(255) ",
					"access"  => "ALTER TABLE " . $table_prefix . "articles ADD COLUMN stream_video VARCHAR(255)"
				);
				$sqls[] = $sql_types[$db_type];
				
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "articles ADD COLUMN stream_video_width INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "articles ADD COLUMN stream_video_width INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "articles ADD COLUMN stream_video_width INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "articles ADD COLUMN stream_video_height INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "articles ADD COLUMN stream_video_height INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "articles ADD COLUMN stream_video_height INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.2.6");
			}

			if (comp_vers("3.2.7", $current_db_version) == 1)
			{
				// payment system images
				$sqls[] = "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN small_image VARCHAR(255) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN small_image_alt VARCHAR(255) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN big_image VARCHAR(255) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN big_image_alt VARCHAR(255) ";

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.2.7");
			}

			if (comp_vers("3.2.8", $current_db_version) == 1)
			{
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN quantity INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN quantity INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN quantity INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items_properties_values ADD COLUMN quantity INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items_properties_values ADD COLUMN quantity INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "items_properties_values ADD COLUMN quantity INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN coupon_tax_free INT(11) DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN coupon_tax_free INT4 DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN coupon_tax_free INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN order_tax_free INT(11) DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN order_tax_free INT4 DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN order_tax_free INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = " UPDATE " . $table_prefix . "coupons SET order_tax_free=tax_free ";
				$sqls[] = " ALTER TABLE " . $table_prefix . "coupons DROP COLUMN tax_free ";

				if ($db_type == "mysql") {
					$sqls[] = "ALTER TABLE " . $table_prefix . "items MODIFY COLUMN use_stock_level INT(11) DEFAULT '0'";
				}

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "orders_coupons (";
				$mysql_sql .= "  `order_coupon_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `order_id` INT(11) default '0',";
				$mysql_sql .= "  `coupon_id` INT(11) default '0',";
				$mysql_sql .= "  `coupon_code` VARCHAR(64),";
				$mysql_sql .= "  `coupon_title` VARCHAR(255),";
				$mysql_sql .= "  `discount_amount` DOUBLE(16,2) default '0',";
				$mysql_sql .= "  `discount_tax_amount` DOUBLE(16,2) default '0'";
				$mysql_sql .= "  ,KEY coupon_id (coupon_id)";
				$mysql_sql .= "  ,KEY order_id (order_id)";
				$mysql_sql .= "  ,PRIMARY KEY (order_coupon_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "orders_coupons START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "orders_coupons (";
				$postgre_sql .= "  order_coupon_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "orders_coupons'),";
				$postgre_sql .= "  order_id INT4 default '0',";
				$postgre_sql .= "  coupon_id INT4 default '0',";
				$postgre_sql .= "  coupon_code VARCHAR(64),";
				$postgre_sql .= "  coupon_title VARCHAR(255),";
				$postgre_sql .= "  discount_amount FLOAT4 default '0',";
				$postgre_sql .= "  discount_tax_amount FLOAT4 default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (order_coupon_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "orders_coupons (";
				$access_sql .= "  [order_coupon_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [order_id] INTEGER,";
				$access_sql .= "  [coupon_id] INTEGER,";
				$access_sql .= "  [coupon_code] VARCHAR(64),";
				$access_sql .= "  [coupon_title] VARCHAR(255),";
				$access_sql .= "  [discount_amount] FLOAT,";
				$access_sql .= "  [discount_tax_amount] FLOAT";
				$access_sql .= "  ,PRIMARY KEY (order_coupon_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "orders_coupons_coupon_id ON " . $table_prefix . "orders_coupons (coupon_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "orders_coupons_order_id ON " . $table_prefix . "orders_coupons (order_id)";
				}

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.2.8");
			}

			if (comp_vers("3.2.9", $current_db_version) == 1)
			{
				$sqls[] = "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN image_small VARCHAR(255) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN image_small_alt VARCHAR(255) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN image_large VARCHAR(255) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN image_large_alt VARCHAR(255) ";

				$sqls[] = " UPDATE " . $table_prefix . "payment_systems SET image_small=small_image, image_small_alt=small_image_alt, image_large=big_image, image_large_alt=big_image_alt ";

				$sqls[] = " ALTER TABLE " . $table_prefix . "payment_systems DROP COLUMN small_image ";
				$sqls[] = " ALTER TABLE " . $table_prefix . "payment_systems DROP COLUMN small_image_alt ";
				$sqls[] = " ALTER TABLE " . $table_prefix . "payment_systems DROP COLUMN big_image ";
				$sqls[] = " ALTER TABLE " . $table_prefix . "payment_systems DROP COLUMN big_image_alt ";

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.2.9");
			}

			if (comp_vers("3.2.10", $current_db_version) == 1)
			{
				// add new permissions for admin
				$permissions = array("products_settings", "downloadable_products", "advanced_search", "products_report", "product_prices", "product_images", "product_properties", "product_features", "product_related", "product_categories", "product_accessories", "product_releases", "products_order", "products_export", "products_import", "products_export_froogle", "features_groups", "tell_friend", "categories_export", "categories_import", "categories_order", "view_categories", "view_products", "add_categories", "update_categories", "remove_categories", "add_products", "update_products", "remove_products", "duplicate_products", "approve_products");
				$sql = " SELECT privilege_id FROM  " . $table_prefix . "admin_privileges_settings WHERE block_name='products_categories' AND permission=1 ";
				$db->query($sql);
				while ($db->next_record()) {
					$privilege_id = $db->f("privilege_id");
					for ($i = 0; $i < sizeof($permissions); $i++) {
						$sql  = " DELETE FROM " . $table_prefix . "admin_privileges_settings ";
						$sql .= " WHERE privilege_id=" . $db->tosql($privilege_id, INTEGER);
						$sql .= " AND block_name=" . $db->tosql($permissions[$i], TEXT);
						$sqls[] = $sql;
						$sql  = " INSERT INTO " . $table_prefix . "admin_privileges_settings (privilege_id, block_name, permission) VALUES (";
						$sql .= $db->tosql($privilege_id, INTEGER) . ", '" . $permissions[$i] . "',1)";
						$sqls[] = $sql;
					}
				}

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.2.10");
			}

			if (comp_vers("3.2.11", $current_db_version) == 1)
			{
				// add new fields for export/import subscribe email list
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "admins ADD COLUMN `exported_email_id` int(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "admins ADD COLUMN exported_email_id INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "admins ADD COLUMN [exported_email_id] INTEGER "
				);
				$sqls[] = $sql_types[$db_type];


				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "admins ADD COLUMN `imported_email_fields` TEXT ",
					"postgre" => "ALTER TABLE " . $table_prefix . "admins ADD COLUMN imported_email_fields TEXT ",
					"access"  => "ALTER TABLE " . $table_prefix . "admins ADD COLUMN [imported_email_fields] LONGTEXT "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "admins ADD COLUMN `exported_email_fields` TEXT ",
					"postgre" => "ALTER TABLE " . $table_prefix . "admins ADD COLUMN exported_email_fields TEXT ",
					"access"  => "ALTER TABLE " . $table_prefix . "admins ADD COLUMN [exported_email_fields] LONGTEXT "
				);
				$sqls[] = $sql_types[$db_type];

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.2.11");
			}

			if (comp_vers("3.2.12", $current_db_version) == 1)
			{
				// re-create quotes structure
				$sqls[] = " DROP TABLE " . $table_prefix . "quotes ";
				$sqls[] = " DROP TABLE " . $table_prefix . "quotes_features ";
				$sqls[] = " DROP TABLE " . $table_prefix . "quotes_history ";
				$sqls[] = " DROP TABLE " . $table_prefix . "quotes_statuses ";

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "quotes (";
				$mysql_sql .= "  `quote_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `support_id` INT(11) default '0',";
				$mysql_sql .= "  `user_id` INT(11) default '0',";
				$mysql_sql .= "  `user_name` VARCHAR(255),";
				$mysql_sql .= "  `user_email` VARCHAR(255),";
				$mysql_sql .= "  `quote_price` DOUBLE(16,2) default '0',";
				$mysql_sql .= "  `quote_status_id` INT(11) default '0',";
				$mysql_sql .= "  `is_paid` INT(11) default '0',";
				$mysql_sql .= "  `minutes_spent` INT(11) default '0',";
				$mysql_sql .= "  `date_due` DATETIME,";
				$mysql_sql .= "  `summary` VARCHAR(255),";
				$mysql_sql .= "  `description` TEXT,";
				$mysql_sql .= "  `admin_id_added_by` INT(11) default '0',";
				$mysql_sql .= "  `admin_id_modified_by` INT(11) default '0',";
				$mysql_sql .= "  `date_added` DATETIME,";
				$mysql_sql .= "  `date_modified` DATETIME";
				$mysql_sql .= "  ,KEY is_paid (is_paid)";
				$mysql_sql .= "  ,PRIMARY KEY (quote_id)";
				$mysql_sql .= "  ,KEY quote_id (quote_id)";
				$mysql_sql .= "  ,KEY quote_status_id (quote_status_id)";
				$mysql_sql .= "  ,KEY support_id (support_id)";
				$mysql_sql .= "  ,KEY user_id (user_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "quotes START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "quotes (";
				$postgre_sql .= "  quote_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "quotes'),";
				$postgre_sql .= "  support_id INT4 default '0',";
				$postgre_sql .= "  user_id INT4 default '0',";
				$postgre_sql .= "  user_name VARCHAR(255),";
				$postgre_sql .= "  user_email VARCHAR(255),";
				$postgre_sql .= "  quote_price FLOAT4 default '0',";
				$postgre_sql .= "  quote_status_id INT4 default '0',";
				$postgre_sql .= "  is_paid INT4 default '0',";
				$postgre_sql .= "  minutes_spent INT4 default '0',";
				$postgre_sql .= "  date_due TIMESTAMP,";
				$postgre_sql .= "  summary VARCHAR(255),";
				$postgre_sql .= "  description TEXT,";
				$postgre_sql .= "  admin_id_added_by INT4 default '0',";
				$postgre_sql .= "  admin_id_modified_by INT4 default '0',";
				$postgre_sql .= "  date_added TIMESTAMP,";
				$postgre_sql .= "  date_modified TIMESTAMP";
				$postgre_sql .= "  ,PRIMARY KEY (quote_id))";


				$access_sql  = "CREATE TABLE " . $table_prefix . "quotes (";
				$access_sql .= "  [quote_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [support_id] INTEGER,";
				$access_sql .= "  [user_id] INTEGER,";
				$access_sql .= "  [user_name] VARCHAR(255),";
				$access_sql .= "  [user_email] VARCHAR(255),";
				$access_sql .= "  [quote_price] FLOAT,";
				$access_sql .= "  [quote_status_id] INTEGER,";
				$access_sql .= "  [is_paid] INTEGER,";
				$access_sql .= "  [minutes_spent] INTEGER,";
				$access_sql .= "  [date_due] DATETIME,";
				$access_sql .= "  [summary] VARCHAR(255),";
				$access_sql .= "  [description] LONGTEXT,";
				$access_sql .= "  [admin_id_added_by] INTEGER,";
				$access_sql .= "  [admin_id_modified_by] INTEGER,";
				$access_sql .= "  [date_added] DATETIME,";
				$access_sql .= "  [date_modified] DATETIME";
				$access_sql .= "  ,PRIMARY KEY (quote_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "quotes_is_paid ON " . $table_prefix . "quotes (is_paid)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "quotes_quote_id ON " . $table_prefix . "quotes (quote_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "quotes_quote_status_id ON " . $table_prefix . "quotes (quote_status_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "quotes_support_id ON " . $table_prefix . "quotes (support_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "quotes_user_id ON " . $table_prefix . "quotes (user_id)";
				}

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "quotes_events (";
				$mysql_sql .= "  `event_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `quote_id` INT(11) default '0',";
				$mysql_sql .= "  `feature_id` INT(11) default '0',";
				$mysql_sql .= "  `admin_id` INT(11) default '0',";
				$mysql_sql .= "  `status_id_old` INT(11) default '0',";
				$mysql_sql .= "  `status_id_new` INT(11) default '0',";
				$mysql_sql .= "  `event_date` DATETIME,";
				$mysql_sql .= "  `event_name` VARCHAR(255),";
				$mysql_sql .= "  `event_description` TEXT";
				$mysql_sql .= "  ,KEY admin_id (admin_id)";
				$mysql_sql .= "  ,KEY feature_id (feature_id)";
				$mysql_sql .= "  ,PRIMARY KEY (event_id)";
				$mysql_sql .= "  ,KEY quote_id (quote_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "quotes_events START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "quotes_events (";
				$postgre_sql .= "  event_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "quotes_events'),";
				$postgre_sql .= "  quote_id INT4 default '0',";
				$postgre_sql .= "  feature_id INT4 default '0',";
				$postgre_sql .= "  admin_id INT4 default '0',";
				$postgre_sql .= "  status_id_old INT4 default '0',";
				$postgre_sql .= "  status_id_new INT4 default '0',";
				$postgre_sql .= "  event_date TIMESTAMP,";
				$postgre_sql .= "  event_name VARCHAR(255),";
				$postgre_sql .= "  event_description TEXT";
				$postgre_sql .= "  ,PRIMARY KEY (event_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "quotes_events (";
				$access_sql .= "  [event_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [quote_id] INTEGER,";
				$access_sql .= "  [feature_id] INTEGER,";
				$access_sql .= "  [admin_id] INTEGER,";
				$access_sql .= "  [status_id_old] INTEGER,";
				$access_sql .= "  [status_id_new] INTEGER,";
				$access_sql .= "  [event_date] DATETIME,";
				$access_sql .= "  [event_name] VARCHAR(255),";
				$access_sql .= "  [event_description] LONGTEXT";
				$access_sql .= "  ,PRIMARY KEY (event_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "quotes_events_admin_id ON " . $table_prefix . "quotes_events (admin_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "quotes_events_feature_id ON " . $table_prefix . "quotes_events (feature_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "quotes_events_quote_id ON " . $table_prefix . "quotes_events (quote_id)";
				}


				$mysql_sql  = "CREATE TABLE " . $table_prefix . "quotes_features (";
				$mysql_sql .= "  `feature_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `quote_id` INT(11) default '0',";
				$mysql_sql .= "  `feature_description` TEXT,";
				$mysql_sql .= "  `feature_price` DOUBLE(16,2) default '0',";
				$mysql_sql .= "  `feature_status_id` INT(11) default '0',";
				$mysql_sql .= "  `feature_paid` INT(11) default '0',";
				$mysql_sql .= "  `minutes_spent` INT(11) default '0',";
				$mysql_sql .= "  `date_due` DATETIME,";
				$mysql_sql .= "  `admin_id_added_by` INT(11) default '0',";
				$mysql_sql .= "  `admin_id_modified_by` INT(11) default '0',";
				$mysql_sql .= "  `date_added` DATETIME,";
				$mysql_sql .= "  `date_modified` DATETIME";
				$mysql_sql .= "  ,KEY feature_paid (feature_paid)";
				$mysql_sql .= "  ,KEY feature_status_id (feature_status_id)";
				$mysql_sql .= "  ,PRIMARY KEY (feature_id)";
				$mysql_sql .= "  ,KEY quote_id (quote_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "quotes_features START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "quotes_features (";
				$postgre_sql .= "  feature_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "quotes_features'),";
				$postgre_sql .= "  quote_id INT4 default '0',";
				$postgre_sql .= "  feature_description TEXT,";
				$postgre_sql .= "  feature_price FLOAT4 default '0',";
				$postgre_sql .= "  feature_status_id INT4 default '0',";
				$postgre_sql .= "  feature_paid INT4 default '0',";
				$postgre_sql .= "  minutes_spent INT4 default '0',";
				$postgre_sql .= "  date_due TIMESTAMP,";
				$postgre_sql .= "  admin_id_added_by INT4 default '0',";
				$postgre_sql .= "  admin_id_modified_by INT4 default '0',";
				$postgre_sql .= "  date_added TIMESTAMP,";
				$postgre_sql .= "  date_modified TIMESTAMP";
				$postgre_sql .= "  ,PRIMARY KEY (feature_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "quotes_features (";
				$access_sql .= "  [feature_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [quote_id] INTEGER,";
				$access_sql .= "  [feature_description] LONGTEXT,";
				$access_sql .= "  [feature_price] FLOAT,";
				$access_sql .= "  [feature_status_id] INTEGER,";
				$access_sql .= "  [feature_paid] INTEGER,";
				$access_sql .= "  [minutes_spent] INTEGER,";
				$access_sql .= "  [date_due] DATETIME,";
				$access_sql .= "  [admin_id_added_by] INTEGER,";
				$access_sql .= "  [admin_id_modified_by] INTEGER,";
				$access_sql .= "  [date_added] DATETIME,";
				$access_sql .= "  [date_modified] DATETIME";
				$access_sql .= "  ,PRIMARY KEY (feature_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "quotes_features_feature_paid ON " . $table_prefix . "quotes_features (feature_paid)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "quotes_features_feature__39 ON " . $table_prefix . "quotes_features (feature_status_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "quotes_features_quote_id ON " . $table_prefix . "quotes_features (quote_id)";
				}

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "quotes_orders (";
				$mysql_sql .= "  `quote_order_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `quote_id` INT(11) default '0',";
				$mysql_sql .= "  `feature_id` INT(11) default '0',";
				$mysql_sql .= "  `order_id` INT(11) default '0',";
				$mysql_sql .= "  `order_item_id` INT(11) default '0'";
				$mysql_sql .= "  ,KEY feature_id (feature_id)";
				$mysql_sql .= "  ,KEY order_id (order_id)";
				$mysql_sql .= "  ,KEY order_item_id (order_item_id)";
				$mysql_sql .= "  ,PRIMARY KEY (quote_order_id)";
				$mysql_sql .= "  ,KEY quote_id (quote_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "quotes_orders START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "quotes_orders (";
				$postgre_sql .= "  quote_order_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "quotes_orders'),";
				$postgre_sql .= "  quote_id INT4 default '0',";
				$postgre_sql .= "  feature_id INT4 default '0',";
				$postgre_sql .= "  order_id INT4 default '0',";
				$postgre_sql .= "  order_item_id INT4 default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (quote_order_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "quotes_orders (";
				$access_sql .= "  [quote_order_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [quote_id] INTEGER,";
				$access_sql .= "  [feature_id] INTEGER,";
				$access_sql .= "  [order_id] INTEGER,";
				$access_sql .= "  [order_item_id] INTEGER";
				$access_sql .= "  ,PRIMARY KEY (quote_order_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "quotes_orders_feature_id ON " . $table_prefix . "quotes_orders (feature_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "quotes_orders_order_id ON " . $table_prefix . "quotes_orders (order_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "quotes_orders_order_item_id ON " . $table_prefix . "quotes_orders (order_item_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "quotes_orders_quote_id ON " . $table_prefix . "quotes_orders (quote_id)";
				}

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "quotes_statuses (";
				$mysql_sql .= "  `status_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `status_name` VARCHAR(255),";
				$mysql_sql .= "  `status_icon` VARCHAR(255),";
				$mysql_sql .= "  `html_start` VARCHAR(255),";
				$mysql_sql .= "  `html_end` VARCHAR(255),";
				$mysql_sql .= "  `notes` TEXT";
				$mysql_sql .= "  ,PRIMARY KEY (status_id)";
				$mysql_sql .= "  ,KEY quote_status_id (status_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "quotes_statuses START 5";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "quotes_statuses (";
				$postgre_sql .= "  status_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "quotes_statuses'),";
				$postgre_sql .= "  status_name VARCHAR(255),";
				$postgre_sql .= "  status_icon VARCHAR(255),";
				$postgre_sql .= "  html_start VARCHAR(255),";
				$postgre_sql .= "  html_end VARCHAR(255),";
				$postgre_sql .= "  notes TEXT";
				$postgre_sql .= "  ,PRIMARY KEY (status_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "quotes_statuses (";
				$access_sql .= "  [status_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [status_name] VARCHAR(255),";
				$access_sql .= "  [status_icon] VARCHAR(255),";
				$access_sql .= "  [html_start] VARCHAR(255),";
				$access_sql .= "  [html_end] VARCHAR(255),";
				$access_sql .= "  [notes] LONGTEXT";
				$access_sql .= "  ,PRIMARY KEY (status_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "quotes_statuses_quote_st_40 ON " . $table_prefix . "quotes_statuses (status_id)";
				}

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "articles_categories_items (";
				$mysql_sql .= "  `category_id` INT(11) default '0',";
				$mysql_sql .= "  `item_id` INT(11) default '0',";
				$mysql_sql .= "  `related_order` INT(11) NOT NULL default '1'";
				$mysql_sql .= "  ,KEY category_id (category_id)";
				$mysql_sql .= "  ,KEY item_id (item_id))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "articles_categories_items (";
				$postgre_sql .= "  category_id INT4 default '0',";
				$postgre_sql .= "  item_id INT4 default '0',";
				$postgre_sql .= "  related_order INT4 NOT NULL default '1')";

				$access_sql  = "CREATE TABLE " . $table_prefix . "articles_categories_items (";
				$access_sql .= "  [category_id] INTEGER,";
				$access_sql .= "  [item_id] INTEGER,";
				$access_sql .= "  [related_order] INTEGER)";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "articles_categories_item_8 ON " . $table_prefix . "articles_categories_items (category_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "articles_categories_item_9 ON " . $table_prefix . "articles_categories_items (item_id)";
				}

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "articles_items_related (";
				$mysql_sql .= "  `article_id` INT(11) default '0',";
				$mysql_sql .= "  `item_id` INT(11) default '0',";
				$mysql_sql .= "  `related_order` INT(11) NOT NULL default '1'";
				$mysql_sql .= "  ,KEY article_id (article_id)";
				$mysql_sql .= "  ,KEY item_id (item_id))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "articles_items_related (";
				$postgre_sql .= "  article_id INT4 default '0',";
				$postgre_sql .= "  item_id INT4 default '0',";
				$postgre_sql .= "  related_order INT4 NOT NULL default '1')";

				$access_sql  = "CREATE TABLE " . $table_prefix . "articles_items_related (";
				$access_sql .= "  [article_id] INTEGER,";
				$access_sql .= "  [item_id] INTEGER,";
				$access_sql .= "  [related_order] INTEGER)";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "articles_items_related_a_10 ON " . $table_prefix . "articles_items_related (article_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "articles_items_related_i_11 ON " . $table_prefix . "articles_items_related (item_id)";
				}

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "header_submenus (";
				$mysql_sql .= "  `submenu_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `menu_id` INT(11) default '0',";
				$mysql_sql .= "  `show_for_user` INT(11) default '1',";
				$mysql_sql .= "  `match_type` INT(11) default '1',";
				$mysql_sql .= "  `submenu_title` VARCHAR(255),";
				$mysql_sql .= "  `submenu_url` VARCHAR(255),";
				$mysql_sql .= "  `submenu_page` VARCHAR(128),";
				$mysql_sql .= "  `submenu_target` VARCHAR(32),";
				$mysql_sql .= "  `submenu_image` VARCHAR(255),";
				$mysql_sql .= "  `submenu_image_active` VARCHAR(255),";
				$mysql_sql .= "  `submenu_order` INT(11) default '0'";
				$mysql_sql .= "  ,KEY menu_id (menu_id)";
				$mysql_sql .= "  ,PRIMARY KEY (submenu_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "header_submenus START 1";
				}

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "header_submenus (";
				$postgre_sql .= "  submenu_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "header_submenus'),";
				$postgre_sql .= "  menu_id INT4 default '0',";
				$postgre_sql .= "  show_for_user INT4 default '1',";
				$postgre_sql .= "  match_type INT4 default '1',";
				$postgre_sql .= "  submenu_title VARCHAR(255),";
				$postgre_sql .= "  submenu_url VARCHAR(255),";
				$postgre_sql .= "  submenu_page VARCHAR(128),";
				$postgre_sql .= "  submenu_target VARCHAR(32),";
				$postgre_sql .= "  submenu_image VARCHAR(255),";
				$postgre_sql .= "  submenu_image_active VARCHAR(255),";
				$postgre_sql .= "  submenu_order INT4 default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (submenu_id))";


				$access_sql  = "CREATE TABLE " . $table_prefix . "header_submenus (";
				$access_sql .= "  [submenu_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [menu_id] INTEGER,";
				$access_sql .= "  [show_for_user] INTEGER,";
				$access_sql .= "  [match_type] INTEGER,";
				$access_sql .= "  [submenu_title] VARCHAR(255),";
				$access_sql .= "  [submenu_url] VARCHAR(255),";
				$access_sql .= "  [submenu_page] VARCHAR(128),";
				$access_sql .= "  [submenu_target] VARCHAR(32),";
				$access_sql .= "  [submenu_image] VARCHAR(255),";
				$access_sql .= "  [submenu_image_active] VARCHAR(255),";
				$access_sql .= "  [submenu_order] INTEGER";
				$access_sql .= "  ,PRIMARY KEY (submenu_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "header_submenus_menu_id ON " . $table_prefix . "header_submenus (menu_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "header_submenus_submenu_page ON " . $table_prefix . "header_submenus (submenu_page)";
				}

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.2.12");
			}

			if (comp_vers("3.2.13", $current_db_version) == 1)
			{
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "header_submenus ADD COLUMN parent_submenu_id INT(11) DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "header_submenus ADD COLUMN parent_submenu_id INT4 DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "header_submenus ADD COLUMN parent_submenu_id INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = " UPDATE " . $table_prefix . "header_submenus SET parent_submenu_id=0 ";

				$sqls[] = "ALTER TABLE " . $table_prefix . "header_links ADD COLUMN submenu_style_name VARCHAR(64) ";

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.2.13");
			}

			if (comp_vers("3.2.14", $current_db_version) == 1)
			{
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "users ADD COLUMN layout_id INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "users ADD COLUMN layout_id INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "users ADD COLUMN layout_id INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "layouts ADD COLUMN show_for_user INT(11) DEFAULT '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "layouts ADD COLUMN show_for_user INT4 DEFAULT '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "layouts ADD COLUMN show_for_user INTEGER"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "layouts SET show_for_user=0 ";

				$sqls[] = "ALTER TABLE " . $table_prefix . "layouts ADD COLUMN user_layout_name VARCHAR(255) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN item_code VARCHAR(64) DEFAULT '' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN item_code VARCHAR(64) DEFAULT '' ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN item_code VARCHAR(64) "
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "items SET item_code='' ";

				$sqls[] = "CREATE INDEX " . $table_prefix . "items_item_code ON " . $table_prefix . "items (item_code)";

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.2.14");
			}

			if (comp_vers("3.2.15", $current_db_version) == 1)
			{
				$sqls[] = "ALTER TABLE " . $table_prefix . "header_submenus ADD COLUMN submenu_path VARCHAR(255) ";

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.2.15");
			}


			if (comp_vers("3.2.16", $current_db_version) == 1)
			{
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN item_code VARCHAR(64) DEFAULT '' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN item_code VARCHAR(64) DEFAULT '' ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN item_code VARCHAR(64) "
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "orders_items SET item_code='' ";

				$sqls[] = "CREATE INDEX " . $table_prefix . "orders_items_item_code ON " . $table_prefix . "orders_items (item_code)";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items_properties_values ADD COLUMN item_code VARCHAR(64) DEFAULT '' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items_properties_values ADD COLUMN item_code VARCHAR(64) DEFAULT '' ",
					"access"  => "ALTER TABLE " . $table_prefix . "items_properties_values ADD COLUMN item_code VARCHAR(64) "
				);
				$sqls[] = $sql_types[$db_type];

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.2.16");
			}
			
			if (comp_vers("3.2.17", $current_db_version) == 1)
			{
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "articles ADD COLUMN stream_video_preview VARCHAR(255) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "articles ADD COLUMN stream_video_preview VARCHAR(255) ",
					"access"  => "ALTER TABLE " . $table_prefix . "articles ADD COLUMN stream_video_preview VARCHAR(255)"
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (setting_type, setting_name, setting_value) VALUES ('products', 'basket_item_name', '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (setting_type, setting_name, setting_value) VALUES ('products', 'basket_item_price', '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (setting_type, setting_name, setting_value) VALUES ('products', 'basket_item_quantity', '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (setting_type, setting_name, setting_value) VALUES ('products', 'basket_item_price_total', '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (setting_type, setting_name, setting_value) VALUES ('products', 'basket_item_tax_total', '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (setting_type, setting_name, setting_value) VALUES ('products', 'basket_item_price_incl_tax_total', '1')";

				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (setting_type, setting_name, setting_value) VALUES ('products', 'checkout_item_name', '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (setting_type, setting_name, setting_value) VALUES ('products', 'checkout_item_price', '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (setting_type, setting_name, setting_value) VALUES ('products', 'checkout_item_quantity', '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (setting_type, setting_name, setting_value) VALUES ('products', 'checkout_item_price_total', '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (setting_type, setting_name, setting_value) VALUES ('products', 'checkout_item_tax_total', '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (setting_type, setting_name, setting_value) VALUES ('products', 'checkout_item_price_incl_tax_total', '1')";

				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (setting_type, setting_name, setting_value) VALUES ('products', 'invoice_item_name', '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (setting_type, setting_name, setting_value) VALUES ('products', 'invoice_item_price', '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (setting_type, setting_name, setting_value) VALUES ('products', 'invoice_item_quantity', '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (setting_type, setting_name, setting_value) VALUES ('products', 'invoice_item_price_total', '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (setting_type, setting_name, setting_value) VALUES ('products', 'invoice_item_tax_total', '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (setting_type, setting_name, setting_value) VALUES ('products', 'invoice_item_price_incl_tax_total', '1')";

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.2.17");
			}

			if (comp_vers("3.2.18", $current_db_version) == 1)
			{
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN is_points_price INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN is_points_price INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN is_points_price INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN points_price DOUBLE(16,4) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN points_price FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN points_price FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN reward_type INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN reward_type INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN reward_type INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN reward_amount DOUBLE(16,4) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN reward_amount FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN reward_amount FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "users ADD COLUMN total_points DOUBLE(16,4) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "users ADD COLUMN total_points FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "users ADD COLUMN total_points FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "users ADD COLUMN reward_type INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "users ADD COLUMN reward_type INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "users ADD COLUMN reward_type INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "users ADD COLUMN reward_amount DOUBLE(16,4) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "users ADD COLUMN reward_amount FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "users ADD COLUMN reward_amount FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN reward_points DOUBLE(16,4) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN reward_points FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN reward_points FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN points_price DOUBLE(16,4) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN points_price FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN points_price FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN total_points_amount DOUBLE(16,4) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN total_points_amount FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN total_points_amount FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN total_reward_points DOUBLE(16,4) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN total_reward_points FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN total_reward_points FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN shipping_points_amount DOUBLE(16,4) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN shipping_points_amount FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN shipping_points_amount FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN properties_points_amount DOUBLE(16,4) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN properties_points_amount FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN properties_points_amount FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN reward_type INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN reward_type INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN reward_type INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN reward_amount DOUBLE(16,4) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN reward_amount FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN reward_amount FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "item_types ADD COLUMN reward_type INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "item_types ADD COLUMN reward_type INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "item_types ADD COLUMN reward_type INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "item_types ADD COLUMN reward_amount DOUBLE(16,4) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "item_types ADD COLUMN reward_amount FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "item_types ADD COLUMN reward_amount FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_properties ADD COLUMN property_points_amount DOUBLE(16,4) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_properties ADD COLUMN property_points_amount FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_properties ADD COLUMN property_points_amount FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN stock_level_action INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN stock_level_action INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN stock_level_action INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN points_action INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN points_action INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN points_action INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = " UPDATE " . $table_prefix . "order_statuses SET status_type='NEW' WHERE status_name LIKE '%New%' ";
				$sqls[] = " UPDATE " . $table_prefix . "order_statuses SET status_type='PAYMENT_INFO' WHERE status_name LIKE '%CC%' ";
				$sqls[] = " UPDATE " . $table_prefix . "order_statuses SET status_type='CONFIRMED' WHERE status_name LIKE '%Confirm%' ";
				$sqls[] = " UPDATE " . $table_prefix . "order_statuses SET status_type='PAID' WHERE status_name LIKE '%Paid%' ";
				$sqls[] = " UPDATE " . $table_prefix . "order_statuses SET status_type='SHIPPED' WHERE status_name LIKE '%Ship%' OR status_name LIKE '%Deliver%' ";
				$sqls[] = " UPDATE " . $table_prefix . "order_statuses SET status_type='PENDING' WHERE status_name LIKE '%Pending%' ";
				$sqls[] = " UPDATE " . $table_prefix . "order_statuses SET status_type='CLOSED' WHERE status_name LIKE '%Close%' ";
				$sqls[] = " UPDATE " . $table_prefix . "order_statuses SET status_type='DECLINED' WHERE status_name LIKE '%Decline%' ";
				$sqls[] = " UPDATE " . $table_prefix . "order_statuses SET status_type='FAILED' WHERE status_name LIKE '%Fail%' ";
				$sqls[] = " UPDATE " . $table_prefix . "order_statuses SET status_type='DISPATCHED' WHERE status_name LIKE '%Dispatch%' ";
				$sqls[] = " UPDATE " . $table_prefix . "order_statuses SET status_type='CANCELLED' WHERE status_name LIKE '%Cancel%' ";
				$sqls[] = " UPDATE " . $table_prefix . "order_statuses SET status_type='REFUNDED' WHERE status_name LIKE '%Refund%' ";
				$sqls[] = " UPDATE " . $table_prefix . "order_statuses SET status_type='CAPTURED' WHERE status_name LIKE '%Capture%' ";
				$sqls[] = " UPDATE " . $table_prefix . "order_statuses SET status_type='VOIDED' WHERE status_name LIKE '%Void%' ";
				$sqls[] = " UPDATE " . $table_prefix . "order_statuses SET status_type='AUTHORIZED' WHERE status_name LIKE '%Authorize%' ";
				$sqls[] = " UPDATE " . $table_prefix . "order_statuses SET status_type='OTHER' WHERE status_type='' OR status_type IS NULL ";

				$sql  = " UPDATE " . $table_prefix . "order_statuses SET stock_level_action=1, points_action=1 ";
				$sql .= " WHERE status_type='NEW' OR status_type='PAYMENT_INFO' OR status_type='CONFIRMED' ";
				$sql .= " OR status_type='PAID' OR status_type='SHIPPED' OR status_type='PENDING' ";
				$sql .= " OR status_type='CLOSED' OR status_type='VALIDATED' OR status_type='DISPATCHED' ";
				$sql .= " OR status_type='CAPTURED' OR status_type='AUTHORIZED' OR status_type='OTHER' ";
				$sqls[] = $sql;

				$sql  = " UPDATE " . $table_prefix . "order_statuses SET stock_level_action=-1, points_action=-1 ";
				$sql .= " WHERE status_type='DECLINED' OR status_type='FALIED' OR status_type='CANCELLED' ";
				$sql .= " OR status_type='REFUNDED' OR status_type='VOIDED' ";
				$sqls[] = $sql;

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN status_order INT(11) default '1' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN status_order INT4 default '1' ",
					"access"  => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN status_order INTEGER "
				);
				$sqls[] = $sql_types[$db_type];
 				$sqls[] = " UPDATE " . $table_prefix . "order_statuses SET status_order=1 ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN final_message TEXT ",
					"postgre" => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN final_message TEXT ",
					"access"  => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN final_message LONGTEXT "
				);
				$sqls[] = $sql_types[$db_type];

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "users_points (";
				$mysql_sql .= "  `points_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `user_id` INT(11) default '0',";
				$mysql_sql .= "  `order_id` INT(11) default '0',";
				$mysql_sql .= "  `order_item_id` INT(11) default '0',";
				$mysql_sql .= "  `points_amount` DOUBLE(16,4) default '0',";
				$mysql_sql .= "  `points_action` INT(11) default '0',";
				$mysql_sql .= "  `points_type` INT(11) default '0',";
				$mysql_sql .= "  `admin_id_added_by` INT(11) default '0',";
				$mysql_sql .= "  `admin_id_modified_by` INT(11) default '0',";
				$mysql_sql .= "  `date_added` DATETIME,";
				$mysql_sql .= "  `date_modified` DATETIME";
				$mysql_sql .= "  ,KEY date_added (date_added)";
				$mysql_sql .= "  ,KEY order_id (order_id)";
				$mysql_sql .= "  ,KEY order_item_id (order_item_id)";
				$mysql_sql .= "  ,PRIMARY KEY (points_id)";
				$mysql_sql .= "  ,KEY user_id (user_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "users_points START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "users_points (";
				$postgre_sql .= "  points_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "users_points'),";
				$postgre_sql .= "  user_id INT4 default '0',";
				$postgre_sql .= "  order_id INT4 default '0',";
				$postgre_sql .= "  order_item_id INT4 default '0',";
				$postgre_sql .= "  points_amount FLOAT4 default '0',";
				$postgre_sql .= "  points_action INT4 default '0',";
				$postgre_sql .= "  points_type INT4 default '0',";
				$postgre_sql .= "  admin_id_added_by INT4 default '0',";
				$postgre_sql .= "  admin_id_modified_by INT4 default '0',";
				$postgre_sql .= "  date_added TIMESTAMP,";
				$postgre_sql .= "  date_modified TIMESTAMP";
				$postgre_sql .= "  ,PRIMARY KEY (points_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "users_points (";
				$access_sql .= "  [points_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [user_id] INTEGER,";
				$access_sql .= "  [order_id] INTEGER,";
				$access_sql .= "  [order_item_id] INTEGER,";
				$access_sql .= "  [points_amount] FLOAT,";
				$access_sql .= "  [points_action] INTEGER,";
				$access_sql .= "  [points_type] INTEGER,";
				$access_sql .= "  [admin_id_added_by] INTEGER,";
				$access_sql .= "  [admin_id_modified_by] INTEGER,";
				$access_sql .= "  [date_added] DATETIME,";
				$access_sql .= "  [date_modified] DATETIME";
				$access_sql .= "  ,PRIMARY KEY (points_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "postgre" || $db_type == "access") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "users_points_date_added ON " . $table_prefix . "users_points (date_added)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "users_points_order_id ON " . $table_prefix . "users_points (order_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "users_points_order_item_id ON " . $table_prefix . "users_points (order_item_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "users_points_user_id ON " . $table_prefix . "users_points (user_id)";
				}

				$sqls[] = "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN user_payment_name VARCHAR(255) ";

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.2.18");
			}

			if (comp_vers("3.2.19", $current_db_version) == 1)
			{
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN is_remote_rss INT(11) DEFAULT 0 ",
					"postgre" => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN is_remote_rss INT4 DEFAULT 0 ",
					"access"  => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN is_remote_rss INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN remote_rss_url VARCHAR(255) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN remote_rss_url VARCHAR(255) ",
					"access"  => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN remote_rss_url VARCHAR(255) "
				);
				$sqls[] = $sql_types[$db_type];
				
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN remote_rss_date_updated DATETIME ",
					"postgre" => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN remote_rss_date_updated TIMESTAMP ",
					"access"  => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN remote_rss_date_updated DATETIME "
				);
				$sqls[] = $sql_types[$db_type];
				
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN remote_rss_ttl INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN remote_rss_ttl INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN remote_rss_ttl INTEGER "
				);
				$sqls[] = $sql_types[$db_type];
				
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN remote_rss_refresh_rate INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN remote_rss_refresh_rate INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN remote_rss_refresh_rate INTEGER "
				);
				$sqls[] = $sql_types[$db_type];
				
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "articles ADD COLUMN is_remote_rss INT(11) DEFAULT '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "articles ADD COLUMN is_remote_rss INT4 DEFAULT '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "articles ADD COLUMN is_remote_rss INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "articles ADD COLUMN details_remote_url VARCHAR(255) DEFAULT '' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "articles ADD COLUMN details_remote_url VARCHAR(255) DEFAULT '' ",
					"access"  => "ALTER TABLE " . $table_prefix . "articles ADD COLUMN details_remote_url VARCHAR(255) "
				);
				$sqls[] = $sql_types[$db_type];

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.2.19");
			}

			if (comp_vers("3.2.20", $current_db_version) == 1)
			{
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN total_buying_tax DOUBLE(16,2) DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN total_buying_tax FLOAT4 DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN total_buying_tax FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN goods_tax DOUBLE(16,2) DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN goods_tax FLOAT4 DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN goods_tax FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN goods_points_amount DOUBLE(16,4) DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN goods_points_amount FLOAT4 DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN goods_points_amount FLOAT"
				);
				$sqls[] = $sql_types[$db_type];

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.2.20");
			}

			if (comp_vers("3.3.1", $current_db_version) == 1)
			{
				if ($db_type == "mysql") {
					$sqls[] = "ALTER TABLE " . $table_prefix . "admin_privileges MODIFY COLUMN is_hidden TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "admin_privileges MODIFY COLUMN support_privilege TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "admin_privileges_settings MODIFY COLUMN permission TINYINT";
					$sqls[] = "ALTER TABLE " . $table_prefix . "admins MODIFY COLUMN is_hidden TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "admins MODIFY COLUMN is_generate_big_image TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "admins MODIFY COLUMN is_generate_small_image TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "ads_categories MODIFY COLUMN allowed_view TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "ads_categories MODIFY COLUMN allowed_post TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "ads_items MODIFY COLUMN is_hot TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "ads_items MODIFY COLUMN is_approved TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "ads_items MODIFY COLUMN is_compared TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "articles MODIFY COLUMN is_html TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "articles MODIFY COLUMN allowed_rate TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "articles MODIFY COLUMN is_hot TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "articles MODIFY COLUMN is_remote_rss TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "articles_categories MODIFY COLUMN is_hot TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "articles_categories MODIFY COLUMN allowed_view TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "articles_categories MODIFY COLUMN allowed_post TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "articles_categories MODIFY COLUMN allowed_rate TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "articles_categories MODIFY COLUMN is_rss TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "articles_categories MODIFY COLUMN is_remote_rss TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "articles_reviews MODIFY COLUMN recommended TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "articles_reviews MODIFY COLUMN approved TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "articles_statuses MODIFY COLUMN is_shown TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "articles_statuses MODIFY COLUMN allowed_view TINYINT NOT NULL default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "banners MODIFY COLUMN is_new_window TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "banners MODIFY COLUMN is_active TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "banners MODIFY COLUMN show_on_ssl TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "banners_groups MODIFY COLUMN is_active TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "bookmarks MODIFY COLUMN is_start_page TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "bookmarks MODIFY COLUMN is_popup TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "categories MODIFY COLUMN is_showing TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "categories MODIFY COLUMN allowed_post TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "categories MODIFY COLUMN show_sub_products TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "coupons MODIFY COLUMN is_active TINYINT default '1'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "coupons MODIFY COLUMN discount_type TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "coupons MODIFY COLUMN coupon_tax_free TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "coupons MODIFY COLUMN order_tax_free TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "coupons MODIFY COLUMN items_all TINYINT default '1'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "coupons MODIFY COLUMN is_exclusive TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "currencies MODIFY COLUMN is_default TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "forum_categories MODIFY COLUMN allowed_view TINYINT NOT NULL default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "forum_list MODIFY COLUMN allowed_view TINYINT NOT NULL default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "forum_list MODIFY COLUMN allowed_view_topics TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "forum_list MODIFY COLUMN allowed_view_topic TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "forum_list MODIFY COLUMN allowed_post_topics TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "forum_list MODIFY COLUMN allowed_post_replies TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "forum_moderators MODIFY COLUMN is_default_forum TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "header_links MODIFY COLUMN show_non_logged TINYINT default '1'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "header_links MODIFY COLUMN show_logged TINYINT default '1'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "header_submenus MODIFY COLUMN show_for_user TINYINT default '1'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "header_submenus MODIFY COLUMN match_type TINYINT default '1'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "icons MODIFY COLUMN is_active TINYINT default '1'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "icons MODIFY COLUMN show_for_user TINYINT default '1'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "item_types MODIFY COLUMN is_gift_voucher TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "item_types MODIFY COLUMN is_bundle TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "item_types MODIFY COLUMN is_user TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items MODIFY COLUMN hide_add_list TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items MODIFY COLUMN hide_add_details TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items MODIFY COLUMN is_special_offer TINYINT NOT NULL default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items MODIFY COLUMN is_price_edit TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items MODIFY COLUMN tax_free TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items MODIFY COLUMN disable_out_of_stock TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items MODIFY COLUMN is_points_price TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items MODIFY COLUMN is_recurring TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items MODIFY COLUMN is_showing TINYINT NOT NULL default '1'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items MODIFY COLUMN is_approved TINYINT NOT NULL default '1'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items MODIFY COLUMN is_compared TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items_properties MODIFY COLUMN use_on_list TINYINT default '1'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items_properties MODIFY COLUMN use_on_details TINYINT default '1'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items_properties MODIFY COLUMN use_on_checkout TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items_properties MODIFY COLUMN use_on_second TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items_properties MODIFY COLUMN required TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items_properties_values MODIFY COLUMN use_stock_level TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items_properties_values MODIFY COLUMN hide_out_of_stock TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items_properties_values MODIFY COLUMN hide_value TINYINT NOT NULL default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items_properties_values MODIFY COLUMN is_default_value TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items_serials MODIFY COLUMN used TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "languages MODIFY COLUMN show_for_user TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "layouts MODIFY COLUMN show_for_user TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "manuals_articles MODIFY COLUMN allowed_view TINYINT NOT NULL default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "manuals_articles MODIFY COLUMN shown_in_contents TINYINT NOT NULL default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "manuals_categories MODIFY COLUMN allowed_view TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "manuals_list MODIFY COLUMN allowed_view TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "menus_items MODIFY COLUMN show_non_logged TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "menus_items MODIFY COLUMN show_logged TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "newsletters MODIFY COLUMN mail_type TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "newsletters MODIFY COLUMN is_active TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "newsletters MODIFY COLUMN is_sent TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "newsletters MODIFY COLUMN is_prepared TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "order_custom_properties MODIFY COLUMN tax_free TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "order_custom_properties MODIFY COLUMN required TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "order_custom_values MODIFY COLUMN hide_value TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "order_custom_values MODIFY COLUMN is_default_value TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses MODIFY COLUMN is_user_cancel TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses MODIFY COLUMN allow_user_cancel TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses MODIFY COLUMN is_dispatch TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses MODIFY COLUMN is_list TINYINT default '1'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses MODIFY COLUMN show_for_user TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses MODIFY COLUMN paid_status TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses MODIFY COLUMN download_notify TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses MODIFY COLUMN item_notify TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses MODIFY COLUMN mail_notify TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses MODIFY COLUMN sms_notify TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "orders MODIFY COLUMN is_placed TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "orders MODIFY COLUMN is_exported TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "orders MODIFY COLUMN is_call_center TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "orders MODIFY COLUMN is_recurring TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "orders_items MODIFY COLUMN is_recurring TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "orders_items MODIFY COLUMN is_subscription TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "orders_items_serials MODIFY COLUMN activated TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "orders_notes MODIFY COLUMN show_for_user TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "orders_properties MODIFY COLUMN tax_free TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "pages MODIFY COLUMN is_showing TINYINT NOT NULL default '1'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "pages MODIFY COLUMN link_in_footer TINYINT NOT NULL default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "payment_parameters MODIFY COLUMN not_passed TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "payment_systems MODIFY COLUMN is_advanced TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "payment_systems MODIFY COLUMN is_active TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "payment_systems MODIFY COLUMN is_default TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "payment_systems MODIFY COLUMN is_call_center TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "payment_systems MODIFY COLUMN user_types_all TINYINT default '1'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "polls MODIFY COLUMN is_active TINYINT NOT NULL default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "polls_options MODIFY COLUMN is_default_value TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "quotes MODIFY COLUMN is_paid TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "release_changes MODIFY COLUMN is_showing TINYINT NOT NULL default '1'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "releases MODIFY COLUMN is_showing TINYINT NOT NULL default '1'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "releases MODIFY COLUMN show_on_index TINYINT NOT NULL default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "reviews MODIFY COLUMN recommended TINYINT NOT NULL default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "reviews MODIFY COLUMN approved TINYINT NOT NULL default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "shipping_modules MODIFY COLUMN is_external TINYINT default '1'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "shipping_modules MODIFY COLUMN is_active TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "shipping_modules_parameters MODIFY COLUMN not_passed TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "shipping_rules MODIFY COLUMN is_country_restriction TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "shipping_types MODIFY COLUMN is_taxable TINYINT default '1'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "shipping_types MODIFY COLUMN is_active TINYINT default '1'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "shipping_types MODIFY COLUMN user_types_all TINYINT default '1'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "support_departments MODIFY COLUMN show_for_user TINYINT default '1'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "support_messages MODIFY COLUMN internal TINYINT NOT NULL default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "support_messages MODIFY COLUMN is_user_reply TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "support_priorities MODIFY COLUMN is_default TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "support_products MODIFY COLUMN show_for_user TINYINT default '1'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "support_statuses MODIFY COLUMN show_for_user TINYINT default '1'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "support_statuses MODIFY COLUMN is_user_new TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "support_statuses MODIFY COLUMN is_user_reply TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "support_statuses MODIFY COLUMN is_operation TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "support_statuses MODIFY COLUMN is_reassign TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "support_statuses MODIFY COLUMN is_internal TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "support_statuses MODIFY COLUMN is_list TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "support_statuses MODIFY COLUMN is_closed TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "support_statuses MODIFY COLUMN is_add_knowledge TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "support_types MODIFY COLUMN show_for_user TINYINT default '1'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "support_users_departments MODIFY COLUMN is_default_dep TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "user_profile_properties MODIFY COLUMN property_show TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "user_profile_properties MODIFY COLUMN required TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "user_profile_sections MODIFY COLUMN is_active TINYINT default '1'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "user_profile_values MODIFY COLUMN hide_value TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "user_profile_values MODIFY COLUMN is_default_value TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "user_types MODIFY COLUMN is_default TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "user_types MODIFY COLUMN is_active TINYINT default '1'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "user_types MODIFY COLUMN is_sms_allowed TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "user_types MODIFY COLUMN show_for_user TINYINT default '1'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "user_types MODIFY COLUMN price_type TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "user_types MODIFY COLUMN tax_free TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "user_types MODIFY COLUMN is_subscription TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "users MODIFY COLUMN is_approved TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "users MODIFY COLUMN is_hidden TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "users MODIFY COLUMN is_sms_allowed TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "users MODIFY COLUMN tax_free TINYINT default '0'";
					$sqls[] = "ALTER TABLE " . $table_prefix . "users_payments MODIFY COLUMN is_paid TINYINT default '0'";
				} elseif ($db_type == "access") {
					$sqls[] = "ALTER TABLE " . $table_prefix . "admin_privileges ALTER COLUMN is_hidden BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "admin_privileges ALTER COLUMN support_privilege BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "admin_privileges_settings ALTER COLUMN permission BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "admins ALTER COLUMN is_hidden BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "admins ALTER COLUMN is_generate_big_image BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "admins ALTER COLUMN is_generate_small_image BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "ads_categories ALTER COLUMN allowed_view BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "ads_categories ALTER COLUMN allowed_post BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "ads_items ALTER COLUMN is_hot BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "ads_items ALTER COLUMN is_approved BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "ads_items ALTER COLUMN is_compared BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "articles ALTER COLUMN is_html BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "articles ALTER COLUMN allowed_rate BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "articles ALTER COLUMN is_hot BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "articles ALTER COLUMN is_remote_rss BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "articles_categories ALTER COLUMN is_hot BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "articles_categories ALTER COLUMN allowed_view BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "articles_categories ALTER COLUMN allowed_post BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "articles_categories ALTER COLUMN allowed_rate BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "articles_categories ALTER COLUMN is_rss BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "articles_categories ALTER COLUMN is_remote_rss BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "articles_reviews ALTER COLUMN recommended BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "articles_reviews ALTER COLUMN approved BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "articles_statuses ALTER COLUMN is_shown BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "articles_statuses ALTER COLUMN allowed_view BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "banners ALTER COLUMN is_new_window BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "banners ALTER COLUMN is_active BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "banners ALTER COLUMN show_on_ssl BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "banners_groups ALTER COLUMN is_active BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "bookmarks ALTER COLUMN is_start_page BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "bookmarks ALTER COLUMN is_popup BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "categories ALTER COLUMN is_showing BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "categories ALTER COLUMN allowed_post BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "categories ALTER COLUMN show_sub_products BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "coupons ALTER COLUMN is_active BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "coupons ALTER COLUMN discount_type BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "coupons ALTER COLUMN coupon_tax_free BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "coupons ALTER COLUMN order_tax_free BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "coupons ALTER COLUMN items_all BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "coupons ALTER COLUMN is_exclusive BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "currencies ALTER COLUMN is_default BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "forum_categories ALTER COLUMN allowed_view BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "forum_list ALTER COLUMN allowed_view BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "forum_list ALTER COLUMN allowed_view_topics BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "forum_list ALTER COLUMN allowed_view_topic BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "forum_list ALTER COLUMN allowed_post_topics BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "forum_list ALTER COLUMN allowed_post_replies BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "forum_moderators ALTER COLUMN is_default_forum BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "header_links ALTER COLUMN show_non_logged BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "header_links ALTER COLUMN show_logged BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "header_submenus ALTER COLUMN show_for_user BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "header_submenus ALTER COLUMN match_type BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "icons ALTER COLUMN is_active BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "icons ALTER COLUMN show_for_user BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "item_types ALTER COLUMN is_gift_voucher BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "item_types ALTER COLUMN is_bundle BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "item_types ALTER COLUMN is_user BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items ALTER COLUMN hide_add_list BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items ALTER COLUMN hide_add_details BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items ALTER COLUMN is_special_offer BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items ALTER COLUMN is_price_edit BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items ALTER COLUMN tax_free BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items ALTER COLUMN disable_out_of_stock BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items ALTER COLUMN is_points_price BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items ALTER COLUMN is_recurring BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items ALTER COLUMN is_showing BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items ALTER COLUMN is_approved BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items ALTER COLUMN is_compared BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items_properties ALTER COLUMN use_on_list BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items_properties ALTER COLUMN use_on_details BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items_properties ALTER COLUMN use_on_checkout BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items_properties ALTER COLUMN use_on_second BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items_properties ALTER COLUMN required BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items_properties_values ALTER COLUMN use_stock_level BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items_properties_values ALTER COLUMN hide_out_of_stock BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items_properties_values ALTER COLUMN hide_value BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items_properties_values ALTER COLUMN is_default_value BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "items_serials ALTER COLUMN used BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "languages ALTER COLUMN show_for_user BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "layouts ALTER COLUMN show_for_user BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "manuals_articles ALTER COLUMN allowed_view BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "manuals_articles ALTER COLUMN shown_in_contents BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "manuals_categories ALTER COLUMN allowed_view BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "manuals_list ALTER COLUMN allowed_view BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "menus_items ALTER COLUMN show_non_logged BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "menus_items ALTER COLUMN show_logged BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "newsletters ALTER COLUMN mail_type BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "newsletters ALTER COLUMN is_active BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "newsletters ALTER COLUMN is_sent BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "newsletters ALTER COLUMN is_prepared BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "order_custom_properties ALTER COLUMN tax_free BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "order_custom_properties ALTER COLUMN required BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "order_custom_values ALTER COLUMN hide_value BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "order_custom_values ALTER COLUMN is_default_value BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses ALTER COLUMN is_user_cancel BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses ALTER COLUMN allow_user_cancel BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses ALTER COLUMN is_dispatch BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses ALTER COLUMN is_list BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses ALTER COLUMN show_for_user BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses ALTER COLUMN paid_status BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses ALTER COLUMN download_notify BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses ALTER COLUMN item_notify BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses ALTER COLUMN mail_notify BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses ALTER COLUMN sms_notify BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "orders ALTER COLUMN is_placed BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "orders ALTER COLUMN is_exported BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "orders ALTER COLUMN is_call_center BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "orders ALTER COLUMN is_recurring BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "orders_items ALTER COLUMN is_recurring BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "orders_items ALTER COLUMN is_subscription BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "orders_items_serials ALTER COLUMN activated BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "orders_notes ALTER COLUMN show_for_user BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "orders_properties ALTER COLUMN tax_free BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "pages ALTER COLUMN is_showing BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "pages ALTER COLUMN link_in_footer BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "payment_parameters ALTER COLUMN not_passed BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "payment_systems ALTER COLUMN is_advanced BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "payment_systems ALTER COLUMN is_active BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "payment_systems ALTER COLUMN is_default BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "payment_systems ALTER COLUMN is_call_center BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "payment_systems ALTER COLUMN user_types_all BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "polls ALTER COLUMN is_active BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "polls_options ALTER COLUMN is_default_value BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "quotes ALTER COLUMN is_paid BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "release_changes ALTER COLUMN is_showing BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "releases ALTER COLUMN is_showing BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "releases ALTER COLUMN show_on_index BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "reviews ALTER COLUMN recommended BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "reviews ALTER COLUMN approved BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "shipping_modules ALTER COLUMN is_external BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "shipping_modules ALTER COLUMN is_active BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "shipping_modules_parameters ALTER COLUMN not_passed BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "shipping_rules ALTER COLUMN is_country_restriction BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "shipping_types ALTER COLUMN is_taxable BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "shipping_types ALTER COLUMN is_active BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "shipping_types ALTER COLUMN user_types_all BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "support_departments ALTER COLUMN show_for_user BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "support_messages ALTER COLUMN internal BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "support_messages ALTER COLUMN is_user_reply BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "support_priorities ALTER COLUMN is_default BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "support_products ALTER COLUMN show_for_user BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "support_statuses ALTER COLUMN show_for_user BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "support_statuses ALTER COLUMN is_user_new BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "support_statuses ALTER COLUMN is_user_reply BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "support_statuses ALTER COLUMN is_operation BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "support_statuses ALTER COLUMN is_reassign BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "support_statuses ALTER COLUMN is_internal BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "support_statuses ALTER COLUMN is_list BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "support_statuses ALTER COLUMN is_closed BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "support_statuses ALTER COLUMN is_add_knowledge BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "support_types ALTER COLUMN show_for_user BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "support_users_departments ALTER COLUMN is_default_dep BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "user_profile_properties ALTER COLUMN property_show BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "user_profile_properties ALTER COLUMN required BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "user_profile_sections ALTER COLUMN is_active BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "user_profile_values ALTER COLUMN hide_value BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "user_profile_values ALTER COLUMN is_default_value BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "user_types ALTER COLUMN is_default BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "user_types ALTER COLUMN is_active BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "user_types ALTER COLUMN is_sms_allowed BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "user_types ALTER COLUMN show_for_user BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "user_types ALTER COLUMN price_type BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "user_types ALTER COLUMN tax_free BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "user_types ALTER COLUMN is_subscription BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "users ALTER COLUMN is_approved BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "users ALTER COLUMN is_hidden BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "users ALTER COLUMN is_sms_allowed BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "users ALTER COLUMN tax_free BYTE";
					$sqls[] = "ALTER TABLE " . $table_prefix . "users_payments ALTER COLUMN is_paid BYTE";
				}
				$sqls[] = "CREATE INDEX " . $table_prefix . "items_is_special_offer ON " . $table_prefix . "items (is_special_offer)";
				$sqls[] = "CREATE INDEX " . $table_prefix . "items_hide_out_of_stock ON " . $table_prefix . "items (hide_out_of_stock)";
				$sqls[] = "CREATE INDEX " . $table_prefix . "items_is_showing ON " . $table_prefix . "items (is_showing)";
				$sqls[] = "CREATE INDEX " . $table_prefix . "categories_is_showing ON " . $table_prefix . "categories (is_showing)";

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.3.1");
			}

			// fix field name	
			if (comp_vers("3.3.2", $current_db_version) == 1)
			{
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "header_links CHANGE COLUMN sudmenu_style_name submenu_style_name VARCHAR(64)",
					"postgre" => "ALTER TABLE " . $table_prefix . "header_links RENAME COLUMN sudmenu_style_name TO submenu_style_name",
					"access"  => "ALTER TABLE " . $table_prefix . "header_links RENAME COLUMN sudmenu_style_name TO submenu_style_name",
					"db2"     => "ALTER TABLE " . $table_prefix . "header_links ADD COLUMN submenu_style_name VARCHAR(64)"
				);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == 'db2'){
					$sqls[] = "UPDATE " . $table_prefix . "header_links set submenu_style_name = sudmenu_style_name";
					$sqls[] = "ALTER TABLE " . $table_prefix . "header_links DROP COLUMN sudmenu_style_name";
				}
				
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "tracking_visits MODIFY COLUMN week_added INT(11) NOT NULL default '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "tracking_visits ALTER COLUMN week_added TYPE INT4",
					"access"  => "ALTER TABLE " . $table_prefix . "tracking_visits ALTER COLUMN week_added INTEGER",
					"db2"     => "ALTER TABLE " . $table_prefix . "tracking_visits ALTER COLUMN week_added SET DATA TYPE INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.3.2");
			}

			if (comp_vers("3.3.3", $current_db_version) == 1)
			{
			  // multi-site functionality and states by countries
				$mysql_sql  = "CREATE TABLE " . $table_prefix . "sites (";
				$mysql_sql .= "  `site_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `site_name` VARCHAR(255),";
				$mysql_sql .= "  `site_description` TEXT";
				$mysql_sql .= "  ,PRIMARY KEY (site_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "sites START 2";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "sites (";
				$postgre_sql .= "  site_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "sites'),";
				$postgre_sql .= "  site_name VARCHAR(255),";
				$postgre_sql .= "  site_description TEXT";
				$postgre_sql .= "  ,PRIMARY KEY (site_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "sites (";
				$access_sql .= "  [site_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [site_name] VARCHAR(255),";
				$access_sql .= "  [site_description] LONGTEXT";
				$access_sql .= "  ,PRIMARY KEY (site_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "sites (";
				$db2_sql .= "  site_id INTEGER NOT NULL,";
				$db2_sql .= "  site_name VARCHAR(255),";
				$db2_sql .= "  site_description LONG VARCHAR";
				$db2_sql .= "  ,PRIMARY KEY (site_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "db2") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "sites AS INTEGER START WITH 2 INCREMENT BY 1 NO CACHE NO CYCLE";
					$sqls[] = "CREATE TRIGGER tr_" . $table_prefix . "135 NO CASCADE BEFORE INSERT ON " . $table_prefix . "sites REFERENCING NEW AS newr_" . $table_prefix . "sites FOR EACH ROW MODE DB2SQL WHEN (newr_" . $table_prefix . "sites.site_id IS NULL ) begin atomic set newr_" . $table_prefix . "sites.site_id = nextval for seq_" . $table_prefix . "sites; end";
				}

				$sqls[] = "INSERT INTO " . $table_prefix . "sites (site_id, site_name, site_description) VALUES (1, 'Default Site', '')";

				// primary keys changes
				if ($db_type == "mysql" || $db_type == "db2") {
					$sqls[] = "ALTER TABLE " . $table_prefix . "global_settings DROP PRIMARY KEY";
					$sqls[] = "ALTER TABLE " . $table_prefix . "page_settings DROP PRIMARY KEY";
					$sqls[] = "ALTER TABLE " . $table_prefix . "states DROP PRIMARY KEY";
				} else if ($db_type == "postgre") {
					$sqls[] = "ALTER TABLE " . $table_prefix . "global_settings DROP CONSTRAINT " . $table_prefix . "global_settings_pkey ";
					$sqls[] = "ALTER TABLE " . $table_prefix . "page_settings DROP CONSTRAINT " . $table_prefix . "page_settings_pkey ";
					$sqls[] = "ALTER TABLE " . $table_prefix . "states DROP CONSTRAINT " . $table_prefix . "states_pkey ";
				} else if ($db_type == "access") {
					$sqls[] = "ALTER TABLE " . $table_prefix . "global_settings DROP CONSTRAINT PrimaryKey";
					$sqls[] = "ALTER TABLE " . $table_prefix . "page_settings DROP CONSTRAINT PrimaryKey";
					$sqls[] = "ALTER TABLE " . $table_prefix . "states DROP CONSTRAINT PrimaryKey";
				} 

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "global_settings ADD COLUMN site_id INT(11) NOT NULL DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "global_settings ADD COLUMN site_id INT4 NOT NULL DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "global_settings ADD COLUMN site_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "global_settings ADD COLUMN site_id INTEGER NOT NULL DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "global_settings SET site_id=1 ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "page_settings ADD COLUMN site_id INT(11) NOT NULL DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "page_settings ADD COLUMN site_id INT4 NOT NULL DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "page_settings ADD COLUMN site_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "page_settings ADD COLUMN site_id INTEGER NOT NULL DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "page_settings SET site_id=1 ";

				if ($db_type == "mysql" || $db_type == "db2" || $db_type == "postgre") {
					$sqls[] = "ALTER TABLE " . $table_prefix . "states ADD COLUMN country_code VARCHAR(4) NOT NULL DEFAULT ''";
				} else {
					$sqls[] = "ALTER TABLE " . $table_prefix . "states ADD COLUMN country_code VARCHAR(4) NOT NULL ";
				}
				$sqls[] = " UPDATE " . $table_prefix . "states SET country_code='' ";

				if ($db_type == "mysql" || $db_type == "db2" || $db_type == "postgre") {
					$sqls[] = "ALTER TABLE " . $table_prefix . "global_settings ADD PRIMARY KEY (site_id,setting_type,setting_name)";
					$sqls[] = "ALTER TABLE " . $table_prefix . "page_settings ADD PRIMARY KEY (site_id,layout_id,page_name,setting_name)";
					$sqls[] = "ALTER TABLE " . $table_prefix . "states ADD PRIMARY KEY (state_code,country_code)";
				} else if ($db_type == "access") {
					$sqls[] = "ALTER TABLE " . $table_prefix . "global_settings ADD CONSTRAINT PrimaryKey PRIMARY KEY (site_id,setting_type,setting_name)";
					$sqls[] = "ALTER TABLE " . $table_prefix . "page_settings ADD CONSTRAINT PrimaryKey PRIMARY KEY (site_id,layout_id,page_name,setting_name)";
					$sqls[] = "ALTER TABLE " . $table_prefix . "states ADD CONSTRAINT PrimaryKey PRIMARY KEY (state_code,country_code)";
				} 
				// end primary keys changes

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "ads_categories_sites (";
				$mysql_sql .= "  `category_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `site_id` INT(11) NOT NULL default '0'";
				$mysql_sql .= "  ,PRIMARY KEY (category_id,site_id))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "ads_categories_sites (";
				$postgre_sql .= "  category_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  site_id INT4 NOT NULL default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (category_id,site_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "ads_categories_sites (";
				$access_sql .= "  [category_id] INTEGER NOT NULL,";
				$access_sql .= "  [site_id] INTEGER NOT NULL";
				$access_sql .= "  ,PRIMARY KEY (category_id,site_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "ads_categories_sites (";
				$db2_sql .= "  category_id INTEGER NOT NULL default 0,";
				$db2_sql .= "  site_id INTEGER NOT NULL default 0";
				$db2_sql .= "  ,PRIMARY KEY (category_id,site_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "ads_categories ADD COLUMN sites_all TINYINT NOT NULL DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "ads_categories ADD COLUMN sites_all SMALLINT NOT NULL DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "ads_categories ADD COLUMN sites_all BYTE NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "ads_categories ADD COLUMN sites_all SMALLINT NOT NULL DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "ads_categories SET sites_all=1 ";

				// articles categories
				$mysql_sql  = "CREATE TABLE " . $table_prefix . "articles_categories_sites (";
				$mysql_sql .= "  `category_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `site_id` INT(11) NOT NULL default '0'";
				$mysql_sql .= "  ,PRIMARY KEY (category_id,site_id))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "articles_categories_sites (";
				$postgre_sql .= "  category_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  site_id INT4 NOT NULL default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (category_id,site_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "articles_categories_sites (";
				$access_sql .= "  [category_id] INTEGER NOT NULL,";
				$access_sql .= "  [site_id] INTEGER NOT NULL";
				$access_sql .= "  ,PRIMARY KEY (category_id,site_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "articles_categories_sites (";
				$db2_sql .= "  category_id INTEGER NOT NULL default 0,";
				$db2_sql .= "  site_id INTEGER NOT NULL default 0";
				$db2_sql .= "  ,PRIMARY KEY (category_id,site_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN sites_all TINYINT NOT NULL DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN sites_all SMALLINT NOT NULL DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN sites_all BYTE NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN sites_all SMALLINT NOT NULL DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "articles_categories SET sites_all=1 ";

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "articles_categories_types (";
				$mysql_sql .= "  `category_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `user_type_id` INT(11) NOT NULL default '0'";
				$mysql_sql .= "  ,PRIMARY KEY (category_id,user_type_id))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "articles_categories_types (";
				$postgre_sql .= "  category_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  user_type_id INT4 NOT NULL default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (category_id,user_type_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "articles_categories_types (";
				$access_sql .= "  [category_id] INTEGER NOT NULL,";
				$access_sql .= "  [user_type_id] INTEGER NOT NULL";
				$access_sql .= "  ,PRIMARY KEY (category_id,user_type_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "articles_categories_types (";
				$db2_sql .= "  category_id INTEGER NOT NULL default 0,";
				$db2_sql .= "  user_type_id INTEGER NOT NULL default 0";
				$db2_sql .= "  ,PRIMARY KEY (category_id,user_type_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN user_types_all TINYINT NOT NULL DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN user_types_all SMALLINT NOT NULL DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN user_types_all BYTE NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "articles_categories ADD COLUMN user_types_all SMALLINT NOT NULL DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "articles_categories SET user_types_all=1 ";

				// categories
				$mysql_sql  = "CREATE TABLE " . $table_prefix . "categories_sites (";
				$mysql_sql .= "  `category_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `site_id` INT(11) NOT NULL default '0'";
				$mysql_sql .= "  ,PRIMARY KEY (category_id,site_id))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "categories_sites (";
				$postgre_sql .= "  category_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  site_id INT4 NOT NULL default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (category_id,site_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "categories_sites (";
				$access_sql .= "  [category_id] INTEGER NOT NULL,";
				$access_sql .= "  [site_id] INTEGER NOT NULL";
				$access_sql .= "  ,PRIMARY KEY (category_id,site_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "categories_sites (";
				$db2_sql .= "  category_id INTEGER NOT NULL default 0,";
				$db2_sql .= "  site_id INTEGER NOT NULL default 0";
				$db2_sql .= "  ,PRIMARY KEY (category_id,site_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN sites_all TINYINT NOT NULL DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN sites_all SMALLINT NOT NULL DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN sites_all BYTE NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN sites_all SMALLINT NOT NULL DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "categories SET sites_all=1 ";

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "categories_user_types (";
				$mysql_sql .= "  `category_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `user_type_id` INT(11) NOT NULL default '0'";
				$mysql_sql .= "  ,PRIMARY KEY (category_id,user_type_id))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "categories_user_types (";
				$postgre_sql .= "  category_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  user_type_id INT4 NOT NULL default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (category_id,user_type_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "categories_user_types (";
				$access_sql .= "  [category_id] INTEGER NOT NULL,";
				$access_sql .= "  [user_type_id] INTEGER NOT NULL";
				$access_sql .= "  ,PRIMARY KEY (category_id,user_type_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "categories_user_types (";
				$db2_sql .= "  category_id INTEGER NOT NULL default 0,";
				$db2_sql .= "  user_type_id INTEGER NOT NULL default 0";
				$db2_sql .= "  ,PRIMARY KEY (category_id,user_type_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN user_types_all TINYINT NOT NULL DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN user_types_all SMALLINT NOT NULL DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN user_types_all BYTE NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN user_types_all SMALLINT NOT NULL DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "categories SET user_types_all=1 ";

				// product items
				$mysql_sql  = "CREATE TABLE " . $table_prefix . "items_sites (";
				$mysql_sql .= "  `item_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `site_id` INT(11) NOT NULL default '0'";
				$mysql_sql .= "  ,PRIMARY KEY (item_id,site_id))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "items_sites (";
				$postgre_sql .= "  item_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  site_id INT4 NOT NULL default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (item_id,site_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "items_sites (";
				$access_sql .= "  [item_id] INTEGER NOT NULL,";
				$access_sql .= "  [site_id] INTEGER NOT NULL";
				$access_sql .= "  ,PRIMARY KEY (item_id,site_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "items_sites (";
				$db2_sql .= "  item_id INTEGER NOT NULL default 0,";
				$db2_sql .= "  site_id INTEGER NOT NULL default 0";
				$db2_sql .= "  ,PRIMARY KEY (item_id,site_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN sites_all TINYINT NOT NULL DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN sites_all SMALLINT NOT NULL DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN sites_all BYTE NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "items ADD COLUMN sites_all SMALLINT NOT NULL DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "items SET sites_all=1 ";

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "items_user_types (";
				$mysql_sql .= "  `item_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `user_type_id` INT(11) NOT NULL default '0'";
				$mysql_sql .= "  ,PRIMARY KEY (item_id,user_type_id))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "items_user_types (";
				$postgre_sql .= "  item_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  user_type_id INT4 NOT NULL default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (item_id,user_type_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "items_user_types (";
				$access_sql .= "  [item_id] INTEGER NOT NULL,";
				$access_sql .= "  [user_type_id] INTEGER NOT NULL";
				$access_sql .= "  ,PRIMARY KEY (item_id,user_type_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "items_user_types (";
				$db2_sql .= "  item_id INTEGER NOT NULL default 0,";
				$db2_sql .= "  user_type_id INTEGER NOT NULL default 0";
				$db2_sql .= "  ,PRIMARY KEY (item_id,user_type_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN user_types_all TINYINT NOT NULL DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN user_types_all SMALLINT NOT NULL DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN user_types_all BYTE NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "items ADD COLUMN user_types_all SMALLINT NOT NULL DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "items SET user_types_all=1 ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN min_quantity INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN min_quantity INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN min_quantity INTEGER ",
					"db2"     => "ALTER TABLE " . $table_prefix . "items ADD COLUMN min_quantity INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN max_quantity INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN max_quantity INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN max_quantity INTEGER ",
					"db2"     => "ALTER TABLE " . $table_prefix . "items ADD COLUMN max_quantity INTEGER "
				);
				$sqls[] = $sql_types[$db_type];
				// end product items changes

				// forum categories
				$mysql_sql  = "CREATE TABLE " . $table_prefix . "forum_categories_sites (";
				$mysql_sql .= "  `category_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `site_id` INT(11) NOT NULL default '0'";
				$mysql_sql .= "  ,PRIMARY KEY (category_id,site_id))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "forum_categories_sites (";
				$postgre_sql .= "  category_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  site_id INT4 NOT NULL default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (category_id,site_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "forum_categories_sites (";
				$access_sql .= "  [category_id] INTEGER NOT NULL,";
				$access_sql .= "  [site_id] INTEGER NOT NULL";
				$access_sql .= "  ,PRIMARY KEY (category_id,site_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "forum_categories_sites (";
				$db2_sql .= "  category_id INTEGER NOT NULL default 0,";
				$db2_sql .= "  site_id INTEGER NOT NULL default 0";
				$db2_sql .= "  ,PRIMARY KEY (category_id,site_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "forum_categories ADD COLUMN sites_all TINYINT NOT NULL DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "forum_categories ADD COLUMN sites_all SMALLINT NOT NULL DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "forum_categories ADD COLUMN sites_all BYTE NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "forum_categories ADD COLUMN sites_all SMALLINT NOT NULL DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "forum_categories SET sites_all=1 ";

				// manuals categories
				$mysql_sql  = "CREATE TABLE " . $table_prefix . "manuals_categories_sites (";
				$mysql_sql .= "  `category_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `site_id` INT(11) NOT NULL default '0'";
				$mysql_sql .= "  ,PRIMARY KEY (category_id,site_id))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "manuals_categories_sites (";
				$postgre_sql .= "  category_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  site_id INT4 NOT NULL default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (category_id,site_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "manuals_categories_sites (";
				$access_sql .= "  [category_id] INTEGER NOT NULL,";
				$access_sql .= "  [site_id] INTEGER NOT NULL";
				$access_sql .= "  ,PRIMARY KEY (category_id,site_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "manuals_categories_sites (";
				$db2_sql .= "  category_id INTEGER NOT NULL default 0,";
				$db2_sql .= "  site_id INTEGER NOT NULL default 0";
				$db2_sql .= "  ,PRIMARY KEY (category_id,site_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "manuals_categories ADD COLUMN sites_all TINYINT NOT NULL DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "manuals_categories ADD COLUMN sites_all SMALLINT NOT NULL DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "manuals_categories ADD COLUMN sites_all BYTE NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "manuals_categories ADD COLUMN sites_all SMALLINT NOT NULL DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "manuals_categories SET sites_all=1 ";

				// custom pages
				$mysql_sql  = "CREATE TABLE " . $table_prefix . "pages_sites (";
				$mysql_sql .= "  `page_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `site_id` INT(11) NOT NULL default '0'";
				$mysql_sql .= "  ,PRIMARY KEY (page_id,site_id))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "pages_sites (";
				$postgre_sql .= "  page_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  site_id INT4 NOT NULL default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (page_id,site_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "pages_sites (";
				$access_sql .= "  [page_id] INTEGER NOT NULL,";
				$access_sql .= "  [site_id] INTEGER NOT NULL";
				$access_sql .= "  ,PRIMARY KEY (page_id,site_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "pages_sites (";
				$db2_sql .= "  page_id INTEGER NOT NULL default 0,";
				$db2_sql .= "  site_id INTEGER NOT NULL default 0";
				$db2_sql .= "  ,PRIMARY KEY (page_id,site_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "pages ADD COLUMN sites_all TINYINT NOT NULL DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "pages ADD COLUMN sites_all SMALLINT NOT NULL DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "pages ADD COLUMN sites_all BYTE NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "pages ADD COLUMN sites_all SMALLINT NOT NULL DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "pages SET sites_all=1 ";

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "pages_user_types (";
				$mysql_sql .= "  `page_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `user_type_id` INT(11) NOT NULL default '0'";
				$mysql_sql .= "  ,PRIMARY KEY (page_id,user_type_id))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "pages_user_types (";
				$postgre_sql .= "  page_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  user_type_id INT4 NOT NULL default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (page_id,user_type_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "pages_user_types (";
				$access_sql .= "  [page_id] INTEGER NOT NULL,";
				$access_sql .= "  [user_type_id] INTEGER NOT NULL";
				$access_sql .= "  ,PRIMARY KEY (page_id,user_type_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "pages_user_types (";
				$db2_sql .= "  page_id INTEGER NOT NULL default 0,";
				$db2_sql .= "  user_type_id INTEGER NOT NULL default 0";
				$db2_sql .= "  ,PRIMARY KEY (page_id,user_type_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "pages ADD COLUMN user_types_all TINYINT NOT NULL DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "pages ADD COLUMN user_types_all SMALLINT NOT NULL DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "pages ADD COLUMN user_types_all BYTE NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "pages ADD COLUMN user_types_all SMALLINT NOT NULL DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "pages SET user_types_all=1 ";

				// layouts 
				$mysql_sql  = "CREATE TABLE " . $table_prefix . "layouts_sites (";
				$mysql_sql .= "  `layout_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `site_id` INT(11) NOT NULL default '0'";
				$mysql_sql .= "  ,PRIMARY KEY (layout_id,site_id))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "layouts_sites (";
				$postgre_sql .= "  layout_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  site_id INT4 NOT NULL default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (layout_id,site_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "layouts_sites (";
				$access_sql .= "  [layout_id] INTEGER NOT NULL,";
				$access_sql .= "  [site_id] INTEGER NOT NULL";
				$access_sql .= "  ,PRIMARY KEY (layout_id,site_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "layouts_sites (";
				$db2_sql .= "  layout_id INTEGER NOT NULL default 0,";
				$db2_sql .= "  site_id INTEGER NOT NULL default 0";
				$db2_sql .= "  ,PRIMARY KEY (layout_id,site_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "layouts ADD COLUMN sites_all TINYINT NOT NULL DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "layouts ADD COLUMN sites_all SMALLINT NOT NULL DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "layouts ADD COLUMN sites_all BYTE NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "layouts ADD COLUMN sites_all SMALLINT NOT NULL DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "layouts SET sites_all=1 ";

				// shipping types
				$mysql_sql  = "CREATE TABLE " . $table_prefix . "shipping_types_sites (";
				$mysql_sql .= "  `shipping_type_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `site_id` INT(11) NOT NULL default '0'";
				$mysql_sql .= "  ,PRIMARY KEY (shipping_type_id,site_id))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "shipping_types_sites (";
				$postgre_sql .= "  shipping_type_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  site_id INT4 NOT NULL default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (shipping_type_id,site_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "shipping_types_sites (";
				$access_sql .= "  [shipping_type_id] INTEGER NOT NULL,";
				$access_sql .= "  [site_id] INTEGER NOT NULL";
				$access_sql .= "  ,PRIMARY KEY (shipping_type_id,site_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "shipping_types_sites (";
				$db2_sql .= "  shipping_type_id INTEGER NOT NULL default 0,";
				$db2_sql .= "  site_id INTEGER NOT NULL default 0";
				$db2_sql .= "  ,PRIMARY KEY (shipping_type_id,site_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "shipping_types ADD COLUMN sites_all TINYINT NOT NULL DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "shipping_types ADD COLUMN sites_all SMALLINT NOT NULL DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "shipping_types ADD COLUMN sites_all BYTE NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "shipping_types ADD COLUMN sites_all SMALLINT NOT NULL DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "shipping_types SET sites_all=1 ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "shipping_types ADD COLUMN countries_all TINYINT NOT NULL DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "shipping_types ADD COLUMN countries_all SMALLINT NOT NULL DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "shipping_types ADD COLUMN countries_all BYTE NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "shipping_types ADD COLUMN countries_all SMALLINT NOT NULL DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "shipping_types SET countries_all=0 ";

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "shipping_types_states (";
				$mysql_sql .= "  `shipping_type_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `state_code` VARCHAR(8) NOT NULL ";
				$mysql_sql .= "  ,PRIMARY KEY (shipping_type_id,state_code))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "shipping_types_states (";
				$postgre_sql .= "  shipping_type_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  state_code VARCHAR(8) NOT NULL ";
				$postgre_sql .= "  ,PRIMARY KEY (shipping_type_id,state_code))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "shipping_types_states (";
				$access_sql .= "  [shipping_type_id] INTEGER NOT NULL,";
				$access_sql .= "  [state_code] VARCHAR(8) NOT NULL ";
				$access_sql .= "  ,PRIMARY KEY (shipping_type_id,state_code))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "shipping_types_states (";
				$db2_sql .= "  shipping_type_id INTEGER NOT NULL default 0,";
				$db2_sql .= "  state_code VARCHAR(8) NOT NULL ";
				$db2_sql .= "  ,PRIMARY KEY (shipping_type_id,state_code))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "shipping_types ADD COLUMN states_all TINYINT NOT NULL DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "shipping_types ADD COLUMN states_all SMALLINT NOT NULL DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "shipping_types ADD COLUMN states_all BYTE NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "shipping_types ADD COLUMN states_all SMALLINT NOT NULL DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "shipping_types SET states_all=1 ";

				// user types 
				$mysql_sql  = "CREATE TABLE " . $table_prefix . "user_types_sites (";
				$mysql_sql .= "  `type_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `site_id` INT(11) NOT NULL default '0'";
				$mysql_sql .= "  ,PRIMARY KEY (type_id,site_id))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "user_types_sites (";
				$postgre_sql .= "  type_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  site_id INT4 NOT NULL default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (type_id,site_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "user_types_sites (";
				$access_sql .= "  [type_id] INTEGER NOT NULL,";
				$access_sql .= "  [site_id] INTEGER NOT NULL";
				$access_sql .= "  ,PRIMARY KEY (type_id,site_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "user_types_sites (";
				$db2_sql .= "  type_id INTEGER NOT NULL default 0,";
				$db2_sql .= "  site_id INTEGER NOT NULL default 0";
				$db2_sql .= "  ,PRIMARY KEY (type_id,site_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN sites_all TINYINT NOT NULL DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN sites_all SMALLINT NOT NULL DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN sites_all BYTE NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN sites_all SMALLINT NOT NULL DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "user_types SET sites_all=1 ";

				// payment systems 
				$mysql_sql  = "CREATE TABLE " . $table_prefix . "payment_systems_sites (";
				$mysql_sql .= "  `payment_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `site_id` INT(11) NOT NULL default '0'";
				$mysql_sql .= "  ,PRIMARY KEY (payment_id,site_id))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "payment_systems_sites (";
				$postgre_sql .= "  payment_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  site_id INT4 NOT NULL default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (payment_id,site_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "payment_systems_sites (";
				$access_sql .= "  [payment_id] INTEGER NOT NULL,";
				$access_sql .= "  [site_id] INTEGER NOT NULL";
				$access_sql .= "  ,PRIMARY KEY (payment_id,site_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "payment_systems_sites (";
				$db2_sql .= "  payment_id INTEGER NOT NULL default 0,";
				$db2_sql .= "  site_id INTEGER NOT NULL default 0";
				$db2_sql .= "  ,PRIMARY KEY (payment_id,site_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN sites_all TINYINT NOT NULL DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN sites_all SMALLINT NOT NULL DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN sites_all BYTE NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "payment_systems ADD COLUMN sites_all SMALLINT NOT NULL DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "payment_systems SET sites_all=1 ";

				// support departments 
				$mysql_sql  = "CREATE TABLE " . $table_prefix . "support_departments_sites (";
				$mysql_sql .= "  `dep_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `site_id` INT(11) NOT NULL default '0'";
				$mysql_sql .= "  ,PRIMARY KEY (dep_id,site_id))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "support_departments_sites (";
				$postgre_sql .= "  dep_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  site_id INT4 NOT NULL default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (dep_id,site_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "support_departments_sites (";
				$access_sql .= "  [dep_id] INTEGER NOT NULL,";
				$access_sql .= "  [site_id] INTEGER NOT NULL";
				$access_sql .= "  ,PRIMARY KEY (dep_id,site_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "support_departments_sites (";
				$db2_sql .= "  dep_id INTEGER NOT NULL default 0,";
				$db2_sql .= "  site_id INTEGER NOT NULL default 0";
				$db2_sql .= "  ,PRIMARY KEY (dep_id,site_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "support_departments ADD COLUMN sites_all TINYINT NOT NULL DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "support_departments ADD COLUMN sites_all SMALLINT NOT NULL DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "support_departments ADD COLUMN sites_all BYTE NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "support_departments ADD COLUMN sites_all SMALLINT NOT NULL DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "support_departments SET sites_all=1 ";

				// support products
				$mysql_sql  = "CREATE TABLE " . $table_prefix . "support_products_sites (";
				$mysql_sql .= "  `product_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `site_id` INT(11) NOT NULL default '0'";
				$mysql_sql .= "  ,PRIMARY KEY (product_id,site_id))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "support_products_sites (";
				$postgre_sql .= "  product_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  site_id INT4 NOT NULL default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (product_id,site_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "support_products_sites (";
				$access_sql .= "  [product_id] INTEGER NOT NULL,";
				$access_sql .= "  [site_id] INTEGER NOT NULL";
				$access_sql .= "  ,PRIMARY KEY (product_id,site_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "support_products_sites (";
				$db2_sql .= "  product_id INTEGER NOT NULL default 0,";
				$db2_sql .= "  site_id INTEGER NOT NULL default 0";
				$db2_sql .= "  ,PRIMARY KEY (product_id,site_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "support_products ADD COLUMN sites_all TINYINT NOT NULL DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "support_products ADD COLUMN sites_all SMALLINT NOT NULL DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "support_products ADD COLUMN sites_all BYTE NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "support_products ADD COLUMN sites_all SMALLINT NOT NULL DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "support_products SET sites_all=1 ";

				// add site_id field to existed tables
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN site_id INT(11) NOT NULL DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN site_id INT4 NOT NULL DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN site_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN site_id INTEGER NOT NULL DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "orders SET site_id=1 ";
				$sqls[] = " CREATE INDEX " . $table_prefix . "orders_site_id ON " . $table_prefix . "orders (site_id) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN site_id INT(11) NOT NULL DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN site_id INT4 NOT NULL DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN site_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN site_id INTEGER NOT NULL DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "orders_items SET site_id=1 ";
				$sqls[] = " CREATE INDEX " . $table_prefix . "orders_items_site_id ON " . $table_prefix . "orders_items (site_id) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items_prices ADD COLUMN site_id INT(11) NOT NULL DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "items_prices ADD COLUMN site_id INT4 NOT NULL DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "items_prices ADD COLUMN site_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "items_prices ADD COLUMN site_id INTEGER NOT NULL DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "items_prices SET site_id=0 ";
				$sqls[] = " CREATE INDEX " . $table_prefix . "items_prices_site_id ON " . $table_prefix . "items_prices (site_id) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "order_custom_properties ADD COLUMN site_id INT(11) NOT NULL DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "order_custom_properties ADD COLUMN site_id INT4 NOT NULL DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "order_custom_properties ADD COLUMN site_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "order_custom_properties ADD COLUMN site_id INTEGER NOT NULL DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "order_custom_properties SET site_id=1 ";
				$sqls[] = " CREATE INDEX " . $table_prefix . "order_custom_props_site_id ON " . $table_prefix . "order_custom_properties (site_id) ";
				// end multi-site changes

				// merchant user types who can post to categories
				$mysql_sql  = "CREATE TABLE " . $table_prefix . "categories_post_types (";
				$mysql_sql .= "  `category_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `user_type_id` INT(11) NOT NULL default '0'";
				$mysql_sql .= "  ,PRIMARY KEY (category_id,user_type_id))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "categories_post_types (";
				$postgre_sql .= "  category_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  user_type_id INT4 NOT NULL default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (category_id,user_type_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "categories_post_types (";
				$access_sql .= "  [category_id] INTEGER NOT NULL,";
				$access_sql .= "  [user_type_id] INTEGER NOT NULL";
				$access_sql .= "  ,PRIMARY KEY (category_id,user_type_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "categories_post_types (";
				$db2_sql .= "  category_id INTEGER NOT NULL default 0,";
				$db2_sql .= "  user_type_id INTEGER NOT NULL default 0";
				$db2_sql .= "  ,PRIMARY KEY (category_id,user_type_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN allowed_post_types_all TINYINT DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN allowed_post_types_all SMALLINT DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN allowed_post_types_all BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN allowed_post_types_all SMALLINT DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "categories SET allowed_post_types_all=1 ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN allowed_post_subcategories TINYINT DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN allowed_post_subcategories SMALLINT DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN allowed_post_subcategories BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN allowed_post_subcategories SMALLINT DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "categories SET allowed_post_subcategories=0 ";

				// custom fields for support form
				$mysql_sql  = "CREATE TABLE " . $table_prefix . "support_custom_properties (";
				$mysql_sql .= "  `property_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `site_id` INT(11) default '1',";
				$mysql_sql .= "  `property_order` INT(11) default '0',";
				$mysql_sql .= "  `property_name` VARCHAR(255),";
				$mysql_sql .= "  `property_description` TEXT,";
				$mysql_sql .= "  `default_value` TEXT,";
				$mysql_sql .= "  `property_style` VARCHAR(255),";
				$mysql_sql .= "  `section_id` INT(11) default '0',";
				$mysql_sql .= "  `property_show` TINYINT default '0',";
				$mysql_sql .= "  `control_type` VARCHAR(16),";
				$mysql_sql .= "  `control_style` VARCHAR(255),";
				$mysql_sql .= "  `control_code` TEXT,";
				$mysql_sql .= "  `onchange_code` TEXT,";
				$mysql_sql .= "  `onclick_code` TEXT,";
				$mysql_sql .= "  `required` TINYINT default '0',";
				$mysql_sql .= "  `before_name_html` TEXT,";
				$mysql_sql .= "  `after_name_html` TEXT,";
				$mysql_sql .= "  `before_control_html` TEXT,";
				$mysql_sql .= "  `after_control_html` TEXT,";
				$mysql_sql .= "  `validation_regexp` TEXT,";
				$mysql_sql .= "  `regexp_error` TEXT,";
				$mysql_sql .= "  `options_values_sql` TEXT";
				$mysql_sql .= "  ,KEY payment_id (site_id)";
				$mysql_sql .= "  ,PRIMARY KEY (property_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "support_custom_properties START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "support_custom_properties (";
				$postgre_sql .= "  property_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "support_custom_properties'),";
				$postgre_sql .= "  site_id INT4 default '1',";
				$postgre_sql .= "  property_order INT4 default '0',";
				$postgre_sql .= "  property_name VARCHAR(255),";
				$postgre_sql .= "  property_description TEXT,";
				$postgre_sql .= "  default_value TEXT,";
				$postgre_sql .= "  property_style VARCHAR(255),";
				$postgre_sql .= "  section_id INT4 default '0',";
				$postgre_sql .= "  property_show SMALLINT default '0',";
				$postgre_sql .= "  control_type VARCHAR(16),";
				$postgre_sql .= "  control_style VARCHAR(255),";
				$postgre_sql .= "  control_code TEXT,";
				$postgre_sql .= "  onchange_code TEXT,";
				$postgre_sql .= "  onclick_code TEXT,";
				$postgre_sql .= "  required SMALLINT default '0',";
				$postgre_sql .= "  before_name_html TEXT,";
				$postgre_sql .= "  after_name_html TEXT,";
				$postgre_sql .= "  before_control_html TEXT,";
				$postgre_sql .= "  after_control_html TEXT,";
				$postgre_sql .= "  validation_regexp TEXT,";
				$postgre_sql .= "  regexp_error TEXT,";
				$postgre_sql .= "  options_values_sql TEXT";
				$postgre_sql .= "  ,PRIMARY KEY (property_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "support_custom_properties (";
				$access_sql .= "  [property_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [site_id] INTEGER,";
				$access_sql .= "  [property_order] INTEGER,";
				$access_sql .= "  [property_name] VARCHAR(255),";
				$access_sql .= "  [property_description] LONGTEXT,";
				$access_sql .= "  [default_value] LONGTEXT,";
				$access_sql .= "  [property_style] VARCHAR(255),";
				$access_sql .= "  [section_id] INTEGER,";
				$access_sql .= "  [property_show] BYTE,";
				$access_sql .= "  [control_type] VARCHAR(16),";
				$access_sql .= "  [control_style] VARCHAR(255),";
				$access_sql .= "  [control_code] LONGTEXT,";
				$access_sql .= "  [onchange_code] LONGTEXT,";
				$access_sql .= "  [onclick_code] LONGTEXT,";
				$access_sql .= "  [required] BYTE,";
				$access_sql .= "  [before_name_html] LONGTEXT,";
				$access_sql .= "  [after_name_html] LONGTEXT,";
				$access_sql .= "  [before_control_html] LONGTEXT,";
				$access_sql .= "  [after_control_html] LONGTEXT,";
				$access_sql .= "  [validation_regexp] LONGTEXT,";
				$access_sql .= "  [regexp_error] LONGTEXT,";
				$access_sql .= "  [options_values_sql] LONGTEXT";
				$access_sql .= "  ,PRIMARY KEY (property_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "support_custom_properties (";
				$db2_sql .= "  property_id INTEGER NOT NULL,";
				$db2_sql .= "  site_id INTEGER default 1,";
				$db2_sql .= "  property_order INTEGER default 0,";
				$db2_sql .= "  property_name VARCHAR(255),";
				$db2_sql .= "  property_description LONG VARCHAR,";
				$db2_sql .= "  default_value LONG VARCHAR,";
				$db2_sql .= "  property_style VARCHAR(255),";
				$db2_sql .= "  section_id INTEGER default 0,";
				$db2_sql .= "  property_show SMALLINT default 0,";
				$db2_sql .= "  control_type VARCHAR(16),";
				$db2_sql .= "  control_style VARCHAR(255),";
				$db2_sql .= "  control_code LONG VARCHAR,";
				$db2_sql .= "  onchange_code LONG VARCHAR,";
				$db2_sql .= "  onclick_code LONG VARCHAR,";
				$db2_sql .= "  required SMALLINT default 0,";
				$db2_sql .= "  before_name_html LONG VARCHAR,";
				$db2_sql .= "  after_name_html LONG VARCHAR,";
				$db2_sql .= "  before_control_html LONG VARCHAR,";
				$db2_sql .= "  after_control_html LONG VARCHAR,";
				$db2_sql .= "  validation_regexp LONG VARCHAR,";
				$db2_sql .= "  regexp_error LONG VARCHAR,";
				$db2_sql .= "  options_values_sql LONG VARCHAR";
				$db2_sql .= "  ,PRIMARY KEY (property_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type != "mysql") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "support_custom_propertie_55 ON " . $table_prefix . "support_custom_properties (site_id)";
				}

				if ($db_type == "db2") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "support_custom_properties AS INTEGER START WITH 1 INCREMENT BY 1 NO CACHE NO CYCLE";
					$sqls[] = "CREATE TRIGGER tr_" . $table_prefix . "139 NO CASCADE BEFORE INSERT ON " . $table_prefix . "support_custom_properties REFERENCING NEW AS newr_" . $table_prefix . "support_custom_properties FOR EACH ROW MODE DB2SQL WHEN (newr_" . $table_prefix . "support_custom_properties.property_id IS NULL ) begin atomic set newr_" . $table_prefix . "support_custom_properties.property_id = nextval for seq_" . $table_prefix . "support_custom_properties; end";
				}

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "support_custom_values (";
				$mysql_sql .= "  `property_value_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `property_id` INT(11) default '0',";
				$mysql_sql .= "  `property_value` VARCHAR(255),";
				$mysql_sql .= "  `hide_value` TINYINT default '0',";
				$mysql_sql .= "  `is_default_value` TINYINT default '0'";
				$mysql_sql .= "  ,PRIMARY KEY (property_value_id)";
				$mysql_sql .= "  ,KEY property_id (property_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "support_custom_values START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "support_custom_values (";
				$postgre_sql .= "  property_value_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "support_custom_values'),";
				$postgre_sql .= "  property_id INT4 default '0',";
				$postgre_sql .= "  property_value VARCHAR(255),";
				$postgre_sql .= "  hide_value SMALLINT default '0',";
				$postgre_sql .= "  is_default_value SMALLINT default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (property_value_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "support_custom_values (";
				$access_sql .= "  [property_value_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [property_id] INTEGER,";
				$access_sql .= "  [property_value] VARCHAR(255),";
				$access_sql .= "  [hide_value] BYTE,";
				$access_sql .= "  [is_default_value] BYTE";
				$access_sql .= "  ,PRIMARY KEY (property_value_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "support_custom_values (";
				$db2_sql .= "  property_value_id INTEGER NOT NULL,";
				$db2_sql .= "  property_id INTEGER default 0,";
				$db2_sql .= "  property_value VARCHAR(255),";
				$db2_sql .= "  hide_value SMALLINT default 0,";
				$db2_sql .= "  is_default_value SMALLINT default 0";
				$db2_sql .= "  ,PRIMARY KEY (property_value_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type != "mysql") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "support_custom_values_pr_56 ON " . $table_prefix . "support_custom_values (property_id)";
				}

				if ($db_type == "db2") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "support_custom_values AS INTEGER START WITH 1 INCREMENT BY 1 NO CACHE NO CYCLE";
					$sqls[] = "CREATE TRIGGER tr_" . $table_prefix . "140 NO CASCADE BEFORE INSERT ON " . $table_prefix . "support_custom_values REFERENCING NEW AS newr_" . $table_prefix . "support_custom_values FOR EACH ROW MODE DB2SQL WHEN (newr_" . $table_prefix . "support_custom_values.property_value_id IS NULL ) begin atomic set newr_" . $table_prefix . "support_custom_values.property_value_id = nextval for seq_" . $table_prefix . "support_custom_values; end";
				}

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "support_properties (";
				$mysql_sql .= "  `support_property_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `support_id` INT(11) default '0',";
				$mysql_sql .= "  `property_id` INT(11) default '0',";
				$mysql_sql .= "  `property_value` TEXT";
				$mysql_sql .= "  ,PRIMARY KEY (support_property_id)";
				$mysql_sql .= "  ,KEY property_id (property_id)";
				$mysql_sql .= "  ,KEY support_id (support_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "support_properties START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "support_properties (";
				$postgre_sql .= "  support_property_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "support_properties'),";
				$postgre_sql .= "  support_id INT4 default '0',";
				$postgre_sql .= "  property_id INT4 default '0',";
				$postgre_sql .= "  property_value TEXT";
				$postgre_sql .= "  ,PRIMARY KEY (support_property_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "support_properties (";
				$access_sql .= "  [support_property_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [support_id] INTEGER,";
				$access_sql .= "  [property_id] INTEGER,";
				$access_sql .= "  [property_value] LONGTEXT";
				$access_sql .= "  ,PRIMARY KEY (support_property_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "support_properties (";
				$db2_sql .= "  support_property_id INTEGER NOT NULL,";
				$db2_sql .= "  support_id INTEGER default 0,";
				$db2_sql .= "  property_id INTEGER default 0,";
				$db2_sql .= "  property_value LONG VARCHAR";
				$db2_sql .= "  ,PRIMARY KEY (support_property_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type != "mysql") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "support_properties_order_id ON " . $table_prefix . "support_properties (support_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "support_properties_prope_63 ON " . $table_prefix . "support_properties (property_id)";
				}

				if ($db_type == "db2") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "support_properties AS INTEGER START WITH 1 INCREMENT BY 1 NO CACHE NO CYCLE";
					$sqls[] = "CREATE TRIGGER tr_" . $table_prefix . "148 NO CASCADE BEFORE INSERT ON " . $table_prefix . "support_properties REFERENCING NEW AS newr_" . $table_prefix . "support_properties FOR EACH ROW MODE DB2SQL WHEN (newr_" . $table_prefix . "support_properties.support_property_id IS NULL ) begin atomic set newr_" . $table_prefix . "support_properties.support_property_id = nextval for seq_" . $table_prefix . "support_properties; end";
				}
				// end support custom fields changes

				// order_statuses notification fields
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN merchant_notify TINYINT DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN merchant_notify SMALLINT DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN merchant_notify BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN merchant_notify SMALLINT DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN merchant_to VARCHAR(255) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN merchant_from VARCHAR(64) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN merchant_cc VARCHAR(255) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN merchant_bcc VARCHAR(255) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN merchant_reply_to VARCHAR(64) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN merchant_return_path VARCHAR(64) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN merchant_mail_type TINYINT DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN merchant_mail_type SMALLINT DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN merchant_mail_type BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN merchant_mail_type SMALLINT DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN merchant_subject VARCHAR(255) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN merchant_body TEXT",
					"postgre" => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN merchant_body TEXT",
					"access"  => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN merchant_body LONGTEXT",
					"db2"  => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN merchant_body LONG VARCHAR"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN merchant_sms_notify TINYINT DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN merchant_sms_notify SMALLINT DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN merchant_sms_notify BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN merchant_sms_notify SMALLINT DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN merchant_sms_recipient VARCHAR(255) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN merchant_sms_originator VARCHAR(255) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN merchant_sms_message TEXT",
					"postgre" => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN merchant_sms_message TEXT",
					"access"  => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN merchant_sms_message LONGTEXT",
					"db2"  => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN merchant_sms_message LONG VARCHAR"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN admin_notify TINYINT DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN admin_notify SMALLINT DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN admin_notify BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN admin_notify SMALLINT DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN admin_to VARCHAR(255) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN admin_from VARCHAR(64) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN admin_cc VARCHAR(255) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN admin_bcc VARCHAR(255) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN admin_reply_to VARCHAR(64) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN admin_return_path VARCHAR(64) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN admin_mail_type TINYINT DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN admin_mail_type SMALLINT DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN admin_mail_type BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN admin_mail_type SMALLINT DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN admin_subject VARCHAR(255) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN admin_body TEXT",
					"postgre" => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN admin_body TEXT",
					"access"  => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN admin_body LONGTEXT",
					"db2"  => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN admin_body LONG VARCHAR"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN admin_sms_notify TINYINT DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN admin_sms_notify SMALLINT DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN admin_sms_notify BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN admin_sms_notify SMALLINT DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN admin_sms_recipient VARCHAR(255) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN admin_sms_originator VARCHAR(255) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN admin_sms_message TEXT",
					"postgre" => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN admin_sms_message TEXT",
					"access"  => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN admin_sms_message LONGTEXT",
					"db2"  => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN admin_sms_message LONG VARCHAR"
				);
				$sqls[] = $sql_types[$db_type];
				// end order_statuses notification fields

				// changes for saved items
				$mysql_sql  = "CREATE TABLE " . $table_prefix . "saved_types (";
				$mysql_sql .= "  `type_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `type_name` VARCHAR(64),";
				$mysql_sql .= "  `type_desc` TEXT,";
				$mysql_sql .= "  `is_active` TINYINT default '1',";
				$mysql_sql .= "  `allowed_search` TINYINT default '0'";
				$mysql_sql .= "  ,PRIMARY KEY (type_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "saved_types START 2";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "saved_types (";
				$postgre_sql .= "  type_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "saved_types'),";
				$postgre_sql .= "  type_name VARCHAR(64),";
				$postgre_sql .= "  type_desc TEXT,";
				$postgre_sql .= "  is_active SMALLINT default '1',";
				$postgre_sql .= "  allowed_search SMALLINT default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (type_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "saved_types (";
				$access_sql .= "  [type_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [type_name] VARCHAR(64),";
				$access_sql .= "  [type_desc] LONGTEXT,";
				$access_sql .= "  [is_active] BYTE,";
				$access_sql .= "  [allowed_search] BYTE";
				$access_sql .= "  ,PRIMARY KEY (type_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "saved_types (";
				$db2_sql .= "  type_id INTEGER NOT NULL,";
				$db2_sql .= "  type_name VARCHAR(64),";
				$db2_sql .= "  type_desc LONG VARCHAR,";
				$db2_sql .= "  is_active SMALLINT default 1,";
				$db2_sql .= "  allowed_search SMALLINT default 0";
				$db2_sql .= "  ,PRIMARY KEY (type_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "db2") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "saved_types AS INTEGER START WITH 2 INCREMENT BY 1 NO CACHE NO CYCLE";
					$sqls[] = "CREATE TRIGGER tr_" . $table_prefix . "123 NO CASCADE BEFORE INSERT ON " . $table_prefix . "saved_types REFERENCING NEW AS newr_" . $table_prefix . "saved_types FOR EACH ROW MODE DB2SQL WHEN (newr_" . $table_prefix . "saved_types.type_id IS NULL ) begin atomic set newr_" . $table_prefix . "saved_types.type_id = nextval for seq_" . $table_prefix . "saved_types; end";
				}

				$sqls[] = "INSERT INTO " . $table_prefix . "saved_types (type_id, type_name, type_desc, is_active, allowed_search) VALUES (1, 'Wish List', '', 1, 0)";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "saved_items ADD COLUMN type_id INT(11) NOT NULL DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "saved_items ADD COLUMN type_id INT4 NOT NULL DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "saved_items ADD COLUMN type_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "saved_items ADD COLUMN type_id INTEGER NOT NULL DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "saved_items SET type_id=0 ";
				$sqls[] = " CREATE INDEX " . $table_prefix . "saved_items_type_id ON " . $table_prefix . "saved_items (type_id) ";
				// end changes for saved items

				// coupons changes
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN is_auto_apply TINYINT NOT NULL DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN is_auto_apply SMALLINT NOT NULL DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN is_auto_apply BYTE NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN is_auto_apply SMALLINT NOT NULL DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "coupons SET is_auto_apply=0 ";
				$sqls[] = " CREATE INDEX " . $table_prefix . "coupons_is_auto_apply ON " . $table_prefix . "coupons (is_auto_apply) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN cart_items_all TINYINT DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN cart_items_all SMALLINT DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN cart_items_all BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN cart_items_all SMALLINT DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "coupons SET cart_items_all=1 ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN cart_items_ids TEXT",
					"postgre" => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN cart_items_ids TEXT",
					"access"  => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN cart_items_ids LONGTEXT",
					"db2"  => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN cart_items_ids LONG VARCHAR"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN min_quantity INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN min_quantity INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN min_quantity INTEGER ",
					"db2"     => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN min_quantity INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN max_quantity INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN max_quantity INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN max_quantity INTEGER ",
					"db2"     => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN max_quantity INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN discount_quantity INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN discount_quantity INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN discount_quantity INTEGER ",
					"db2"     => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN discount_quantity INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN maximum_amount DOUBLE(16,2) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN maximum_amount FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN maximum_amount FLOAT",
					"db2"     => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN maximum_amount DOUBLE",
				);
				$sqls[] = $sql_types[$db_type];
				// end coupons changes

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.3.3");
			}

			if (comp_vers("3.3.4", $current_db_version) == 1)
			{
				// recreate shipping_types_states support_products_sites tables
				$sqls[] = " DROP TABLE " . $table_prefix . "support_products_sites ";

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "support_products_sites (";
				$mysql_sql .= "  `product_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `site_id` INT(11) NOT NULL default '0'";
				$mysql_sql .= "  ,PRIMARY KEY (product_id,site_id))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "support_products_sites (";
				$postgre_sql .= "  product_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  site_id INT4 NOT NULL default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (product_id,site_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "support_products_sites (";
				$access_sql .= "  [product_id] INTEGER NOT NULL,";
				$access_sql .= "  [site_id] INTEGER NOT NULL";
				$access_sql .= "  ,PRIMARY KEY (product_id,site_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "support_products_sites (";
				$db2_sql .= "  product_id INTEGER NOT NULL default 0,";
				$db2_sql .= "  site_id INTEGER NOT NULL default 0";
				$db2_sql .= "  ,PRIMARY KEY (product_id,site_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = " DROP TABLE " . $table_prefix . "shipping_types_states ";

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "shipping_types_states (";
				$mysql_sql .= "  `shipping_type_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `state_id` INT(11) NOT NULL DEFAULT '0' ";
				$mysql_sql .= "  ,PRIMARY KEY (shipping_type_id,state_id))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "shipping_types_states (";
				$postgre_sql .= "  shipping_type_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  state_id INT4 NOT NULL DEFAULT '0' ";
				$postgre_sql .= "  ,PRIMARY KEY (shipping_type_id,state_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "shipping_types_states (";
				$access_sql .= "  [shipping_type_id] INTEGER NOT NULL,";
				$access_sql .= "  [state_id] INTEGER NOT NULL ";
				$access_sql .= "  ,PRIMARY KEY (shipping_type_id,state_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "shipping_types_states (";
				$db2_sql .= "  shipping_type_id INTEGER NOT NULL default 0,";
				$db2_sql .= "  state_id INTEGER NOT NULL DEFAULT 0 ";
				$db2_sql .= "  ,PRIMARY KEY (shipping_type_id,state_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				// alter orders tables with new fields session_id,country_id,state_id
				$sqls[] = "ALTER TABLE " . $table_prefix . "orders ADD COLUMN session_id VARCHAR(32) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN state_id INT(11) NOT NULL DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN state_id INT4 NOT NULL DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN state_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN state_id INTEGER NOT NULL DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "orders SET state_id=0 ";
				$sqls[] = " CREATE INDEX " . $table_prefix . "orders_state_id ON " . $table_prefix . "orders (state_id) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN country_id INT(11) NOT NULL DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN country_id INT4 NOT NULL DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN country_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN country_id INTEGER NOT NULL DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "orders SET country_id=0 ";
				$sqls[] = " CREATE INDEX " . $table_prefix . "orders_country_id ON " . $table_prefix . "orders (country_id) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN delivery_state_id INT(11) NOT NULL DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN delivery_state_id INT4 NOT NULL DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN delivery_state_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN delivery_state_id INTEGER NOT NULL DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "orders SET delivery_state_id=0 ";
				$sqls[] = " CREATE INDEX " . $table_prefix . "orders_delivery_state_id ON " . $table_prefix . "orders (delivery_state_id) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN delivery_country_id INT(11) NOT NULL DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN delivery_country_id INT4 NOT NULL DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN delivery_country_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN delivery_country_id INTEGER NOT NULL DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "orders SET delivery_country_id=0 ";
				$sqls[] = " CREATE INDEX " . $table_prefix . "orders_delivery_country_id ON " . $table_prefix . "orders (delivery_country_id) ";

				// alter users tables with new fields country_id,state_id
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "users ADD COLUMN state_id INT(11) NOT NULL DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "users ADD COLUMN state_id INT4 NOT NULL DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "users ADD COLUMN state_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "users ADD COLUMN state_id INTEGER NOT NULL DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "users SET state_id=0 ";
				$sqls[] = " CREATE INDEX " . $table_prefix . "users_state_id ON " . $table_prefix . "users (state_id) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "users ADD COLUMN country_id INT(11) NOT NULL DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "users ADD COLUMN country_id INT4 NOT NULL DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "users ADD COLUMN country_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "users ADD COLUMN country_id INTEGER NOT NULL DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "users SET country_id=0 ";
				$sqls[] = " CREATE INDEX " . $table_prefix . "users_country_id ON " . $table_prefix . "users (country_id) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "users ADD COLUMN delivery_state_id INT(11) NOT NULL DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "users ADD COLUMN delivery_state_id INT4 NOT NULL DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "users ADD COLUMN delivery_state_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "users ADD COLUMN delivery_state_id INTEGER NOT NULL DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "users SET delivery_state_id=0 ";
				$sqls[] = " CREATE INDEX " . $table_prefix . "users_delivery_state_id ON " . $table_prefix . "users (delivery_state_id) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "users ADD COLUMN delivery_country_id INT(11) NOT NULL DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "users ADD COLUMN delivery_country_id INT4 NOT NULL DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "users ADD COLUMN delivery_country_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "users ADD COLUMN delivery_country_id INTEGER NOT NULL DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "users SET delivery_country_id=0 ";
				$sqls[] = " CREATE INDEX " . $table_prefix . "users_delivery_country_id ON " . $table_prefix . "users (delivery_country_id) ";
				// end users table changes

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "currencies ADD COLUMN decimals_number TINYINT DEFAULT '2'",
					"postgre" => "ALTER TABLE " . $table_prefix . "currencies ADD COLUMN decimals_number SMALLINT DEFAULT '2'",
					"access"  => "ALTER TABLE " . $table_prefix . "currencies ADD COLUMN decimals_number BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "currencies ADD COLUMN decimals_number SMALLINT DEFAULT 2"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = "ALTER TABLE " . $table_prefix . "currencies ADD COLUMN decimal_point VARCHAR(16) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "currencies ADD COLUMN thousands_separator VARCHAR(16) ";

				$sqls[] = " UPDATE " . $table_prefix . "currencies SET decimals_number=2 ";
				$sqls[] = " UPDATE " . $table_prefix . "currencies SET decimal_point='.' ";
				$sqls[] = " UPDATE " . $table_prefix . "currencies SET thousands_separator=',' ";

				// coupons sites 
				$mysql_sql  = "CREATE TABLE " . $table_prefix . "coupons_sites (";
				$mysql_sql .= "  `coupon_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `site_id` INT(11) NOT NULL default '0'";
				$mysql_sql .= "  ,PRIMARY KEY (coupon_id,site_id))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "coupons_sites (";
				$postgre_sql .= "  coupon_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  site_id INT4 NOT NULL default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (coupon_id,site_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "coupons_sites (";
				$access_sql .= "  [coupon_id] INTEGER NOT NULL,";
				$access_sql .= "  [site_id] INTEGER NOT NULL";
				$access_sql .= "  ,PRIMARY KEY (coupon_id,site_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "coupons_sites (";
				$db2_sql .= "  coupon_id INTEGER NOT NULL default 0,";
				$db2_sql .= "  site_id INTEGER NOT NULL default 0";
				$db2_sql .= "  ,PRIMARY KEY (coupon_id,site_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN sites_all TINYINT NOT NULL DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN sites_all SMALLINT NOT NULL DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN sites_all BYTE NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "coupons ADD COLUMN sites_all SMALLINT NOT NULL DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "coupons SET sites_all=1 ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "shipping_rules_countries ADD COLUMN country_id INT(11) NOT NULL DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "shipping_rules_countries ADD COLUMN country_id INT4 NOT NULL DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "shipping_rules_countries ADD COLUMN country_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "shipping_rules_countries ADD COLUMN country_id INTEGER NOT NULL DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "shipping_rules_countries SET country_id=0 ";
				$sqls[] = " CREATE INDEX " . $table_prefix . "shipping_rules_country_id ON " . $table_prefix . "shipping_rules_countries (country_id) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "shipping_types_countries ADD COLUMN country_id INT(11) NOT NULL DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "shipping_types_countries ADD COLUMN country_id INT4 NOT NULL DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "shipping_types_countries ADD COLUMN country_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "shipping_types_countries ADD COLUMN country_id INTEGER NOT NULL DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "shipping_types_countries SET country_id=0 ";
				$sqls[] = " CREATE INDEX " . $table_prefix . "shipping_types_country_id ON " . $table_prefix . "shipping_types_countries (country_id) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "tax_rates ADD COLUMN country_id INT(11) NOT NULL DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "tax_rates ADD COLUMN country_id INT4 NOT NULL DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "tax_rates ADD COLUMN country_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "tax_rates ADD COLUMN country_id INTEGER NOT NULL DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "tax_rates SET country_id=0 ";
				$sqls[] = " CREATE INDEX " . $table_prefix . "tax_rates_country_id ON " . $table_prefix . "tax_rates (country_id) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "tax_rates ADD COLUMN state_id INT(11) NOT NULL DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "tax_rates ADD COLUMN state_id INT4 NOT NULL DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "tax_rates ADD COLUMN state_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "tax_rates ADD COLUMN state_id INTEGER NOT NULL DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "tax_rates SET state_id=0 ";
				$sqls[] = " CREATE INDEX " . $table_prefix . "tax_rates_state_id ON " . $table_prefix . "tax_rates (state_id) ";

				// recreate states tables
				$sql = " SELECT COUNT(*) FROM " . $table_prefix . "states ";
				$states_sequence = get_db_value($sql) + 1;

				$sqls[] = " DROP TABLE " . $table_prefix . "states ";

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "states (";
				$mysql_sql .= "  `state_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `state_code` VARCHAR(8),";
				$mysql_sql .= "  `country_id` INT(11) NOT NULL DEFAULT '0',";
				$mysql_sql .= "  `state_name` VARCHAR(64) NOT NULL";
				$mysql_sql .= "  ,KEY country_id (country_id)";
				$mysql_sql .= "  ,PRIMARY KEY (state_id)";
				$mysql_sql .= "  ,KEY state_code (state_code))";

				if ($db_type == "postgre") {
					$sqls[] = "DROP SEQUENCE seq_" . $table_prefix . "states ";
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "states START " . $states_sequence;
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "states (";
				$postgre_sql .= "  state_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "states'),";
				$postgre_sql .= "  state_code VARCHAR(8),";
				$postgre_sql .= "  country_id INT4 NOT NULL DEFAULT '0',";
				$postgre_sql .= "  state_name VARCHAR(64) NOT NULL";
				$postgre_sql .= "  ,PRIMARY KEY (state_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "states (";
				$access_sql .= "  [state_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [state_code] VARCHAR(8),";
				$access_sql .= "  [country_id] INTEGER NOT NULL,";
				$access_sql .= "  [state_name] VARCHAR(64)";
				$access_sql .= "  ,PRIMARY KEY (state_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "states (";
				$db2_sql .= "  state_id INTEGER NOT NULL,";
				$db2_sql .= "  state_code VARCHAR(8),";
				$db2_sql .= "  country_id INTEGER NOT NULL DEFAULT 0,";
				$db2_sql .= "  state_name VARCHAR(64) NOT NULL";
				$db2_sql .= "  ,PRIMARY KEY (state_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type != "mysql") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "states_country_id ON " . $table_prefix . "states (country_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "states_state_code ON " . $table_prefix . "states (state_code)";
				}

				if ($db_type == "db2") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "states AS INTEGER START WITH " . $states_sequence . " INCREMENT BY 1 NO CACHE NO CYCLE";
					$sqls[] = "CREATE TRIGGER tr_" . $table_prefix . "states NO CASCADE BEFORE INSERT ON " . $table_prefix . "states REFERENCING NEW AS newr_" . $table_prefix . "states FOR EACH ROW MODE DB2SQL WHEN (newr_" . $table_prefix . "states.state_id IS NULL ) begin atomic set newr_" . $table_prefix . "states.state_id = nextval for seq_" . $table_prefix . "states; end";
				}

				$state_index = 1; $states_codes = array();
				$sql = " SELECT * FROM " . $table_prefix . "states ";
				$db->query($sql);
				while ($db->next_record()) {
					$sql  = " INSERT INTO " . $table_prefix . "states (state_id, state_code, country_id, state_name) VALUES (";
					$sql .= $db->tosql($state_index, INTEGER) . ", ";
					$sql .= $db->tosql($db->f("state_code"), TEXT) . ", ";
					$sql .= $db->tosql(0, INTEGER) . ", ";
					$sql .= $db->tosql($db->f("state_name"), TEXT) . ") ";
					$sqls[] = $sql;
					$states_codes[$db->f("state_code")] = $state_index;
					$state_index++;
				}
				// end recreate states


				// recreate countries tables
				$sql = " SELECT COUNT(*) FROM " . $table_prefix . "countries ";
				$countries_sequence = get_db_value($sql) + 1;

				$sqls[] = " DROP TABLE " . $table_prefix . "countries ";

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "countries (";
				$mysql_sql .= "  `country_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `country_code` VARCHAR(4) NOT NULL,";
				$mysql_sql .= "  `country_iso_number` VARCHAR(4),";
				$mysql_sql .= "  `country_order` INT(11) default '1',";
				$mysql_sql .= "  `country_name` VARCHAR(64) NOT NULL,";
				$mysql_sql .= "  `currency_code` VARCHAR(4)";
				$mysql_sql .= "  ,KEY country_code (country_code)";
				$mysql_sql .= "  ,PRIMARY KEY (country_id))";

				if ($db_type == "postgre") {
					$sqls[] = "DROP SEQUENCE seq_" . $table_prefix . "countries ";
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "countries START " . $countries_sequence;
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "countries (";
				$postgre_sql .= "  country_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "countries'),";
				$postgre_sql .= "  country_code VARCHAR(4) NOT NULL,";
				$postgre_sql .= "  country_iso_number VARCHAR(4),";
				$postgre_sql .= "  country_order INT4 default '1',";
				$postgre_sql .= "  country_name VARCHAR(64) NOT NULL,";
				$postgre_sql .= "  currency_code VARCHAR(4)";
				$postgre_sql .= "  ,PRIMARY KEY (country_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "countries (";
				$access_sql .= "  [country_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [country_code] VARCHAR(4),";
				$access_sql .= "  [country_iso_number] VARCHAR(4),";
				$access_sql .= "  [country_order] INTEGER,";
				$access_sql .= "  [country_name] VARCHAR(64),";
				$access_sql .= "  [currency_code] VARCHAR(4)";
				$access_sql .= "  ,PRIMARY KEY (country_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "countries (";
				$db2_sql .= "  country_id INTEGER NOT NULL,";
				$db2_sql .= "  country_code VARCHAR(4) NOT NULL,";
				$db2_sql .= "  country_iso_number VARCHAR(4),";
				$db2_sql .= "  country_order INTEGER default 1,";
				$db2_sql .= "  country_name VARCHAR(64) NOT NULL,";
				$db2_sql .= "  currency_code VARCHAR(4)";
				$db2_sql .= "  ,PRIMARY KEY (country_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type != "mysql") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "countries_country_code ON " . $table_prefix . "countries (country_code)";
				}

				if ($db_type == "db2") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "countries AS INTEGER START WITH " . $countries_sequence . " INCREMENT BY 1 NO CACHE NO CYCLE";
					$sqls[] = "CREATE TRIGGER tr_" . $table_prefix . "countries NO CASCADE BEFORE INSERT ON " . $table_prefix . "countries REFERENCING NEW AS newr_" . $table_prefix . "countries FOR EACH ROW MODE DB2SQL WHEN (newr_" . $table_prefix . "countries.country_id IS NULL ) begin atomic set newr_" . $table_prefix . "countries.country_id = nextval for seq_" . $table_prefix . "countries; end";
				}

				$country_index = 1; $countries_codes = array();
				$sql = " SELECT * FROM " . $table_prefix . "countries ";
				$db->query($sql);
				while ($db->next_record()) {
					$sql  = " INSERT INTO " . $table_prefix . "countries (country_id, country_code, country_iso_number, country_order, country_name, currency_code) VALUES (";
					$sql .= $db->tosql($country_index, INTEGER) . ", ";
					$sql .= $db->tosql($db->f("country_code"), TEXT) . ", ";
					$sql .= $db->tosql($db->f("country_iso_number"), TEXT) . ", ";
					$sql .= $db->tosql($db->f("country_order"), INTEGER) . ", ";
					$sql .= $db->tosql($db->f("country_name"), TEXT) . ", ";
					$sql .= $db->tosql($db->f("currency_code"), TEXT) . ") ";
					$sqls[] = $sql;
					$countries_codes[$db->f("country_code")] = $country_index;
					$country_index++;
				}

				// update old structure with new data and delete old country_code and state_code columns
				$updated_settings = array(
					"show_country_code" => "show_country_id",
					"show_state_code" => "show_state_id",
					"show_delivery_country_code" => "show_delivery_country_id",
					"show_delivery_state_code" => "show_delivery_state_id",
					"country_code_required" => "country_id_required",
					"state_code_required" => "state_id_required",
					"delivery_country_code_required" => "delivery_country_id_required",
					"delivery_state_code_required" => "delivery_state_id_required",
				);
				foreach($updated_settings as $old_setting_name => $new_setting_name) {
					$sql  = " UPDATE " . $table_prefix . "global_settings ";
					$sql .= " SET setting_name=" . $db->tosql($new_setting_name, TEXT);
					$sql .= " WHERE setting_name=" . $db->tosql($old_setting_name, TEXT);
					$sqls[] = $sql;
				}

				$sql = " SELECT country_code FROM " . $table_prefix . "shipping_rules_countries GROUP BY country_code ";
				$db->query($sql);
				while ($db->next_record()) {
					$country_code = $db->f("country_code");
					if ($country_code && isset($countries_codes[$country_code])) {
						$sql  = " UPDATE " . $table_prefix . "shipping_rules_countries SET country_id=" . $db->tosql($countries_codes[$country_code], INTEGER);
						$sql .= " WHERE country_code=" . $db->tosql($country_code, TEXT);
						$sqls[] = $sql;
					} else {
						$sqls[] = " DELETE FROM " . $table_prefix . "shipping_rules_countries WHERE country_code=" . $db->tosql($country_code, TEXT);
					}
				}

				$sql = " SELECT country_code FROM " . $table_prefix . "shipping_types_countries GROUP BY country_code ";
				$db->query($sql);
				while ($db->next_record()) {
					$country_code = $db->f("country_code");
					if ($country_code && isset($countries_codes[$country_code])) {
						$sql  = " UPDATE " . $table_prefix . "shipping_types_countries SET country_id=" . $db->tosql($countries_codes[$country_code], INTEGER);
						$sql .= " WHERE country_code=" . $db->tosql($country_code, TEXT);
						$sqls[] = $sql;
					} else {
						$sqls[] = " DELETE FROM " . $table_prefix . "shipping_types_countries WHERE country_code=" . $db->tosql($country_code, TEXT);
					}
				}

				$sql = " SELECT country_code, state_code FROM " . $table_prefix . "tax_rates GROUP BY country_code, state_code ";
				$db->query($sql);
				while ($db->next_record()) {
					$country_code = $db->f("country_code");
					$state_code = $db->f("state_code");
					if ($country_code && isset($countries_codes[$country_code])) {
						$state_id = 0;
						if ($state_code && isset($states_codes[$state_code])) {
							$state_id = $states_codes[$state_code];
						}
						$sql  = " UPDATE " . $table_prefix . "tax_rates SET country_id=" . $db->tosql($countries_codes[$country_code], INTEGER);
						$sql .= " , state_id=" . $db->tosql($state_id, INTEGER);
						$sql .= " WHERE country_code=" . $db->tosql($country_code, TEXT);
						$sqls[] = $sql;
					} else {
						$sqls[] = " DELETE FROM " . $table_prefix . "tax_rates WHERE country_code=" . $db->tosql($country_code, TEXT);
					}
				}

				// drop old columns
				$sqls[] = " ALTER TABLE ". $table_prefix . "shipping_rules_countries DROP COLUMN country_code ";
				$sqls[] = " ALTER TABLE ". $table_prefix . "shipping_types_countries DROP COLUMN country_code ";
				$sqls[] = " ALTER TABLE ". $table_prefix . "tax_rates DROP COLUMN country_code ";
				$sqls[] = " ALTER TABLE ". $table_prefix . "tax_rates DROP COLUMN state_code ";

				// update orders data
				$sql = " SELECT country_code FROM " . $table_prefix . "orders GROUP BY country_code ";
				$db->query($sql);
				while ($db->next_record()) {
					$country_code = $db->f("country_code");
					if ($country_code && isset($countries_codes[$country_code])) {
						$sql  = " UPDATE " . $table_prefix . "orders SET country_id=" . $db->tosql($countries_codes[$country_code], INTEGER);
						$sql .= " WHERE country_code=" . $db->tosql($country_code, TEXT);
						$sqls[] = $sql;
					}
				}

				$sql = " SELECT delivery_country_code FROM " . $table_prefix . "orders GROUP BY delivery_country_code ";
				$db->query($sql);
				while ($db->next_record()) {
					$country_code = $db->f("delivery_country_code");
					if ($country_code && isset($countries_codes[$country_code])) {
						$sql  = " UPDATE " . $table_prefix . "orders SET delivery_country_id=" . $db->tosql($countries_codes[$country_code], INTEGER);
						$sql .= " WHERE delivery_country_code=" . $db->tosql($country_code, TEXT);
						$sqls[] = $sql;
					}
				}

				$sql = " SELECT state_code FROM " . $table_prefix . "orders GROUP BY state_code ";
				$db->query($sql);
				while ($db->next_record()) {
					$state_code = $db->f("state_code");
					if ($state_code && isset($states_codes[$state_code])) {
						$sql  = " UPDATE " . $table_prefix . "orders SET state_id=" . $db->tosql($states_codes[$state_code], INTEGER);
						$sql .= " WHERE state_code=" . $db->tosql($state_code, TEXT);
						$sqls[] = $sql;
					}
				}

				$sql = " SELECT delivery_state_code FROM " . $table_prefix . "orders GROUP BY delivery_state_code ";
				$db->query($sql);
				while ($db->next_record()) {
					$state_code = $db->f("delivery_state_code");
					if ($state_code && isset($states_codes[$state_code])) {
						$sql  = " UPDATE " . $table_prefix . "orders SET delivery_state_id=" . $db->tosql($states_codes[$state_code], INTEGER);
						$sql .= " WHERE delivery_state_code=" . $db->tosql($state_code, TEXT);
						$sqls[] = $sql;
					}
				}

				// update users data
				$sql = " SELECT country_code FROM " . $table_prefix . "users GROUP BY country_code ";
				$db->query($sql);
				while ($db->next_record()) {
					$country_code = $db->f("country_code");
					if (isset($countries_codes[$country_code])) {
						$sql  = " UPDATE " . $table_prefix . "users SET country_id=" . $db->tosql($countries_codes[$country_code], INTEGER);
						$sql .= " WHERE country_code=" . $db->tosql($country_code, TEXT);
						$sqls[] = $sql;
					}
				}

				$sql = " SELECT delivery_country_code FROM " . $table_prefix . "users GROUP BY delivery_country_code ";
				$db->query($sql);
				while ($db->next_record()) {
					$country_code = $db->f("delivery_country_code");
					if (isset($countries_codes[$country_code])) {
						$sql  = " UPDATE " . $table_prefix . "users SET delivery_country_id=" . $db->tosql($countries_codes[$country_code], INTEGER);
						$sql .= " WHERE delivery_country_code=" . $db->tosql($country_code, TEXT);
						$sqls[] = $sql;
					}
				}

				$sql = " SELECT state_code FROM " . $table_prefix . "users GROUP BY state_code ";
				$db->query($sql);
				while ($db->next_record()) {
					$state_code = $db->f("state_code");
					if ($state_code && isset($states_codes[$state_code])) {
						$sql  = " UPDATE " . $table_prefix . "users SET state_id=" . $db->tosql($states_codes[$state_code], INTEGER);
						$sql .= " WHERE state_code=" . $db->tosql($state_code, TEXT);
						$sqls[] = $sql;
					}
				}

				$sql = " SELECT delivery_state_code FROM " . $table_prefix . "users GROUP BY delivery_state_code ";
				$db->query($sql);
				while ($db->next_record()) {
					$state_code = $db->f("delivery_state_code");
					if ($state_code && isset($states_codes[$state_code])) {
						$sql  = " UPDATE " . $table_prefix . "users SET delivery_state_id=" . $db->tosql($states_codes[$state_code], INTEGER);
						$sql .= " WHERE delivery_state_code=" . $db->tosql($state_code, TEXT);
						$sqls[] = $sql;
					}
				}

				// update global settings
				$sql = " SELECT * FROM " . $table_prefix . "global_settings WHERE setting_type='global' AND setting_name='country_code' ";
				$db->query($sql);
				if ($db->next_record()) {
					$country_code = $db->f("setting_value");
					if (isset($countries_codes[$country_code])) {
						$sql  = " UPDATE " . $table_prefix . "global_settings ";
						$sql .= " SET setting_value=" . $db->tosql($countries_codes[$country_code], TEXT);
						$sql .= " , setting_name='country_id' ";
						$sql .= " WHERE setting_type='global' AND setting_name='country_code' ";
						$sqls[] = $sql;
					} else {
						$sqls[] = " DELETE FROM " . $table_prefix . "global_settings WHERE setting_type='global' AND setting_name='country_code' ";
					}
				}

				$sql = " SELECT * FROM " . $table_prefix . "global_settings WHERE setting_type='global' AND setting_name='state_code' ";
				$db->query($sql);
				if ($db->next_record()) {
					$state_code = $db->f("setting_value");
					if (isset($countries_codes[$state_code])) {
						$sql  = " UPDATE " . $table_prefix . "global_settings ";
						$sql .= " SET setting_value=" . $db->tosql($countries_codes[$state_code], TEXT);
						$sql .= " , setting_name='state_id' ";
						$sql .= " WHERE setting_type='global' AND setting_name='state_code' ";
						$sqls[] = $sql;
					} else {
						$sqls[] = " DELETE FROM " . $table_prefix . "global_settings WHERE setting_type='global' AND setting_name='state_code' ";
					}
				}

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.3.4");
			}


			if (comp_vers("3.3.5", $current_db_version) == 1)
			{
				// tables to assign users groups for each forum
				// table for view forums by different user types
				$mysql_sql  = "CREATE TABLE " . $table_prefix . "forum_view_types (";
				$mysql_sql .= "  `forum_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `user_type_id` INT(11) NOT NULL default '0'";
				$mysql_sql .= "  ,PRIMARY KEY (forum_id,user_type_id))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "forum_view_types (";
				$postgre_sql .= "  forum_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  user_type_id INT4 NOT NULL default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (forum_id,user_type_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "forum_view_types (";
				$access_sql .= "  [forum_id] INTEGER NOT NULL,";
				$access_sql .= "  [user_type_id] INTEGER NOT NULL";
				$access_sql .= "  ,PRIMARY KEY (forum_id,user_type_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "forum_view_types (";
				$db2_sql .= "  forum_id INTEGER NOT NULL default 0,";
				$db2_sql .= "  user_type_id INTEGER NOT NULL default 0";
				$db2_sql .= "  ,PRIMARY KEY (forum_id,user_type_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN view_forum_types_all TINYINT DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN view_forum_types_all SMALLINT DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN view_forum_types_all BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN view_forum_types_all SMALLINT DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "forum_list SET view_forum_types_all=1 ";

				// table for view topics by different user types
				$mysql_sql  = "CREATE TABLE " . $table_prefix . "forum_view_topics (";
				$mysql_sql .= "  `forum_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `user_type_id` INT(11) NOT NULL default '0'";
				$mysql_sql .= "  ,PRIMARY KEY (forum_id,user_type_id))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "forum_view_topics (";
				$postgre_sql .= "  forum_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  user_type_id INT4 NOT NULL default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (forum_id,user_type_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "forum_view_topics (";
				$access_sql .= "  [forum_id] INTEGER NOT NULL,";
				$access_sql .= "  [user_type_id] INTEGER NOT NULL";
				$access_sql .= "  ,PRIMARY KEY (forum_id,user_type_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "forum_view_topics (";
				$db2_sql .= "  forum_id INTEGER NOT NULL default 0,";
				$db2_sql .= "  user_type_id INTEGER NOT NULL default 0";
				$db2_sql .= "  ,PRIMARY KEY (forum_id,user_type_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN view_topics_types_all TINYINT DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN view_topics_types_all SMALLINT DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN view_topics_types_all BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN view_topics_types_all SMALLINT DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "forum_list SET view_topics_types_all=1 ";

				// table for view topic by different user types
				$mysql_sql  = "CREATE TABLE " . $table_prefix . "forum_view_topic (";
				$mysql_sql .= "  `forum_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `user_type_id` INT(11) NOT NULL default '0'";
				$mysql_sql .= "  ,PRIMARY KEY (forum_id,user_type_id))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "forum_view_topic (";
				$postgre_sql .= "  forum_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  user_type_id INT4 NOT NULL default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (forum_id,user_type_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "forum_view_topic (";
				$access_sql .= "  [forum_id] INTEGER NOT NULL,";
				$access_sql .= "  [user_type_id] INTEGER NOT NULL";
				$access_sql .= "  ,PRIMARY KEY (forum_id,user_type_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "forum_view_topic (";
				$db2_sql .= "  forum_id INTEGER NOT NULL default 0,";
				$db2_sql .= "  user_type_id INTEGER NOT NULL default 0";
				$db2_sql .= "  ,PRIMARY KEY (forum_id,user_type_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN view_topic_types_all TINYINT DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN view_topic_types_all SMALLINT DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN view_topic_types_all BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN view_topic_types_all SMALLINT DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "forum_list SET view_topic_types_all=1 ";

				// table for post topics by different user types
				$mysql_sql  = "CREATE TABLE " . $table_prefix . "forum_post_topics (";
				$mysql_sql .= "  `forum_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `user_type_id` INT(11) NOT NULL default '0'";
				$mysql_sql .= "  ,PRIMARY KEY (forum_id,user_type_id))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "forum_post_topics (";
				$postgre_sql .= "  forum_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  user_type_id INT4 NOT NULL default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (forum_id,user_type_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "forum_post_topics (";
				$access_sql .= "  [forum_id] INTEGER NOT NULL,";
				$access_sql .= "  [user_type_id] INTEGER NOT NULL";
				$access_sql .= "  ,PRIMARY KEY (forum_id,user_type_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "forum_post_topics (";
				$db2_sql .= "  forum_id INTEGER NOT NULL default 0,";
				$db2_sql .= "  user_type_id INTEGER NOT NULL default 0";
				$db2_sql .= "  ,PRIMARY KEY (forum_id,user_type_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN post_topics_types_all TINYINT DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN post_topics_types_all SMALLINT DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN post_topics_types_all BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN post_topics_types_all SMALLINT DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "forum_list SET post_topics_types_all=1 ";


				// table for post replies by different user types
				$mysql_sql  = "CREATE TABLE " . $table_prefix . "forum_post_replies (";
				$mysql_sql .= "  `forum_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `user_type_id` INT(11) NOT NULL default '0'";
				$mysql_sql .= "  ,PRIMARY KEY (forum_id,user_type_id))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "forum_post_replies (";
				$postgre_sql .= "  forum_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  user_type_id INT4 NOT NULL default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (forum_id,user_type_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "forum_post_replies (";
				$access_sql .= "  [forum_id] INTEGER NOT NULL,";
				$access_sql .= "  [user_type_id] INTEGER NOT NULL";
				$access_sql .= "  ,PRIMARY KEY (forum_id,user_type_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "forum_post_replies (";
				$db2_sql .= "  forum_id INTEGER NOT NULL default 0,";
				$db2_sql .= "  user_type_id INTEGER NOT NULL default 0";
				$db2_sql .= "  ,PRIMARY KEY (forum_id,user_type_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN post_replies_types_all TINYINT DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN post_replies_types_all SMALLINT DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN post_replies_types_all BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN post_replies_types_all SMALLINT DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "forum_list SET post_replies_types_all=1 ";

				// table for attachments by different user types
				$mysql_sql  = "CREATE TABLE " . $table_prefix . "forum_attachments_types (";
				$mysql_sql .= "  `forum_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `user_type_id` INT(11) NOT NULL default '0'";
				$mysql_sql .= "  ,PRIMARY KEY (forum_id,user_type_id))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "forum_attachments_types (";
				$postgre_sql .= "  forum_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  user_type_id INT4 NOT NULL default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (forum_id,user_type_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "forum_attachments_types (";
				$access_sql .= "  [forum_id] INTEGER NOT NULL,";
				$access_sql .= "  [user_type_id] INTEGER NOT NULL";
				$access_sql .= "  ,PRIMARY KEY (forum_id,user_type_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "forum_attachments_types (";
				$db2_sql .= "  forum_id INTEGER NOT NULL default 0,";
				$db2_sql .= "  user_type_id INTEGER NOT NULL default 0";
				$db2_sql .= "  ,PRIMARY KEY (forum_id,user_type_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN allowed_attachments TINYINT DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN allowed_attachments SMALLINT DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN allowed_attachments BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN allowed_attachments SMALLINT DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "forum_list SET allowed_attachments=0 ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN attachments_types_all TINYINT DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN attachments_types_all SMALLINT DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN attachments_types_all BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "forum_list ADD COLUMN attachments_types_all SMALLINT DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "forum_list SET attachments_types_all=1 ";


				$mysql_sql  = "CREATE TABLE " . $table_prefix . "forum_attachments (";
				$mysql_sql .= "  `attachment_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `forum_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `thread_id` INT(11) default '0',";
				$mysql_sql .= "  `message_id` INT(11) default '0',";
				$mysql_sql .= "  `admin_id` INT(11) default '0',";
				$mysql_sql .= "  `user_id` INT(11) default '0',";
				$mysql_sql .= "  `attachment_status` INT(11) default '0',";
				$mysql_sql .= "  `file_name` VARCHAR(255),";
				$mysql_sql .= "  `file_path` VARCHAR(255),";
				$mysql_sql .= "  `date_added` DATETIME";
				$mysql_sql .= "  ,KEY admin_id (admin_id)";
				$mysql_sql .= "  ,KEY message_id (message_id)";
				$mysql_sql .= "  ,PRIMARY KEY (attachment_id)";
				$mysql_sql .= "  ,KEY support_id (forum_id)";
				$mysql_sql .= "  ,KEY thread_id (thread_id)";
				$mysql_sql .= "  ,KEY user_id (user_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "forum_attachments START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "forum_attachments (";
				$postgre_sql .= "  attachment_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "forum_attachments'),";
				$postgre_sql .= "  forum_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  thread_id INT4 default '0',";
				$postgre_sql .= "  message_id INT4 default '0',";
				$postgre_sql .= "  admin_id INT4 default '0',";
				$postgre_sql .= "  user_id INT4 default '0',";
				$postgre_sql .= "  attachment_status INT4 default '0',";
				$postgre_sql .= "  file_name VARCHAR(255),";
				$postgre_sql .= "  file_path VARCHAR(255),";
				$postgre_sql .= "  date_added TIMESTAMP";
				$postgre_sql .= "  ,PRIMARY KEY (attachment_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "forum_attachments (";
				$access_sql .= "  [attachment_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [forum_id] INTEGER,";
				$access_sql .= "  [thread_id] INTEGER,";
				$access_sql .= "  [message_id] INTEGER,";
				$access_sql .= "  [admin_id] INTEGER,";
				$access_sql .= "  [user_id] INTEGER,";
				$access_sql .= "  [attachment_status] INTEGER,";
				$access_sql .= "  [file_name] VARCHAR(255),";
				$access_sql .= "  [file_path] VARCHAR(255),";
				$access_sql .= "  [date_added] DATETIME";
				$access_sql .= "  ,PRIMARY KEY (attachment_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "forum_attachments (";
				$db2_sql .= "  attachment_id INTEGER NOT NULL,";
				$db2_sql .= "  forum_id INTEGER NOT NULL default 0,";
				$db2_sql .= "  thread_id INTEGER default 0,";
				$db2_sql .= "  message_id INTEGER default 0,";
				$db2_sql .= "  admin_id INTEGER default 0,";
				$db2_sql .= "  user_id INTEGER default 0,";
				$db2_sql .= "  attachment_status INTEGER default 0,";
				$db2_sql .= "  file_name VARCHAR(255),";
				$db2_sql .= "  file_path VARCHAR(255),";
				$db2_sql .= "  date_added TIMESTAMP";
				$db2_sql .= "  ,PRIMARY KEY (attachment_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type != "mysql") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "forum_attachments_admin_id ON " . $table_prefix . "forum_attachments (admin_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "forum_attachments_message_id ON " . $table_prefix . "forum_attachments (message_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "forum_attachments_support_id ON " . $table_prefix . "forum_attachments (forum_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "forum_attachments_thread_id ON " . $table_prefix . "forum_attachments (thread_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "forum_attachments_user_id ON " . $table_prefix . "forum_attachments (user_id)";
				}

				if ($db_type == "db2") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "forum_attachments AS INTEGER START WITH 1 INCREMENT BY 1 NO CACHE NO CYCLE";
					$sqls[] = "CREATE TRIGGER tr_" . $table_prefix . "forum_at_31 NO CASCADE BEFORE INSERT ON " . $table_prefix . "forum_attachments REFERENCING NEW AS newr_" . $table_prefix . "forum_attachments FOR EACH ROW MODE DB2SQL WHEN (newr_" . $table_prefix . "forum_attachments.attachment_id IS NULL ) begin atomic set newr_" . $table_prefix . "forum_attachments.attachment_id = nextval for seq_" . $table_prefix . "forum_attachments; end";
				}
				// end forum changes

				// items properties changes
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN property_price_type TINYINT ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN property_price_type SMALLINT ",
					"access"  => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN property_price_type BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN property_price_type SMALLINT "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN free_price_type TINYINT ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN free_price_type SMALLINT ",
					"access"  => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN free_price_type BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN free_price_type SMALLINT "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN free_price_length INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN free_price_length INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN free_price_length INTEGER ",
					"db2"     => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN free_price_length INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN max_limit_type TINYINT ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN max_limit_type SMALLINT ",
					"access"  => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN max_limit_type BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN max_limit_type SMALLINT "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN max_limit_length INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN max_limit_length INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN max_limit_length INTEGER ",
					"db2"     => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN max_limit_length INTEGER "
				);
				$sqls[] = $sql_types[$db_type];
				// end items properties changes

				// support changes
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "support_attachments ADD COLUMN user_id INT(11) NOT NULL DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "support_attachments ADD COLUMN user_id INT4 NOT NULL DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "support_attachments ADD COLUMN user_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "support_attachments ADD COLUMN user_id INTEGER NOT NULL DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "support_attachments SET user_id=0 ";
				$sqls[] = " CREATE INDEX " . $table_prefix . "support_attachments_user_id ON " . $table_prefix . "support_attachments (user_id) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "support_users_priorities ADD COLUMN priority_expiry DATETIME ",
					"postgre" => "ALTER TABLE " . $table_prefix . "support_users_priorities ADD COLUMN priority_expiry TIMESTAMP ",
					"access"  => "ALTER TABLE " . $table_prefix . "support_users_priorities ADD COLUMN priority_expiry DATETIME ",
					"db2"     => "ALTER TABLE " . $table_prefix . "support_users_priorities ADD COLUMN priority_expiry TIMESTAMP"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "support_users_priorities ADD COLUMN admin_id_added_by INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "support_users_priorities ADD COLUMN admin_id_added_by INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "support_users_priorities ADD COLUMN admin_id_added_by INTEGER ",
					"db2"     => "ALTER TABLE " . $table_prefix . "support_users_priorities ADD COLUMN admin_id_added_by INTEGER DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "support_users_priorities ADD COLUMN admin_id_modified_by INT(11) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "support_users_priorities ADD COLUMN admin_id_modified_by INT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "support_users_priorities ADD COLUMN admin_id_modified_by INTEGER ",
					"db2"     => "ALTER TABLE " . $table_prefix . "support_users_priorities ADD COLUMN admin_id_modified_by INTEGER DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "support_users_priorities ADD COLUMN date_added DATETIME ",
					"postgre" => "ALTER TABLE " . $table_prefix . "support_users_priorities ADD COLUMN date_added TIMESTAMP ",
					"access"  => "ALTER TABLE " . $table_prefix . "support_users_priorities ADD COLUMN date_added DATETIME ",
					"db2"     => "ALTER TABLE " . $table_prefix . "support_users_priorities ADD COLUMN date_added TIMESTAMP"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "support_users_priorities ADD COLUMN date_modified DATETIME ",
					"postgre" => "ALTER TABLE " . $table_prefix . "support_users_priorities ADD COLUMN date_modified TIMESTAMP ",
					"access"  => "ALTER TABLE " . $table_prefix . "support_users_priorities ADD COLUMN date_modified DATETIME ",
					"db2"     => "ALTER TABLE " . $table_prefix . "support_users_priorities ADD COLUMN date_modified TIMESTAMP"
				);
				$sqls[] = $sql_types[$db_type];
				// end support changes	

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.3.5");
			}

			if (comp_vers("3.3.6", $current_db_version) == 1)
			{
				// new global price table and related fields table
				$mysql_sql  = "CREATE TABLE " . $table_prefix . "prices (";
				$mysql_sql .= "  `price_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `price_title` VARCHAR(64),";
				$mysql_sql .= "  `price_amount` DOUBLE(16,2) default '0',";
				$mysql_sql .= "  `price_description` TEXT";
				$mysql_sql .= "  ,PRIMARY KEY (price_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "prices START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "prices (";
				$postgre_sql .= "  price_id INT4 NOT NULL DEFAULT nextval('seq_va_prices'),";
				$postgre_sql .= "  price_title VARCHAR(64),";
				$postgre_sql .= "  price_amount FLOAT4 default '0',";
				$postgre_sql .= "  price_description TEXT";
				$postgre_sql .= "  ,PRIMARY KEY (price_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "prices (";
				$access_sql .= "  [price_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [price_title] VARCHAR(64),";
				$access_sql .= "  [price_amount] FLOAT,";
				$access_sql .= "  [price_description] LONGTEXT";
				$access_sql .= "  ,PRIMARY KEY (price_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "prices (";
				$db2_sql .= "  price_id INTEGER NOT NULL,";
				$db2_sql .= "  price_title VARCHAR(64),";
				$db2_sql .= "  price_amount DOUBLE default 0,";
				$db2_sql .= "  price_description LONG VARCHAR";
				$db2_sql .= "  ,PRIMARY KEY (price_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "db2") {
					$sqls[] = "CREATE SEQUENCE seq_va_prices AS INTEGER START WITH 1 INCREMENT BY 1 NO CACHE NO CYCLE";
					$sqls[] = "CREATE TRIGGER tr_va_prices NO CASCADE BEFORE INSERT ON va_prices REFERENCING NEW AS newr_va_prices FOR EACH ROW MODE DB2SQL WHEN (newr_va_prices.price_id IS NULL ) begin atomic set newr_va_prices.price_id = nextval for seq_va_prices; end";
				}

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN price_id INT(11) NOT NULL DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN price_id INT4 NOT NULL DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN price_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "items ADD COLUMN price_id INTEGER NOT NULL DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "items SET price_id=0 ";
				$sqls[] = " CREATE INDEX " . $table_prefix . "items_price_id ON " . $table_prefix . "items (price_id) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN trade_price_id INT(11) NOT NULL DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN trade_price_id INT4 NOT NULL DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN trade_price_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "items ADD COLUMN trade_price_id INTEGER NOT NULL DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "items SET trade_price_id=0 ";
				$sqls[] = " CREATE INDEX " . $table_prefix . "items_trade_price_id ON " . $table_prefix . "items (trade_price_id) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN buying_price_id INT(11) NOT NULL DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN buying_price_id INT4 NOT NULL DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN buying_price_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "items ADD COLUMN buying_price_id INTEGER NOT NULL DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "items SET buying_price_id=0 ";
				$sqls[] = " CREATE INDEX " . $table_prefix . "items_buying_price_id ON " . $table_prefix . "items (buying_price_id) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN properties_price_id INT(11) NOT NULL DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN properties_price_id INT4 NOT NULL DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN properties_price_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "items ADD COLUMN properties_price_id INTEGER NOT NULL DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "items SET properties_price_id=0 ";
				$sqls[] = " CREATE INDEX " . $table_prefix . "items_properties_price_id ON " . $table_prefix . "items (properties_price_id) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN sales_price_id INT(11) NOT NULL DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN sales_price_id INT4 NOT NULL DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN sales_price_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "items ADD COLUMN sales_price_id INTEGER NOT NULL DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "items SET sales_price_id=0 ";
				$sqls[] = " CREATE INDEX " . $table_prefix . "items_sales_price_id ON " . $table_prefix . "items (sales_price_id) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN trade_sales_id INT(11) NOT NULL DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN trade_sales_id INT4 NOT NULL DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN trade_sales_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "items ADD COLUMN trade_sales_id INTEGER NOT NULL DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "items SET trade_sales_id=0 ";
				$sqls[] = " CREATE INDEX " . $table_prefix . "items_trade_sales_id ON " . $table_prefix . "items (trade_sales_id) ";
				// end prices changes

				// trade prices for properites
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN trade_additional_price DOUBLE(16,2) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN trade_additional_price FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN trade_additional_price FLOAT",
					"db2"     => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN trade_additional_price DOUBLE",
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items_properties_values ADD COLUMN trade_additional_price DOUBLE(16,2) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items_properties_values ADD COLUMN trade_additional_price FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "items_properties_values ADD COLUMN trade_additional_price FLOAT",
					"db2"     => "ALTER TABLE " . $table_prefix . "items_properties_values ADD COLUMN trade_additional_price DOUBLE",
				);
				$sqls[] = $sql_types[$db_type];
				// end trade prices for properites

				// custom friendly urls
				$mysql_sql  = "CREATE TABLE " . $table_prefix . "friendly_urls (";
				$mysql_sql .= "  `friendly_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `script_name` VARCHAR(255),";
				$mysql_sql .= "  `friendly_url` VARCHAR(255),";
				$mysql_sql .= "  `sites_all` TINYINT default '1'";
				$mysql_sql .= "  ,KEY friendly_url (friendly_url)";
				$mysql_sql .= "  ,PRIMARY KEY (friendly_id)";
				$mysql_sql .= "  ,KEY script_name (script_name)";
				$mysql_sql .= "  ,KEY sites_all (sites_all))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "friendly_urls START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "friendly_urls (";
				$postgre_sql .= "  friendly_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "friendly_urls'),";
				$postgre_sql .= "  script_name VARCHAR(255),";
				$postgre_sql .= "  friendly_url VARCHAR(255),";
				$postgre_sql .= "  sites_all SMALLINT default '1'";
				$postgre_sql .= "  ,PRIMARY KEY (friendly_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "friendly_urls (";
				$access_sql .= "  [friendly_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [script_name] VARCHAR(255),";
				$access_sql .= "  [friendly_url] VARCHAR(255),";
				$access_sql .= "  [sites_all] BYTE";
				$access_sql .= "  ,PRIMARY KEY (friendly_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "friendly_urls (";
				$db2_sql .= "  friendly_id INTEGER NOT NULL,";
				$db2_sql .= "  script_name VARCHAR(255),";
				$db2_sql .= "  friendly_url VARCHAR(255),";
				$db2_sql .= "  sites_all SMALLINT default 1";
				$db2_sql .= "  ,PRIMARY KEY (friendly_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type != "mysql") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "friendly_urls_friendly_url ON " . $table_prefix . "friendly_urls (friendly_url)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "friendly_urls_script_name ON " . $table_prefix . "friendly_urls (script_name)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "friendly_urls_sites_all ON " . $table_prefix . "friendly_urls (sites_all)";
				}

				if ($db_type == "db2") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "friendly_urls AS INTEGER START WITH 1 INCREMENT BY 1 NO CACHE NO CYCLE";
					$sqls[] = "CREATE TRIGGER tr_" . $table_prefix . "friendly_42 NO CASCADE BEFORE INSERT ON " . $table_prefix . "friendly_urls REFERENCING NEW AS newr_" . $table_prefix . "friendly_urls FOR EACH ROW MODE DB2SQL WHEN (newr_" . $table_prefix . "friendly_urls.friendly_id IS NULL ) begin atomic set newr_" . $table_prefix . "friendly_urls.friendly_id = nextval for seq_" . $table_prefix . "friendly_urls; end";
				}

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "friendly_urls_sites (";
				$mysql_sql .= "  `friendly_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `site_id` INT(11) NOT NULL default '0'";
				$mysql_sql .= "  ,PRIMARY KEY (friendly_id,site_id))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "friendly_urls_sites (";
				$postgre_sql .= "  friendly_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  site_id INT4 NOT NULL default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (friendly_id,site_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "friendly_urls_sites (";
				$access_sql .= "  [friendly_id] INTEGER NOT NULL,";
				$access_sql .= "  [site_id] INTEGER NOT NULL";
				$access_sql .= "  ,PRIMARY KEY (friendly_id,site_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "friendly_urls_sites (";
				$db2_sql .= "  friendly_id INTEGER NOT NULL default 0,";
				$db2_sql .= "  site_id INTEGER NOT NULL default 0";
				$db2_sql .= "  ,PRIMARY KEY (friendly_id,site_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];
				// end custom friendly urls

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.3.6");
			}

			if (comp_vers("3.3.7", $current_db_version) == 1)
			{
				// add value_order field into items_properties_values
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items_properties_values ADD COLUMN value_order INT(11) DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "items_properties_values ADD COLUMN value_order INT4 DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "items_properties_values ADD COLUMN value_order INTEGER ",
					"db2"     => "ALTER TABLE " . $table_prefix . "items_properties_values ADD COLUMN value_order INTEGER DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "items_properties_values SET value_order=1 ";

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "reminders (";
				$mysql_sql .= "  `reminder_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `user_id` INT(11) default '0',";
				$mysql_sql .= "  `start_date` DATETIME,";
				$mysql_sql .= "  `end_date` DATETIME,";
				$mysql_sql .= "  `reminder_year` INT(11) default '0',";
				$mysql_sql .= "  `reminder_month` TINYINT default '0',";
				$mysql_sql .= "  `reminder_day` TINYINT default '0',";
				$mysql_sql .= "  `reminder_weekdays` TINYINT default '0',";
				$mysql_sql .= "  `reminder_title` VARCHAR(255),";
				$mysql_sql .= "  `reminder_notes` TEXT,";
				$mysql_sql .= "  `date_added` DATETIME,";
				$mysql_sql .= "  `date_modified` DATETIME";
				$mysql_sql .= "  ,KEY end_date (end_date)";
				$mysql_sql .= "  ,PRIMARY KEY (reminder_id)";
				$mysql_sql .= "  ,KEY reminder_day (reminder_day)";
				$mysql_sql .= "  ,KEY reminder_month (reminder_month)";
				$mysql_sql .= "  ,KEY reminder_weekdays (reminder_weekdays)";
				$mysql_sql .= "  ,KEY reminder_year (reminder_year)";
				$mysql_sql .= "  ,KEY start_date (start_date)";
				$mysql_sql .= "  ,KEY user_id (user_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "reminders START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "reminders (";
				$postgre_sql .= "  reminder_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "reminders'),";
				$postgre_sql .= "  user_id INT4 default '0',";
				$postgre_sql .= "  start_date TIMESTAMP,";
				$postgre_sql .= "  end_date TIMESTAMP,";
				$postgre_sql .= "  reminder_year INT4 default '0',";
				$postgre_sql .= "  reminder_month SMALLINT default '0',";
				$postgre_sql .= "  reminder_day SMALLINT default '0',";
				$postgre_sql .= "  reminder_weekdays SMALLINT default '0',";
				$postgre_sql .= "  reminder_title VARCHAR(255),";
				$postgre_sql .= "  reminder_notes TEXT,";
				$postgre_sql .= "  date_added TIMESTAMP,";
				$postgre_sql .= "  date_modified TIMESTAMP";
				$postgre_sql .= "  ,PRIMARY KEY (reminder_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "reminders (";
				$access_sql .= "  [reminder_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [user_id] INTEGER,";
				$access_sql .= "  [start_date] DATETIME,";
				$access_sql .= "  [end_date] DATETIME,";
				$access_sql .= "  [reminder_year] INTEGER,";
				$access_sql .= "  [reminder_month] BYTE,";
				$access_sql .= "  [reminder_day] BYTE,";
				$access_sql .= "  [reminder_weekdays] BYTE,";
				$access_sql .= "  [reminder_title] VARCHAR(255),";
				$access_sql .= "  [reminder_notes] LONGTEXT,";
				$access_sql .= "  [date_added] DATETIME,";
				$access_sql .= "  [date_modified] DATETIME";
				$access_sql .= "  ,PRIMARY KEY (reminder_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "reminders (";
				$db2_sql .= "  reminder_id INTEGER NOT NULL,";
				$db2_sql .= "  user_id INTEGER default 0,";
				$db2_sql .= "  start_date TIMESTAMP,";
				$db2_sql .= "  end_date TIMESTAMP,";
				$db2_sql .= "  reminder_year INTEGER default 0,";
				$db2_sql .= "  reminder_month SMALLINT default 0,";
				$db2_sql .= "  reminder_day SMALLINT default 0,";
				$db2_sql .= "  reminder_weekdays SMALLINT default 0,";
				$db2_sql .= "  reminder_title VARCHAR(255),";
				$db2_sql .= "  reminder_notes LONG VARCHAR,";
				$db2_sql .= "  date_added TIMESTAMP,";
				$db2_sql .= "  date_modified TIMESTAMP";
				$db2_sql .= "  ,PRIMARY KEY (reminder_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type != "mysql") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "reminders_end_date ON " . $table_prefix . "reminders (end_date)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "reminders_reminder_day ON " . $table_prefix . "reminders (reminder_day)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "reminders_reminder_month ON " . $table_prefix . "reminders (reminder_month)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "reminders_reminder_weekdays ON " . $table_prefix . "reminders (reminder_weekdays)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "reminders_reminder_year ON " . $table_prefix . "reminders (reminder_year)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "reminders_start_date ON " . $table_prefix . "reminders (start_date)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "reminders_user_id ON " . $table_prefix . "reminders (user_id)";

				}

				if ($db_type == "db2") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "reminders AS INTEGER START WITH 1 INCREMENT BY 1 NO CACHE NO CYCLE";
					$sqls[] = "CREATE TRIGGER tr_" . $table_prefix . "reminders NO CASCADE BEFORE INSERT ON " . $table_prefix . "reminders REFERENCING NEW AS newr_" . $table_prefix . "reminders FOR EACH ROW MODE DB2SQL WHEN (newr_" . $table_prefix . "reminders.reminder_id IS NULL ) begin atomic set newr_" . $table_prefix . "reminders.reminder_id = nextval for seq_" . $table_prefix . "reminders; end";
				}

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.3.7");
			}

			if (comp_vers("3.3.8", $current_db_version) == 1)
			{
				// add filters tables
				$mysql_sql  = "CREATE TABLE " . $table_prefix . "filters (";
				$mysql_sql .= "  `filter_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `filter_type` VARCHAR(32),";
				$mysql_sql .= "  `filter_name` VARCHAR(255),";
				$mysql_sql .= "  `filter_desc` TEXT";
				$mysql_sql .= "  ,PRIMARY KEY (filter_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "filters START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "filters (";
				$postgre_sql .= "  filter_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "filters'),";
				$postgre_sql .= "  filter_type VARCHAR(32),";
				$postgre_sql .= "  filter_name VARCHAR(255),";
				$postgre_sql .= "  filter_desc TEXT";
				$postgre_sql .= "  ,PRIMARY KEY (filter_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "filters (";
				$access_sql .= "  [filter_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [filter_type] VARCHAR(32),";
				$access_sql .= "  [filter_name] VARCHAR(255),";
				$access_sql .= "  [filter_desc] LONGTEXT";
				$access_sql .= "  ,PRIMARY KEY (filter_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "filters (";
				$db2_sql .= "  filter_id INTEGER NOT NULL,";
				$db2_sql .= "  filter_type VARCHAR(32),";
				$db2_sql .= "  filter_name VARCHAR(255),";
				$db2_sql .= "  filter_desc LONG VARCHAR";
				$db2_sql .= "  ,PRIMARY KEY (filter_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "db2") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "filters AS INTEGER START WITH 1 INCREMENT BY 1 NO CACHE NO CYCLE";
					$sqls[] = "CREATE TRIGGER tr_" . $table_prefix . "filters NO CASCADE BEFORE INSERT ON " . $table_prefix . "filters REFERENCING NEW AS newr_" . $table_prefix . "filters FOR EACH ROW MODE DB2SQL WHEN (newr_" . $table_prefix . "filters.filter_id IS NULL ) begin atomic set newr_" . $table_prefix . "filters.filter_id = nextval for seq_" . $table_prefix . "filters; end";
				}

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "filters_properties (";
				$mysql_sql .= "  `property_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `filter_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `property_order` INT(11) NOT NULL default '1',";
				$mysql_sql .= "  `property_name` VARCHAR(255),";
				$mysql_sql .= "  `property_type` VARCHAR(64),";
				$mysql_sql .= "  `property_value` VARCHAR(255),";
				$mysql_sql .= "  `filter_from_sql` TEXT,";
				$mysql_sql .= "  `filter_join_sql` TEXT,";
				$mysql_sql .= "  `filter_where_sql` TEXT,";
				$mysql_sql .= "  `list_table` VARCHAR(64),";
				$mysql_sql .= "  `list_field_id` VARCHAR(64),";
				$mysql_sql .= "  `list_field_title` VARCHAR(64),";
				$mysql_sql .= "  `list_field_total` VARCHAR(64),";
				$mysql_sql .= "  `list_sql` TEXT";
				$mysql_sql .= "  ,KEY filter_id (filter_id)";
				$mysql_sql .= "  ,PRIMARY KEY (property_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "filters_properties START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "filters_properties (";
				$postgre_sql .= "  property_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "filters_properties'),";
				$postgre_sql .= "  filter_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  property_order INT4 NOT NULL default '1',";
				$postgre_sql .= "  property_name VARCHAR(255),";
				$postgre_sql .= "  property_type VARCHAR(64),";
				$postgre_sql .= "  property_value VARCHAR(255),";
				$postgre_sql .= "  filter_from_sql TEXT,";
				$postgre_sql .= "  filter_join_sql TEXT,";
				$postgre_sql .= "  filter_where_sql TEXT,";
				$postgre_sql .= "  list_table VARCHAR(64),";
				$postgre_sql .= "  list_field_id VARCHAR(64),";
				$postgre_sql .= "  list_field_title VARCHAR(64),";
				$postgre_sql .= "  list_field_total VARCHAR(64),";
				$postgre_sql .= "  list_sql TEXT";
				$postgre_sql .= "  ,PRIMARY KEY (property_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "filters_properties (";
				$access_sql .= "  [property_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [filter_id] INTEGER NOT NULL,";
				$access_sql .= "  [property_order] INTEGER NOT NULL,";
				$access_sql .= "  [property_name] VARCHAR(255),";
				$access_sql .= "  [property_type] VARCHAR(64),";
				$access_sql .= "  [property_value] VARCHAR(255),";
				$access_sql .= "  [filter_from_sql] LONGTEXT,";
				$access_sql .= "  [filter_join_sql] LONGTEXT,";
				$access_sql .= "  [filter_where_sql] LONGTEXT,";
				$access_sql .= "  [list_table] VARCHAR(64),";
				$access_sql .= "  [list_field_id] VARCHAR(64),";
				$access_sql .= "  [list_field_title] VARCHAR(64),";
				$access_sql .= "  [list_field_total] VARCHAR(64),";
				$access_sql .= "  [list_sql] LONGTEXT";
				$access_sql .= "  ,PRIMARY KEY (property_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "filters_properties (";
				$db2_sql .= "  property_id INTEGER NOT NULL,";
				$db2_sql .= "  filter_id INTEGER NOT NULL default 0,";
				$db2_sql .= "  property_order INTEGER NOT NULL default 1,";
				$db2_sql .= "  property_name VARCHAR(255),";
				$db2_sql .= "  property_type VARCHAR(64),";
				$db2_sql .= "  property_value VARCHAR(255),";
				$db2_sql .= "  filter_from_sql LONG VARCHAR,";
				$db2_sql .= "  filter_join_sql LONG VARCHAR,";
				$db2_sql .= "  filter_where_sql LONG VARCHAR,";
				$db2_sql .= "  list_table VARCHAR(64),";
				$db2_sql .= "  list_field_id VARCHAR(64),";
				$db2_sql .= "  list_field_title VARCHAR(64),";
				$db2_sql .= "  list_field_total VARCHAR(64),";
				$db2_sql .= "  list_sql LONG VARCHAR";
				$db2_sql .= "  ,PRIMARY KEY (property_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type != "mysql") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "filters_properties_filter ON " . $table_prefix . "filters_properties (filter_id)";
				}

				if ($db_type == "db2") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "filters_properties AS INTEGER START WITH 1 INCREMENT BY 1 NO CACHE NO CYCLE";
					$sqls[] = "CREATE TRIGGER tr_" . $table_prefix . "filters__31 NO CASCADE BEFORE INSERT ON " . $table_prefix . "filters_properties REFERENCING NEW AS newr_" . $table_prefix . "filters_properties FOR EACH ROW MODE DB2SQL WHEN (newr_" . $table_prefix . "filters_properties.property_id IS NULL ) begin atomic set newr_" . $table_prefix . "filters_properties.property_id = nextval for seq_" . $table_prefix . "filters_properties; end";
				}

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "filters_properties_values (";
				$mysql_sql .= "  `value_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `property_id` INT(11) default '0',";
				$mysql_sql .= "  `value_order` INT(11),";
				$mysql_sql .= "  `list_value_id` VARCHAR(128),";
				$mysql_sql .= "  `list_value_title` VARCHAR(255),";
				$mysql_sql .= "  `filter_where_sql` TEXT";
				$mysql_sql .= "  ,KEY property_id (property_id)";
				$mysql_sql .= "  ,PRIMARY KEY (value_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "filters_properties_values START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "filters_properties_values (";
				$postgre_sql .= "  value_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "filters_properties_values'),";
				$postgre_sql .= "  property_id INT4 default '0',";
				$postgre_sql .= "  value_order INT4,";
				$postgre_sql .= "  list_value_id VARCHAR(128),";
				$postgre_sql .= "  list_value_title VARCHAR(255),";
				$postgre_sql .= "  filter_where_sql TEXT";
				$postgre_sql .= "  ,PRIMARY KEY (value_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "filters_properties_values (";
				$access_sql .= "  [value_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [property_id] INTEGER,";
				$access_sql .= "  [value_order] INTEGER,";
				$access_sql .= "  [list_value_id] VARCHAR(128),";
				$access_sql .= "  [list_value_title] VARCHAR(255),";
				$access_sql .= "  [filter_where_sql] LONGTEXT";
				$access_sql .= "  ,PRIMARY KEY (value_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "filters_properties_values (";
				$db2_sql .= "  value_id INTEGER NOT NULL,";
				$db2_sql .= "  property_id INTEGER default 0,";
				$db2_sql .= "  value_order INTEGER,";
				$db2_sql .= "  list_value_id VARCHAR(128),";
				$db2_sql .= "  list_value_title VARCHAR(255),";
				$db2_sql .= "  filter_where_sql LONG VARCHAR";
				$db2_sql .= "  ,PRIMARY KEY (value_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type != "mysql") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "filters_properties_value_14 ON " . $table_prefix . "filters_properties_values (property_id)";
				}

				if ($db_type == "db2") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "filters_properties_values AS INTEGER START WITH 1 INCREMENT BY 1 NO CACHE NO CYCLE";
					$sqls[] = "CREATE TRIGGER tr_" . $table_prefix . "filters__32 NO CASCADE BEFORE INSERT ON " . $table_prefix . "filters_properties_values REFERENCING NEW AS newr_" . $table_prefix . "filters_properties_values FOR EACH ROW MODE DB2SQL WHEN (newr_" . $table_prefix . "filters_properties_values.value_id IS NULL ) begin atomic set newr_" . $table_prefix . "filters_properties_values.value_id = nextval for seq_" . $table_prefix . "filters_properties_values; end";
				}

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.3.8");
			}

			if (comp_vers("3.3.9", $current_db_version) == 1)
			{
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "tax_rates ADD COLUMN is_default TINYINT DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "tax_rates ADD COLUMN is_default SMALLINT DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "tax_rates ADD COLUMN is_default BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "tax_rates ADD COLUMN is_default SMALLINT DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];

				// update default currency
				$default_country_id = get_setting_value($settings, "country_id", "");
				$default_country_code = get_setting_value($settings, "country_code", "");
				if ($default_country_id) {
					$default_state_id = get_setting_value($settings, "state_id", "");
					$sql  = " SELECT tax_id ";
					$sql .= " FROM " . $table_prefix . "tax_rates ";
					$sql .= " WHERE country_id=" . $db->tosql($default_country_id, INTEGER);
					if ($default_state_id) {
						$sql .= " AND state_id=" . $db->tosql($default_state_id, INTEGER);
					} else {
						$sql .= " AND state_id=0 ";
					}
					$db->query($sql);
					if ($db->next_record()) {
						$tax_id = $db->f("tax_id");
						$sqls[] = " UPDATE " . $table_prefix . "tax_rates SET is_default=1 WHERE tax_id=" . $db->tosql($tax_id, INTEGER);
					}
				} else if ($default_country_code) {
					$default_state_code = get_setting_value($settings, "state_code", "");
					$sql  = " SELECT tax_id ";
					$sql .= " FROM " . $table_prefix . "tax_rates ";
					$sql .= " WHERE country_code=" . $db->tosql($default_country_code, TEXT);
					if ($default_state_code) {
						$sql .= " AND state_code=" . $db->tosql($default_state_code, TEXT);
					} else {
						$sql .= " AND state_code IS NULL ";
					}
					$db->query($sql);
					if ($db->next_record()) {
						$tax_id = $db->f("tax_id");
						$sqls[] = " UPDATE " . $table_prefix . "tax_rates SET is_default=1 WHERE tax_id=" . $db->tosql($tax_id, INTEGER);
					}
				}

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN hide_add_table TINYINT DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN hide_add_table SMALLINT DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN hide_add_table BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "items ADD COLUMN hide_add_table SMALLINT DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN hide_add_grid TINYINT DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN hide_add_grid SMALLINT DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN hide_add_grid BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "items ADD COLUMN hide_add_grid SMALLINT DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = " UPDATE " . $table_prefix . "items SET hide_add_table=1, hide_add_grid=1 WHERE hide_add_list=1 ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN use_on_table TINYINT DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN use_on_table SMALLINT DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN use_on_table BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN use_on_table SMALLINT DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN use_on_grid TINYINT DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN use_on_grid SMALLINT DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN use_on_grid BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN use_on_grid SMALLINT DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = " UPDATE " . $table_prefix . "items_properties SET use_on_table=1, use_on_grid=1 WHERE use_on_list=1 ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN user_invoice_activation TINYINT DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN user_invoice_activation SMALLINT DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN user_invoice_activation BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN user_invoice_activation SMALLINT DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "order_statuses SET user_invoice_activation=1 ";


				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (site_id, setting_type, setting_name, setting_value) VALUES (1, 'products', 'option_positive_price_right', ' (+ ')";
				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (site_id, setting_type, setting_name, setting_value) VALUES (1, 'products', 'option_positive_price_left', ')')";
				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (site_id, setting_type, setting_name, setting_value) VALUES (1, 'products', 'option_negative_price_right', ' (- ')";
				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (site_id, setting_type, setting_name, setting_value) VALUES (1, 'products', 'option_negative_price_left', ')')";

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.3.9");
			}

			if (comp_vers("3.3.10", $current_db_version) == 1)
			{
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "saved_carts ADD COLUMN site_id INT(11) NOT NULL DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "saved_carts ADD COLUMN site_id INT4 NOT NULL DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "saved_carts ADD COLUMN site_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "saved_carts ADD COLUMN site_id INTEGER NOT NULL DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "saved_carts SET site_id=1 ";
				$sqls[] = " CREATE INDEX " . $table_prefix . "saved_carts_site_id ON " . $table_prefix . "saved_carts (site_id) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "saved_items ADD COLUMN site_id INT(11) NOT NULL DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "saved_items ADD COLUMN site_id INT4 NOT NULL DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "saved_items ADD COLUMN site_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "saved_items ADD COLUMN site_id INTEGER NOT NULL DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "saved_items SET site_id=1 ";
				$sqls[] = " CREATE INDEX " . $table_prefix . "saved_items_site_id ON " . $table_prefix . "saved_items (site_id) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "saved_items ADD COLUMN quantity_bought INT(11) NOT NULL DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "saved_items ADD COLUMN quantity_bought INT4 NOT NULL DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "saved_items ADD COLUMN quantity_bought INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "saved_items ADD COLUMN quantity_bought INTEGER NOT NULL DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN cart_item_id INT(11) NOT NULL DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN cart_item_id INT4 NOT NULL DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN cart_item_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN cart_item_id INTEGER NOT NULL DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " CREATE INDEX " . $table_prefix . "orders_items_cart_item_id ON " . $table_prefix . "orders_items (cart_item_id) ";

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "users_credits (";
				$mysql_sql .= "  `credit_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `user_id` INT(11) default '0',";
				$mysql_sql .= "  `order_id` INT(11) default '0',";
				$mysql_sql .= "  `credit_amount` DOUBLE(16,4) default '0',";
				$mysql_sql .= "  `credit_action` INT(11) default '0',";
				$mysql_sql .= "  `admin_id_added_by` INT(11) default '0',";
				$mysql_sql .= "  `admin_id_modified_by` INT(11) default '0',";
				$mysql_sql .= "  `date_added` DATETIME,";
				$mysql_sql .= "  `date_modified` DATETIME";
				$mysql_sql .= "  ,KEY date_added (date_added)";
				$mysql_sql .= "  ,KEY order_id (order_id)";
				$mysql_sql .= "  ,PRIMARY KEY (credit_id)";
				$mysql_sql .= "  ,KEY user_id (user_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "users_credits START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "users_credits (";
				$postgre_sql .= "  credit_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "users_credits'),";
				$postgre_sql .= "  user_id INT4 default '0',";
				$postgre_sql .= "  order_id INT4 default '0',";
				$postgre_sql .= "  credit_amount FLOAT4 default '0',";
				$postgre_sql .= "  credit_action INT4 default '0',";
				$postgre_sql .= "  admin_id_added_by INT4 default '0',";
				$postgre_sql .= "  admin_id_modified_by INT4 default '0',";
				$postgre_sql .= "  date_added TIMESTAMP,";
				$postgre_sql .= "  date_modified TIMESTAMP";
				$postgre_sql .= "  ,PRIMARY KEY (credit_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "users_credits (";
				$access_sql .= "  [credit_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [user_id] INTEGER,";
				$access_sql .= "  [order_id] INTEGER,";
				$access_sql .= "  [credit_amount] FLOAT,";
				$access_sql .= "  [credit_action] INTEGER,";
				$access_sql .= "  [admin_id_added_by] INTEGER,";
				$access_sql .= "  [admin_id_modified_by] INTEGER,";
				$access_sql .= "  [date_added] DATETIME,";
				$access_sql .= "  [date_modified] DATETIME";
				$access_sql .= "  ,PRIMARY KEY (credit_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "users_credits (";
				$db2_sql .= "  credit_id INTEGER NOT NULL,";
				$db2_sql .= "  user_id INTEGER default 0,";
				$db2_sql .= "  order_id INTEGER default 0,";
				$db2_sql .= "  credit_amount DOUBLE default 2,";
				$db2_sql .= "  credit_action INTEGER default 0,";
				$db2_sql .= "  admin_id_added_by INTEGER default 0,";
				$db2_sql .= "  admin_id_modified_by INTEGER default 0,";
				$db2_sql .= "  date_added TIMESTAMP,";
				$db2_sql .= "  date_modified TIMESTAMP";
				$db2_sql .= "  ,PRIMARY KEY (credit_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type != "mysql") {
					$sqls[] = "CREATE INDEX " . $table_prefix . "users_credits_date_added ON " . $table_prefix . "users_credits (date_added)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "users_credits_order_id ON " . $table_prefix . "users_credits (order_id)";
					$sqls[] = "CREATE INDEX " . $table_prefix . "users_credits_user_id ON " . $table_prefix . "users_credits (user_id)";
				}

				if ($db_type == "db2") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "users_credits AS INTEGER START WITH 1 INCREMENT BY 1 NO CACHE NO CYCLE";
					$sqls[] = "CREATE TRIGGER tr_" . $table_prefix . "users_cr_117 NO CASCADE BEFORE INSERT ON " . $table_prefix . "users_credits REFERENCING NEW AS newr_" . $table_prefix . "users_credits FOR EACH ROW MODE DB2SQL WHEN (newr_" . $table_prefix . "users_credits.credit_id IS NULL ) begin atomic set newr_" . $table_prefix . "users_credits.credit_id = nextval for seq_" . $table_prefix . "users_credits; end";
				}

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "users ADD COLUMN credit_balance DOUBLE(16,2) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "users ADD COLUMN credit_balance FLOAT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "users ADD COLUMN credit_balance FLOAT",
					"db2"     => "ALTER TABLE " . $table_prefix . "users ADD COLUMN credit_balance DOUBLE default 0",
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN credit_amount DOUBLE(16,2) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN credit_amount FLOAT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN credit_amount FLOAT",
					"db2"     => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN credit_amount DOUBLE default 0",
				);
				$sqls[] = $sql_types[$db_type];

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "google_base_attributes (";
				$mysql_sql .= "  `attribute_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `attribute_name` VARCHAR(255),";
				$mysql_sql .= "  `attribute_type` VARCHAR(16),";
				$mysql_sql .= "  `value_type` VARCHAR(32)";
				$mysql_sql .= "  ,PRIMARY KEY (attribute_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "google_base_attributes START 1";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "google_base_attributes (";
				$postgre_sql .= "  attribute_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "google_base_attributes'),";
				$postgre_sql .= "  attribute_name VARCHAR(255),";
				$postgre_sql .= "  attribute_type VARCHAR(16),";
				$postgre_sql .= "  value_type VARCHAR(32)";
				$postgre_sql .= "  ,PRIMARY KEY (attribute_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "google_base_attributes (";
				$access_sql .= "  [attribute_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [attribute_name] VARCHAR(255),";
				$access_sql .= "  [attribute_type] VARCHAR(16),";
				$access_sql .= "  [value_type] VARCHAR(32)";
				$access_sql .= "  ,PRIMARY KEY (attribute_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "google_base_attributes (";
				$db2_sql .= "  attribute_id INTEGER NOT NULL,";
				$db2_sql .= "  attribute_name VARCHAR(255),";
				$db2_sql .= "  attribute_type VARCHAR(16),";
				$db2_sql .= "  value_type VARCHAR(32)";
				$db2_sql .= "  ,PRIMARY KEY (attribute_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "db2") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "google_base_attributes AS INTEGER START WITH 1 INCREMENT BY 1 NO CACHE NO CYCLE";
					$sqls[] = "CREATE TRIGGER tr_" . $table_prefix . "google_b_46 NO CASCADE BEFORE INSERT ON " . $table_prefix . "google_base_attributes REFERENCING NEW AS newr_" . $table_prefix . "google_base_attributes FOR EACH ROW MODE DB2SQL WHEN (newr_" . $table_prefix . "google_base_attributes.attribute_id IS NULL ) begin atomic set newr_" . $table_prefix . "google_base_attributes.attribute_id = nextval for seq_" . $table_prefix . "google_base_attributes; end";
				}

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "google_base_types (";
				$mysql_sql .= "  `type_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `type_name` VARCHAR(255)";
				$mysql_sql .= "  ,PRIMARY KEY (type_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "google_base_types START 23";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "google_base_types (";
				$postgre_sql .= "  type_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "google_base_types'),";
				$postgre_sql .= "  type_name VARCHAR(255)";
				$postgre_sql .= "  ,PRIMARY KEY (type_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "google_base_types (";
				$access_sql .= "  [type_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [type_name] VARCHAR(255)";
				$access_sql .= "  ,PRIMARY KEY (type_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "google_base_types (";
				$db2_sql .= "  type_id INTEGER NOT NULL,";
				$db2_sql .= "  type_name VARCHAR(255)";
				$db2_sql .= "  ,PRIMARY KEY (type_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "db2") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "google_base_types AS INTEGER START WITH 23 INCREMENT BY 1 NO CACHE NO CYCLE";
					$sqls[] = "CREATE TRIGGER tr_" . $table_prefix . "google_b_47 NO CASCADE BEFORE INSERT ON " . $table_prefix . "google_base_types REFERENCING NEW AS newr_" . $table_prefix . "google_base_types FOR EACH ROW MODE DB2SQL WHEN (newr_" . $table_prefix . "google_base_types.type_id IS NULL ) begin atomic set newr_" . $table_prefix . "google_base_types.type_id = nextval for seq_" . $table_prefix . "google_base_types; end";
				}

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "google_base_types_attributes (";
				$mysql_sql .= "  `type_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `attribute_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `required` TINYINT default '0'";
				$mysql_sql .= "  ,PRIMARY KEY (type_id,attribute_id))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "google_base_types_attributes (";
				$postgre_sql .= "  type_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  attribute_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  required SMALLINT default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (type_id,attribute_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "google_base_types_attributes (";
				$access_sql .= "  [type_id] INTEGER NOT NULL,";
				$access_sql .= "  [attribute_id] INTEGER NOT NULL,";
				$access_sql .= "  [required] BYTE";
				$access_sql .= "  ,PRIMARY KEY (type_id,attribute_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "google_base_types_attributes (";
				$db2_sql .= "  type_id INTEGER NOT NULL default 0,";
				$db2_sql .= "  attribute_id INTEGER NOT NULL default 0,";
				$db2_sql .= "  required SMALLINT default 0";
				$db2_sql .= "  ,PRIMARY KEY (type_id,attribute_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN google_base_type_id INT(11) NOT NULL DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN google_base_type_id INT4 NOT NULL DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN google_base_type_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "categories ADD COLUMN google_base_type_id INTEGER NOT NULL DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " CREATE INDEX " . $table_prefix . "categories_google_base_type ON " . $table_prefix . "categories (google_base_type_id) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "item_types ADD COLUMN google_base_type_id INT(11) NOT NULL DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "item_types ADD COLUMN google_base_type_id INT4 NOT NULL DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "item_types ADD COLUMN google_base_type_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "item_types ADD COLUMN google_base_type_id INTEGER NOT NULL DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " CREATE INDEX " . $table_prefix . "item_types_google_base_t_18 ON " . $table_prefix . "item_types (google_base_type_id) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN google_base_type_id INT(11) NOT NULL DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN google_base_type_id INT4 NOT NULL DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN google_base_type_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "items ADD COLUMN google_base_type_id INTEGER NOT NULL DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " CREATE INDEX " . $table_prefix . "items_google_base_type_id ON " . $table_prefix . "items (google_base_type_id) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "features ADD COLUMN google_base_attribute_id INT(11) NOT NULL DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "features ADD COLUMN google_base_attribute_id INT4 NOT NULL DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "features ADD COLUMN google_base_attribute_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "features ADD COLUMN google_base_attribute_id INTEGER NOT NULL DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " CREATE INDEX " . $table_prefix . "features_google_base_att_14 ON " . $table_prefix . "features (google_base_attribute_id) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "features_default ADD COLUMN google_base_attribute_id INT(11) NOT NULL DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "features_default ADD COLUMN google_base_attribute_id INT4 NOT NULL DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "features_default ADD COLUMN google_base_attribute_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "features_default ADD COLUMN google_base_attribute_id INTEGER NOT NULL DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " CREATE INDEX " . $table_prefix . "features_default_google__15 ON " . $table_prefix . "features_default (google_base_attribute_id) ";

				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types (type_id,type_name) VALUES (1 , 'Apparel' )";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types (type_id,type_name) VALUES (2 , 'Books' )";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types (type_id,type_name) VALUES (3 , 'Consumer Electronics: Cell Phones' )";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types (type_id,type_name) VALUES (4 , 'Consumer Electronics: Computers' )";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types (type_id,type_name) VALUES (5 , 'Consumer Electronics: Digital Cameras' )";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types (type_id,type_name) VALUES (6 , 'Consumer Electronics: Monitors' )";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types (type_id,type_name) VALUES (7 , 'Consumer Electronics: MP3 Players' )";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types (type_id,type_name) VALUES (8 , 'Consumer Electronics: Printers' )";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types (type_id,type_name) VALUES (9 , 'Consumer Electronics: Televisions' )";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types (type_id,type_name) VALUES (10 , 'Consumer Electronics: Video Cameras and Camcorders' )";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types (type_id,type_name) VALUES (11 , 'Consumer Electronics: Washers' )";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types (type_id,type_name) VALUES (12 , 'Consumer Electronics: Other' )";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types (type_id,type_name) VALUES (13 , 'Home and Garden: Furniture' )";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types (type_id,type_name) VALUES (14 , 'Home and Garden: Kitchen Appliances' )";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types (type_id,type_name) VALUES (15 , 'Home and Garden: Rugs' )";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types (type_id,type_name) VALUES (16 , 'Home and Garden: Other' )";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types (type_id,type_name) VALUES (17 , 'Jewelry' )";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types (type_id,type_name) VALUES (18 , 'Music' )";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types (type_id,type_name) VALUES (19 , 'Movies' )";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types (type_id,type_name) VALUES (20 , 'Shoes' )";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types (type_id,type_name) VALUES (21 , 'Toys' )";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types (type_id,type_name) VALUES (22 , 'Video and PC Games' )";

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.3.10");
			}
	
			if (comp_vers("3.3.11", $current_db_version) == 1)
			{
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "pages ADD COLUMN is_site_map TINYINT DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "pages ADD COLUMN is_site_map SMALLINT DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "pages ADD COLUMN is_site_map BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "pages ADD COLUMN is_site_map SMALLINT DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "pages SET is_site_map=1 ";
				$sqls[] = " CREATE INDEX " . $table_prefix . "pages_is_site_map ON " . $table_prefix . "pages (is_site_map) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN tax_prices_type TINYINT DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN tax_prices_type SMALLINT DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN tax_prices_type BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN tax_prices_type SMALLINT DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];

				$tax_prices_type = get_setting_value($settings, "tax_prices_type", 0);
				$sqls[] = " UPDATE " . $table_prefix . "orders SET tax_prices_type=" . $db->tosql($tax_prices_type, INTEGER);

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.3.11");
			}

			if (comp_vers("3.3.12", $current_db_version) == 1)
			{
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN credit_action INT(11) DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN credit_action INT4 DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN credit_action INTEGER ",
					"db2"     => "ALTER TABLE " . $table_prefix . "order_statuses ADD COLUMN credit_action INTEGER DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "order_statuses SET credit_action=points_action";
				
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(1, 'actor', 'g', 'string')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(2, 'age_range', 'g', 'string')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(3, 'artist', 'g', 'string')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(4, 'aspect_ratio', 'g', 'string')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(5, 'author', 'g', 'string')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(6, 'battery_life', 'g', 'int')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(7, 'binding', 'g', 'string')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(8, 'capacity', 'g', 'intUnit')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(9, 'color', 'g', 'string')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(10, 'color_output', 'g', 'boolean')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(11, 'department', 'g', 'string')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(12, 'director', 'g', 'string')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(13, 'display_type', 'g', 'string')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(14, 'edition', 'g', 'string')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(15, 'feature', 'g', 'string')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(16, 'focus_type', 'g', 'string')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(17, 'format', 'g', 'string')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(18, 'functions', 'g', 'string')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(19, 'genre', 'g', 'string')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(20, 'heel_height', 'g', 'floatUnit')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(21, 'height', 'g', 'floatUnit')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(22, 'installation', 'g', 'string')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(23, 'length', 'g', 'floatUnit')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(24, 'load_type', 'g', 'string')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(25, 'made_in', 'g', 'location')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(26, 'material', 'g', 'string')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(27, 'megapixels', 'g', 'floatUnit')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(28, 'memory_card_slot', 'g', 'string')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(29, 'occasion', 'g', 'string')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(30, 'operating_system', 'g', 'string')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(31, 'optical_drive', 'g', 'string')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(32, 'pages', 'g', 'string')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(33, 'payment_accepted', 'g', 'string')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(34, 'payment_notes', 'g', 'string')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(35, 'pickup', 'g', 'boolean')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(36, 'platform', 'g', 'string')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(37, 'processor_speed', 'g', 'floatUnit')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(38, 'publisher', 'g', 'string')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(39, 'rating', 'g', 'string')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(40, 'recommended_usage', 'g', 'string')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(41, 'resolution', 'g', 'string')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(42, 'screen_size', 'g', 'intUnit')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(43, 'shoe_width', 'g', 'string')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(44, 'size', 'g', 'string')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(45, 'style', 'g', 'string')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(46, 'tech_spec_link', 'g', 'url')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(47, 'width', 'g', 'intUnit')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(48, 'wireless_interface', 'g', 'string')";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_attributes VALUES(49, 'zoom', 'g', 'string')";

				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(1, 9, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(1, 11, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(1, 25, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(1, 26, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(1, 44, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(1, 45, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(2, 5, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(2, 7, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(2, 14, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(2, 19, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(2, 32, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(2, 38, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(3, 9, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(3, 18, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(3, 21, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(3, 23, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(3, 46, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(3, 47, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(3, 48, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(4, 6, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(4, 8, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(4, 9, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(4, 21, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(4, 23, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(4, 30, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(4, 31, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(4, 37, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(4, 40, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(4, 42, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(4, 46, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(4, 47, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(5, 9, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(5, 16, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(5, 21, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(5, 23, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(5, 27, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(5, 41, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(5, 46, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(5, 47, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(5, 49, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(6, 4, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(6, 9, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(6, 13, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(6, 21, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(6, 23, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(6, 41, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(6, 42, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(6, 46, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(6, 47, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(7, 8, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(7, 9, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(7, 18, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(7, 21, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(7, 23, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(7, 46, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(7, 47, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(8, 9, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(8, 10, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(8, 18, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(8, 21, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(8, 23, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(8, 28, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(8, 46, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(8, 47, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(9, 4, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(9, 9, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(9, 13, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(9, 21, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(9, 23, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(9, 41, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(9, 42, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(9, 46, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(9, 47, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(10, 9, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(10, 21, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(10, 23, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(10, 42, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(10, 46, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(10, 47, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(10, 49, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(11, 8, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(11, 9, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(11, 21, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(11, 23, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(11, 24, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(11, 46, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(11, 47, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(12, 9, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(12, 21, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(12, 23, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(12, 46, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(12, 47, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(13, 3, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(13, 11, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(13, 15, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(13, 21, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(13, 23, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(13, 25, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(13, 47, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(14, 8, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(14, 21, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(14, 22, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(14, 23, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(14, 25, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(14, 47, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(15, 15, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(15, 23, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(15, 25, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(15, 26, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(15, 47, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(16, 11, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(16, 21, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(16, 23, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(16, 25, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(16, 47, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(17, 3, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(17, 11, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(17, 26, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(17, 29, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(17, 45, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(18, 3, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(18, 14, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(18, 17, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(18, 19, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(19, 1, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(19, 12, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(19, 17, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(19, 19, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(19, 39, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(19, 49, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(20, 9, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(20, 11, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(20, 20, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(20, 25, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(20, 26, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(20, 43, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(20, 44, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(20, 45, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(21, 2, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(21, 25, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(22, 19, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(22, 36, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "google_base_types_attributes VALUES(22, 39, 1)";

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.3.12");
			}

			if (comp_vers("3.3.13", $current_db_version) == 1)
			{
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "newsletters_emails ADD COLUMN is_sent TINYINT(1) DEFAULT 0",
					"postgre" => "ALTER TABLE " . $table_prefix . "newsletters_emails ADD COLUMN is_sent SMALLINT DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "newsletters_emails ADD COLUMN is_sent BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "newsletters_emails ADD COLUMN is_sent SMALLINT DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "newsletters_emails ADD COLUMN is_custom TINYINT(1) DEFAULT 0",
					"postgre" => "ALTER TABLE " . $table_prefix . "newsletters_emails ADD COLUMN is_custom SMALLINT DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "newsletters_emails ADD COLUMN is_custom BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "newsletters_emails ADD COLUMN is_custom SMALLINT DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.3.13");
			}

			if (comp_vers("3.3.14", $current_db_version) == 1)
			{
				$sql  = " UPDATE " . $table_prefix . "order_statuses SET stock_level_action=1 ";
				$sqls[] = $sql;

				$sql  = " UPDATE " . $table_prefix . "order_statuses SET stock_level_action=-1, points_action=-1 ";
				$sql .= " WHERE status_type='CANCELLED' OR status_type='REFUNDED' OR status_type='VOIDED' ";
				$sqls[] = $sql;

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.3.14");
			}

			if (comp_vers("3.3.15", $current_db_version) == 1)
			{
				// add layout for default custom page
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'custom_page', 'custom_page_body', 0, 'middle')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'custom_page', 'left_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'custom_page', 'left_column_width', NULL, NULL)";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'custom_page', 'middle_column_hide', NULL, '0')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'custom_page', 'middle_column_width', NULL, '100%')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'custom_page', 'right_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'custom_page', 'right_column_width', NULL, NULL)";

				// add layout for wishlist page
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'wishlist', 'wishlist_search', 0, 'middle')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'wishlist', 'wishlist_items', 1, 'middle')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'wishlist', 'left_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'wishlist', 'left_column_width', NULL, NULL)";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'wishlist', 'middle_column_hide', NULL, '0')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'wishlist', 'middle_column_width', NULL, '100%')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'wishlist', 'right_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'wishlist', 'right_column_width', NULL, NULL)";


				$mysql_sql  = "CREATE TABLE " . $table_prefix . "forum_priorities (";
				$mysql_sql .= "  `priority_id` INT(11) NOT NULL AUTO_INCREMENT,";
				$mysql_sql .= "  `priority_name` VARCHAR(255),";
				$mysql_sql .= "  `priority_rank` INT(11) default '0',";
				$mysql_sql .= "  `html_before_title` TEXT,";
				$mysql_sql .= "  `html_after_title` TEXT,";
				$mysql_sql .= "  `is_default` TINYINT default '0'";
				$mysql_sql .= "  ,PRIMARY KEY (priority_id))";

				if ($db_type == "postgre") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "forum_priorities START 3";
				}
				$postgre_sql  = "CREATE TABLE " . $table_prefix . "forum_priorities (";
				$postgre_sql .= "  priority_id INT4 NOT NULL DEFAULT nextval('seq_" . $table_prefix . "forum_priorities'),";
				$postgre_sql .= "  priority_name VARCHAR(255),";
				$postgre_sql .= "  priority_rank INT4 default '0',";
				$postgre_sql .= "  html_before_title TEXT,";
				$postgre_sql .= "  html_after_title TEXT,";
				$postgre_sql .= "  is_default SMALLINT default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (priority_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "forum_priorities (";
				$access_sql .= "  [priority_id]  COUNTER  NOT NULL,";
				$access_sql .= "  [priority_name] VARCHAR(255),";
				$access_sql .= "  [priority_rank] INTEGER,";
				$access_sql .= "  [html_before_title] LONGTEXT,";
				$access_sql .= "  [html_after_title] LONGTEXT,";
				$access_sql .= "  [is_default] BYTE";
				$access_sql .= "  ,PRIMARY KEY (priority_id))";


				$db2_sql  = "CREATE TABLE " . $table_prefix . "forum_priorities (";
				$db2_sql .= "  priority_id INTEGER NOT NULL,";
				$db2_sql .= "  priority_name VARCHAR(255),";
				$db2_sql .= "  priority_rank INTEGER default 0,";
				$db2_sql .= "  html_before_title LONG VARCHAR,";
				$db2_sql .= "  html_after_title LONG VARCHAR,";
				$db2_sql .= "  is_default SMALLINT default 0";
				$db2_sql .= "  ,PRIMARY KEY (priority_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "db2") {
					$sqls[] = "CREATE SEQUENCE seq_" . $table_prefix . "forum_priorities AS INTEGER START WITH 3 INCREMENT BY 1 NO CACHE NO CYCLE";
					$sqls[] = "CREATE TRIGGER tr_" . $table_prefix . "forum_pr_41 NO CASCADE BEFORE INSERT ON " . $table_prefix . "forum_priorities REFERENCING NEW AS newr_" . $table_prefix . "forum_priorities FOR EACH ROW MODE DB2SQL WHEN (newr_" . $table_prefix . "forum_priorities.priority_id IS NULL ) begin atomic set newr_" . $table_prefix . "forum_priorities.priority_id = nextval for seq_" . $table_prefix . "forum_priorities; end";
				}

				$sqls[] = "INSERT INTO " . $table_prefix . "forum_priorities (priority_id,priority_name,priority_rank,html_before_title,html_after_title,is_default) VALUES (1, 'Normal', 3, NULL, NULL, 1)";
				$sqls[] = "INSERT INTO " . $table_prefix . "forum_priorities (priority_id,priority_name,priority_rank,html_before_title,html_after_title,is_default) VALUES (2, 'Important' , 1, '<b>Important:</b> ', NULL, 0)";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "forum ADD COLUMN priority_id INT(11) DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "forum ADD COLUMN priority_id INT4 DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "forum ADD COLUMN priority_id INTEGER ",
					"db2"     => "ALTER TABLE " . $table_prefix . "forum ADD COLUMN priority_id INTEGER DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "forum SET priority_id=1 ";
				$sqls[] = " CREATE INDEX " . $table_prefix . "forum_priority_id ON " . $table_prefix . "forum (priority_id)";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN usage_type TINYINT DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN usage_type SMALLINT DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN usage_type BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN usage_type SMALLINT DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "items_properties SET usage_type=1 ";
				$sqls[] = " CREATE INDEX " . $table_prefix . "items_properties_usage_type ON " . $table_prefix . "items_properties (usage_type) ";

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "items_properties_assigned (";
				$mysql_sql .= "  `item_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `property_id` INT(11) NOT NULL default '0'";
				$mysql_sql .= "  ,PRIMARY KEY (item_id,property_id))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "items_properties_assigned (";
				$postgre_sql .= "  item_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  property_id INT4 NOT NULL default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (item_id,property_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "items_properties_assigned (";
				$access_sql .= "  [item_id] INTEGER NOT NULL,";
				$access_sql .= "  [property_id] INTEGER NOT NULL";
				$access_sql .= "  ,PRIMARY KEY (item_id,property_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "items_properties_assigned (";
				$db2_sql .= "  item_id INTEGER NOT NULL default 0,";
				$db2_sql .= "  property_id INTEGER NOT NULL default 0";
				$db2_sql .= "  ,PRIMARY KEY (item_id,property_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				$mysql_sql  = "CREATE TABLE " . $table_prefix . "items_values_assigned (";
				$mysql_sql .= "  `item_id` INT(11) NOT NULL default '0',";
				$mysql_sql .= "  `property_value_id` INT(11) NOT NULL default '0'";
				$mysql_sql .= "  ,PRIMARY KEY (item_id,property_value_id))";

				$postgre_sql  = "CREATE TABLE " . $table_prefix . "items_values_assigned (";
				$postgre_sql .= "  item_id INT4 NOT NULL default '0',";
				$postgre_sql .= "  property_value_id INT4 NOT NULL default '0'";
				$postgre_sql .= "  ,PRIMARY KEY (item_id,property_value_id))";

				$access_sql  = "CREATE TABLE " . $table_prefix . "items_values_assigned (";
				$access_sql .= "  [item_id] INTEGER NOT NULL,";
				$access_sql .= "  [property_value_id] INTEGER NOT NULL";
				$access_sql .= "  ,PRIMARY KEY (item_id,property_value_id))";

				$db2_sql  = "CREATE TABLE " . $table_prefix . "items_values_assigned (";
				$db2_sql .= "  item_id INTEGER NOT NULL default 0,";
				$db2_sql .= "  property_value_id INTEGER NOT NULL default 0";
				$db2_sql .= "  ,PRIMARY KEY (item_id,property_value_id))";

				$sql_types = array("mysql" => $mysql_sql, "postgre" => $postgre_sql, "access" => $access_sql, "db2" => $db2_sql);
				$sqls[] = $sql_types[$db_type];

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.3.15");
			}

			if (comp_vers("3.3.16", $current_db_version) == 1)
			{
				// add layout for user login page
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'user_login', 'advanced_login', 0, 'middle')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'user_login', 'left_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'user_login', 'left_column_width', NULL, NULL)";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'user_login', 'middle_column_hide', NULL, '0')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'user_login', 'middle_column_width', NULL, '100%')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'user_login', 'right_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'user_login', 'right_column_width', NULL, NULL)";

				// add layout for user profile page
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'user_profile', 'userhome_breadcrumb', 0, 'middle')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'user_profile', 'user_profile_form', 1, 'middle')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'user_profile', 'left_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'user_profile', 'left_column_width', NULL, NULL)";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'user_profile', 'middle_column_hide', NULL, '0')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'user_profile', 'middle_column_width', NULL, '100%')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'user_profile', 'right_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'user_profile', 'right_column_width', NULL, NULL)";

				// add layout for forgot password page
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'forgot_password', 'forgot_password', 0, 'middle')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'forgot_password', 'left_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'forgot_password', 'left_column_width', NULL, NULL)";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'forgot_password', 'middle_column_hide', NULL, '0')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'forgot_password', 'middle_column_width', NULL, '100%')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'forgot_password', 'right_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'forgot_password', 'right_column_width', NULL, NULL)";

				// add layout for reset password page
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'reset_password', 'reset_password', 0, 'middle')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'reset_password', 'left_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'reset_password', 'left_column_width', NULL, NULL)";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'reset_password', 'middle_column_hide', NULL, '0')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'reset_password', 'middle_column_width', NULL, '100%')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'reset_password', 'right_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'reset_password', 'right_column_width', NULL, NULL)";

				// add layout for support reply page
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'support_reply', 'support_reply', 0, 'middle')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'support_reply', 'left_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'support_reply', 'left_column_width', NULL, NULL)";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'support_reply', 'middle_column_hide', NULL, '0')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'support_reply', 'middle_column_width', NULL, '100%')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'support_reply', 'right_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'support_reply', 'right_column_width', NULL, NULL)";

				// add layout for advanced search page
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'products_advanced_search', 'products_advanced_search', 0, 'middle')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'products_advanced_search', 'left_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'products_advanced_search', 'left_column_width', NULL, NULL)";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'products_advanced_search', 'middle_column_hide', NULL, '0')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'products_advanced_search', 'middle_column_width', NULL, '100%')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'products_advanced_search', 'right_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'products_advanced_search', 'right_column_width', NULL, NULL)";

				// add layout for compare page
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'products_compare', 'products_compare', 0, 'middle')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'products_compare', 'left_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'products_compare', 'left_column_width', NULL, NULL)";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'products_compare', 'middle_column_hide', NULL, '0')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'products_compare', 'middle_column_width', NULL, '100%')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'products_compare', 'right_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'products_compare', 'right_column_width', NULL, NULL)";

				// add layout for releases page
				$sqls[]  = " UPDATE " . $table_prefix . "page_settings SET setting_name='products_releases_hot' WHERE setting_name='products_releases' ";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'products_releases', 'products_releases', 0, 'middle')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'products_releases', 'left_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'products_releases', 'left_column_width', NULL, NULL)";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'products_releases', 'middle_column_hide', NULL, '0')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'products_releases', 'middle_column_width', NULL, '100%')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'products_releases', 'right_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'products_releases', 'right_column_width', NULL, NULL)";

				// add layout for changes log page
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'products_changes_log', 'products_changes_log', 0, 'middle')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'products_changes_log', 'left_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'products_changes_log', 'left_column_width', NULL, NULL)";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'products_changes_log', 'middle_column_hide', NULL, '0')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'products_changes_log', 'middle_column_width', NULL, '100%')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'products_changes_log', 'right_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'products_changes_log', 'right_column_width', NULL, NULL)";

				// add layout for cart save page
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'cart_save', 'cart_save', 0, 'middle')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'cart_save', 'left_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'cart_save', 'left_column_width', NULL, NULL)";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'cart_save', 'middle_column_hide', NULL, '0')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'cart_save', 'middle_column_width', NULL, '100%')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'cart_save', 'right_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'cart_save', 'right_column_width', NULL, NULL)";

				// add layout for cart retrieve page
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'cart_retrieve', 'cart_retrieve', 0, 'middle')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'cart_retrieve', 'left_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'cart_retrieve', 'left_column_width', NULL, NULL)";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'cart_retrieve', 'middle_column_hide', NULL, '0')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'cart_retrieve', 'middle_column_width', NULL, '100%')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'cart_retrieve', 'right_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'cart_retrieve', 'right_column_width', NULL, NULL)";

				// add layout for user home pages
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'userhome_pages', 'userhome_breadcrumb', 0, 'middle')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'userhome_pages', 'userhome_main_block', 1, 'middle')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'userhome_pages', 'left_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'userhome_pages', 'left_column_width', NULL, NULL)";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'userhome_pages', 'middle_column_hide', NULL, '0')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'userhome_pages', 'middle_column_width', NULL, '100%')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'userhome_pages', 'right_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'userhome_pages', 'right_column_width', NULL, NULL)";

				// add layout for checkout login page
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'checkout_login', 'checkout_login', 0, 'middle')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'checkout_login', 'left_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'checkout_login', 'left_column_width', NULL, NULL)";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'checkout_login', 'middle_column_hide', NULL, '0')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'checkout_login', 'middle_column_width', NULL, '100%')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'checkout_login', 'right_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'checkout_login', 'right_column_width', NULL, NULL)";

				// add layout for checkout order data page
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'order_info', 'checkout_breadcrumb', 0, 'middle')";
				// show currency block on first checkout page
				$sql  = "SELECT setting_value FROM " . $table_prefix . "global_settings ";
				$sql .= "WHERE setting_type='order_info' AND setting_name='currency_block' ";
				$currency_block = get_db_value($sql);
				if ($currency_block) {
					$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'order_info', 'currency_block', 1, 'middle')";
				}
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'order_info', 'order_data_form', 2, 'middle')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'order_info', 'left_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'order_info', 'left_column_width', NULL, NULL)";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'order_info', 'middle_column_hide', NULL, '0')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'order_info', 'middle_column_width', NULL, '100%')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'order_info', 'right_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'order_info', 'right_column_width', NULL, NULL)";

				// add layout for checkout payment details page
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'order_payment_details', 'checkout_breadcrumb', 0, 'middle')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'order_payment_details', 'order_cart', 1, 'middle')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'order_payment_details', 'order_payment_details_form', 2, 'middle')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'order_payment_details', 'left_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'order_payment_details', 'left_column_width', NULL, NULL)";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'order_payment_details', 'middle_column_hide', NULL, '0')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'order_payment_details', 'middle_column_width', NULL, '100%')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'order_payment_details', 'right_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'order_payment_details', 'right_column_width', NULL, NULL)";

				// add layout for checkout confirmation page
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'order_confirmation', 'checkout_breadcrumb', 0, 'middle')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'order_confirmation', 'order_cart', 1, 'middle')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'order_confirmation', 'order_data_preview', 2, 'middle')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'order_confirmation', 'left_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'order_confirmation', 'left_column_width', NULL, NULL)";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'order_confirmation', 'middle_column_hide', NULL, '0')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'order_confirmation', 'middle_column_width', NULL, '100%')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'order_confirmation', 'right_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'order_confirmation', 'right_column_width', NULL, NULL)";

				// add layout for checkout final page
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'order_final', 'checkout_final', 0, 'middle')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'order_final', 'left_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'order_final', 'left_column_width', NULL, NULL)";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'order_final', 'middle_column_hide', NULL, '0')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'order_final', 'middle_column_width', NULL, '100%')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'order_final', 'right_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'order_final', 'right_column_width', NULL, NULL)";

				// add layout for ads compare page
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'ads_compare', 'ads_compare', 0, 'middle')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'ads_compare', 'left_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'ads_compare', 'left_column_width', NULL, NULL)";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'ads_compare', 'middle_column_hide', NULL, '0')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'ads_compare', 'middle_column_width', NULL, '100%')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'ads_compare', 'right_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'ads_compare', 'right_column_width', NULL, NULL)";

				// add layout for ads advanced search page
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'ads_search', 'ads_search_advanced', 0, 'middle')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'ads_search', 'left_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'ads_search', 'left_column_width', NULL, NULL)";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'ads_search', 'middle_column_hide', NULL, '0')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'ads_search', 'middle_column_width', NULL, '100%')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'ads_search', 'right_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'ads_search', 'right_column_width', NULL, NULL)";

				// add layout for previous polls page
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'polls_previous', 'polls_previous_list', 0, 'middle')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'polls_previous', 'left_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'polls_previous', 'left_column_width', NULL, NULL)";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'polls_previous', 'middle_column_hide', NULL, '0')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'polls_previous', 'middle_column_width', NULL, '100%')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'polls_previous', 'right_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'polls_previous', 'right_column_width', NULL, NULL)";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN parent_property_id INT(11)",
					"postgre" => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN parent_property_id INT4",
					"access"  => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN parent_property_id INTEGER ",
					"db2"     => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN parent_property_id INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN parent_value_id INT(11)",
					"postgre" => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN parent_value_id INT4",
					"access"  => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN parent_value_id INTEGER ",
					"db2"     => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN parent_value_id INTEGER"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN shipping_trade_cost DOUBLE(16,2) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN shipping_trade_cost FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN shipping_trade_cost FLOAT",
					"db2"     => "ALTER TABLE " . $table_prefix . "items ADD COLUMN shipping_trade_cost DOUBLE ",
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "filters_properties ADD COLUMN list_group_fields TEXT",
					"postgre" => "ALTER TABLE " . $table_prefix . "filters_properties ADD COLUMN list_group_fields TEXT",
					"access"  => "ALTER TABLE " . $table_prefix . "filters_properties ADD COLUMN list_group_fields LONGTEXT",
					"db2"     => "ALTER TABLE " . $table_prefix . "filters_properties ADD COLUMN list_group_fields LONG VARCHAR"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "filters_properties ADD COLUMN list_group_where TEXT",
					"postgre" => "ALTER TABLE " . $table_prefix . "filters_properties ADD COLUMN list_group_where TEXT",
					"access"  => "ALTER TABLE " . $table_prefix . "filters_properties ADD COLUMN list_group_where LONGTEXT",
					"db2"     => "ALTER TABLE " . $table_prefix . "filters_properties ADD COLUMN list_group_where LONG VARCHAR"
				);
				$sqls[] = $sql_types[$db_type];

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.3.16");
			}

			if (comp_vers("3.3.17", $current_db_version) == 1)
			{
				$sqls[] = " ALTER TABLE ". $table_prefix . "items_properties DROP COLUMN free_price_length ";
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN free_price_amount DOUBLE(16,2) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN free_price_amount FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN free_price_amount FLOAT",
					"db2"     => "ALTER TABLE " . $table_prefix . "items_properties ADD COLUMN free_price_amount DOUBLE ",
				);
				$sqls[] = $sql_types[$db_type];

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.3.17");
			}

			if (comp_vers("3.3.18", $current_db_version) == 1)
			{
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "manufacturers ADD COLUMN manufacturer_order INT(11) NOT NULL DEFAULT 1 ",
					"postgre" => "ALTER TABLE " . $table_prefix . "manufacturers ADD COLUMN manufacturer_order INT4 NOT NULL DEFAULT 1 ",
					"access"  => "ALTER TABLE " . $table_prefix . "manufacturers ADD COLUMN manufacturer_order INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "manufacturers ADD COLUMN manufacturer_order INTEGER NOT NULL DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.3.18");
			}


			if (comp_vers("3.4.3", $current_db_version) == 1)
			{
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN total_reward_credits DOUBLE(16,2) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN total_reward_credits FLOAT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN total_reward_credits FLOAT",
					"db2"     => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN total_reward_credits DOUBLE default 0",
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN reward_credits DOUBLE(16,2) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN reward_credits FLOAT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN reward_credits FLOAT",
					"db2"     => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN reward_credits DOUBLE default 0",
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN credit_reward_type TINYINT ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN credit_reward_type SMALLINT ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN credit_reward_type BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "items ADD COLUMN credit_reward_type SMALLINT "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN credit_reward_amount DOUBLE(16,2) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN credit_reward_amount FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN credit_reward_amount FLOAT",
					"db2"     => "ALTER TABLE " . $table_prefix . "items ADD COLUMN credit_reward_amount DOUBLE ",
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "item_types ADD COLUMN credit_reward_type TINYINT ",
					"postgre" => "ALTER TABLE " . $table_prefix . "item_types ADD COLUMN credit_reward_type SMALLINT ",
					"access"  => "ALTER TABLE " . $table_prefix . "item_types ADD COLUMN credit_reward_type BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "item_types ADD COLUMN credit_reward_type SMALLINT "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "item_types ADD COLUMN credit_reward_amount DOUBLE(16,2) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "item_types ADD COLUMN credit_reward_amount FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "item_types ADD COLUMN credit_reward_amount FLOAT",
					"db2"     => "ALTER TABLE " . $table_prefix . "item_types ADD COLUMN credit_reward_amount DOUBLE ",
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "users ADD COLUMN credit_reward_type TINYINT ",
					"postgre" => "ALTER TABLE " . $table_prefix . "users ADD COLUMN credit_reward_type SMALLINT ",
					"access"  => "ALTER TABLE " . $table_prefix . "users ADD COLUMN credit_reward_type BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "users ADD COLUMN credit_reward_type SMALLINT "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "users ADD COLUMN credit_reward_amount DOUBLE(16,2) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "users ADD COLUMN credit_reward_amount FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "users ADD COLUMN credit_reward_amount FLOAT",
					"db2"     => "ALTER TABLE " . $table_prefix . "users ADD COLUMN credit_reward_amount DOUBLE ",
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN credit_reward_type TINYINT ",
					"postgre" => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN credit_reward_type SMALLINT ",
					"access"  => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN credit_reward_type BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN credit_reward_type SMALLINT "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN credit_reward_amount DOUBLE(16,2) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN credit_reward_amount FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN credit_reward_amount FLOAT",
					"db2"     => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN credit_reward_amount DOUBLE ",
				);
				$sqls[] = $sql_types[$db_type];

				if ($db_type == "mysql" || $db_type == "db2" || $db_type == "postgre") {
					$sqls[] = "ALTER TABLE " . $table_prefix . "ads_items ADD COLUMN location_postcode VARCHAR(16) NOT NULL DEFAULT ''";
				} else {
					$sqls[] = "ALTER TABLE " . $table_prefix . "ads_items ADD COLUMN location_postcode VARCHAR(16) NOT NULL ";
				}
				$sqls[] = " UPDATE " . $table_prefix . "ads_items SET location_postcode='' ";
				$sqls[] = " CREATE INDEX " . $table_prefix . "ads_items_location_postcode ON " . $table_prefix . "ads_items (location_postcode) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "ads_items ADD COLUMN location_country_id INT(11) NOT NULL DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "ads_items ADD COLUMN location_country_id INT4 NOT NULL DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "ads_items ADD COLUMN location_country_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "ads_items ADD COLUMN location_country_id INTEGER NOT NULL DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "ads_items SET location_country_id=0 ";
				$sqls[] = " CREATE INDEX " . $table_prefix . "ads_items_location_country_id ON " . $table_prefix . "ads_items (location_country_id) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "ads_items ADD COLUMN location_state_id INT(11) NOT NULL DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "ads_items ADD COLUMN location_state_id INT4 NOT NULL DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "ads_items ADD COLUMN location_state_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "ads_items ADD COLUMN location_state_id INTEGER NOT NULL DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "ads_items SET location_state_id=0 ";
				$sqls[] = " CREATE INDEX " . $table_prefix . "ads_items_location_state_id ON " . $table_prefix . "ads_items (location_state_id) ";

				$countries_codes = array();
				$sql = " SELECT * FROM " . $table_prefix . "countries ";
				$db->query($sql);
				while ($db->next_record()) {
					$countries_codes[$db->f("country_code")] = $db->f("country_id");
				}

				$sql = " SELECT location_country FROM " . $table_prefix . "ads_items GROUP BY location_country ";
				$db->query($sql);
				while ($db->next_record()) {
					$location_country = $db->f("location_country");
					if ($location_country && isset($countries_codes[$location_country])) {
						$sql  = " UPDATE " . $table_prefix . "ads_items SET location_country_id=" . $db->tosql($countries_codes[$location_country], INTEGER);
						$sql .= " WHERE location_country=" . $db->tosql($location_country, TEXT);
						$sqls[] = $sql;
					}
				}

				$states_codes = array();
				$sql = " SELECT * FROM " . $table_prefix . "states ";
				$db->query($sql);
				while ($db->next_record()) {
					$states_codes[$db->f("state_code")] = $db->f("state_id");
				}

				$sql = " SELECT location_state FROM " . $table_prefix . "ads_items GROUP BY location_state ";
				$db->query($sql);
				while ($db->next_record()) {
					$location_state = $db->f("location_state");
					if ($location_state && isset($states_codes[$location_state])) {
						$sql  = " UPDATE " . $table_prefix . "ads_items SET location_state_id=" . $db->tosql($states_codes[$location_state], INTEGER);
						$sql .= " WHERE location_state=" . $db->tosql($location_state, TEXT);
						$sqls[] = $sql;
					}
				}

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.4.3");
			}

			if (comp_vers("3.4.4", $current_db_version) == 1)
			{
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "users_credits ADD COLUMN credit_type TINYINT(1) DEFAULT 0",
					"postgre" => "ALTER TABLE " . $table_prefix . "users_credits ADD COLUMN credit_type SMALLINT DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "users_credits ADD COLUMN credit_type BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "users_credits ADD COLUMN credit_type SMALLINT DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "users_credits SET credit_type=3 ";

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.4.4");
			}

			if (comp_vers("3.4.5", $current_db_version) == 1)
			{
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "users_credits ADD COLUMN order_item_id INT(11) DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "users_credits ADD COLUMN order_item_id INT4 DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "users_credits ADD COLUMN order_item_id INTEGER ",
					"db2"     => "ALTER TABLE " . $table_prefix . "users_credits ADD COLUMN order_item_id INTEGER DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "users_credits SET order_item_id=0 ";
				$sqls[] = " CREATE INDEX " . $table_prefix . "users_credits_order_item_id ON " . $table_prefix . "users_credits (order_item_id) ";

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.4.5");
			}

			if (comp_vers("3.4.6", $current_db_version) == 1)
			{
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN is_confirmed TINYINT(1) DEFAULT 0",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN is_confirmed SMALLINT DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN is_confirmed BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "orders ADD COLUMN is_confirmed SMALLINT DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "orders SET is_confirmed=is_placed  ";

				$sqls[] = "ALTER TABLE " . $table_prefix . "orders ADD COLUMN invoice_number VARCHAR(128) ";
				$sqls[] = "UPDATE " . $table_prefix . "orders SET invoice_number=order_id ";
				$sqls[] = "CREATE INDEX " . $table_prefix . "orders_invoice_number ON " . $table_prefix . "orders (invoice_number) ";
				$sqls[] = "ALTER TABLE " . $table_prefix . "orders ADD COLUMN default_currency_code VARCHAR(4) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items_images ADD COLUMN image_position TINYINT(1) DEFAULT 1",
					"postgre" => "ALTER TABLE " . $table_prefix . "items_images ADD COLUMN image_position SMALLINT DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "items_images ADD COLUMN image_position BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "items_images ADD COLUMN image_position SMALLINT DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "items_images SET image_position=1 ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items_values_assigned ADD COLUMN is_default_value TINYINT(1) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items_values_assigned ADD COLUMN is_default_value SMALLINT ",
					"access"  => "ALTER TABLE " . $table_prefix . "items_values_assigned ADD COLUMN is_default_value BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "items_values_assigned ADD COLUMN is_default_value SMALLINT "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items_properties_assigned ADD COLUMN property_description TEXT",
					"postgre" => "ALTER TABLE " . $table_prefix . "items_properties_assigned ADD COLUMN property_description TEXT",   
					"access"  => "ALTER TABLE " . $table_prefix . "items_properties_assigned ADD COLUMN property_description LONGTEXT",
					"db2"     => "ALTER TABLE " . $table_prefix . "items_properties_assigned ADD COLUMN property_description LONG VARCHAR"
				);
				$sqls[] = $sql_types[$db_type];

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.4.6");
			}

			if (comp_vers("3.4.7", $current_db_version) == 1)
			{
				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (site_id, setting_type, setting_name, setting_value) VALUES (1, 'products', 'credits_balance_user_home', '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (site_id, setting_type, setting_name, setting_value) VALUES (1, 'products', 'credits_balance_order_profile', '1')";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_points_type TINYINT ",
					"postgre" => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_points_type SMALLINT ",
					"access"  => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_points_type BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_points_type SMALLINT "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_points_amount DOUBLE(16,2) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_points_amount FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_points_amount FLOAT",
					"db2"     => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_points_amount DOUBLE ",
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_credits_type TINYINT ",
					"postgre" => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_credits_type SMALLINT ",
					"access"  => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_credits_type BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_credits_type SMALLINT "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_credits_amount DOUBLE(16,2) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_credits_amount FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_credits_amount FLOAT",
					"db2"     => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_credits_amount DOUBLE ",
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_affiliate_type TINYINT ",
					"postgre" => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_affiliate_type SMALLINT ",
					"access"  => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_affiliate_type BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_affiliate_type SMALLINT "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_affiliate_amount DOUBLE(16,2) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_affiliate_amount FLOAT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_affiliate_amount FLOAT",
					"db2"     => "ALTER TABLE " . $table_prefix . "user_types ADD COLUMN subscription_affiliate_amount DOUBLE ",
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "countries ADD COLUMN show_for_user TINYINT(1) DEFAULT 1",
					"postgre" => "ALTER TABLE " . $table_prefix . "countries ADD COLUMN show_for_user SMALLINT DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "countries ADD COLUMN show_for_user BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "countries ADD COLUMN show_for_user SMALLINT DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "countries SET show_for_user=1 ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "states ADD COLUMN show_for_user TINYINT(1) DEFAULT 1",
					"postgre" => "ALTER TABLE " . $table_prefix . "states ADD COLUMN show_for_user SMALLINT DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "states ADD COLUMN show_for_user BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "states ADD COLUMN show_for_user SMALLINT DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "states SET show_for_user=1 ";

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.4.7");
			}

			if (comp_vers("3.4.8", $current_db_version) == 1)
			{
				// add layout for product options page
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'products_options', 'products_options', 0, 'middle')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'products_options', 'left_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'products_options', 'left_column_width', NULL, NULL)";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'products_options', 'middle_column_hide', NULL, '0')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'products_options', 'middle_column_width', NULL, '100%')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'products_options', 'right_column_hide', NULL, '1')";
				$sqls[] = "INSERT INTO " . $table_prefix . "page_settings (site_id,layout_id,page_name,setting_name,setting_order,setting_value) VALUES (1, 0, 'products_options', 'right_column_width', NULL, NULL)";

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.4.8");
			}


			if (comp_vers("3.4.9", $current_db_version) == 1)
			{
				$product_quantity = get_setting_value($settings, "product_quantity", "");
				$quantity_control = get_setting_value($settings, "quantity_control", "");
				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (site_id, setting_type, setting_name, setting_value) VALUES (1, 'products', 'quantity_control_list', ".$db->tosql($product_quantity, TEXT).")";
				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (site_id, setting_type, setting_name, setting_value) VALUES (1, 'products', 'quantity_control_details', ".$db->tosql($product_quantity, TEXT).")";
				$sqls[] = "INSERT INTO " . $table_prefix . "global_settings (site_id, setting_type, setting_name, setting_value) VALUES (1, 'products', 'quantity_control_basket', ".$db->tosql($quantity_control, TEXT).")";
				$sqls[] = "DELETE FROM " . $table_prefix . "global_settings WHERE setting_name='product_quantity' OR setting_name='quantity_control' ";

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.4.9");
			}

			if (comp_vers("3.4.10", $current_db_version) == 1)
			{
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN is_shipping_free TINYINT(1) DEFAULT 0",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN is_shipping_free SMALLINT DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN is_shipping_free BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "items ADD COLUMN is_shipping_free SMALLINT DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.4.10");
			}

			if (comp_vers("3.4.11", $current_db_version) == 1)
			{
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN quantity_increment INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN quantity_increment INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN quantity_increment INTEGER ",
					"db2"     => "ALTER TABLE " . $table_prefix . "items ADD COLUMN quantity_increment INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.4.11");
			}

			if (comp_vers("3.4.12", $current_db_version) == 1)
			{
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "shipping_types  ADD COLUMN min_quantity INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "shipping_types  ADD COLUMN min_quantity INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "shipping_types  ADD COLUMN min_quantity INTEGER ",
					"db2"     => "ALTER TABLE " . $table_prefix . "shipping_types  ADD COLUMN min_quantity INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "shipping_types  ADD COLUMN max_quantity INT(11) ",
					"postgre" => "ALTER TABLE " . $table_prefix . "shipping_types  ADD COLUMN max_quantity INT4 ",
					"access"  => "ALTER TABLE " . $table_prefix . "shipping_types  ADD COLUMN max_quantity INTEGER ",
					"db2"     => "ALTER TABLE " . $table_prefix . "shipping_types  ADD COLUMN max_quantity INTEGER "
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN top_order_item_id INT(11) DEFAULT '0'",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN top_order_item_id INT4 DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN top_order_item_id INTEGER ",
					"db2"     => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN top_order_item_id INTEGER DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "orders_items SET top_order_item_id=0 ";
				$sqls[] = " CREATE INDEX " . $table_prefix . "orders_items_top ON " . $table_prefix . "orders_items (top_order_item_id) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN is_shipping_free TINYINT(1) DEFAULT 0",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN is_shipping_free SMALLINT DEFAULT '0'",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN is_shipping_free BYTE ",
					"db2"     => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN is_shipping_free SMALLINT DEFAULT 0"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN shipping_cost DOUBLE(16,2) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN shipping_cost FLOAT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN shipping_cost FLOAT",
					"db2"     => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN shipping_cost DOUBLE default 0",
				);
				$sqls[] = $sql_types[$db_type];

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.4.12");
			}


			if (comp_vers("3.4.13", $current_db_version) == 1)
			{
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "support ADD COLUMN site_id INT(11) NOT NULL DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "support ADD COLUMN site_id INT4 NOT NULL DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "support ADD COLUMN site_id INTEGER NOT NULL ",
					"db2"     => "ALTER TABLE " . $table_prefix . "support ADD COLUMN site_id INTEGER NOT NULL DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];
				$sqls[] = " UPDATE " . $table_prefix . "support SET site_id=1 ";
				$sqls[] = " CREATE INDEX " . $table_prefix . "support_site_id ON " . $table_prefix . "support (site_id) ";

				$sqls[] = "ALTER TABLE " . $table_prefix . "items_images ADD COLUMN image_super VARCHAR(255) ";

				$sqls[] = "ALTER TABLE " . $table_prefix . "countries ADD COLUMN country_code_alpha3 VARCHAR(4) ";

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.4.13");
			}

			if (comp_vers("3.4.15", $current_db_version) == 1)
			{
				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN component_order INT(11) DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN component_order INT4 DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN component_order INTEGER ",
					"db2"     => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN component_order INTEGER DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];

				$sqls[] = "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN component_name VARCHAR(255) ";

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items_properties ADD COLUMN property_order INT(11) DEFAULT '1'",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items_properties ADD COLUMN property_order INT4 DEFAULT '1'",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items_properties ADD COLUMN property_order INTEGER ",
					"db2"     => "ALTER TABLE " . $table_prefix . "orders_items_properties ADD COLUMN property_order INTEGER DEFAULT 1"
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN width DOUBLE(16,4) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN width FLOAT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN width FLOAT",
					"db2"     => "ALTER TABLE " . $table_prefix . "items ADD COLUMN width DOUBLE default 0",
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN height DOUBLE(16,4) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN height FLOAT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN height FLOAT",
					"db2"     => "ALTER TABLE " . $table_prefix . "items ADD COLUMN height DOUBLE default 0",
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "items ADD COLUMN length DOUBLE(16,4) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "items ADD COLUMN length FLOAT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "items ADD COLUMN length FLOAT",
					"db2"     => "ALTER TABLE " . $table_prefix . "items ADD COLUMN length DOUBLE default 0",
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN width DOUBLE(16,4) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN width FLOAT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN width FLOAT",
					"db2"     => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN width DOUBLE default 0",
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN height DOUBLE(16,4) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN height FLOAT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN height FLOAT",
					"db2"     => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN height DOUBLE default 0",
				);
				$sqls[] = $sql_types[$db_type];

				$sql_types = array(
					"mysql"   => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN length DOUBLE(16,4) default '0' ",
					"postgre" => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN length FLOAT4 default '0' ",
					"access"  => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN length FLOAT",
					"db2"     => "ALTER TABLE " . $table_prefix . "orders_items ADD COLUMN length DOUBLE default 0",
				);
				$sqls[] = $sql_types[$db_type];

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.4.15");
			}

			if (comp_vers("3.4.16", $current_db_version) == 1)
			{
				$sqls[] = "ALTER TABLE " . $table_prefix . "languages ADD COLUMN language_image_active VARCHAR(255) ";

				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.4.16");
			}

			if (comp_vers("3.5", $current_db_version) == 1)
			{
				run_queries($sqls, $queries_success, $queries_failed, $errors, "3.5");
			}

			set_session("session_errors", $errors);
			set_session("session_queries_failed", $queries_failed);
			set_session("session_queries_success", $queries_success);
		} else {
			$errors = get_session("session_errors");
			$queries_failed = get_session("session_queries_failed");
			$queries_success = get_session("session_queries_success");
		}

		$total_queries = $queries_failed + $queries_success;
		output_block_info($queries_failed, "queriesFailed", false);
		output_block_info($queries_success, "queriesSuccess", false);

		echo "<script language=\"JavaScript\" type=\"text/javascript\">".$eol."<!--".$eol."databaseUpgraded();".$eol."//-->".$eol."</script>".$eol;
		flush();

		$t->pparse("page_end", false);
		return;
	} 
	elseif (comp_vers(VA_RELEASE, $current_db_version) == 1) 
	{
		$r = new VA_Record("", "upgrade_available");
		$r->add_hidden("operation", TEXT);
		$r->set_form_parameters();
		$t->set_var("ct", va_timestamp());
		$t->set_var("current_version", $current_db_version);
		$t->set_var("latest_version", VA_RELEASE);
		$t->parse("upgrade_available", false);

	
	} 


	$t->parse("page_end", false);
	$t->pparse("main");

	function run_queries(&$sqls, &$queries_success, &$queries_failed, &$errors, $version_number)
	{
		global $db, $table_prefix;

		if (is_array($sqls)) {
			for ($i = 0; $i < sizeof($sqls); $i++) {
				$sql = $sqls[$i];
				$db->query($sql);
				if ($db->Error) {
					$queries_failed++;
					$errors .= $db->Error . "<br>";
					$errors .= "SQL: " . $sql . "<br>";
					output_block_info($queries_failed, "queriesFailed", false);
					output_block_info($errors, "queriesErrors", true);
				} else {
					$queries_success++;
					output_block_info($queries_success, "queriesSuccess");
				}
			}
		}
		$sqls = array(); // empty array

		// set version information in database
		$sql = "DELETE FROM " . $table_prefix . "global_settings WHERE setting_type='version' AND (setting_name='number' OR setting_name='upgraded') ";
		$db->query($sql);
		if ($db->Error) { $errors .= $db->Error . "<br>"; }
		$sql  = " INSERT INTO " . $table_prefix . "global_settings (setting_type, setting_name, setting_value) VALUES ";
		$sql .= " ('version', 'number', " . $db->tosql($version_number, TEXT) . ")";
		$db->query($sql);
		if ($db->Error) { $errors .= $db->Error . "<br>"; }
		$sql  = " INSERT INTO " . $table_prefix . "global_settings (setting_type, setting_name, setting_value) VALUES ";
		$sql .= " ('version', 'upgraded', " . $db->tosql(va_timestamp(), TEXT) . ")";
		$db->query($sql);
		if ($db->Error) { $errors .= $db->Error . "<br>"; }
	}

	function output_block_info($message, $control_name) 
	{
		global $eol;
		$message = str_replace("'", "\\'", $message);
		echo "<script language=\"JavaScript\" type=\"text/javascript\">".$eol."<!--".$eol."updateBlockInfo('".$message."','".$control_name."');".$eol."//-->".$eol."</script>".$eol;
		flush();
	}

?>