<?php
/*
  ****************************************************************************
  ***                                                                      ***
  ***      ViArt Shop 3.5                                                  ***
  ***      File:  admin_header_menus_order.php                             ***
  ***      Built: Fri Jun 20 19:43:16 2008                                 ***
  ***                                                 ***
  ***                                                                      ***
  ****************************************************************************
*/

/*
  ****************************************************************************
  ***                                                                      ***
  ***      ViArt SHOP 3.4.7                                                ***
  ***      File:  admin_header_menus_order.php                               ***
  ***      Built: Mon Mar 31 15:34:33 2008                                 ***
  ***                                                 ***
  ***                                                                      ***
  ****************************************************************************
*/


	include("./admin_config.php");
	include($root_folder_path . "includes/common.php");
	include_once("./admin_common.php");
	include($root_folder_path . "includes/record.php");

	check_admin_security("layouts");

  $t = new VA_Template($settings["admin_templates_dir"]);
  $t->set_file("main","admin_header_menus_order.html");
  $t->set_var("admin_header_menus_href", "admin_header_menus_order.php");

	$layout_id = get_param("layout_id");
	if(!$layout_id) {
		$layout_id = get_setting_value($settings, "layout_id", "");
	}
	
	$shown_header_menus = array();

	$operation = get_param("operation");
	$return_page = "admin_header_menus.php?layout_id=" . $layout_id;
	
	$sql = "SELECT layout_name FROM " . $table_prefix . "layouts WHERE layout_id=" . $db->tosql($layout_id, INTEGER);
	$db->query($sql);
	if($db->next_record()) {
		$layout_name = $db->f("layout_name");
		$t->set_var("layout_name", htmlspecialchars($layout_name));
	} else {
		header("Location: " . $return_page);
		exit;
	}

	$t->set_var("admin_layout_href", "admin_layout.php");
	$t->set_var("admin_header_menus_href", "admin_header_menus.php");

	if(strlen($operation))
	{
		if($operation == "cancel")
		{
			header("Location: " . $return_page);
			exit;
		}
		$shown_list = get_param("shown_list");
		if($shown_list) {
			$left_array = split(",", $shown_list);
			for($i = 0; $i < sizeof($left_array); $i++) {
				$shown_header_menus[] = $left_array[$i];
			}
		}

		if($operation == "save")
		{
			for($i = 0; $i < sizeof($shown_header_menus); $i++) {
				$sql  = " UPDATE " . $table_prefix . "header_links SET menu_order=" . intval($i + 1);				
				$sql .= " WHERE menu_id=" . $shown_header_menus[$i];
				$db->query($sql);
			}
			header("Location: " . $return_page);
			exit;
		}
	}
	else
	{
		$sql  = " SELECT menu_id, menu_title, menu_order ";
		$sql .= " FROM " . $table_prefix . "header_links WHERE layout_id = " . $db->tosql($layout_id, INTEGER);
		$sql .= " ORDER BY menu_order, menu_id DESC ";
		$db->query($sql);
		while($db->next_record())
		{
			$menu_id = $db->f("menu_id");
			$menu_order = $db->f("menu_order");
			$menu_title = get_translation($db->f("menu_title"), $language_code);
			$shown_header_menus[] = array($menu_id, $menu_title);
		}
	}

	set_options($shown_header_menus, "", "shown_header_menus");

	$t->set_var("errors", "");
	$t->set_var("layout_id", $layout_id);

	include("./admin_header.php");
	include("./admin_footer.php");

	$t->pparse("main");

?>