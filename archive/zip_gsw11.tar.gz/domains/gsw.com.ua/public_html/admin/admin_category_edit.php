<?php
/*
  ****************************************************************************
  ***                                                                      ***
  ***      ViArt Shop 3.5                                                  ***
  ***      File:  admin_category_edit.php                                  ***
  ***      Built: Fri Jun 20 19:43:16 2008                                 ***
  ***                                                 ***
  ***                                                                      ***
  ****************************************************************************
*/


	include_once("./admin_config.php");
	include_once($root_folder_path . "includes/common.php");
	include_once("./admin_common.php");
	include_once($root_folder_path . "includes/record.php");
	include_once($root_folder_path . "includes/shopping_cart.php");
	include_once($root_folder_path . "includes/friendly_functions.php");

	check_admin_security("products_categories");
	$permissions = get_permissions();
	$add_categories = get_setting_value($permissions, "add_categories", 0);
	$update_categories = get_setting_value($permissions, "update_categories", 0);
	$remove_categories = get_setting_value($permissions, "remove_categories", 0);

	$t = new VA_Template($settings["admin_templates_dir"]);
	$t->set_file("main", "admin_category_edit.html");

	$html_editor = get_setting_value($settings, "html_editor", 1);
	$t->set_var("html_editor", $html_editor);		

	$site_url_path = $settings["site_url"] ? $settings["site_url"] : "../";
	$t->set_var("css_file", $site_url_path . "styles/" . $settings["style_name"] . ".css");

	include_once("./admin_header.php");
	include_once("./admin_footer.php");

	$t->set_var("admin_upload_href", "admin_upload.php");
	$t->set_var("admin_category_edit_href", "admin_category_edit.php");
	$t->set_var("admin_select_href", "admin_select.php");
	$t->set_var("admin_items_list_href", "admin_items_list.php");

	$category_id = get_param("category_id");

	$r = new VA_Record($table_prefix . "categories");

	$r->add_where("category_id", INTEGER);
	$r->add_checkbox("is_showing", INTEGER);
	$r->add_textbox("category_order", INTEGER, CATEGORY_ORDER_MSG);
	$r->change_property("category_order", REQUIRED, true);
	$r->add_textbox("total_views", INTEGER);
	$r->change_property("total_views", USE_IN_INSERT, false);
	$r->change_property("total_views", USE_IN_UPDATE, false);
	$r->add_textbox("category_name", TEXT, CATEGORY_NAME_MSG);
	$r->change_property("category_name", REQUIRED, true);
	$r->add_textbox("friendly_url", TEXT, FRIENDLY_URL_MSG);
	$r->change_property("friendly_url", USE_SQL_NULL, false);
	$r->change_property("friendly_url", BEFORE_VALIDATE, "validate_friendly_url");
	$r->add_textbox("short_description", TEXT);
	$r->add_textbox("full_description", TEXT);
	$r->add_checkbox("show_sub_products", INTEGER);
	$r->add_checkbox("allowed_post", INTEGER);
	$r->add_checkbox("allowed_post_subcategories", INTEGER);
	$r->add_textbox("image", TEXT);
	$r->add_textbox("image_alt", TEXT);
	$r->add_textbox("image_large", TEXT);
	$r->add_textbox("image_large_alt", TEXT);

	//-- parent items
	$sql  = " SELECT * FROM " . $table_prefix . "categories ";
	$sql .= " ORDER BY category_path, category_order ";
	$db->query($sql);
	while ($db->next_record()) {
		$list_id = $db->f("category_id");
		$list_parent_id = $db->f("parent_category_id");
		$list_title = get_translation($db->f("category_name"));

		$category_values = array(
			"category_name" => $list_title, "category_path" => $db->f("category_path")
		);
		$categories[$list_id] = $category_values;
		$categories[$list_parent_id]["subs"][] = $list_id;
		$parent_categories[$list_id] = $list_parent_id;
	}

	$items = array();
	$items[] = array(0, "[Top]");
	build_category_list(0);

	$r->add_select("parent_category_id", INTEGER, $items, PARENT_CATEGORY_MSG);
	$r->change_property("parent_category_id", REQUIRED, true);

	$r->add_textbox("category_path", TEXT);

	// templates settings
	$r->add_textbox("list_template", TEXT);
	$r->add_textbox("details_template", TEXT);

    //page title

    $r->add_textbox("page_title", TEXT);

	// meta data
	$r->add_textbox("meta_title", TEXT);
	$r->add_textbox("meta_keywords", TEXT);
	$r->add_textbox("meta_description", TEXT);

	// editing information
	$r->add_textbox("admin_id_added_by", INTEGER);
	$r->change_property("admin_id_added_by", USE_IN_UPDATE, false);
	$r->add_textbox("admin_id_modified_by", INTEGER);
	$r->add_textbox("date_added", DATETIME);
	$r->change_property("date_added", USE_IN_UPDATE, false);
	$r->add_textbox("date_modified", DATETIME);

	$google_base_product_types = get_db_values("SELECT type_id, type_name FROM " . $table_prefix . "google_base_types ORDER BY type_name", array(array(-1, NOT_EXPORTED_MSG), array(0, USE_GLOBAL_MSG)));
	$r->add_select("google_base_type_id", INTEGER, $google_base_product_types);
		
	$r->add_checkbox("allowed_post_types_all", INTEGER);
	$r->add_checkbox("user_types_all", INTEGER);
	$r->add_checkbox("sites_all", INTEGER);

	$r->get_form_values();

	if(!strlen($r->get_value("parent_category_id"))) $r->set_value("parent_category_id", "0");
	$parent_category_id = $r->get_value("parent_category_id");

	$tree = new VA_Tree("category_id", "category_name", "parent_category_id", $table_prefix . "categories", "tree");
	$tree->show($parent_category_id);

	$operation = get_param("operation");
	$tab = get_param("tab");
	if (!$tab) { $tab = "general"; }
	$return_page = "admin_items_list.php?category_id=" . $parent_category_id;

	$selected_user_types = array();
	if (strlen($operation)) {
		$user_types = get_param("user_types");
		if ($user_types) {
			$selected_user_types = split(",", $user_types);
		}
	} elseif ($category_id) {
		$sql  = "SELECT user_type_id FROM " . $table_prefix . "categories_user_types ";
		$sql .= " WHERE category_id=" . $db->tosql($category_id, INTEGER);
		$db->query($sql);
		while ($db->next_record()) {
			$selected_user_types[] = $db->f("user_type_id");
		}
	}

	$selected_allowed_post_types = array();
	if (strlen($operation)) {
		$allowed_post_types = get_param("allowed_post_types");
		if ($allowed_post_types) {
			$selected_allowed_post_types = split(",", $allowed_post_types);
		}
	} elseif ($category_id) {
		$sql  = "SELECT user_type_id FROM " . $table_prefix . "categories_post_types ";
		$sql .= " WHERE category_id=" . $db->tosql($category_id, INTEGER);
		$db->query($sql);
		while ($db->next_record()) {
			$selected_allowed_post_types[] = $db->f("user_type_id");
		}
	}

	if ($sitelist) {
		$selected_sites = array();
		if (strlen($operation)) {
			$sites = get_param("sites");
			if ($sites) {
				$selected_sites = split(",", $sites);
			}
		} elseif ($category_id) {
			$sql  = " SELECT site_id FROM " . $table_prefix . "categories_sites ";
			$sql .= " WHERE category_id=" . $db->tosql($category_id, INTEGER);
			$db->query($sql);
			while ($db->next_record()) {
				$selected_sites[] = $db->f("site_id");
			}
		}
	}

	if (strlen($operation))
	{
		$tree = new VA_Tree("category_id", "category_name", "parent_category_id", $table_prefix . "categories", "");

		if ($operation == "cancel")
		{
			header("Location: " . $return_page);
			exit;
		}
		elseif ($operation == "delete" && $r->get_value("category_id"))
		{
			delete_categories($category_id);

			header("Location: " . $return_page);
			exit;
		}

		$is_valid = $r->validate();

		if ($is_valid)
		{
			// build path for current category
			$category_path = "";
			$category_id = $r->get_value("category_id");
			$parent_category_id = $r->get_value("parent_category_id");
			if ($category_id) {
				$parent_categories[$category_id] = $parent_category_id;
				if ($parent_category_id == $category_id) {
					$parent_category_id = 0;
				}
			}
			$current_parent_id = $parent_category_id;
			while ($current_parent_id) {
				$category_path = $current_parent_id.",".$category_path;
				$parent_id = isset($parent_categories[$current_parent_id]) ? $parent_categories[$current_parent_id] : 0;
				if ($parent_id == $current_parent_id) {
					$current_parent_id = 0;
				} else {
					$current_parent_id = $parent_id;
				}
			}
			$category_path = "0,".$category_path;

			$r->set_value("admin_id_added_by", get_session("session_admin_id"));
			$r->set_value("admin_id_modified_by", get_session("session_admin_id"));
			$r->set_value("date_added", va_time());
			$r->set_value("date_modified", va_time());
			$r->set_value("category_path", $category_path);
			$r->set_value("parent_category_id", $parent_category_id);
			if (!$sitelist) {
				$r->set_value("sites_all", 1);
			}

			if (strlen($r->get_value("category_id")))
			{
				set_friendly_url();
				$record_updated = $r->update_record();
				update_category_tree($category_id, $category_path);
			}
			else
			{
				set_friendly_url();
				$db->query("SELECT MAX(category_id) FROM " . $table_prefix . "categories");
				$db->next_record();
				$category_id = $db->f(0) + 1;
				$r->set_value("category_id", $category_id);
				$record_updated = $r->insert_record();
			}

			$nested_categories = array();
			$nested_categories_inline = '';			
			if (get_param('save_nested_user_types') || get_param('save_nested_post_types') || get_param('save_nested_sites')
				|| get_param('save_products_user_types') || get_param('save_nested_products_user_types')
				|| get_param('save_products_sites') || get_param('save_nested_products_sites')) 
			{
				recursive_build_nested_categories($category_id, 50);			
				if (get_param('save_products_user_types') || get_param('save_nested_products_user_types')
					|| get_param('save_products_sites') || get_param('save_nested_products_sites')) 
				{
					foreach ($nested_categories AS $nesteds) {
						if ($nesteds) {
							$nested_categories_inline = ',' . implode(',', $nesteds);
						}
					}
				}
			}

			// update users types
			$user_types_all = $r->get_value('user_types_all');			
			if (get_param('save_nested_user_types')) {		
				recursive_save_user_types($category_id, 50);
			} else {
				recursive_save_user_types($category_id, 0);
			}
			//nested products
			if ( get_param('save_products_user_types') || ($nested_categories_inline && get_param('save_nested_products_user_types'))) {
				$sql  = " SELECT item_id ";
				$sql .= " FROM " . $table_prefix . "items_categories ";
				if ($nested_categories_inline) {
					if (get_param('save_nested_products_user_types')) {						
						if (get_param('save_products_user_types')) {
							$sql .= " WHERE category_id IN (" . $category_id . $nested_categories_inline . ")" ;											
						} else {
							$sql .= " WHERE category_id IN (" . substr($nested_categories_inline, 1) . ")" ;
						}
					} else {						
						$sql .= "WHERE category_id=" . $category_id;
					}
				} else {
					if (get_param('save_products_user_types')) {						
						$sql .= "WHERE category_id=" . $category_id;
					}
				}
				$sql .= " GROUP BY item_id ";
				$db->query($sql);
				$item_ids = array();
				while ($db->next_record()) {
					$item_ids[] = $db->f('item_id');					
				}
				for ($i=0; $i<sizeof($item_ids); $i++) {
					$item_id = $item_ids[$i];
					$db->query("UPDATE " . $table_prefix . "items SET user_types_all= " . $db->tosql($user_types_all, INTEGER, true, false) . " WHERE item_id=" . $db->tosql($item_id, INTEGER));
					$db->query("DELETE FROM " . $table_prefix . "items_user_types WHERE item_id=" . $db->tosql($item_id, INTEGER));
					for ($ut = 0; $ut < sizeof($selected_user_types); $ut++) {
						$user_type_id = $selected_user_types[$ut];
						if (strlen($user_type_id)) {
							$sql  = " INSERT INTO " . $table_prefix . "items_user_types (item_id, user_type_id) VALUES (";
							$sql .= $db->tosql($item_id, INTEGER, true, false) . ", ";
							$sql .= $db->tosql($user_type_id, INTEGER, true, false) . ") ";
							$db->query($sql);
						}
					}
				}
			}

			// update post users types
			$allowed_post_types_all = $r->get_value('allowed_post_types_all');
			if (get_param('save_nested_post_types')) {		
				recursive_save_post_types($category_id, 50);
			} else {
				recursive_save_post_types($category_id, 0);
			}
			
			// update sites
			if ($sitelist) {
				$sites_all = $r->get_value("sites_all");
				if (get_param('save_nested_sites')) {		
					recursive_save_sites($category_id, 50);
				} else {
					recursive_save_sites($category_id, 0);
				}
				//nested products
				if (get_param('save_products_sites') || ($nested_categories_inline && get_param('save_nested_products_sites'))) {
					$sql  = " SELECT item_id ";
					$sql .= " FROM " . $table_prefix . "items_categories ";
					if ($nested_categories_inline) {
						if (get_param('save_nested_products_sites')) {						
							if (get_param('save_nested_products_sites')) {
								$sql .= " WHERE category_id IN (" . $category_id . $nested_categories_inline . ")" ;											
							} else {
								$sql .= " WHERE category_id IN (" . substr($nested_categories_inline, 1) . ")" ;
							}
						} else {						
							$sql .= "WHERE category_id=" . $category_id;
						}
					} else {
						if (get_param('save_products_sites')) {						
							$sql .= "WHERE category_id=" . $category_id;
						}
					}
					$sql .= " GROUP BY item_id ";
					$db->query($sql);
					$item_ids = array();
					while ($db->next_record()) {
						$item_ids[] = $db->f('item_id');					
					}
					for ($i=0; $i<sizeof($item_ids); $i++) {
						$item_id = $item_ids[$i];
						$db->query("UPDATE " . $table_prefix . "items SET sites_all= " . $db->tosql($sites_all, INTEGER, true, false) . " WHERE item_id=" . $db->tosql($item_id, INTEGER));
						$db->query("DELETE FROM " . $table_prefix . "items_sites WHERE item_id=" . $db->tosql($item_id, INTEGER));
						for ($st = 0; $st < sizeof($selected_sites); $st++) {
							$selected_site_id = $selected_sites[$st];
							if (strlen($selected_site_id)) {
								$sql  = " INSERT INTO " . $table_prefix . "items_sites (item_id, site_id) VALUES (";
								$sql .= $db->tosql($item_id, INTEGER, true, false) . ", ";
								$sql .= $db->tosql($selected_site_id, INTEGER, true, false) . ") ";
								$db->query($sql);
							}
						}
					}
				}								
			}			
			
			if ($record_updated) {
				header("Location: " . $return_page);
				exit;
			}
		}
	} elseif (strlen($r->get_value("category_id")))	{
		$r->get_db_values();
	} else {
		$category_order = get_db_value("SELECT MAX(category_order) FROM " . $table_prefix . "categories WHERE parent_category_id=" . $db->tosql($parent_category_id, INTEGER));
		$category_order++;
		$r->set_value("is_showing", 1);
		$r->set_value("category_order", $category_order);
		$r->set_value("allowed_post_types_all", 1);
		$r->set_value("user_types_all", 1);
		$r->set_value("sites_all", 1);
	}

	$r->set_parameters();


	$user_types = array();
	$sql = " SELECT type_id, type_name FROM " . $table_prefix . "user_types ";
	$db->query($sql);
	while ($db->next_record())	{
		$type_id = $db->f("type_id");
		$type_name = get_translation($db->f("type_name"));
		$user_types[$type_id] = $type_name;
	}

	foreach ($user_types as $type_id => $type_name) {
		$t->set_var("type_id", $type_id);
		$t->set_var("type_name", $type_name);
		if (in_array($type_id, $selected_user_types)) {
			$t->parse("selected_user_types", true);
		} else {
			$t->parse("available_user_types", true);
		}
		if (in_array($type_id, $selected_allowed_post_types)) {
			$t->parse("selected_allowed_post_types", true);
		} else {
			$t->parse("available_allowed_post_types", true);
		}
	}


	if ($sitelist) {
		$sites = array();
		$sql = " SELECT site_id, site_name FROM " . $table_prefix . "sites ";
		$db->query($sql);
		while ($db->next_record())	{
			$site_id   = $db->f("site_id");
			$site_name = get_translation($db->f("site_name"));
			$sites[$site_id] = $site_name;
			$t->set_var("site_id", $site_id);
			$t->set_var("site_name", $site_name);
			if (in_array($site_id, $selected_sites)) {
				$t->parse("selected_sites", true);
			} else {
				$t->parse("available_sites", true);
			}
		}
	}

	if (strlen($category_id)) {
		if ($update_categories) {
			$t->set_var("save_button", UPDATE_BUTTON);
			$t->parse("save", false);
		}
		if ($remove_categories) {
			$t->parse("delete", false);
		}
	}	else {
		if ($add_categories) {
			$t->set_var("save_button", ADD_BUTTON);
			$t->parse("save", false);
		}
		$t->set_var("delete", "");
	}

	$tabs = array("general" => EDIT_CATEGORY_MSG, "user_types" => USERS_TYPES_MSG, "allowed_post_types" => POST_TYPES_MSG);
	if ($sitelist) {
		$tabs["sites"] = 'Sites';
	}
	foreach ($tabs as $tab_name => $tab_title) {
		$t->set_var("tab_id", "tab_" . $tab_name);
		$t->set_var("tab_name", $tab_name);
		$t->set_var("tab_title", $tab_title);
		if ($tab_name == $tab) {
			$t->set_var("tab_class", "adminTabActive");
			$t->set_var($tab_name . "_style", "display: block;");
		} else {
			$t->set_var("tab_class", "adminTab");
			$t->set_var($tab_name . "_style", "display: none;");
		}
		$t->parse("tabs", $tab_title);
	}
	$t->set_var("tab", $tab);

	if ($sitelist) {
		$t->parse('sitelist');
	}

	$t->pparse("main");

	function spaces_level($level)
	{
		$spaces = "";
		for ($i =1; $i <= $level; $i++) {
			$spaces .= "--";
		}
		return $spaces . " ";
	}
	
	
	function update_category_tree($parent_category_id, $category_path)
	{
		global $db, $table_prefix, $categories, $parent_categories;
	
		if (isset($categories[$parent_category_id]["subs"])) {
			$category_path .= $parent_category_id . ",";
	
			$subs = $categories[$parent_category_id]["subs"];
			for ($s = 0; $s < sizeof($subs); $s++) {
				$sub_id = $subs[$s];
	
				$sql  = " UPDATE " . $table_prefix . "categories SET ";
				$sql .= " category_path=" . $db->tosql($category_path, TEXT);
				$sql .= " WHERE category_id=" . $db->tosql($sub_id, INTEGER);
				$db->query($sql);
	
				if (isset($categories[$sub_id]["subs"])) {
					update_category_tree($sub_id, $category_path);
				}
			}
		}
	}
	
	function build_category_list($parent_id) 
	{
		global $t, $categories, $items;
		$subs = $categories[$parent_id]["subs"];
		for ($m = 0; $m < sizeof($subs); $m++) {
			$category_id = $subs[$m];
			$category_path = $categories[$category_id]["category_path"];
			$category_name = $categories[$category_id]["category_name"];
			$category_level = preg_replace("/\d/", "", $category_path);
			$spaces = spaces_level(strlen($category_level));
	
			$items[] = array($category_id, $spaces.$category_name);
	
			if (isset($categories[$category_id]["subs"])) {
				build_category_list($category_id);
			}
		}
	}
	
	function recursive_save_user_types($category_id, $stop_level = 5, $level = 0) 
	{
		global $db, $table_prefix;
		global $selected_user_types, $user_types_all;
		global $nested_categories;
		$db->query("DELETE FROM " . $table_prefix . "categories_user_types WHERE category_id=" . $db->tosql($category_id, INTEGER));
		for ($ut = 0; $ut < sizeof( $selected_user_types); $ut++) {
			$type_id =  $selected_user_types[$ut];
			if (strlen($type_id)) {
				$sql  = " INSERT INTO " . $table_prefix . "categories_user_types (category_id, user_type_id) VALUES (";
				$sql .= $db->tosql($category_id, INTEGER) . ", ";
				$sql .= $db->tosql($type_id, INTEGER) . ") ";
				$db->query($sql);
			}
		}
				
		if ($level < $stop_level) {
			$db->query("UPDATE " . $table_prefix . "categories SET user_types_all= " . $db->tosql($user_types_all, INTEGER, true, false) . " WHERE parent_category_id=" . $db->tosql($category_id, INTEGER));
			if ($nested_categories[$category_id]) {
				for ($i=0, $count=count($nested_categories[$category_id]); $i<$count; $i++) {
					recursive_save_user_types($nested_categories[$category_id][$i], $stop_level, $level+1);
				}
			}
		}		
	}
	
	function recursive_save_post_types($category_id, $stop_level = 5, $level = 0) 
	{
		global $db, $table_prefix;
		global $selected_allowed_post_types, $user_post_all;
		global $nested_categories;
			
		$db->query("DELETE FROM " . $table_prefix . "categories_post_types WHERE category_id=" . $db->tosql($category_id, INTEGER));
		for ($ut = 0; $ut < sizeof($selected_allowed_post_types); $ut++) {
			$type_id = $selected_allowed_post_types[$ut];
			if (strlen($type_id)) {
				$sql  = " INSERT INTO " . $table_prefix . "categories_post_types (category_id, user_type_id) VALUES (";
				$sql .= $db->tosql($category_id, INTEGER) . ", ";
				$sql .= $db->tosql($type_id, INTEGER) . ") ";
				$db->query($sql);
			}
		}
			
		if ($level < $stop_level) {
			$db->query("UPDATE " . $table_prefix . "categories SET user_types_all= " . $db->tosql($user_post_all, INTEGER, true, false) . " WHERE parent_category_id=" . $db->tosql($category_id, INTEGER));
			if ($nested_categories[$category_id]) {
				for ($i=0, $count=count($nested_categories[$category_id]); $i<$count; $i++) {
					recursive_save_user_types($nested_categories[$category_id][$i], $stop_level, $level+1);
				}
			}
		}		
	}
		
	function recursive_save_sites($category_id,  $stop_level = 5, $level = 0) 
	{
		global $db, $table_prefix;
		global $selected_sites, $sites_all;
		global $nested_categories;
			
		$db->query("DELETE FROM " . $table_prefix . "categories_sites WHERE category_id=" . $db->tosql($category_id, INTEGER));
		for ($st = 0; $st < sizeof($selected_sites); $st++) {
			$selected_site_id = $selected_sites[$st];
			if (strlen($selected_site_id)) {
				$sql  = " INSERT INTO " . $table_prefix . "categories_sites (category_id, site_id) VALUES (";
				$sql .= $db->tosql($category_id, INTEGER, true, false) . ", ";
				$sql .= $db->tosql($selected_site_id, INTEGER, true, false) . ") ";
				$db->query($sql);
			}
		}
			
		if ($level < $stop_level) {
			$db->query("UPDATE " . $table_prefix . "categories SET sites_all= " . $db->tosql($sites_all, INTEGER, true, false) . " WHERE parent_category_id=" . $db->tosql($category_id, INTEGER));
			if ($nested_categories[$category_id]) {
				for ($i=0, $count=count($nested_categories[$category_id]); $i<$count; $i++) {
					recursive_save_sites($nested_categories[$category_id][$i], $stop_level, $level+1);
				}
			}			
		}		
	}
	
	function recursive_build_nested_categories($category_id,  $stop_level = 5, $level = 0) 
	{
		global $db, $table_prefix;
		global $nested_categories;	
			
		if ($level < $stop_level) {
			if (!isset($nested_categories[$category_id])) {
				$db->query("SELECT category_id FROM " . $table_prefix . "categories WHERE parent_category_id=" . $db->tosql($category_id, INTEGER));
				$nested_categories[$category_id] = array();
				while ($db->next_record()) {
					$nested_categories[$category_id][] = $db->f('category_id');
				}
			}
			if ($nested_categories[$category_id]) {
				for ($i=0, $count=count($nested_categories[$category_id]); $i<$count; $i++) {
					recursive_build_nested_categories($nested_categories[$category_id][$i], $stop_level, $level+1);
				}
			}	
		}		
	}

?>