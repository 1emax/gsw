<?php
/*
  ****************************************************************************
  ***                                                                      ***
  ***      ViArt Shop 3.5                                                  ***
  ***      File:  admin_manual_category.php                                ***
  ***      Built: Fri Jun 20 19:43:16 2008                                 ***
  ***                                                 ***
  ***                                                                      ***
  ****************************************************************************
*/


	include_once ("./admin_config.php");
	include_once ($root_folder_path . "includes/common.php");
	include_once ($root_folder_path . "includes/record.php");
	include_once ($root_folder_path . "includes/friendly_functions.php");
	include_once($root_folder_path . "messages/".$language_code."/manuals_messages.php");

	include_once("./admin_common.php");

	check_admin_security("manual");
	
	$return_page = "admin_manual.php";
	$operation = get_param("operation");
	$tab = get_param("tab");
	if (!$tab) { $tab = "general"; }

 	$t = new VA_Template($settings["admin_templates_dir"]);
 	$t->set_file("main", "admin_manual_category.html");

	$t->set_var("admin_manual_href", "admin_manual.php");
	$t->set_var("admin_manual_category_href", "admin_manual_category.php");

	$category_id = get_param("category_id");

	$r = new VA_Record($table_prefix . "manuals_categories");
	$r->return_page = $return_page;
	
	$r->set_event(BEFORE_INSERT, "set_db_values_before_changes");
	$r->set_event(BEFORE_UPDATE, "set_db_values_before_changes");
	
	$r->add_where("category_id", INTEGER);
	$r->add_textbox("category_name", TEXT, CATEGORY_NAME_MSG);
	$r->change_property("category_name", REQUIRED, true);
	$r->change_property("category_name", MAX_LENGTH, 255);
	$r->add_textbox("friendly_url", TEXT, FRIENDLY_URL_MSG);
	$r->change_property("friendly_url", USE_SQL_NULL, false);
	$r->change_property("friendly_url", BEFORE_VALIDATE, "validate_friendly_url");
	
	// Get orders of categories
	$orders = array();
	$sql = "SELECT * FROM ".$table_prefix."manuals_categories ";
	$sql .= " ORDER BY category_order";
	
	$db->query($sql);
	$i = 0;
	$order = 0;
	while ($db->next_record()) {
		$order = $db->f("category_order");
		$orders[] = array($order, ++$i);
	}
	if ($category_id == "") {
		$orders[] = array(++$order, ++$i);
	}
	
	$r->add_select("category_order", INTEGER, $orders, CATEGORY_ORDER_MSG);
	$r->change_property("category_order", REQUIRED, true);
	if ($category_id == "") {
		$r->set_value("category_order", $order);
	}
	// --------------------------
	
	$r->add_textbox("meta_title", TEXT, META_TITLE_MSG);
	$r->change_property("meta_title", MAX_LENGTH, 255);
	
	$r->add_textbox("meta_keywords", TEXT, ADMIN_META_KEYWORD_MSG);
	$r->change_property("meta_keywords", MAX_LENGTH, 255);
	
	$r->add_textbox("meta_description", TEXT, META_DESCRIPTION_MSG);
	$r->change_property("meta_description", MAX_LENGTH, 255);
	
	$r->add_textbox("admin_id_added_by", INTEGER, ADMIN_ID_ADDED_BY_MSG);
	$r->change_property("admin_id_added_by", USE_IN_INSERT, true);
	$r->change_property("admin_id_added_by", USE_IN_UPDATE, false);
	
	$r->add_textbox("admin_id_modified_by", INTEGER, ADMIN_ID_MODIFIED_BY_MSG);
	$r->change_property("admin_id_modified_by", USE_IN_INSERT, true);
	$r->change_property("admin_id_modified_by", USE_IN_UPDATE, true);

	$r->add_textbox("date_added", DATETIME, MODIFICATION_DATE_MSG);
	$r->change_property("date_added", USE_IN_INSERT, true);
	$r->change_property("date_added", USE_IN_UPDATE, false);
	
	$r->add_textbox("date_modified", DATETIME, MODIFICATION_DATE_MSG);
	$r->change_property("date_modified", USE_IN_INSERT, true);
	$r->change_property("date_modified", USE_IN_UPDATE, true);

	$allowed_values = array(array("0", NOBODY_MSG), array("1", FOR_ALL_USERS_MSG));
	$r->add_radio("allowed_view", INTEGER, $allowed_values, ALLOW_VIEW_MSG);
	$r->change_property("allowed_view", DEFAULT_VALUE, 1);
	$r->add_checkbox("sites_all", INTEGER);
	$r->change_property("sites_all", DEFAULT_VALUE, 1);

	$r->add_textbox("short_description", TEXT);
	$r->add_textbox("full_description", TEXT);

	$r->set_event(AFTER_REQUEST, "set_manual_category_data");
	
	if ($sitelist) {
		$selected_sites = array();
		if (strlen($operation)) {
			$sites = get_param("sites");
			if ($sites) {
				$selected_sites = split(",", $sites);
			}
		} elseif ($category_id) {
			$sql  = "SELECT site_id FROM " . $table_prefix . "manuals_categories_sites ";
			$sql .= " WHERE category_id=" . $db->tosql($category_id, INTEGER);
			$db->query($sql);
			while ($db->next_record()) {
				$selected_sites[] = $db->f("site_id");
			}
		}
	}

	
	$r->set_event(BEFORE_DELETE, "actions_before_delete_category");
	$r->set_event(BEFORE_SHOW,   "set_values_before_show");
	$r->set_event(AFTER_UPDATE,  "save_other_values_after_save");
	$r->set_event(AFTER_INSERT,  "save_other_values_after_save");
	
	$r->process();

	if ($sitelist) {
		$sites = array();
		$sql = " SELECT site_id, site_name FROM " . $table_prefix . "sites ";
		$db->query($sql);
		while ($db->next_record())	{
			$site_id   = $db->f("site_id");
			$site_name = $db->f("site_name");
			$sites[$site_id] = $site_name;
			$t->set_var("site_id", $site_id);
			$t->set_var("site_name", $site_name);
			if (in_array($site_id, $selected_sites)) {
				$t->parse("selected_sites", true);
			} else {
				$t->parse("available_sites", true);
			}
		}
	}

	$tabs = array("general" => EDIT_CATEGORY_MSG);
	if ($sitelist) {
		$tabs["sites"] = ADMIN_SITES_MSG;
	}
	foreach ($tabs as $tab_name => $tab_title) {
		$t->set_var("tab_id", "tab_" . $tab_name);
		$t->set_var("tab_name", $tab_name);
		$t->set_var("tab_title", $tab_title);
		if ($tab_name == $tab) {
			$t->set_var("tab_class", "adminTabActive");
			$t->set_var($tab_name . "_style", "display: block;");
		} else {
			$t->set_var("tab_class", "adminTab");
			$t->set_var($tab_name . "_style", "display: none;");
		}
		$t->parse("tabs", $tab_title);
	}
	$t->set_var("tab", $tab);
	
	if ($sitelist) {
		$t->parse("sitelist");
	}
	
	include_once("./admin_header.php");
	include_once("./admin_footer.php");

	$t->pparse("main");
	
	function set_db_values_before_changes() {
		global $r;
		global $table_prefix;
		global $db;
		global $category_id;
		
		$admin_id = get_session("session_admin_id");
		$r->set_value("admin_id_modified_by", $admin_id);
		$r->set_value("admin_id_added_by", $admin_id);
		$r->set_value("date_modified", va_time());
		$r->set_value("date_added", va_time());
		
		$selected_order = $r->get_value("category_order");
		$saved_order = get_param("saved_category_order");
		
		if ($saved_order == 0 || $saved_order != $selected_order) {
			// Increase menu_order of selected item and all other, which have
			// menu_item_order greater than selected and the same parent_id
			if ($saved_order > $selected_order || $saved_order == 0) {
				$increase_order_sql = "UPDATE ".$table_prefix."manuals_categories ";
				$increase_order_sql .= "SET category_order = category_order + 1 ";
				$increase_order_sql .= "WHERE ";
				$increase_order_sql .= "category_order >=".$db->tosql($selected_order, INTEGER);
				$r->set_value("category_order", $selected_order);
			} else {
				$increase_order_sql = "UPDATE ".$table_prefix."manuals_categories ";
				$increase_order_sql .= "SET category_order = category_order + 2 ";
				$increase_order_sql .= "WHERE ";
				$increase_order_sql .= "category_order >".$db->tosql($selected_order, INTEGER);
				$r->set_value("category_order", $selected_order + 1);
			}
			$db->query($increase_order_sql);
		}
		if (!$category_id) {
			$db->query("SELECT MAX(category_id) FROM " . $table_prefix . "manuals_categories");
			$db->next_record();
			$category_id = $db->f(0) + 1;
			$r->set_value("category_id", $category_id);		
		}	
	}
	function save_other_values_after_save() {
		global $db, $category_id, $table_prefix, $sitelist, $selected_sites;
		// update sites
		if ($sitelist) {
			$db->query("DELETE FROM " . $table_prefix . "manuals_categories_sites WHERE category_id=" . $db->tosql($category_id, INTEGER));
			for ($st = 0; $st < sizeof($selected_sites); $st++) {
				$site_id = $selected_sites[$st];
				if (strlen($site_id)) {
					$sql  = " INSERT INTO " . $table_prefix . "manuals_categories_sites (category_id, site_id) VALUES (";
					$sql .= $db->tosql($category_id, INTEGER) . ", ";
					$sql .= $db->tosql($site_id, INTEGER) . ") ";
					$db->query($sql);
				}
			}
		}	
	}
	
	/**
	 * Function remove manuals and its articles, before category removing
	 *
	 */
	function actions_before_delete_category() {
		global $db, $category_id, $table_prefix;
		// Get manuals of the category
		$sql = "SELECT manual_id FROM ". $table_prefix."manuals_list WHERE category_id = " . $db->tosql($category_id, INTEGER);
		$db->query($sql);
		$manuals = array();
		if ($db->next_record()) {
			$where_arr = array();
			do {
				$manual_id = $db->f("manual_id");
				$where_arr[] = "manual_id = " . $db->tosql($manual_id, INTEGER);
			} while ($db->next_record());
			
			// Remove articles

			if (!empty($where_arr)) {
				$sql = "DELETE FROM " . $table_prefix . "manuals_articles WHERE " . implode(" AND ", $where_arr);
				$db->query($sql);
				//$sql = "DELETE FROM " . $table_prefix . "manuals_list WHERE " . implode(" AND ", $where_arr);
				//$db->query($sql);
			}
		}
		// remove sites
		$db->query("DELETE FROM " . $table_prefix . "manuals_categories_sites WHERE category_id=" . $db->tosql($category_id, INTEGER));
		
		$sql = "DELETE FROM " . $table_prefix . "manuals_list WHERE category_id=".$db->tosql($category_id, INTEGER);	
		$db->query($sql);
		
	}
	
	/**
	 * Function calls before form showing.
	 * Assignes additional parameters
	 *
	 */
	function set_values_before_show() {
		global $r;
		global $t;

		$t->set_var("saved_category_order", $r->get_value("category_order"));
	}

	function set_manual_category_data()  
	{
		global $r, $sitelist;
		if (!$sitelist) {
			$r->set_value("sites_all", 1);
		}
	}

?>