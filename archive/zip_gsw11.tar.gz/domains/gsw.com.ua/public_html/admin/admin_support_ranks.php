<?php
/*
  ****************************************************************************
  ***                                                                      ***
  ***      ViArt Shop 3.5                                                  ***
  ***      File:  admin_support_ranks.php                                  ***
  ***      Built: Fri Jun 20 19:43:16 2008                                 ***
  ***                                                 ***
  ***                                                                      ***
  ****************************************************************************
*/


	include_once("./admin_config.php");
	include_once($root_folder_path."includes/common.php");
	include_once($root_folder_path . "includes/sorter.php");
	include_once($root_folder_path . "includes/navigator.php");

	include_once($root_folder_path."messages/".$language_code."/support_messages.php");
	include_once("./admin_common.php");

	check_admin_security("support_users_priorities");

  $t = new VA_Template($settings["admin_templates_dir"]);
  $t->set_file("main","admin_support_ranks.html");

	$t->set_var("admin_support_href", "admin_support.php");
	$t->set_var("admin_support_rank_href",  "admin_support_rank.php");
	$t->set_var("admin_support_ranks_href", "admin_support_ranks.php");

	$s = new VA_Sorter($settings["admin_templates_dir"], "sorter_img.html", "admin_support_ranks.php");
	$s->set_sorter(ID_MSG, "sorter_user_priority_id", "1", "sup.user_priority_id");
	$s->set_sorter(USER_NAME_MSG, "sorter_user_name", "2", "u.name, u.first_name, u.last_name, u.login");
	$s->set_sorter(CUSTOMER_EMAIL_MSG, "sorter_user_email", "3", "sup.user_email");
	$s->set_sorter(PRIORITY_MSG, "sorter_priority_name", "4", "sp.priority_name");
	$s->set_sorter(EXPIRY_DATE_MSG, "sorter_priority_expiry", "5", "sp.priority_expiry");

	$n = new VA_Navigator($settings["admin_templates_dir"], "navigator.html", "admin_support_ranks.php");

	include_once("./admin_header.php");
	include_once("./admin_footer.php");

	// set up variables for navigator
	$db->query("SELECT COUNT(*) FROM " . $table_prefix . "support_users_priorities");
	$db->next_record();
	$total_records = $db->f(0);
	$records_per_page = get_param("q") > 0 ? get_param("q") : 25;
	$pages_number = 5;
	$page_number = $n->set_navigator("navigator", "page", SIMPLE, $pages_number, $records_per_page, $total_records, false);

	$db->RecordsPerPage = $records_per_page;
	$db->PageNumber = $page_number;
	$sql  = " SELECT sup.user_priority_id, u.name, u.first_name, u.last_name, u.login, sup.user_email, ";
	$sql .= " sp.priority_name, sup.priority_expiry ";
	$sql .= " FROM ((" . $table_prefix . "support_users_priorities sup ";
	$sql .= " LEFT JOIN " . $table_prefix . "users u ON u.user_id=sup.user_id) ";
	$sql .= " LEFT JOIN " . $table_prefix . "support_priorities sp ON sp.priority_id=sup.priority_id) ";
	$sql .= $s->order_by;
	$db->query($sql);
	if($db->next_record())
	{
		$current_ts = va_timestamp();
		$t->set_var("no_records", "");
		$t->parse("sorters", false);
		do {
			$user_name = $db->f("name");
			$priority_expiry = $db->f("priority_expiry", DATETIME);

			if (!$user_name) {
				$user_name = trim($db->f("first_name") . " " . $db->f("last_name"));
			}
			if (!$user_name) {
				$user_name = $db->f("login");
			}
			$t->set_var("user_priority_id", $db->f("user_priority_id"));
			$t->set_var("user_name", $user_name);
			$t->set_var("user_email", $db->f("user_email"));
			$t->set_var("priority_name", $db->f("priority_name"));
			$t->set_var("priority_expiry", "");
			if (is_array($priority_expiry)) {
				$priority_expiry_ts = va_timestamp($priority_expiry); 
				$expiry_formatted = va_date($date_show_format, $priority_expiry);
				if ($priority_expiry_ts < $current_ts) {
					$t->set_var("priority_expiry", "<font color=\"red\">".$expiry_formatted."</font>");
				} else {
					$t->set_var("priority_expiry", "<font color=\"blue\">".$expiry_formatted."</font>");
				}
			}


			$t->parse("records", true);
		} while($db->next_record());
	}
	else
	{
		$t->set_var("records", "");
		$t->set_var("navigator", "");
		$t->parse("no_records", false);
	}

	$t->set_var("admin_href", "admin.php");
	$t->pparse("main");

?>
