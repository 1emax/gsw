<?php
/*
  ****************************************************************************
  ***                                                                      ***
  ***      ViArt Shop 3.5                                                  ***
  ***      File:  admin_footer.php                                         ***
  ***      Built: Fri Jun 20 19:43:16 2008                                 ***
  ***                                                 ***
  ***                                                                      ***
  ****************************************************************************
*/


	$t->set_file("admin_footer", "admin_footer.html");

	$t->set_var("footer_html", get_setting_value($settings, "html_below_footer", ""));

	
		$t->global_parse("support_link", false, false, true);
	
	$t->parse("admin_footer");

?>