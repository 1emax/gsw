<?php
/*
  ****************************************************************************
  ***                                                                      ***
  ***      ViArt Shop 3.5                                                  ***
  ***      File:  admin_orders_tax_report.php                              ***
  ***      Built: Fri Jun 20 19:43:16 2008                                 ***
  ***                                                 ***
  ***                                                                      ***
  ****************************************************************************
*/
                                   	

	include_once ("./admin_config.php");
	include_once ($root_folder_path . "includes/common.php");
	include_once ($root_folder_path . "includes/sorter.php");
	include_once ($root_folder_path . "includes/navigator.php");
	include_once ($root_folder_path . "includes/record.php");
	include_once ($root_folder_path . "includes/shopping_cart.php");
	include_once ($root_folder_path . "includes/order_items.php");
	include_once ("../messages/".$language_code."/cart_messages.php");

	include_once("./admin_common.php");

	check_admin_security("orders_stats");

	$t = new VA_Template($settings["admin_templates_dir"]);
	$t->set_file("main","admin_orders_tax_report.html");

	// prepare list values 
	$order_statuses = get_db_values("SELECT status_id, status_name FROM " . $table_prefix . "order_statuses", array(array("", "")));
	$periods = array(array("", ""), array("1", TODAY_MSG), array("2", YESTERDAY_MSG), array("3", LAST_7DAYS_MSG), array("4", THIS_MONTH_MSG), array("5", LAST_MONTH_MSG), array("6", THIS_QUARTER_MSG), array("7", THIS_YEAR_MSG));

	// prepare dates for stats
	$current_date = va_time();
	$cyear = $current_date[YEAR]; 
	$cmonth = $current_date[MONTH]; 
	$cday = $current_date[DAY]; 
	$today_ts = mktime (0, 0, 0, $cmonth, $cday, $cyear);
	$tomorrow_ts = mktime (0, 0, 0, $cmonth, $cday + 1, $cyear);
	$yesterday_ts = mktime (0, 0, 0, $cmonth, $cday - 1, $cyear);
	$week_ts = mktime (0, 0, 0, $cmonth, $cday - 6, $cyear);
	$month_ts = mktime (0, 0, 0, $cmonth, 1, $cyear);
	$last_month_start_ts = mktime (0, 0, 0, $cmonth - 1, 1, $cyear);
	$last_month_end_ts = mktime (0, 0, 0, $cmonth, 0, $cyear);
	$quarter_ts = mktime (0, 0, 0, intval(($cmonth - 1) / 3) * 3 + 1, 1, $cyear);
	$year_ts = mktime (0, 0, 0, 1, 1, $cyear);
	$today_date = va_date($date_edit_format, $today_ts);
	$tomorrow_date = va_date($date_edit_format, $tomorrow_ts);
	$yesterday_date = va_date($date_edit_format, $yesterday_ts);
	$week_start_date = va_date($date_edit_format, $week_ts);
	$month_start_date = va_date($date_edit_format, $month_ts);
	$last_month_start_date = va_date($date_edit_format, $last_month_start_ts);
	$last_month_end_date = va_date($date_edit_format, $last_month_end_ts);
	$quarter_start_date = va_date($date_edit_format, $quarter_ts);
	$year_start_date = va_date($date_edit_format, $year_ts);

	$t->set_var("date_edit_format", join("", $date_edit_format));
	$t->set_var("today_date", $today_date);
	$t->set_var("yesterday_date", $yesterday_date);
	$t->set_var("week_start_date", $week_start_date);
	$t->set_var("month_start_date", $month_start_date);
	$t->set_var("last_month_start_date", $last_month_start_date);
	$t->set_var("last_month_end_date", $last_month_end_date);
	$t->set_var("quarter_start_date", $quarter_start_date);
	$t->set_var("year_start_date", $year_start_date);

	$t->set_var("admin_orders_tax_report_href", "admin_orders_tax_report.php");
	$t->set_var("admin_product_href", "admin_product.php");

	include_once("./admin_header.php");
	include_once("./admin_footer.php");

	$where = "";
	$r = new VA_Record("");
	$r->add_select("s_tp", INTEGER, $periods);
	$r->add_textbox("s_sd", DATE, FROM_DATE_MSG);
	$r->change_property("s_sd", VALUE_MASK, $date_edit_format);
	$r->add_textbox("s_ed", DATE, END_DATE_MSG);
	$r->change_property("s_ed", VALUE_MASK, $date_edit_format);
	$r->add_select("s_os", INTEGER, $order_statuses);
	$r->get_form_parameters();
	$r->validate();
	$r->set_form_parameters();
	$t->set_var("s_tp_url", $r->get_value("s_tp"));
	$t->set_var("s_os_url", $r->get_value("s_os"));
	
	if (!strlen(get_param("filter")) && $r->is_empty("s_sd") && $r->is_empty("s_ed")) {
		$t->set_var("search_results", "");
		$t->pparse("main");
		exit;
	}

	$where = ""; 
	if(!$r->errors) {

		if(!$r->is_empty("s_sd")) {
			if (strlen($where)) { $where .= " AND "; }
			$where .= " o.order_placed_date >= " . $db->tosql($r->get_value("s_sd"), DATE);
		}

		if(!$r->is_empty("s_ed")) {
			if (strlen($where)) { $where .= " AND "; }
			$end_date = $r->get_value("s_ed");
			$day_after_end = mktime (0, 0, 0, $end_date[MONTH], $end_date[DAY] + 1, $end_date[YEAR]);
			$where .= " o.order_placed_date < " . $db->tosql($day_after_end, DATE);
		}

		if(!$r->is_empty("s_os")) {
			if (strlen($where)) { $where .= " AND "; }
			$where .= " o.order_status = " . $db->tosql($r->get_value("s_os"), INTEGER);
		}

	}

	$where_sql = ""; $where_and_sql = "";
	if (strlen($where)) {
		$where_sql = " WHERE " . $where;
		$where_and_sql = " AND " . $where;
	}

	// group taxes
	$items_taxes = array();
	$tax_index = 0; $goods_total = 0; $total_tax = 0; $goods_with_tax_total = 0;

	$sql  = " SELECT oi.item_id, oi.price, oi.quantity, oi.tax_percent ";
	$sql .= " FROM " . $table_prefix . "orders_items oi, " . $table_prefix . "orders o ";
	$sql .= " WHERE oi.order_id = o.order_id " . $where_and_sql;
	$sql .= " ORDER BY oi.tax_percent ";
	$db->query($sql);
	if ($db->next_record()) {
		do {
			$price = $db->f("price");
			$quantity = $db->f("quantity");
			$tax_percent = $db->f("tax_percent");
			$item_total = $price * $quantity;
			$item_total_tax = round(($item_total * $tax_percent) / 100, 2);

			$goods_total += $item_total;
			$total_tax += $item_total_tax;

			$item_tax_text = str_replace(".", "_", strval(round($tax_percent, 4)));
			if (isset($items_taxes[$item_tax_text])) {
				$items_taxes[$item_tax_text][0] += $item_total;
				$items_taxes[$item_tax_text][1] += $item_total_tax;
			} else {
				$items_taxes[$item_tax_text] = array($item_total, $item_total_tax, $tax_percent);
			}

		} while ($db->next_record());
		$goods_with_tax_total = $goods_total + $total_tax;
	}

	if (sizeof($items_taxes) > 0) {
		$t->parse("sorters", false);
		foreach ($items_taxes as $items_tax_text => $items_tax_data) {
			$tax_index++;

			$t->set_var("tax_percent", round($items_tax_data[2], 3) . "%");
			$t->set_var("goods_total", currency_format($items_tax_data[0] ));
			$t->set_var("goods_tax_total", currency_format($items_tax_data[1] ));
			$t->set_var("goods_with_tax_total", currency_format(($items_tax_data[0] + $items_tax_data[1]) ));

			$row_style = ($tax_index % 2 == 0) ? "row1" : "row2";
			$t->set_var("row_style", $row_style);

			$t->parse("records", true);
		}

		$t->set_var("sum_goods_total", currency_format($goods_total ));
		$t->set_var("sum_goods_tax_total", currency_format($total_tax ));
		$t->set_var("sum_goods_with_tax_total", currency_format($goods_with_tax_total ));

		$t->parse("summary", false);
	} else {
		$t->parse("no_records", false);
	}


	// shipping taxes
	$shipping_taxes = array();
	$shipping_total = 0; $shipping_total_tax = 0; $shipping_with_tax_total = 0;

	$sql  = " SELECT o.shipping_cost, o.shipping_taxable, o.tax_percent ";
	$sql .= " FROM " . $table_prefix . "orders o ";
	$sql .= $where_sql;
	$sql .= " ORDER BY o.tax_percent ";
	$db->query($sql);
	if ($db->next_record()) {
		do {
			$shipping_cost = $db->f("shipping_cost");
			$shipping_taxable = $db->f("shipping_taxable");
			$tax_percent = $db->f("tax_percent");
			if (!$shipping_taxable) { $tax_percent = 0; }

			if ($shipping_cost > 0) {
				$shipping_tax = round(($shipping_cost * $tax_percent) / 100, 2);
		  
				$shipping_total += $shipping_cost;
				$shipping_total_tax += $shipping_tax;
		  
				$tax_text = str_replace(".", "_", strval(round($tax_percent, 4)));
				if (isset($shipping_taxes[$tax_text])) {
					$shipping_taxes[$tax_text][0] += $shipping_cost;
					$shipping_taxes[$tax_text][1] += $shipping_tax;
				} else {
					$shipping_taxes[$tax_text] = array($shipping_cost, $shipping_tax, $tax_percent);
				}
			}

		} while ($db->next_record());
		$shipping_with_tax_total = $shipping_total + $shipping_total_tax;
	}

	if (sizeof($shipping_taxes) > 0) {
		$t->parse("shipping_sorters", false);
		foreach ($shipping_taxes as $tax_text => $shipping_tax_data) {
			$tax_index++;

			$t->set_var("tax_percent", round($shipping_tax_data[2], 3) . "%");
			$t->set_var("shipping_total", currency_format($shipping_tax_data[0] ));
			$t->set_var("shipping_total_tax", currency_format($shipping_tax_data[1] ));
			$t->set_var("shipping_with_tax_total", currency_format(($shipping_tax_data[0] + $shipping_tax_data[1]) ));

			$row_style = ($tax_index % 2 == 0) ? "row1" : "row2";
			$t->set_var("row_style", $row_style);

			$t->parse("shipping_records", true);
		}

		$t->set_var("sum_shipping_total", currency_format($shipping_total));
		$t->set_var("sum_shipping_total_tax", currency_format($shipping_total_tax));
		$t->set_var("sum_shipping_with_tax_total", currency_format($shipping_with_tax_total));

		$t->parse("shipping_summary", false);
		$t->parse("shipping_report", false);

	}


	$t->parse("search_results", false);
	$t->pparse("main");

?>