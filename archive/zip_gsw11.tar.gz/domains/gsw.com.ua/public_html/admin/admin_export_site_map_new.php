<?php
/*
  ****************************************************************************
  ***                                                                      ***
  ***      Appdragon                                                       ***
  ***      File:  admin_export_site_map_new.php                            ***
  ***      Built: Fri Jun 20 19:43:16 2010                                 ***
  ***                                                                      ***
  ***                                                                      ***
  ****************************************************************************
*/

/*
*   Site Map Export
*/

    include_once ("./admin_config.php");
    include_once ($root_folder_path . "includes/common.php");
    include_once ($root_folder_path . "includes/record.php");
    include_once ($root_folder_path . "includes/shopping_cart.php");
    include_once ($root_folder_path . "messages/".$language_code."/cart_messages.php");
    include_once("./admin_common.php");
    $R='';
    $R = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
    $R .="<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n";
    $str_error="#���������� ������#";
    if (isset($post_per_page))
        {
        $per_page=$post_per_page;
        }
    else
        {
        $per_page=50000;
        }
    $count = 0;
	$total_count = 0;
	$sitemap_count = 1;
	$sitemap_started = false;
    $datetime_loc_format = array("YYYY", "-", "MM", "-", "DD", "T", "HH", ":", "mm", ":", "ss", "+00:00");
	$sm_errors = "";
	$message_build_xml = "";
    if (!isset($table_array))
       {        
        if (!isset($_POST['table_array']))
        {
          exit(0);
        }
        else
        {
            $table_array=$_POST['table_array'];
        }
    }
    foreach ($table_array as $table=>$params)
    {
        $filename = $root_folder_path."sitemap".$sitemap_count.".xml";       
        $param_where=array();
        $field_url=$params['field_url'];
        $field_date=$params['field_date'];
        $param_where=$params['filter'];
        $start=$params['start'];
        $limit=$params['limit'];
        $data=get_from_database($table,$field_url,$field_date,$param_where,$start,$limit);
        
        if (!empty($data))
            {
            foreach ($data as $key=>$value)
                {
                    $total_count++;
                    if ($count<$per_page)
                    {
                        if (!isset($value['field_date']))
                        {
                            $value['field_date']=null;
                        }
                        $R.=xml_add_url($value['field_url'], $value['field_date'], null, null);
                        $count++;
                    }
                    else
                    {
                        $R .="</urlset>";

                        $fp = @fopen($filename, "w");
                        @fwrite($fp, $R);
                        @fclose($fp);
                        $sitemap_count++;
                        $count=0;
                        $R='';
                        $R = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
                        $R .="<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n";
                        $filename=$root_folder_path."sitemap".$sitemap_count.".xml";
                    }
                    sleep(1);
                 }
            
                }
    }
        if (($count>0)&&($count<$per_page))
        {
            $R .="</urlset>";
            $fp = @fopen($filename, "w");
            @fwrite($fp, $R);
            @fclose($fp);
        }
        $filename = $root_folder_path."sitemap_index.xml";
		$xml  = "<?xml version=\"1.0\" encoding=\"UTF-8\"" . chr(63) . ">\n";
		$xml .= "\t<sitemapindex xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n";
		for ($i = 1; $i <= $sitemap_count; $i++) {
			$xml .= "\t<sitemap>\n";
			$xml .= "\t\t<loc>".htmlspecialchars($settings["site_url"]."sitemap".$i.".xml", ENT_QUOTES, "UTF-8")."</loc>\n";
			$xml .= "\t\t<lastmod>".va_date($datetime_loc_format)."</lastmod>\n";
			$xml .= "\t</sitemap>\n";
		}
		$xml .= "\t</sitemapindex>";
		$fp = @fopen($filename, "w");
		@fwrite($fp, $xml);
		@fclose($fp);
		$message_build_xml .= str_replace("{urls_number}", $total_count, SM_URLS_ADDED) . "<br>";
    
    
    
    function get_from_database($tablename="",$field_url="",$field_date="",$filter=array(),$start,$limit)
    {
       
        if (!$tablename)
            {
                return false;
                exit();
            }
        else
        {
            $sql = "SELECT ";
            if (!empty($field_url))
                {
                    $sql.="`".$field_url."` as field_url ,";
                }
            else
                {
                    $sql.="null as field_url ,";
                }
            if (!empty($field_date))
                {
                    $sql.="`".$field_date."` as field_date ";
                }
            else
                 {
                    $sql.="null as field_date ";
                }
            $sql.="FROM `".$tablename."` ";
            $filter_str = '';
            if($filter){
                foreach($filter as $key => $value){
                  
                    if(!empty($value)){
                        $filter_str .= ' AND ' . $key . '=\'' . $value . '\'';
                    }
                }
            }
            
            if ($filter_str)
            {
                $sql.=" WHERE 1=1 ".$filter_str;
            }
            if ($limit)
            {
                if ($start > 0)
                {
                    $sql.="LIMIT ". $start .", ". $limit;
                }
                else
                {
                    $sql.="LIMIT ". $start .", ". $limit;
                }
            }

            $result=mysql_query($sql);

            $res= array();
            if (mysql_num_rows($result) == 0) {
               return false;
            }
            else
                {
                while ($row = mysql_fetch_array($result,MYSQL_ASSOC))
                {
                    $tmp=array('field_url'=>$row['field_url']);
                    array_push($res,$tmp);
                }
            
            }
            return $res;
       }
    }

    function xml_add_url($loc="", $lastmod = "", $changefreq = "", $priority = "") {
		global $count;
		global $sitemap_count;
		global $sitemap_started;
        global $settings;
        global $str_error;
        $R='';
        if (!strrpos($loc,'.php'))
            {
                $loc.='.php';
            }
        $string = file_get_contents($settings["site_url"].$loc,NULL, NULL, 20, 150);
        if(preg_match($str_error, $string))
        {
            $real = false;
        }
        else
        {
            $real=true;
        }
        if ($real)
        {
            $R .= "\t<url>\n";
            $R .= "\t\t<loc>" . htmlspecialchars($settings["site_url"].$loc, ENT_QUOTES, "UTF-8") . "</loc>\n";
            if (!strlen($lastmod)){
                $datetime_loc_format = array("YYYY", "-", "MM", "-", "DD", "T", "HH", ":", "mm", ":", "ss", "+00:00");
                $lastmod = va_date($datetime_loc_format);
            }
            if (strlen($lastmod)){
        		$R .="\t\t<lastmod>".$lastmod."</lastmod>\n";
    		}
        	if (strlen($changefreq)){
    			$R .="\t\t<changefreq>".$changefreq."</changefreq>\n";
            }
            if (strlen($priority)){
                $R .="\t\t<priority>".$priority."</priority>\n";
            }
            $R .= "\t</url>\n";
            return $R;
        }
	}
/*
    function va_date($mask = "", $date = "") {
	global $months, $short_months, $weekdays, $short_weekdays;
	$formated_date = "";
	if (! is_array ( $date )) {
		$date = is_numeric ( $date ) ? va_time ( $date ) : va_time ();
	}
	if (is_array ( $mask )) {
		$i = 0;
		for(; $i < sizeof ( $mask ); ++ $i) {
			switch ($mask [$i]) {
				case "YYYY" :
					$formated_date .= $date [YEAR];
					break;
				case "YY" :
					$formated_date .= substr ( $date [YEAR], 2 );
					break;
				case "WWWW" :
					$formated_date .= $weekdays [intval ( date ( "w", va_timestamp ( $date ) ) )] [1];
					break;
				case "WWW" :
					$formated_date .= $short_weekdays [intval ( date ( "w", va_timestamp ( $date ) ) )] [1];
					break;
				case "MMMM" :
					$formated_date .= $months [intval ( $date [MONTH] ) - 1] [1];
					break;
				case "MMM" :
					$formated_date .= $short_months [intval ( $date [MONTH] ) - 1] [1];
					break;
				case "MM" :
					$formated_date .= strlen ( $date [MONTH] ) == 2 ? $date [MONTH] : "0" . $date [MONTH];
					break;
				case "M" :
					$formated_date .= intval ( $date [MONTH] );
					break;
				case "DD" :
					$formated_date .= strlen ( $date [DAY] ) == 2 ? $date [DAY] : "0" . $date [DAY];
					break;
				case "D" :
					$formated_date .= intval ( $date [DAY] );
					break;
				case "HH" :
					$formated_date .= strlen ( $date [HOUR] ) == 2 ? $date [HOUR] : "0" . $date [HOUR];
					break;
				case "H" :
					$formated_date .= intval ( $date [HOUR] );
					break;
				case "hh" :
					$formated_date .= get_ampmhour ( $date ) == 2 ? get_ampmhour ( $date ) : "0" . get_ampmhour ( $date );
					break;
				case "h" :
					$formated_date .= intval ( get_ampmhour ( $date ) );
					break;
				case "mm" :
					$formated_date .= strlen ( $date [MINUTE] ) == 2 ? $date [MINUTE] : "0" . $date [MINUTE];
					break;
				case "m" :
					$formated_date .= intval ( $date [MINUTE] );
					break;
				case "ss" :
					$formated_date .= strlen ( $date [SECOND] ) == 2 ? $date [SECOND] : "0" . $date [SECOND];
					break;
				case "s" :
					$formated_date .= intval ( $date [SECOND] );
					break;
				case "AM" :
					$formated_date .= get_ampm ( $date );
					break;
				case "am" :
					$formated_date .= strtolower ( get_ampm ( $date ) );
					break;
				case "GMT" :
					$formated_date .= isset ( $date [GMT] ) ? $date [GMT] : "";
					break;
				default :
					$formated_date .= stripslashes ( $mask [$i] );
			}
		}
	} else {
		$formated_date = $date [YEAR] . "-" . $date [MONTH] . "-" . $date [DAY] . " " . $date [HOUR] . ":" . $date [MINUTE] . ":" . $date [SECOND];
	}
	return $formated_date;
}
    */
?>