<?php
/*
  ****************************************************************************
  ***                                                                      ***
  ***      ViArt Shop 3.5                                                  ***
  ***      File:  admin_select.php                                         ***
  ***      Built: Fri Jun 20 19:43:16 2008                                 ***
  ***                                                 ***
  ***                                                                      ***
  ****************************************************************************
*/


	define("CURRENT_DIR_MSG", "Current directory"); // 3.5 Peter

	include_once("./admin_config.php");
	include_once($root_folder_path . "includes/common.php");
	include_once($root_folder_path . "includes/sorter.php");
	include_once($root_folder_path . "includes/navigator.php");
	include_once($root_folder_path . "messages/" . $language_code . "/download_messages.php");
	include_once("./admin_common.php");

	check_admin_security();

	$show_preview_image = get_setting_value($settings, "show_preview_image_admin", 0);

	$t = new VA_Template($settings["admin_templates_dir"]);
	$t->set_file("main", "admin_select.html");

	include_once("./admin_header.php");
	include_once("./admin_footer.php");

	$t->set_var("admin_upload_href", "admin_upload.php");
	$t->set_var("admin_select_href", "admin_select.php");

	$filetype = get_param("filetype");
	$sort_dir = get_param("sort_dir");
	if (!$sort_dir) { $sort_dir = "asc"; }
	$search_image = get_param("s_im");
	$image_index = get_param("image_index");

	$downloads_dir = "";
	if ($filetype == "downloads") {
		$download_info = array();
		$sql = "SELECT setting_name,setting_value FROM " . $table_prefix . "global_settings WHERE setting_type='download_info'";
		if ($multisites_version) {
			$sql .= "AND ( site_id=1 OR  site_id=" . $db->tosql($site_id,INTEGER). ") ";
			$sql .= "ORDER BY site_id ASC ";
		}
		$db->query($sql);
		while ($db->next_record()) {
			$download_info[$db->f("setting_name")] = $db->f("setting_value");
		}
		$downloads_dir = get_setting_value($download_info, "downloads_admins_dir", "../");
		if (!preg_match("/[\/\\\\]$/", $downloads_dir)) { $downloads_dir .= "/"; }
	}

	$t->set_var("s_im", $search_image);

	$s = new VA_Sorter($settings["admin_templates_dir"], "sorter_img.html", "admin_select.php");
	$s->set_parameters(false, true, true, true);
	$s->set_default_sorting("1", "asc");
	$s->set_sorter(FILENAME_MSG, "sorter_filename", "1", "");

	$t->set_var("filetype", $filetype);
	$t->set_var("image_index", $image_index);

	if ($filetype == "tiny_image") {
		$files_dir = "../images/tiny/";
	} elseif ($filetype == "small_image") {
		$files_dir = "../images/small/";
	} elseif ($filetype == "big_image") {
		$files_dir = "../images/big/";
	} elseif ($filetype == "super_image") {
		$files_dir = "../images/super/";
	} elseif ($filetype == "article_small") {
		$files_dir = "../images/articles/small/";
	} elseif ($filetype == "preview_video") {
		$files_dir = "../images/video/preview/";
	} elseif ($filetype == "article_large") {
		$files_dir = "../images/articles/large/";
	} elseif ($filetype == "category" || $filetype == "category_small") {
		$files_dir = "../images/categories/";
	} elseif ($filetype == "category_large") {
		$files_dir = "../images/categories/large/";
	} elseif ($filetype == "company_small" || $filetype == "company_large") {
		$files_dir = "../images/companies/";
	} elseif ($filetype == "ad_small") {
		$files_dir = "../images/ads/small/";
	} elseif ($filetype == "ad_large") {
		$files_dir = "../images/ads/large/";
	} elseif ($filetype == "forum_small") {
		$files_dir = "../images/forum/small/";
	} elseif ($filetype == "forum_large") {
		$files_dir = "../images/forum/large/";
	} elseif ($filetype == "banner") {
		$files_dir = "../images/bnrs/";
	} elseif ($filetype == "personal") {
		$files_dir = "../images/users/";
	} elseif ($filetype == "downloads") {
		$files_dir = $downloads_dir;
	} elseif ($filetype == "manufacturer_small") {
		$files_dir = "../images/manufacturers/small/";
	} elseif ($filetype == "manufacturer_large") {
		$files_dir = "../images/manufacturers/large/";
	} elseif ($filetype == "icon") {
		$files_dir = "../images/icons/";
	} elseif ($filetype == "emoticon") {
		$files_dir = "../images/emoticons/";
	} elseif ($filetype == "payment_small") {
		$files_dir = "../images/payments/small/";
	} elseif ($filetype == "payment_large") {
		$files_dir = "../images/payments/large/";
	} elseif ($filetype == "language" || $filetype == "language_active") {
		$files_dir = "../images/flags/";
	} elseif ($filetype == "currency" || $filetype == "currency_active") {
		$files_dir = "../images/currencies/";
	} elseif ($filetype == "article_video") {
		$files_dir = "../video/article/";
	} else {
		$files_dir = "../images/";
	}
	$t->set_var("files_dir", str_replace("../", "", $files_dir));

	$search_regexp = "";
	if (strlen($search_image)) {
		$search_regexp = preg_quote($search_image, "/");
	}
	$dir_values = array();
	if ($dir = @opendir($files_dir))
	{
		$dir_index = 0;
		while ($file = readdir($dir))
		{
			if ($file != "." && $file != ".." && is_file($files_dir . $file))
			{
				if (preg_match("/" . $search_regexp . "/i", $file)) {
					$dir_values[$dir_index] = $file;
					$dir_index++;
				}
			}
		}
		closedir($dir);
	}

	if ($sort_dir == "desc") {
		array_multisort($dir_values, SORT_DESC);
	} else {
		array_multisort($dir_values, SORT_ASC);
	}

	$total_files = sizeof($dir_values);

	// set up variables for navigator
	$n = new VA_Navigator($settings["admin_templates_dir"], "navigator.html", "admin_select.php");
	$records_per_page = 10;
	$pages_number = 10;
	$page_number = $n->set_navigator("navigator", "page", MOVING, $pages_number, $records_per_page, $total_files, false);

	if ($total_files)
	{
		$firt_index = ($page_number - 1) * $records_per_page;
		$last_index = $page_number * $records_per_page;
		if ($last_index > $total_files) { $last_index = $total_files; }
		for ($i = $firt_index; $i < $last_index; $i++)
		{
			$image_name = $dir_values[$i];
			if (strval($search_regexp) == "") {
				$image_name_html = $image_name;
			} else {
				$image_name_html = preg_replace ("/(" . $search_regexp . ")/i", "<font color=blue><b>\\1</b></font>", $image_name);
			}
			$image_name_js = str_replace("'", "\\'", $image_name);
			if ($filetype == "downloads") {
				$downloads_dir_js = str_replace("\\", "\\\\", $downloads_dir);
				$downloads_dir_js = preg_replace("/^\.\.[\/|\\\\]/", "", $downloads_dir_js);
				$image_name_js = $downloads_dir_js . $image_name_js;
			}
			if (preg_match("/((.flv)|(.avi)|(.asf)|(.wmv)|(.vma)|(.mpg)|(.mpeg))$/i", $image_name)){
				$t->set_var("image_href", "admin_video.php?file=" . $files_dir . $dir_values[$i]);
			} else {
				$t->set_var("image_href", $files_dir . $dir_values[$i]);
			}
			$t->set_var("image_name", $image_name);
			$t->set_var("image_name_html", $image_name_html);
			$t->set_var("image_name_js", $image_name_js);
			$t->set_var("image_id", $i);

			if ($show_preview_image == 1){
			  $t->parse("image_row", true);
			} else {
			  $t->parse("image_row_no_preview", true);
			}
		}

		$t->set_var("no_images", "");
		$t->parse("images", false);
	} else {
		$t->parse("no_images", false);
		$t->set_var("images", "");
	}

	if (!$total_files && !strlen($search_image)) {
		$t->set_var("search_images", "");
	} else {
		$t->parse("search_images", false);
	}

	$t->pparse("main");

?>