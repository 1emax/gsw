<?php
/*
  ****************************************************************************
  ***                                                                      ***
  ***      ViArt Shop 3.5                                                  ***
  ***      File:  admin_header_menus.php                                   ***
  ***      Built: Fri Jun 20 19:43:16 2008                                 ***
  ***                                                 ***
  ***                                                                      ***
  ****************************************************************************
*/


	include_once("./admin_config.php");
	include_once($root_folder_path."includes/common.php");
	include_once($root_folder_path . "includes/sorter.php");
	include_once($root_folder_path . "includes/navigator.php");	

	include_once("./admin_common.php");

	check_admin_security("layouts");

	$layout_id   = get_param("layout_id");
	$set_default = get_param("set_default"); //-- set this view by default

	//-- switch to default view 
	if ((@$settings["admin_layout_view"] == "datasheet") && $layout_id && !$set_default) {
		header("Location: admin_layout_header.php?layout_id=$layout_id");
		exit;
	}
	//-- set current view as default
	if ($set_default) {
		set_setting("global","admin_layout_view","tree");
	}

	$t = new VA_Template($settings["admin_templates_dir"]);
	$t->set_file("main","admin_header_menus.html");
	$t->set_var("admin_menu_submenus_href","admin_menu_submenus.php");
	$t->set_var("admin_header_menus_order_href", "admin_header_menus_order.php");

	$sql = "SELECT layout_name FROM " . $table_prefix . "layouts WHERE layout_id=" . $db->tosql($layout_id, INTEGER);
	$db->query($sql);
	if($db->next_record()) {
		$layout_name = $db->f("layout_name");
		$t->set_var("layout_name", htmlspecialchars($layout_name));
		$return_page = "admin_layout.php?layout_id=".$layout_id;
	} else {
		$return_page = "admin_layouts.php";
		header("Location: " . $return_page);
		exit;
	}


	$t->set_var("admin_href", "admin.php");
	$t->set_var("admin_page_href", "admin_menu_item.php?layout_id=".$layout_id);
	$t->set_var("layout_id", $layout_id);
	$t->set_var("admin_layout_href", "admin_layout.php");

	include_once("./admin_header.php");
	include_once("./admin_footer.php");

	$sql  = " SELECT * FROM " . $table_prefix . "header_links WHERE layout_id=" . $db->tosql($layout_id, INTEGER);
	$sql .= " ORDER BY menu_path, menu_order ";
	$db->query($sql);
	while($db->next_record()) {
		$menu_id = $db->f("menu_id");
		$parent_menu_id = $db->f("parent_menu_id");
		if ($menu_id == $parent_menu_id) {
			$parent_menu_id = 0;
		}
		$menu_values = array(
			"menu_id" => $menu_id, "menu_url" => $db->f("menu_url"), 
			"menu_title" => $db->f("menu_title"), "menu_path" => $db->f("menu_path")
		);
		$menu[$menu_id] = $menu_values;
		$menu[$parent_menu_id]["subs"][] = $menu_id;
	}

	$menu_count = 0;
	show_menu(0);

	$t->pparse("main");

	function show_menu($parent_id) {
		global $t, $menu, $menu_count;
		$subs = $menu[$parent_id]["subs"];
		for ($m = 0; $m < sizeof($subs); $m++) {
			$menu_count++;
			$menu_id = $subs[$m];
			$menu_path = $menu[$menu_id]["menu_path"];
			$menu_title = $menu[$menu_id]["menu_title"];
			$menu_title = get_translation($menu_title);
			if (defined($menu_title)) {
				$menu_title = constant($menu_title);
			}
			$menu_url = $menu[$menu_id]["menu_url"];
			$menu_level = preg_replace("/\d/", "", $menu_path);
			$spaces = spaces_level(strlen($menu_level));

			$t->set_var("menu_count", $menu_count);
			$t->set_var("menu_id"   , $menu_id);
			$t->set_var("menu_title", $spaces . $menu_title);
			$t->set_var("menu_url"  , htmlspecialchars($menu_url));
			if ($parent_id) {
				$t->set_var("submenu_link", "");
			} else {
				$t->parse("submenu_link", false);
			}
			$t->parse("records", true);

			if (isset($menu[$menu_id]["subs"])) {
				show_menu($menu_id);
			}

		}
	}

    
	function spaces_level($level)
	{
		$spaces = "";
		for ($i = 0; $i < $level; $i++) {
			$spaces .= " &nbsp; &nbsp; &nbsp; ";
		}
		$spaces .= "<font style='font-size:".(12-$level)."'>";
		return $spaces;
	}

?>