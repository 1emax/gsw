<?php
/*
  ****************************************************************************
  ***                                                                      ***
  ***      ViArt Shop 3.5                                                  ***
  ***      File:  admin_banned_content.php                                 ***
  ***      Built: Fri Jun 20 19:43:16 2008                                 ***
  ***                                                 ***
  ***                                                                      ***
  ****************************************************************************
*/


	include_once("./admin_config.php");
	include_once($root_folder_path."includes/common.php");
	include_once("./admin_common.php");
	include_once($root_folder_path . "includes/record.php");

	check_admin_security("banned_contents");

  $t = new VA_Template($settings["admin_templates_dir"]);
  $t->set_file("main","admin_banned_content.html");

	$t->set_var("admin_href", "admin.php");
	$t->set_var("admin_banned_contents_href", "admin_banned_contents.php");
	$t->set_var("admin_banned_content_href", "admin_banned_content.php");

	$r = new VA_Record($table_prefix . "banned_contents");
	$r->return_page = "admin_banned_contents.php";
	$r->add_where("content_id", INTEGER);

	$r->add_textbox("content_text", TEXT, NOTES_MSG);
	$r->change_property("content_text", REQUIRED, true);

	$r->process();

	include_once("./admin_header.php");
	include_once("./admin_footer.php");

	$t->pparse("main");

?>
