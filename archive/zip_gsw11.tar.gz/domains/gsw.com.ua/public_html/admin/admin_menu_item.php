<?php
/*
  ****************************************************************************
  ***                                                                      ***
  ***      ViArt Shop 3.5                                                  ***
  ***      File:  admin_menu_item.php                                      ***
  ***      Built: Fri Jun 20 19:43:16 2008                                 ***
  ***                                                 ***
  ***                                                                      ***
  ****************************************************************************
*/


	include_once("./admin_config.php");
	include_once($root_folder_path."includes/common.php");
	include_once($root_folder_path . "includes/record.php");

	include_once("./admin_common.php");

	check_admin_security("layouts");

	$layout_id   = get_param("layout_id");
	$menu_id = get_param("menu_id");
	$return_page = get_param("return_page");

	$t = new VA_Template($settings["admin_templates_dir"]);
	$t->set_file("main","admin_menu_item.html");

	$sql = "SELECT layout_name FROM " . $table_prefix . "layouts WHERE layout_id=" . $db->tosql($layout_id, INTEGER);
	$db->query($sql);
	if($db->next_record()) {
		$layout_name = $db->f("layout_name");
		$t->set_var("layout_name", htmlspecialchars($layout_name));
	} else {
		header("Location: " . $return_page);
		exit;
	}
    
	$t->set_var("admin_href"      , "admin.php");
	$t->set_var("admin_pages_href", "admin_header_menus.php");
	$t->set_var("admin_page_href" , "admin_menu_item.php");
	$t->set_var("admin_layout_href", "admin_layout.php");
	$t->set_var("admin_menu_href"  , "admin_header_menus.php");


	if (!$menu_id) {
		$sql = "SELECT MAX(menu_order) FROM " . $table_prefix . "header_links WHERE layout_id=" . $db->tosql($layout_id, INTEGER);
		$menu_order = get_db_value($sql);
		$menu_order++;
	} else {
		$menu_order = 1;
	}

	$r = new VA_Record($table_prefix . "header_links");
	$r->return_page = "admin_header_menus.php?layout_id=" . $layout_id;

	$r->add_where("menu_id", INTEGER);
	$r->add_textbox("layout_id", TEXT, LAYOUT_ID_MSG);

	$r->add_textbox("menu_order", INTEGER, MENU_ORDER_MSG);
	$r->change_property("menu_order", DEFAULT_VALUE, $menu_order);
	$r->add_textbox("menu_title", TEXT, MENU_TITLE_MSG);
	$r->add_textbox("menu_url", TEXT, ADMIN_URL_SHORT_MSG);
	$r->add_textbox("menu_target", TEXT, ADMIN_TARGET_MSG);
	$r->add_textbox("submenu_style_name", TEXT);

	$r->add_textbox("menu_image", TEXT, MENU_IMAGE_MSG);
	$r->add_textbox("menu_image_active", TEXT, MENU_IMAGE_ACTIVE_MSG);

	$r->change_property("menu_url", REQUIRED, true);
	$r->add_checkbox("show_non_logged", INTEGER);
	$r->parameters["show_non_logged"][DEFAULT_VALUE] = 1;
	$r->add_checkbox("show_logged", INTEGER);
	$r->parameters["show_logged"][DEFAULT_VALUE] = 1;


	//-- parent items
	$sql  = " SELECT * FROM " . $table_prefix . "header_links ";
	$sql .= " WHERE layout_id=" . $db->tosql($layout_id, INTEGER);
	$sql .= " ORDER BY menu_path, menu_order ";
	$db->query($sql);
	while($db->next_record()) {
		$list_id = $db->f("menu_id");
		$parent_menu_id = $db->f("parent_menu_id");
		if ($parent_menu_id == $list_id) {
			$parent_menu_id = 0;
		}
		$list_title = $db->f("menu_title");
		if (defined($list_title)) {
			$list_title = constant($list_title);
		}

		$menu_values = array(
			"menu_title" => $list_title, "menu_url" => $db->f("menu_url"), "menu_path" => $db->f("menu_path")
		);
		$menu[$list_id] = $menu_values;
		$menu[$parent_menu_id]["subs"][] = $list_id;
	}

	$items = array();
	build_menu(0);

	$r->add_select("parent_menu_id", TEXT, $items, PARENT_ITEM_MSG);

	$r->set_event(AFTER_INSERT, "build_menus_tree");
	$r->set_event(AFTER_UPDATE, "build_menus_tree");
	$r->process();


	$t->set_var("layout_id" , $layout_id);
	include_once("./admin_header.php");
	include_once("./admin_footer.php");

	$t->pparse("main");

function spaces_level($level)
{
	$spaces = "";
	for ($i =1; $i <= $level; $i++) {
		$spaces .= "---";
	}
	return $spaces . " ";
}


function build_menus_tree()
{
	global $db, $table_prefix, $layout_id;

	// update menu links for new structure
	$header_links = array();
	$sql  = " SELECT menu_id, parent_menu_id FROM " . $table_prefix . "header_links ";
	$sql .= " WHERE layout_id=" . $db->tosql($layout_id, INTEGER);
	$sql .= " ORDER BY menu_id ";
	$db->query($sql);
	while ($db->next_record()) {
		$menu_id = $db->f("menu_id");
		$parent_menu_id = $db->f("parent_menu_id");
		$header_links[$menu_id] = $parent_menu_id;
	}
	foreach ($header_links as $menu_id => $parent_menu_id) {
		if (!$parent_menu_id || $parent_menu_id == $menu_id) {
			$parent_menu_id = 0;
		}
		$menu_path = ""; $current_parent_id = $parent_menu_id;
		while ($current_parent_id) {
			$menu_path = $current_parent_id.",".$menu_path;
			$parent_id = isset($header_links[$current_parent_id]) ? $header_links[$current_parent_id] : 0;
			if ($parent_id == $current_parent_id) {
				$current_parent_id = 0;
			} else {
				$current_parent_id = $parent_id;
			}
		}
		$sql  = " UPDATE " . $table_prefix . "header_links SET ";
		$sql .= " parent_menu_id=" . $db->tosql($parent_menu_id, INTEGER) . ", ";
		$sql .= " menu_path=" . $db->tosql($menu_path, TEXT);
		$sql .= " WHERE menu_id=" . $db->tosql($menu_id, INTEGER);
		$db->query($sql);
	}	

}

function build_menu($parent_id) {
	global $t, $menu, $items, $menu_id;
	if (isset($menu[$parent_id])) {
		$subs = $menu[$parent_id]["subs"];
		for ($m = 0; $m < sizeof($subs); $m++) {
			$item_id = $subs[$m];
			if ($menu_id != $item_id) {
				$menu_path = $menu[$item_id]["menu_path"];
				$menu_title = $menu[$item_id]["menu_title"];
				if (!$menu_title) {
					$menu_title = $menu[$item_id]["menu_url"];
				}
				$menu_level = preg_replace("/\d/", "", $menu_path);
				$spaces = spaces_level(strlen($menu_level));
        
				$items[] = array($item_id, $spaces.$menu_title);
        
				if (isset($menu[$item_id]["subs"])) {
					build_menu($item_id);
				}
			}
		}
	}
}

?>