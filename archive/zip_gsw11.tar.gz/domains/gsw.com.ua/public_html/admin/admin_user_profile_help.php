<?php
/*
  ****************************************************************************
  ***                                                                      ***
  ***      ViArt Shop 3.5                                                  ***
  ***      File:  admin_user_profile_help.php                              ***
  ***      Built: Fri Jun 20 19:43:16 2008                                 ***
  ***                                                 ***
  ***                                                                      ***
  ****************************************************************************
*/


	include_once("./admin_config.php");
	include_once($root_folder_path . "includes/common.php");
	include_once($root_folder_path . "includes/record.php");
	include_once($root_folder_path . "messages/" . $language_code . "/admin_messages.php");

	check_admin_security("users_groups");

	$type = get_param("type");

	$t = new VA_Template($settings["admin_templates_dir"]);
	$t->set_file("main", "admin_user_profile_help.html");
	$t->show_tags = true;

	if ($type == "reset") {
		$t->parse("reset_info", false);
	} else {
		$t->set_var("reset_info", "");
	}

	if ($type == "reminder") {
		$t->parse("reminder_info", false);
	} else {
		$t->set_var("reminder_info", "");
	}

	$t->pparse("main");

?>