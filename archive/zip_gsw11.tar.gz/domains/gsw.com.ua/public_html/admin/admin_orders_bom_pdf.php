<?php
/*
  ****************************************************************************
  ***                                                                      ***
  ***      ViArt Shop 3.5                                                  ***
  ***      File:  admin_orders_bom_pdf.php                                 ***
  ***      Built: Fri Jun 20 19:43:16 2008                                 ***
  ***                                                 ***
  ***                                                                      ***
  ****************************************************************************
*/


	include_once("./admin_config.php");
	include_once($root_folder_path . "includes/common.php");
	include_once($root_folder_path . "includes/pdflib.php");
	include_once($root_folder_path . "includes/pdf.php");
	include_once($root_folder_path . "messages/" . $language_code . "/cart_messages.php");
	include_once("./admin_common.php");

	check_admin_security("sales_orders");

	$currency = get_currency();

	$columns = array(
		"item_name" => array("start" => 40, "width" => 160, "title" => PROD_NAME_MSG),
		"manufacturer_code" => array("start" => 200, "width" => 55, "title" => MANUFACTURER_CODE_MSG),
		"item_code" => array("start" => 255, "width" => 55, "title" => PROD_CODE_MSG),
		"selling_price" => array("start" => 310, "width" => 50, "title" => SELLING_PRICE_MSG),
		"buying_price" => array("start" => 360, "width" => 50, "title" => PROD_BUYING_PRICE_MSG),
		"quantity" => array("start" => 410, "width" => 40, "title" => QTY_MSG),
		"selling_total" => array("start" => 450, "width" => 50, "title" => TOTAL_SELLING_MSG),
		"buying_total" => array("start" => 500, "width" => 55, "title" => TOTAL_BUYING_MSG),
	);

	// additional connection 
	$dbi = new VA_SQL();
	$dbi->DBType      = $db_type;
	$dbi->DBDatabase  = $db_name;
	$dbi->DBUser      = $db_user;
	$dbi->DBPassword  = $db_password;
	$dbi->DBHost      = $db_host;
	$dbi->DBPort      = $db_port;
	$dbi->DBPersistent= $db_persistent;


	$ids = get_param("ids");
	$order_id = get_param("order_id");
	if ($order_id) {
		$ids = $order_id;
	}

	// General PDF information
	$pdf_library = isset($packing["pdf_lib"]) ? $packing["pdf_lib"] : 1;
	if ($pdf_library == 2) {
		$pdf = new VA_PDFLib();
	} else {
		$pdf = new VA_PDF();
	}
	$pdf->set_creator("admin_order_bom.php");
	$pdf->set_author("ViArt Ltd");
	$pdf->set_title(BILL_OF_MATERIALS_MSG . $ids);
	$pdf->set_font_encoding(CHARSET);
	$page_number = 0;

	begin_new_page();		
	set_page_header($ids);

	$sql  = " SELECT oi.item_id, oi.item_name, oi.manufacturer_code, oi.item_code, ";
	$sql .= " oi.price, oi.buying_price, SUM(oi.quantity) AS total_quantity, ";
	$sql .= " m.manufacturer_id, m.manufacturer_name ";
	$sql .= " FROM ((" . $table_prefix . "orders_items oi ";
	$sql .= " LEFT JOIN " . $table_prefix . "items i ON oi.item_id=i.item_id) ";
	$sql .= " LEFT JOIN " . $table_prefix . "manufacturers m ON m.manufacturer_id=i.manufacturer_id) ";
	$sql .= " WHERE oi.order_id IN (" . $db->tosql($ids, TEXT, false) . ") ";
	$sql .= " GROUP BY oi.item_id, oi.item_name, oi.manufacturer_code, oi.item_code, ";
	$sql .= " oi.price, oi.buying_price, ";
	$sql .= " m.manufacturer_id, m.manufacturer_name ";
	$sql .= " ORDER BY m.manufacturer_id ";
	$db->query($sql);
	if ($db->next_record()) {
		$manufacturer_id = $db->f("manufacturer_id");
		$manufacturer_name = $db->f("manufacturer_name");
		$last_manufacturer_id = $manufacturer_id;

		set_manufacturer_header($manufacturer_name);
		set_table_header();

		$man_total_selling = 0; $man_total_buying = 0;
		do {
			if ($height_position < 140) {
				$pdf->end_page();
				begin_new_page();		
				set_table_header();
			}
  
			$price = $db->f("price");
			$buying_price = $db->f("buying_price");
			$quantity = $db->f("total_quantity");
			$item_name = strip_tags(get_translation($db->f("item_name")));
			$item_properties = $db->f("item_properties");
			$item_code = $db->f("item_code");
			$manufacturer_code = $db->f("manufacturer_code");
			$total_selling = $price * $quantity;
			$total_buying = $buying_price * $quantity;

			$manufacturer_id = $db->f("manufacturer_id");
			$manufacturer_name = $db->f("manufacturer_name");
			if ($manufacturer_id != $last_manufacturer_id) {
				set_table_footer($man_total_selling, $man_total_buying);
				set_manufacturer_header($manufacturer_name);
				set_table_header();
				$man_total_selling = 0; $man_total_buying = 0;
			}

			$man_total_selling += $total_selling; 
			$man_total_buying += $total_buying;
  
			$columns["item_name"]["height"] = $pdf->show_xy($item_name, $columns["item_name"]["start"] + 2, $height_position - 2, $columns["item_name"]["width"] - 4, 0);
			$columns["item_code"]["height"] = $pdf->show_xy ($item_code, $columns["item_code"]["start"] + 2, $height_position - 2, $columns["item_code"]["width"] - 4, 0, "center");
			$columns["manufacturer_code"]["height"] = $pdf->show_xy ($manufacturer_code, $columns["manufacturer_code"]["start"] + 2, $height_position - 2, $columns["manufacturer_code"]["width"] - 4, 0, "center");
			$columns["selling_price"]["height"] = $pdf->show_xy (currency_format($price), $columns["selling_price"]["start"] + 2, $height_position - 2, $columns["selling_price"]["width"] - 4, 0, "right");
			$columns["buying_price"]["height"] = $pdf->show_xy (currency_format($buying_price), $columns["buying_price"]["start"] + 2, $height_position - 2, $columns["buying_price"]["width"] - 4, 0, "right");
			$columns["quantity"]["height"] = $pdf->show_xy ($quantity, $columns["quantity"]["start"] + 2, $height_position - 2, $columns["quantity"]["width"] - 4, 0, "center");
			$columns["selling_total"]["height"] = $pdf->show_xy (currency_format($total_selling), $columns["selling_total"]["start"] + 2, $height_position - 2, $columns["selling_total"]["width"] - 4, 0, "right");
			$columns["buying_total"]["height"] = $pdf->show_xy (currency_format($total_buying), $columns["buying_total"]["start"] + 2, $height_position - 2, $columns["buying_total"]["width"] - 4, 0, "right");

			$row_height = $columns["item_name"]["height"];
			foreach($columns as $name => $column) {
				$height = $column["height"];
				if ($height > $row_height) { $row_height = $height; }
			}
			// add additional indent after each item
			$row_height += 6;
  
			$pdf->rect(40, $height_position - $row_height, 515, $row_height);
			foreach($columns as $name => $column) {
				$pdf->line($column["start"], $height_position - $row_height, $column["start"], $height_position);
			}
  
			$height_position -= $row_height;
			$last_manufacturer_id = $manufacturer_id;

		} while ($db->next_record());
		set_table_footer($man_total_selling, $man_total_buying);
	}

	set_page_footer();
	$pdf->end_page();

	$buffer = $pdf->get_buffer();
	$length = strlen($buffer);

	$pdf_filename = "bill_of_materials_" . str_replace(",", "_", $ids) . ".pdf";
	header("Pragma: private");
	header("Expires: 0");
	header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
	header("Cache-Control: private", false);
	header("Content-Type: application/octet-stream");
	header("Content-Length: " . $length); 
	header("Content-Disposition: attachment; filename=" . $pdf_filename); 
	header("Content-Transfer-Encoding: binary"); 

	echo $buffer;

	function begin_new_page()
	{
		global $pdf, $page_number, $height_position;
	
		$page_number++;
		$pdf->begin_page(595, 842);
		$height_position = 800;
	
		$pdf->setfont ("helvetica", "", 8);
		if ($page_number > 1) {
			//$pdf->show_xy("- " . $page_number . " -", 40, 20, 555, 0, "center");
		}
	}

	function set_manufacturer_header($manufacturer_name)
	{
		global $pdf, $height_position;
		global $helvetica, $helvetica_bold;
		global $columns;

		$pdf->setfont ("helvetica", "B", 9);
		$manufacturer_info = ITEMS_FOR_MANUFACTURER_MSG . $manufacturer_name;
		$line_height = $pdf->show_xy ($manufacturer_info, 40, $height_position, 515, 0);
		$height_position -= ($line_height + 6);
	}
	
	function set_table_header()
	{
		global $pdf, $height_position;
		global $helvetica, $helvetica_bold;
		global $columns;
	
		$pdf->setlinewidth(1.0);
		
		$pdf->rect(40, $height_position - 24, 515, 24);
		foreach($columns as $name => $column) {
			$pdf->line($column["start"], $height_position - 24, $column["start"], $height_position);
		}

		$pdf->setfont ("helvetica", "", 8);
		foreach($columns as $name => $column) {
			$pdf->show_xy ($column["title"], $column["start"] + 2, $height_position - 2, $column["width"] - 4, 0, "center");
		}
	
		$height_position -= 24;
	}

	function set_table_footer($man_total_selling, $man_total_buying)
	{
		global $pdf, $height_position;
		global $helvetica, $helvetica_bold;
		global $columns;

		$pdf->rect(40, $height_position - 14, 515, 14);
		$pdf->line($columns["selling_total"]["start"], $height_position - 14, $columns["selling_total"]["start"], $height_position);
		$pdf->line($columns["buying_total"]["start"], $height_position - 14, $columns["buying_total"]["start"], $height_position);

		$pdf->show_xy (TOTAL_MSG, $columns["quantity"]["start"], $height_position - 2, $columns["quantity"]["width"] - 4, 0, "right");
		$pdf->show_xy (currency_format($man_total_selling), $columns["selling_total"]["start"] + 2, $height_position - 2, $columns["selling_total"]["width"] - 4, 0, "right");
		$pdf->show_xy (currency_format($man_total_buying), $columns["buying_total"]["start"] + 2, $height_position - 2, $columns["buying_total"]["width"] - 4, 0, "right");

		//indent after table
		$height_position -= 30;
	}

	
	function set_page_header($ids)
	{
		global $pdf, $height_position;
		global $packing, $helvetica, $helvetica_bold, $order_date, $id, $r;

		$pdf->setfont ("helvetica", "B", 10);
		$ids = str_replace(",", ", ", $ids);
		$manufacturer_info = ITEMS_FOR_ORDERS_MSG . $ids;
		$line_height = $pdf->show_xy ($manufacturer_info, 40, $height_position, 515, 0);
		$height_position -= ($line_height + 18);
	}
	
	function set_page_footer()
	{
		global $pdf, $height_position;
		global $packing, $helvetica, $helvetica_bold, $order_date, $id;
	}

?>