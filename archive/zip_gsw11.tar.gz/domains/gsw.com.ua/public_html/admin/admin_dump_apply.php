<?php
/*
  ****************************************************************************
  ***                                                                      ***
  ***      ViArt Shop 3.5                                                  ***
  ***      File:  admin_dump_apply.php                                     ***
  ***      Built: Fri Jun 20 19:43:16 2008                                 ***
  ***                                                 ***
  ***                                                                      ***
  ****************************************************************************
*/


	@set_time_limit(900);

	include_once("./admin_config.php");
	include_once($root_folder_path . "includes/common.php");
	include_once("./admin_common.php");
	include_once($root_folder_path . "includes/record.php");
	include_once($root_folder_path . "messages/" . $language_code . "/install_messages.php");

	check_admin_security("db_management");

	$file_name = get_param("file_name");
	$return_page = "admin_dump.php";

	$t = new VA_Template($settings["admin_templates_dir"]);
	$t->set_file("main", "admin_dump_apply.html");
	$t->set_var("admin_dump_apply_href", "admin_dump_apply.php");
	$t->set_var("admin_dump_href", "admin_dump.php");

	$operation = get_param("operation");
	if ($operation == "cancel"){
		header("Location: " . $return_page);
		exit;
	}
	flush();

	$r = new VA_Record("", "");
	$r->add_hidden("operation", TEXT);
	$r->add_textbox("sql_file_name", TEXT);
	$r->change_property("sql_file_name", DEFAULT_VALUE, $file_name);
	$r->add_checkbox("is_apply", INTEGER, APPLY_DUMP_MSG);
	$r->change_property("is_apply", REQUIRED, true);


	$total_queries = 0;
	$total_queries_failed = 0;
	$total_queries_success = 0;
	if (!$r->errors)
	{
		if ($operation == "apply") {
			$r->get_form_parameters();
			$is_valid = $r->validate();
			if ($is_valid) {
				$r->empty_values();

				$db->HaltOnError = "no";
				if (!$db->connect()) {
					$r->errors  = DB_CONNECT_ERROR . "<br>";
					if ($db->Error) {
						$r->errors .= $db->Error;
					}
				} else {
					$is_access = ($db->DBType == "access");
					$db_filename = get_param("sql_file_name");
					$dump_sql = "../db/" . $db_filename;
					$sql = "";
					if (!strlen($db_filename))
					{
						$r->errors = ENTER_SQL_FILENAME_MSG . "<br>";
						$dump_sql="";
					}
					elseif (file_exists($dump_sql))
					{
						$sql_strings  = file($dump_sql);
						$total_string = sizeof($sql_strings);
						$last_db_progress = 0;
						$current_progress = 0;
						for ($i = 0; $i < $total_string; $i++) {
							$sql_string = $sql_strings[$i];
							if (preg_match ("/\;\s*$/i", $sql_strings[$i])) {
								$sql_string = preg_replace ("/;\s*$/i", "", $sql_string);
								$sql .= $sql_string;
								if (preg_match ("/^\s*DROP\s+/i", $sql)) {
									$drop_table_syntax = true;
								} else {
									$drop_table_syntax = false;
								}
								if ($is_access) {
									$sql = str_replace("\\n", "\n", $sql);
									$sql = str_replace("\\t", "\t", $sql);
									$sql = str_replace("\\r", "\r", $sql);
								}
								$db->query($sql);
								$total_queries++;
								$current_progress = intval(($i * 100) / $total_string);
								if ($current_progress > $last_db_progress) {
									$last_db_progress = $current_progress;
									//echo "<script>\nupdateProgress(" . $current_progress . ");\n</script>\n";
									//flush();
								}

								if ($db->Error && !$drop_table_syntax) {
									$r->errors .= ERROR_AT_LINE_MSG . $i . ": " . $db->Error . "<br>";
									$total_queries_failed++;
								} else { $total_queries_success++; }
								$sql = "";
							} else {
								$sql .= $sql_string;
							}
						}
						//echo "<script>\nupdateProgress(100);\n</script>\n";
						//flush();

					} else {
						$dump_file_error = str_replace("{file_name}", $dump_sql, DUMP_FILE_ERROR);
						$r->errors .= $dump_file_error;
					}
				}
				if ($total_queries) {
					$t->set_var("total_queries_failed", $total_queries_failed);
					$t->parse("queries_failed", false);

					$t->set_var("total_queries_success", $total_queries_success);
					$t->parse("queries_success", false);

					$t->set_var("total_queries", $total_queries);
					$t->parse("queries", false);

					$operation = "";
				}
			}
		} else {
			$r->set_default_values();
		}
	}

	$r->set_parameters();

	$t->parse("dump_apply_form", true);

	include_once("./admin_header.php");
	include_once("./admin_footer.php");

	$t->pparse("main");

?>