<?php
/*
  ****************************************************************************
  ***                                                                      ***
  ***      ViArt Shop 3.5                                                  ***
  ***      File:  admin_item_type.php                                      ***
  ***      Built: Fri Jun 20 19:43:16 2008                                 ***
  ***                                                 ***
  ***                                                                      ***
  ****************************************************************************
*/


	include_once("./admin_config.php");
	include_once($root_folder_path."includes/common.php");
	include_once($root_folder_path . "includes/record.php");

	include_once($root_folder_path."messages/".$language_code."/cart_messages.php");
	include_once("./admin_common.php");

	check_admin_security("product_types");

  $t = new VA_Template($settings["admin_templates_dir"]);
  $t->set_file("main","admin_item_type.html");

	$t->set_var("admin_href", "admin.php");
	$t->set_var("admin_items_list_href", "admin_items_list.php");
	$t->set_var("admin_item_types_href", "admin_item_types.php");
	$t->set_var("admin_item_type_href", "admin_item_type.php");

	$commission_types = array(
		array("", ""), array(0, NOT_AVAILABLE_MSG), array(1, PERCENT_PER_PROD_FULL_PRICE_MSG),
		array(2, FIXED_AMOUNT_PER_PROD_MSG), array(3, PERCENT_PER_PROD_SELL_PRICE_MSG),
		array(4, PERCENT_PER_PROD_SELL_BUY_MSG)
	);

	$r = new VA_Record($table_prefix . "item_types");
	$r->return_page = "admin_item_types.php";
	
	$r->add_where("item_type_id", INTEGER);

	$r->add_textbox("item_type_name", TEXT, TYPE_NAME_MSG );
	$r->change_property("item_type_name", REQUIRED, true);
	$r->add_checkbox("is_gift_voucher", INTEGER);
	$r->add_checkbox("is_bundle", INTEGER);
	$r->add_checkbox("is_user", INTEGER);
	
	$google_base_product_types = get_db_values ("SELECT type_id, type_name FROM " . $table_prefix . "google_base_types ORDER BY type_name", array(array(-1, NOT_EXPORTED_MSG), array(0, USE_GLOBAL_MSG)));
	$r->add_select("google_base_type_id", INTEGER, $google_base_product_types);
	
	// commissions
	$r->add_select("merchant_fee_type", INTEGER, $commission_types);
	$r->add_textbox("merchant_fee_amount", NUMBER, MERCHANT_FEE_AMOUNT_MSG);
	$r->add_select("affiliate_commission_type", INTEGER, $commission_types);
	$r->add_textbox("affiliate_commission_amount", NUMBER, AFFILIATE_COMMISSION_AMOUNT_MSG);
	$r->add_select("reward_type", INTEGER, $commission_types, REWARD_POINTS_TYPE_MSG);
	$r->add_textbox("reward_amount", NUMBER, REWARD_POINTS_AMOUNT_MSG);
	$r->add_select("credit_reward_type", INTEGER, $commission_types, REWARD_CREDITS_TYPE_MSG);
	$r->add_textbox("credit_reward_amount", NUMBER, REWARD_CREDITS_AMOUNT_MSG);

	$r->events[AFTER_DELETE] = "delete_type_data";

	$r->process();

	include_once("./admin_header.php");
	include_once("./admin_footer.php");

	$t->pparse("main");
	
	function delete_type_data()
	{
		global $r, $db, $table_prefix;

		$item_type_id = $r->get_value("item_type_id");

		// {DELETE_ALL_BUTTON} properties
		$properties_ids = "";
		$sql = " SELECT property_id FROM " . $table_prefix ."items_properties WHERE item_type_id=" . $db->tosql($item_type_id, INTEGER); 
		$db->query($sql);
		while ($db->next_record()) {
			if(strlen($properties_ids)) { $properties_ids .= ","; }
			$properties_ids .= $db->f("property_id");
		}
		if (strlen($properties_ids)) {
			$db->query("DELETE FROM " . $table_prefix . "items_properties_values WHERE property_id IN (" . $db->tosql($properties_ids, TEXT, false) . ") ");
			$db->query("DELETE FROM " . $table_prefix . "items_properties WHERE item_type_id=" . $db->tosql($item_type_id, INTEGER)); 
		}

		// delete predefined specification
		$db->query("DELETE FROM " . $table_prefix . "features_default WHERE item_type_id=" . $db->tosql($item_type_id, INTEGER));		
	}

?>