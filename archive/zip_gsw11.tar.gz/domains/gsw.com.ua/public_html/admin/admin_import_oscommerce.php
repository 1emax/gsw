<?php
/*
  ****************************************************************************
  ***                                                                      ***
  ***      ViArt Shop 3.5                                                  ***
  ***      File:  admin_import_oscommerce.php                              ***
  ***      Built: Fri Jun 20 19:43:16 2008                                 ***
  ***                                                 ***
  ***                                                                      ***
  ****************************************************************************
*/


	// importing categories
	$sql = " SELECT COUNT(*) FROM va_categories ";
	$dbi->query($sql);
	$dbi->next_record($sql);
	$total = $dbi->f(0); // check the total number of records
	
	$imported = 0;
	$sql = " SELECT * FROM va_categories ";
	$dbi->query($sql);
	while ($dbi->next_record()) {
		$imported++; // save number of imported records
		importing_data("categories", $imported, $total); // output importings results to the page
	}

	// importing products

	// importing users

	// importing orders

	// ...

?>