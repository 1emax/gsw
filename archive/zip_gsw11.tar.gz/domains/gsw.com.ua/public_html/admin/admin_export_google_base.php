<?php
/*
  ****************************************************************************
  ***                                                                      ***
  ***      ViArt Shop 3.5                                                  ***
  ***      File:  admin_export_google_base.php                             ***
  ***      Built: Fri Jun 20 19:43:16 2008                                 ***
  ***                                                 ***
  ***                                                                      ***
  ****************************************************************************
*/

/*
*	Google Base Export
*	RSS 2.0 Formatted (Example http://base.google.com/base/products2.xml)
*/
	include_once ("./admin_config.php");
	include_once ($root_folder_path . "includes/common.php");
	include_once ($root_folder_path . "includes/record.php");
	include_once ($root_folder_path . "includes/shopping_cart.php");
	include_once ($root_folder_path . "messages/".$language_code."/cart_messages.php");
	include_once("./admin_common.php");

	check_admin_security("import_export");
	check_admin_security("products_export_google_base");
	
	$tax_rates   = get_tax_rates(true);	
	$country_id  = $settings["country_id"];
	$tax_percent = isset($tax_rates[0]) ? $tax_rates[0] : 0;
	$tax_region  = get_db_value("SELECT country_name FROM " . $table_prefix . "countries WHERE country_id=" . $db->tosql($country_id, INTEGER, true, false));
	
	$google_base_ftp_login    = get_setting_value($settings, "google_base_ftp_login");
	$google_base_ftp_password = get_setting_value($settings, "google_base_ftp_password");
	
	$google_base_filename     = get_setting_value($settings, "google_base_filename");
	$google_base_title        = get_setting_value($settings, "google_base_title");
	$google_base_description  = get_setting_value($settings, "google_base_description");
	$google_base_encoding     = get_setting_value($settings, "google_base_encoding", "UTF-8");
	
	$google_base_save_path    = get_setting_value($settings, "google_base_save_path", get_setting_value($settings, "tmp_dir", "../images/"));
	$google_base_export_type  = get_setting_value($settings, "google_base_export_type", 0);

	if (!$google_base_filename) {
		$google_base_filename = 'googlebase.xml';
	}
	$google_base_tax = get_setting_value($settings, "google_base_tax", true);
	$google_base_days_expiry = get_setting_value($settings, "google_base_days_expiry", 30);
	$google_base_product_condition = get_setting_value($settings, "google_base_product_condition", "new");	
	$product_link  = get_setting_value($settings, "site_url") . get_custom_friendly_url("product_details.php") . "?item_id=";
	
	$current_date = getdate();
	$expiration_date = mktime ($current_date["hours"], $current_date["minutes"], $current_date["seconds"], $current_date["mon"], $current_date["mday"] + $google_base_days_expiry, $current_date["year"]);
	$expiration_date_formatted = date("Y-m-d", $expiration_date);
	
	$s = trim(get_param("s"));
	$sc = get_param("sc");
	$sl = get_param("sl");
	$ss = get_param("ss");
	$ap = get_param("ap");	
	$search = (strlen($sc) || strlen($s) || strlen($sl) || strlen($ss) || strlen($ap)) ? true : false;
	
	$dbd = new VA_SQL();
	$dbd->DBType       = $db->DBType;
	$dbd->DBDatabase   = $db->DBDatabase;
	$dbd->DBUser       = $db->DBUser;
	$dbd->DBPassword   = $db->DBPassword;
	$dbd->DBHost       = $db->DBHost;
	$dbd->DBPort       = $db->DBPort;
	$dbd->DBPersistent = $db->DBPersistent;	
	
	$categories = array();
	$categories[0] = PRODUCTS_TITLE;
	$sql = "SELECT category_id,category_name FROM " . $table_prefix . "categories ";
	$db->query($sql);
	while ($db->next_record()) {
		$category_id = $db->f("category_id");
		$category_name = $db->f("category_name");
		$categories[$category_id] = get_translation($category_name);
	}

	$tree = new VA_Tree("category_id", "category_name", "parent_category_id", $table_prefix . "categories", "tree");
	
	$sql  = " SELECT i.item_id, i.item_type_id, it.item_type_name, i.item_code, i.item_name, i.full_description, i.big_image, i.meta_keywords, ";
	$sql .= " i.manufacturer_code, i.weight, i.issue_date, i.google_base_type_id, m.manufacturer_name, ";
	$sql .= " i.price, i.sales_price, i.is_sales, i.properties_price, i.tax_free, i.stock_level ";
	if (strlen($sc)) {
		$sql .= " FROM ((((" . $table_prefix . "items i ";
		$sql .= " LEFT JOIN " . $table_prefix . "manufacturers m ON i.manufacturer_id=m.manufacturer_id) ";
		$sql .= " LEFT JOIN " . $table_prefix . "items_categories ic ON ic.item_id=i.item_id) ";
		$sql .= " LEFT JOIN " . $table_prefix . "categories c ON ic.category_id=c.category_id) ";
		$sql .= " LEFT JOIN " . $table_prefix . "item_types it ON i.item_type_id=it.item_type_id) ";
	} else {
		$sql .= " FROM ((" . $table_prefix . "items i ";
		$sql .= " LEFT JOIN " . $table_prefix . "manufacturers m ON i.manufacturer_id=m.manufacturer_id) ";
		$sql .= " LEFT JOIN " . $table_prefix . "item_types it ON i.item_type_id=it.item_type_id) ";
	}
	$where = " WHERE i.google_base_type_id>=0 ";
	if (!$search) {
		$where .= " AND i.is_showing=1 ";
		$where .= " AND ((i.hide_out_of_stock=1 AND i.stock_level > 0) OR i.hide_out_of_stock=0)";
	}
	if($search && $sc != 0) {
		$where .= " AND c.category_id = ic.category_id ";
		$where .= " AND (ic.category_id = " . $db->tosql($sc, INTEGER);
		$where .= " OR c.category_path LIKE '" . $db->tosql($tree->get_path($sc), TEXT, false) . "%')";
	} else if(strlen($sc)) {
		$where .= " AND ic.category_id = " . $db->tosql($sc, INTEGER);
	}
	if($s) {
		$sa = split(" ", $s);
		for($si = 0; $si < sizeof($sa); $si++) {
			$where .= " AND (i.item_name LIKE '%" . $db->tosql($sa[$si], TEXT, false) . "%'";
			$where .= " OR i.item_code LIKE '%" . $db->tosql($sa[$si], TEXT, false) . "%'";
			$where .= " OR i.manufacturer_code LIKE '%" . $db->tosql($sa[$si], TEXT, false) . "%')";
		}
	}
	if(strlen($sl)) {
		if ($sl == 1) {
			$where .= " AND (i.stock_level>0 OR i.stock_level IS NULL) ";
		} else {
			$where .= " AND i.stock_level<1 ";
		}
	}
	if(strlen($ss)) {
		if ($ss == 1) {
			$where .= " AND i.is_showing=1 ";
		} else {
			$where .= " AND i.is_showing=0 ";
		}
	}
	if(strlen($ap)) {
		if ($ap == 1) {
			$where .= " AND i.is_approved=1 ";
		} else {
			$where .= " AND i.is_approved=0 ";
		}
	}
	$sql .= $where;
	if ($search && $sc != 0) {
		if ($db_type == "access" || $db_type == "db2" || $db_type == "postgre") {
			$sql .= " GROUP BY i.item_id, i.item_code, i.item_name, i.full_description, i.big_image, i.meta_keywords, i.manufacturer_code, ";
			$sql .= " m.manufacturer_name, i.price, i.sales_price, i.is_sales, i.properties_price, ";
			$sql .= " i.item_type_id, it.item_type_name, i.weight, i.issue_date, i.google_base_type_id, i.tax_free, i.stock_level";
		} else {
			$sql .= " GROUP BY i.item_id ";
		}
	}

	$db->query($sql);
	
	$result_xml = "";
	$schema_type = 'g';
	while ($db->next_record()) {
		
		$item_id      = $db->f("item_id");
		$item_type_id = $db->f("item_type_id");
		$item_name    = htmlspecialchars(trim(get_translation($db->f("item_name"))));

		$google_base_type_id = $db->f('google_base_type_id');
		// find google base type id if product uses "global" type
		if ($google_base_type_id == 0) {
			$sql  = " SELECT MAX(google_base_type_id) ";
			$sql .= " FROM (" . $table_prefix . "items_categories ic ";
			$sql .= " LEFT JOIN " . $table_prefix . "categories c ON c.category_id=ic.category_id) ";
			$sql .= " WHERE ic.item_id=" . $db->tosql($item_id, INTEGER);	
			$dbd->query($sql);
			if ($dbd->next_record()) {	
				$google_base_type_id = $dbd->f(0);
			}
			if ($google_base_type_id == 0) {
				if ($item_type_id) {
					$sql  = " SELECT google_base_type_id FROM " . $table_prefix . "item_types ";
					$sql .= " WHERE item_type_id=" . $db->tosql($item_type_id, INTEGER);
					$dbd->query($sql);
					if ($dbd->next_record()) {	
						$google_base_type_id = $dbd->f(0);
					}			
				}
				if ($google_base_type_id == 0) {	
					$google_base_type_id = get_setting_value($settings, 'google_base_product_type_id', 0);
				}
			}
		}		
		if ($google_base_type_id<=0) {
			continue;			
		}	
		
		$sql  = " SELECT type_name FROM " . $table_prefix . "google_base_types ";
		$sql .= " WHERE type_id=" . $db->tosql($google_base_type_id, INTEGER);
		$dbd->query($sql);
		if ($dbd->next_record()) {	
			$google_base_type_name = $dbd->f(0);
		} else {
			continue;
		}			
		
		$item_xml  = "<ID>" . $item_id . "</ID>" . $eol;
		$item_xml .= "<guid>" . $item_id . "</guid>" . $eol;
		$item_xml .= "<title><![CDATA[" . xml_rep($item_name) . "]]></title>" . $eol;
		$item_xml .= "<link>". $product_link . $item_id ."</link>" . $eol;
				
		$item_code    = $db->f("item_code");
		if ($item_code) {
			$item_xml .= "<g:upc>" . $item_code . "</g:upc>" . $eol;
			$item_xml .= "<g:isbn>" . $item_code . "</g:isbn>" . $eol;
		}
				
		$item_xml .= "<g:product_type>" . $google_base_type_name . "</g:product_type>" . $eol;
		$item_xml .= "<g:expiration_date>" . $expiration_date_formatted . "</g:expiration_date>" . $eol;
		$item_xml .= "<g:condition>" . $google_base_product_condition . "</g:condition>" . $eol;
				
		$full_description = rtrim(trim(get_translation($db->f("full_description"))));
		if (strlen($full_description ))
		$item_xml .= "<description><![CDATA[" . xml_rep($full_description) . "]]></description>" . $eol;

		$manufacturer_name = $db->f("manufacturer_name");
		if (strlen($manufacturer_name))
			$item_xml .= "<g:brand>" . $manufacturer_name . "</g:brand>" . $eol;
		
		$manufacturer_code = $db->f("manufacturer_code");
		if (strlen($manufacturer_code))
			$item_xml .= "<g:mpn>" . $manufacturer_code . "</g:mpn>" . $eol;
		
		$image_url = $db->f("big_image");
		if ($image_url && !preg_match("/^http\:\/\//", $image_url)) {
			$image_url = $settings["site_url"] . $image_url;
		}
		if (strlen($image_url))
			$item_xml .= "<g:image_link>" . $image_url . "</g:image_link>" . $eol;
	  
		$price = $db->f("price");
		$sales_price = $db->f("sales_price");
		$is_sales = $db->f("is_sales");
		$properties_price = $db->f("properties_price");
		$tax_free = $db->f("tax_free");		
		if ($is_sales && $sales_price > 0) {
			$price = $sales_price;
		}
		$price += $properties_price;
		if ($google_base_tax) {
			$item_tax = get_tax_amount($tax_rates, $item_type_id, $price, $tax_free, $tax_percent);
			list($item_tax_percent, $item_tax_total) = $item_tax;
			$price += $item_tax_total;
			$item_xml .= "<g:tax_percent>" . $tax_percent . "</g:tax_percent>" . $eol;	
			$item_xml .= "<g:tax_region>" . $tax_region . "</g:tax_region>" . $eol;	
		}		
		$item_xml .= "<g:price>" . $price . "</g:price>" . $eol;			
		
		$stock_level = $db->f("stock_level");
		if ($stock_level>0) {
			$item_xml .= "<g:pickup>true</g:pickup>" . $eol;
			$item_xml .= "<g:quantity>" . $stock_level . "</g:quantity>" . $eol;	
		} else {
			$item_xml .= "<g:pickup>false</g:pickup>" . $eol;
		}
		
		$weight = $db->f('weight');
		$weight_measure = get_setting_value($settings, "weight_measure", "");
		if ($weight) {
			if ($weight_measure) {
				$item_xml .= "<g:weight>" . $weight . " " . $weight_measure . "</g:weight>" . $eol;		
			} else {
				$item_xml .= "<g:weight>" . $weight . "</g:weight>" . $eol;
			}
		}
		
		$issue_date = $db->f('issue_date');
		if ($issue_date) {
			$tmp =  explode('-', $issue_date);
			if (strlen($tmp[0]))
				$item_xml .= "<g:year>" . $tmp[0] . "</g:year>" . $eol;			
		}
		
		$sql  = " SELECT a.attribute_name, a.attribute_type, a.value_type, f.feature_value FROM (" . $table_prefix . "features f ";
		$sql .= " INNER JOIN " . $table_prefix . "google_base_attributes a ON a.attribute_id=f.google_base_attribute_id)";
		$sql .= " WHERE f.item_id=" . $db->tosql($item_id, INTEGER);
		$dbd->query($sql);
		while ($dbd->next_record()) {	
			$attribute_name = $dbd->f('attribute_name');
			$attribute_type = $dbd->f('attribute_type');
			$value_type = $dbd->f('value_type');
			$feature_value = $dbd->f('feature_value');
			if ($attribute_name && $attribute_type && $feature_value) {
				if ($attribute_type == 'g') {
					$item_xml .= "<g:" . $attribute_name . "><![CDATA[" . xml_rep($feature_value) . "]]></g:" . $attribute_name . ">" . $eol;
				} else {
					$item_xml .= "<c:" . $attribute_name . " type='" . $value_type . "'><![CDATA[" . xml_rep($feature_value) . "]]></c:" . $attribute_name . ">" . $eol;	
					$schema_type = 'c';			
				}
			}
		}	
		
		
		$result_xml .= "<item>" . $eol . $item_xml . "</item>" . $eol;
	}
	
	if (!$result_xml) {
		echo NO_PRODUCTS_EXPORT_MSG;
		exit;		
	}
  
	if ($schema_type == 'c') {
		$result_xml = str_replace(array('<g:','</g:'), array('<c:','</c:'), $result_xml);		
	}
	$xml = "<?xml version='1.0' encoding='" . $google_base_encoding . "'?>" . $eol
		. "<rss version='2.0' xmlns:" . $schema_type . "='http://base.google.com/ns/1.0'>" . $eol
		. "<channel>" . $eol;
	if(strlen($google_base_title))
		$xml .= "<title>" . $google_base_title . "</title>" . $eol;
	if(strlen($google_base_description))
		$xml .= "<description>" . $google_base_description . "</description> " . $eol;
	$xml .= "<link>" . get_setting_value($settings, "site_url") . "</link>" . $eol
		. $result_xml 
		. "</channel>" . $eol 
		. "</rss>";
	if ($google_base_export_type==1 && $google_base_ftp_login && $google_base_ftp_password) {
		$fp = fopen($google_base_save_path . $google_base_filename, "w+");
		if (!fwrite($fp, $xml)) {
			echo MODULE_COULDNT_WRITE_TO_MSG . $google_base_save_path . $google_base_filename . CHECK_PERMISSIONS_MSG . "<br/>";
			echo $xml;
			fclose($fp);
			exit;
		}
		fclose($fp);
		
		$conn_id = ftp_connect("uploads.google.com", 21, 15);
		if (!$conn_id) {
			echo COULDNOT_CONNECT_GOOGLE_MSG ."<br/>";
			echo DATA_FEED_SUBMIT_MSG_MSG . "<br/>";
			echo "<a href='" . $google_base_save_path . $google_base_filename . "'>" . DOWNLOAD_BUTTON  . $google_base_save_path . $google_base_filename . "</a>";
			exit;
		}
		
		$login_result = ftp_login($conn_id, $google_base_ftp_login, $google_base_ftp_password);
		if (!$login_result) {
			echo COULDNOT_CONNECT_GOOGLE_MSG ."<br/>";
			echo DATA_FEED_SUBMIT_MSG_MSG . "<br/>";
			echo "<a href='" . $google_base_save_path . $google_base_filename . "'>" . DOWNLOAD_BUTTON  . $google_base_save_path . $google_base_filename . "</a>";
			ftp_close($conn_id);
			exit;
		}
		ftp_pasv($conn_id, true);	
		
		$upload = ftp_put($conn_id, $google_base_filename, $google_base_save_path . $google_base_filename, FTP_BINARY);
		if (!$upload) {
			echo FTP_UPLOAD_FAILED_MSG ."<br/>";
			echo DATA_FEED_SUBMIT_MSG_MSG . "<br/>";
			echo "<a href='" . $google_base_save_path . $google_base_filename . "'>".DOWNLOAD_BUTTON . $google_base_save_path . $google_base_filename . "</a>";
		} else {
			echo FTP_UPLOAD_SUCCEED_MSG;
		}	
		ftp_close($conn_id);
	
	} else {
		header("Content-Type: text/xml");
		header("Pragma: no-cache");
		echo $xml;
		exit;
		
	}
	
	function xml_rep($string)
	{
		global $google_base_encoding;
		$string = iconv(CHARSET, $google_base_encoding, $string);
		return $string;
	}
?>
	