<?php
/*
  ****************************************************************************
  ***                                                                      ***
  ***      ViArt Shop 3.5                                                  ***
  ***      File:  admin_reviews.php                                        ***
  ***      Built: Fri Jun 20 19:43:16 2008                                 ***
  ***                                                 ***
  ***                                                                      ***
  ****************************************************************************
*/


	include_once("./admin_config.php");
	include_once($root_folder_path."includes/common.php");
	include_once($root_folder_path . "includes/sorter.php");
	include_once($root_folder_path . "includes/navigator.php");
	include_once($root_folder_path . "includes/record.php");
	include_once($root_folder_path."messages/".$language_code."/reviews_messages.php");


	include_once("./admin_common.php");

	check_admin_security("products_reviews");

	// begin delete selected reviews
	$operation = get_param("operation");
	$items_ids = get_param("items_ids");
	$art_cat_id = get_param("art_cat_id");
	if (strlen($art_cat_id)) {
		$column_name = "article_id";
		$column_id  = get_param("article_id");
		$table_name = $table_prefix . "articles_reviews ";
	} else {
		$column_name = "item_id";
		$column_id  = get_param("item_id");
		$table_name = $table_prefix . "reviews ";
	}
	if ($operation == "delete_items" && strlen($items_ids)) {
			$items_for_del = explode(",",$items_ids);
			foreach($items_for_del as $item_for_del)
			{
	 			$db->query("DELETE FROM " . $table_name . " WHERE review_id=" . $db->tosql($item_for_del, INTEGER));		
				update_rating($table_name, $column_name, $items_for_del);
			}
			header("Location: admin_reviews.php?sf=1&art_cat_id=$art_cat_id&sort_ord=1&sort_dir=asc");
			exit;
	}
	// end delete selected reviews
	
	$t = new VA_Template($settings["admin_templates_dir"]);
	$t->set_file("main","admin_reviews.html");

	$t->set_var("admin_href", "admin.php");
	$t->set_var("admin_reviews_href", "admin_reviews.php");
	$t->set_var("admin_articles_href", "admin_articles.php");
	$t->set_var("admin_articles_top_href", "admin_articles_top.php");
	$t->set_var("admin_items_list_href", "admin_items_list.php");

	if (strlen($art_cat_id)) {
		$sql  = " SELECT category_name FROM " . $table_prefix . "articles_categories ";
		$sql .= " WHERE category_id=" . $db->tosql($art_cat_id, INTEGER);
		$db->query($sql);
		if ($db->next_record()) {
			$articles_category = get_translation($db->f("category_name"));
		} else {
			$art_cat_id = "";
		}
	}

	$t->set_var("articles_links", "");
	$t->set_var("products_links", "");
	$t->set_var("art_cat_id", htmlspecialchars($art_cat_id));
	if (strlen($art_cat_id)) {
		$t->set_var("reviews_title", ARTICLES_REVIEWS_MSG);
		$t->set_var("articles_category", $articles_category);
		$table_name = $table_prefix . "articles_reviews ";
		$t->parse("articles_links", false);
	} else {
		$t->set_var("reviews_title", PRODUCTS_REVIEWS_MSG);
		$table_name = $table_prefix . "reviews ";
		$t->parse("products_links", false);
	}

	$sf = get_param("sf");
	$s_a = get_param("s_a");
	$r = new VA_Record($table_prefix . "reviews");
	$search_values = 
		array( 
			array("", ALL_MSG), array(0, NOT_APPROVED_MSG), array(1, IS_APPROVED_MSG)
		);

	$r->add_radio("s_a", INTEGER, $search_values);
	$r->get_form_values();
	if($sf != 1) { $r->set_value("s_a", 0); }

	$r->set_parameters();
	$where = "";
	if (!$r->is_empty("s_a")) {
		$where = " WHERE approved=" . $db->tosql($r->get_value("s_a"), INTEGER);
	}

	$s = new VA_Sorter($settings["admin_templates_dir"], "sorter_img.html", "admin_reviews.php");
	$s->set_default_sorting(3, "desc");
	$s->set_sorter(ID_MSG, "sorter_review_id", "1", "review_id");
	$s->set_sorter(USER_NAME_MSG, "sorter_user_name", "2", "user_name");
	$s->set_sorter(SUMMARY_MSG, "sorter_summary", "2", "summary");
	$s->set_sorter(REVIEW_ADDED_MSG, "sorter_date_added", "3", "date_added");
	$s->set_sorter(APPROVED_QST, "sorter_approved", "4", "approved");

	$n = new VA_Navigator($settings["admin_templates_dir"], "navigator.html", "admin_reviews.php");

	include_once("./admin_header.php");
	include_once("./admin_footer.php");

	
	// set up variables for navigator
	$db->query("SELECT COUNT(*) FROM " . $table_name . $where);
	$db->next_record();
	$total_records = $db->f(0);
	$records_per_page = 25;
	$pages_number = 5;
	$page_number = $n->set_navigator("navigator", "page", SIMPLE, $pages_number, $records_per_page, $total_records, false);
	
	$db->RecordsPerPage = $records_per_page;
	$db->PageNumber = $page_number;
	$db->query("SELECT * FROM " . $table_name . $where . $s->order_by);
	$item_index = 0;
	if($db->next_record())
	{
		$t->parse("sorters", false);
		$t->set_var("no_records", "");
		$t->parse("delete_tickets_link",false);
		
		do
		{
			$item_index++;
			$t->set_var("item_index", $item_index);
			$review_id = $db->f("review_id");
			$admin_review_href = "admin_review.php?review_id=" . urlencode($review_id);
			if (strlen($sf)) { $admin_review_href .= "&sf=" . urlencode($sf); }
			if (strlen($s_a)) { $admin_review_href .= "&s_a=" . urlencode($s_a); }
			if (strlen($art_cat_id)) { $admin_review_href .= "&art_cat_id=" . urlencode($art_cat_id); }

			$t->set_var("review_id", $review_id);
			$t->set_var("admin_review_href", $admin_review_href);
			$t->set_var("user_name", htmlspecialchars($db->f("user_name")));
			$t->set_var("summary", htmlspecialchars($db->f("summary")));
			$date_added = $db->f("date_added", DATETIME);
			$t->set_var("date_added", va_date($date_show_format, $date_added));
			$approved = $db->f("approved") ? "Yes" : "No";
			$t->set_var("approved", $approved);
			$t->parse("records", true);
		} while($db->next_record());
		$t->set_var("items_number", $item_index);
	}
	else
	{
		$t->set_var("records", "");
		$t->set_var("navigator", "");
		$t->parse("no_records", false);
	}

	$t->set_var("admin_href", "admin.php");
	$t->pparse("main");
?>
