<?php
/*
  ****************************************************************************
  ***                                                                      ***
  ***      Appdragon                                                       ***
  ***      File:  admin_export_goldkatalog_yml.php                             ***
  ***      Built: Fri Jun 20 19:43:16 2010                                 ***
  ***                                                                      ***
  ***                                                                      ***
  ****************************************************************************
*/

    include_once ("./admin_config.php");
    include_once ($root_folder_path . "includes/common.php");
    include_once ($root_folder_path . "includes/record.php");
    include_once ($root_folder_path . "includes/shopping_cart.php");
    include_once ($root_folder_path . "messages/".$language_code."/cart_messages.php");
    include_once("./admin_common.php");

    define("SITE_NAME_FOR_EXPORT", "gsw.com.ua");

    header ("content-type: text/xml");

//    check_admin_security("import_export");

    $R = "<?xml version=\"1.0\" encoding=\"windows-1251\"?>
            <!DOCTYPE yml_catalog SYSTEM \"shops.dtd\">

<yml_catalog date=\"" . date('Y-m-d H:i:s') . "\">
     <shop>
      <name>Gold Silver Watches</name>
      <company>�������� ��� \"Gold Silver Watches\"</company>
      <url>http://gsw.com.ua/</url>

      
      <currencies>\n";

    $qstr = "SELECT * FROM `va_currencies` ORDER BY `currency_id`";
    $query = mysql_query($qstr);

    while($row = mysql_fetch_assoc($query)){
        $R .= "         <currency id=\"" . $row['currency_code'] . "\" rate=\"" . ($row['currency_code'] == 'UAH' ? "NBU" : $row['exchange_rate']) . "\"/>\n";
    }             

    $R .= "      </currencies>
      <categories>\n";

    $qstr = "SELECT * FROM `va_categories` ORDER BY `category_id`";
    $query = mysql_query($qstr);

    while($row = mysql_fetch_assoc($query)){
        $R .= "         <category id=\"" . $row['category_id']."\"";        
        if ($row['parent_category_id'])
        {         
         $R .=" parentID=\"" . $row['parent_category_id']."\"";
        }
        $R .=">" . $row['category_name'] . "</category>\n";
    }
                    
    $R .= "      </categories>
      <offers>\n";

    $qstr = "SELECT *
               FROM `va_items` INNER JOIN 
                    `va_items_categories` ON `va_items`.`item_id` = `va_items_categories`.`item_id`
           GROUP BY `va_items`.`item_id`";

    $query = mysql_query($qstr);
    while($row = mysql_fetch_assoc($query)){
        $features_qstr = "SELECT `feature_name`, `feature_value`
                            FROM `va_features` WHERE `va_features`.`item_id` = " . $row['item_id'] . " AND `feature_value` <> ''";
        $features = mysql_query($features_qstr);
        $desc_add = '';
        while($features_row = mysql_fetch_assoc($features)){
            $desc_add .= "<B>" . $features_row['feature_name'] . ":</B> " . $features_row['feature_value'] . "<BR>";
        }

        $R .= "         <offer id=\"" . $row['item_id'] . "\" available=\"true\">\n";
        $R .= "             <name>" . $row['item_name'] . "</name>\n";
        $R .= "             <description><![CDATA[" . $row['full_description'] . "<BR>" . $desc_add . "]]></description>\n";
        $R .= "             <url>http://" . SITE_NAME_FOR_EXPORT . "/product_details.php?item_id=" . $row['item_id'] . "</url>\n";
        $R .= "             <image>http://" . SITE_NAME_FOR_EXPORT . "/" . $row['big_image'] . "</image>\n";
        $R .= "             <price>" . $row['price'] . "</price>\n";
        $R .= "             <categoryId>" . $row['category_id'] . "</categoryId>\n";
        $R .= "             <currencyId>UAH</currencyId>\n";        
        $R .= "             <delivery>true</delivery>\n";
        $R .= "         </offer>\n";
    }

    $R .= "     </offers>    
  </shop>
</yml_catalog>";

    echo $R;
?>