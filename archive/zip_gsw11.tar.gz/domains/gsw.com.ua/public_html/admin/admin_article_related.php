<?php
/*
  ****************************************************************************
  ***                                                                      ***
  ***      ViArt Shop 3.5                                                  ***
  ***      File:  admin_article_related.php                                ***
  ***      Built: Fri Jun 20 19:43:16 2008                                 ***
  ***                                                 ***
  ***                                                                      ***
  ****************************************************************************
*/


	include_once("./admin_config.php");
	include_once($root_folder_path . "includes/common.php");
	include_once("./admin_common.php");
	include_once($root_folder_path . "includes/record.php");

	check_admin_security("articles");

	$article_id = get_param("article_id");

	$t = new VA_Template($settings["admin_templates_dir"]);
	$t->set_file("main", "admin_article_related.html");

	$t->set_var("admin_articles_top_href", "admin_articles_top.php");
	$t->set_var("admin_article_related_href", "admin_article_related.php");
	$t->set_var("admin_articles_href", "admin_articles.php");
	$t->set_var("admin_article_href",  "admin_article.php");
	$t->set_var("related_items", "");
	$t->set_var("available_items", "");

	$sql  = " SELECT article_title FROM " . $table_prefix . "articles ";
	$sql .= " WHERE article_id=" . $db->tosql($article_id, INTEGER);
	$db->query($sql);
	if($db->next_record()) {
		$t->set_var("article_title", get_translation($db->f("article_title")));
	} else {
		die(OBJECT_NO_EXISTS_MSG);
	}

	$category_id = get_param("category_id");
	$sql  = " SELECT category_path,parent_category_id ";
	$sql .= " FROM " . $table_prefix . "articles_categories ";
	$sql .= " WHERE category_id=" . $db->tosql($category_id, INTEGER);
	$db->query($sql);
	if ($db->next_record()) {
		$parent_category_id = $db->f("parent_category_id");
		$category_path = $db->f("category_path");
		if ($parent_category_id == 0) {
			$top_category_id = $category_id;
		} else {
			$categories_ids = explode(",", $category_path);
			$top_category_id = $categories_ids[1];
		}
	}

	$tree = new VA_Tree("category_id", "category_name", "parent_category_id", $table_prefix . "articles_categories", "tree", "");
	$tree->show($category_id);

	$operation = get_param("operation");
	$return_page = "admin_articles.php?category_id=" . $category_id;
	$errors = "";

	if ($operation == "cancel")
	{
		header("Location: " . $return_page);
		exit;
	}
	elseif ($operation == "save")
	{
		$related_ids = get_param("related_ids");
		
		if (!strlen($errors))
		{
			$related_ids = split(",", $related_ids);
			$db->query("DELETE FROM " . $table_prefix . "articles_related WHERE article_id=" . $article_id);
			for ($i = 0; $i < sizeof($related_ids); $i++) {
				if (strlen($related_ids[$i])) {
					$related_order = $i + 1;
					$sql  = " INSERT INTO " . $table_prefix . "articles_related (article_id, related_id, related_order) VALUES (";
					$sql .= $article_id . "," . $db->tosql($related_ids[$i], INTEGER) . "," . $related_order . ")";
					$db->query($sql);
				}
			}
			header("Location: " . $return_page);
			exit;
		}
	}



	$sql  = " SELECT ar.related_id, a.article_id, a.article_title ";
	$sql .= " FROM (((" . $table_prefix . "articles a ";
	$sql .= " INNER JOIN " . $table_prefix . "articles_assigned aa ON a.article_id=aa.article_id) ";
	$sql .= " INNER JOIN " . $table_prefix . "articles_categories ac ON aa.category_id=ac.category_id) ";
	$sql .= " LEFT JOIN " . $table_prefix . "articles_related ar ON (ar.related_id=a.article_id ";
	$sql .= " AND ar.article_id=" . $db->tosql($article_id, INTEGER) . ")) ";
	$sql .= " WHERE (ac.category_id=" . $db->tosql($top_category_id, INTEGER);
	$sql .= " OR ac.category_path LIKE '0," . $top_category_id . ",%') ";
	$sql .= " AND a.article_id<>" . $db->tosql($article_id, INTEGER);
	$sql .= " GROUP BY a.article_id, ar.related_order, ar.related_id, a.article_title ";
	$sql .= " ORDER BY ar.related_order, a.article_title ";
	$db->query($sql);
	while ($db->next_record())
	{
		$row_article_id = $db->f("article_id");
		$related_id = $db->f("related_id");
		$related_name = get_translation($db->f("article_title"));
		$category_name = get_translation($db->f("category_name"));
		$t->set_var("related_id", $row_article_id);
		$t->set_var("category_id", $db->f("category_id"));
		$t->set_var("parent_category_id", $db->f("parent_category_id"));
		$t->set_var("related_name", str_replace("\"", "&quot;", $related_name));
		if ($row_article_id == $related_id) {
			$t->parse("related_items", true);
		} else {
			$t->parse("available_items", true);
		}
	}

	if (strlen($errors))	{
		$t->set_var("errors_list", $errors);
		$t->parse("errors", false);
	} else {
		$t->set_var("errors", "");
	}

	$t->set_var("article_id", $article_id);
	$t->set_var("category_id", $category_id);

	include_once("./admin_header.php");
	include_once("./admin_footer.php");

	$t->pparse("main");

?>