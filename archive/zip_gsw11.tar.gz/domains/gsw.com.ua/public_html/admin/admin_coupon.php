<?php
/*
  ****************************************************************************
  ***                                                                      ***
  ***      ViArt Shop 3.5                                                  ***
  ***      File:  admin_coupon.php                                         ***
  ***      Built: Fri Jun 20 19:43:16 2008                                 ***
  ***                                                 ***
  ***                                                                      ***
  ****************************************************************************
*/


	include_once ("./admin_config.php");
	include_once ($root_folder_path . "includes/common.php");
	include_once("./admin_common.php");
	include_once ($root_folder_path . "includes/record.php");
	include_once ($root_folder_path."messages/".$language_code."/cart_messages.php");

	$operation   = get_param("operation");
	$coupon_id   = get_param("coupon_id");
	
	$tab = get_param("tab");
	if (!$tab) { $tab = "general"; }
	
	$order_id = get_param("order_id");

	if ($order_id > 0) {
		check_admin_security("order_vouchers");
	} else {
		check_admin_security("coupons");
	}
	
	$s = get_param("s");
	$s_a = get_param("s_a");
	$discount_type = get_param("discount_type");

	// NEW TYPES: 6 - buy one and get one free; 7 - buy one and get a % off another product
	// 8 - Amount per products quantities; don't need this one as we use discount quantity for this

	$t = new VA_Template($settings["admin_templates_dir"]);
	$t->set_file("main","admin_coupon.html");

	$t->set_var("admin_coupon_href", "admin_coupon.php");

	$r = new VA_Record($table_prefix . "coupons");
	if ($order_id > 0) {
		$r->return_page  = "admin_order_vouchers.php?order_id=" . urlencode($order_id);
	} else {
		$r->return_page  = "admin_coupons.php?s=" . $s . "&s_a=" . $s_a;
	}

	$yes_no = 
		array( 
			array(1, YES_MSG), array(0, NO_MSG)
		);

	$r->add_where("coupon_id", INTEGER);
	$r->add_textbox("order_id", INTEGER);
	$r->change_property("order_id", DEFAULT_VALUE, $order_id);
	$r->change_property("order_id", USE_IN_UPDATE, false);
	$r->add_select("order_item_id", INTEGER, "");

	$r->add_radio("is_active", INTEGER, $yes_no);
	$r->change_property("is_active", REQUIRED, true);
	$r->change_property("is_active", DEFAULT_VALUE, 1);
	$r->add_radio("is_auto_apply", INTEGER, $yes_no); // new
	$r->change_property("is_auto_apply", REQUIRED, true);
	$r->change_property("is_auto_apply", DEFAULT_VALUE, 0);

	$r->add_textbox("coupon_code", TEXT, COUPON_CODE_MSG);
	$r->change_property("coupon_code", REQUIRED, true);
	$r->change_property("coupon_code", UNIQUE, true);
	$r->change_property("coupon_code", TRIM, true);
	$r->change_property("coupon_code", MIN_LENGTH, 4);
	$r->change_property("coupon_code", MAX_LENGTH, 64);
	$r->change_property("coupon_code", DEFAULT_VALUE, strtoupper(substr(md5(va_timestamp()), 0, 8)));
	$r->add_textbox("coupon_title", TEXT, COUPON_TITLE_MSG);
	$r->change_property("coupon_title", REQUIRED, true);
	$r->add_radio("discount_type", INTEGER, "");
	$r->change_property("discount_type", REQUIRED, true);
	$r->change_property("discount_type", DEFAULT_VALUE, $discount_type);
	$r->add_textbox("discount_type_text", INTEGER);
	$r->change_property("discount_type_text", COLUMN_NAME, "discount_type");
	$r->change_property("discount_type_text", CONTROL_NAME, "discount_type");
	$r->change_property("discount_type_text", DEFAULT_VALUE, $discount_type);

	$r->add_textbox("discount_quantity", INTEGER, DISCOUNT_AMOUNT_MSG); // new
	$r->change_property("discount_quantity", DEFAULT_VALUE, 1);
	$r->add_textbox("discount_amount", NUMBER, DISCOUNT_AMOUNT_MSG);
	$r->change_property("discount_amount", REQUIRED, true);
	$r->change_property("discount_amount", DEFAULT_VALUE, 0);

	$r->add_checkbox("free_postage", NUMBER);
	$r->add_checkbox("coupon_tax_free", NUMBER);
	$r->add_checkbox("order_tax_free", NUMBER);

	$r->add_checkbox("items_all", INTEGER);
	$r->change_property("items_all", DEFAULT_VALUE, 1);
	$r->add_textbox("items_ids", TEXT);

	$r->add_checkbox("cart_items_all", INTEGER); // new
	$r->change_property("cart_items_all", DEFAULT_VALUE, 1); // new
	$r->add_textbox("cart_items_ids", TEXT); // new


	$r->add_textbox("expiry_date", DATETIME, ADMIN_EXPIRY_DATE_MSG);
	$r->change_property("expiry_date", VALUE_MASK, $date_edit_format);
	if ($discount_type != 5) {
		$r->change_property("expiry_date", DEFAULT_VALUE, va_time(va_timestamp() + (60*60*24*366)));
	}

	$r->add_textbox("min_quantity", NUMBER); // new
	$r->add_textbox("max_quantity", NUMBER); // new
	$r->add_textbox("minimum_amount", NUMBER);
	$r->add_textbox("maximum_amount", NUMBER); // new
	$r->add_checkbox("is_exclusive", NUMBER);

	// sites list
	$r->add_checkbox("sites_all", INTEGER);
	$r->change_property("sites_all", DEFAULT_VALUE, 1);
	if ($sitelist) {
		$selected_sites = array();
		if (strlen($operation)) {
			$sites = get_param("sites");
			if ($sites) {
				$selected_sites = split(",", $sites);
			}
		} elseif ($coupon_id) {
			$sql  = "SELECT site_id FROM " . $table_prefix . "coupons_sites ";
			$sql .= " WHERE coupon_id=" . $db->tosql($coupon_id, INTEGER);
			$db->query($sql);
			while ($db->next_record()) {
				$selected_sites[] = $db->f("site_id");
			}
		}
	}
	
	$r->add_textbox("quantity_limit", INTEGER);
	$r->change_property("quantity_limit", DEFAULT_VALUE, 1);
	$r->add_textbox("coupon_uses", INTEGER);
	$r->change_property("coupon_uses", DEFAULT_VALUE, 0);
	
	$r->events[BEFORE_SHOW] = "set_record_controls";
	$r->events[AFTER_REQUEST] = "set_coupon_data";
	$r->events[AFTER_VALIDATE] = "set_record_controls";	
	$r->events[BEFORE_INSERT] = "set_coupon_id";
	$r->events[AFTER_INSERT] = "update_coupon_data";
	$r->events[AFTER_UPDATE] = "update_coupon_data";
	$r->events[AFTER_DELETE] = "delete_coupon_data";
	
	$r->process();

	$t->set_var("s", $s);
	$t->set_var("s_a", $s_a);


	include_once("./admin_header.php");
	include_once("./admin_footer.php");

	$t->set_var("date_added_format", join("", $date_edit_format));
	$t->set_var("admin_href", "admin.php");
	$t->set_var("admin_coupons_href", "admin_coupons.php");
	$t->set_var("admin_orders_href",  "admin_orders.php");
	$t->set_var("admin_order_href",   $order_details_site_url . "admin_order.php");
	$t->set_var("admin_order_vouchers_href", "admin_order_vouchers.php");
	$t->set_var("admin_product_select_href", "admin_product_select.php");


	if ($order_id > 0) {
		$t->parse("orders_path", false);
	} else {
		$t->parse("coupons_path", false);
	}
	
	if ($sitelist) {
		$sites = array();
		$sql = " SELECT site_id, site_name FROM " . $table_prefix . "sites ";
		$db->query($sql);
		while ($db->next_record())	{
			$site_id   = $db->f("site_id");
			$site_name = $db->f("site_name");
			$sites[$site_id] = $site_name;
			$t->set_var("site_id", $site_id);
			$t->set_var("site_name", $site_name);
			if (in_array($site_id, $selected_sites)) {
				$t->parse("selected_sites", true);
			} else {
				$t->parse("available_sites", true);
			}
		}
	}

	$tabs = array("general" => EDIT_COUPON_MSG);
	if ($sitelist) {
		$tabs["sites"] = 'Sites';
	}
	foreach ($tabs as $tab_name => $tab_title) {
		$t->set_var("tab_id", "tab_" . $tab_name);
		$t->set_var("tab_name", $tab_name);
		$t->set_var("tab_title", $tab_title);
		if ($tab_name == $tab) {
			$t->set_var("tab_class", "adminTabActive");
			$t->set_var($tab_name . "_style", "display: block;");
		} else {
			$t->set_var("tab_class", "adminTab");
			$t->set_var($tab_name . "_style", "display: none;");
		}
		$t->parse("tabs", $tab_title);
	}
	$t->set_var("tab", $tab);
	
	if ($sitelist) {
		$t->parse('sitelist');
	}

	$t->pparse("main");
	
	function set_coupon_id()  {
		global $db, $table_prefix, $r;
		global $coupon_id;
		$sql = "SELECT MAX(coupon_id) FROM " . $table_prefix . "coupons";
		$db->query($sql);
		if($db->next_record()) {
			$coupon_id= $db->f(0) + 1;
			$r->change_property("coupon_id", USE_IN_INSERT, true);
			$r->set_value("coupon_id", $coupon_id);
		}	
	}

	function update_coupon_data()  {
		global $db, $table_prefix, $r;
		global $coupon_id;
		global $sitelist, $selected_sites;
					
		if ($sitelist) {
			$db->query("DELETE FROM " . $table_prefix . "coupons_sites WHERE coupon_id=" . $db->tosql($coupon_id, INTEGER));
			for ($st = 0; $st < sizeof($selected_sites); $st++) {
				$site_id = $selected_sites[$st];
				if (strlen($site_id)) {
					$sql  = " INSERT INTO " . $table_prefix . "coupons_sites (coupon_id, site_id) VALUES (";
					$sql .= $db->tosql($coupon_id, INTEGER) . ", ";
					$sql .= $db->tosql($site_id, INTEGER) . ") ";
					$db->query($sql);
				}
			}
		}

	}

	function delete_coupon_data()  {
		global $db, $table_prefix, $r;
		global $coupon_id;
		$db->query("DELETE FROM " . $table_prefix . "coupons_sites WHERE coupon_id=" . $db->tosql($coupon_id, INTEGER));
	}
	
	
	function set_record_controls()
	{
		global $t, $r, $db, $table_prefix;
		$discount_type = $r->get_value("discount_type");

		if ($r->get_value("order_id") < 1) {
			$r->set_value("order_id", 0);
			$r->set_value("order_item_id", 0);
			$r->change_property("order_item_id", SHOW, false);
		} else {
			$order_items = array();
			$sql  = " SELECT oi.order_item_id,oi.item_name ";
			$sql .= " FROM (" . $table_prefix . "orders_items oi ";
			$sql .= " LEFT JOIN " . $table_prefix . "item_types it ON oi.item_type_id=it.item_type_id) ";
			$sql .= " WHERE oi.order_id=" . $db->tosql($r->get_value("order_id"), INTEGER);
			$sql .= " AND it.is_gift_voucher=1 ";
			$order_items = get_db_values($sql, array(array("", "")));
			$r->change_property("order_item_id", VALUES_LIST, $order_items);
		}
		if ($discount_type <= 2) {
			$discount_types = array( array(1, PERCENTAGE_PER_ORDER_MSG), array(2, AMOUNT_PER_ORDER_MSG) );
			$r->change_property("discount_type", VALUES_LIST, $discount_types);
			$r->change_property("items_ids", SHOW, false);
			$r->change_property("discount_type_text", SHOW, false);
			$r->change_property("discount_type_text", USE_IN_INSERT, false);
			$r->change_property("discount_type_text", USE_IN_UPDATE, false);
			$r->change_property("discount_quantity",SHOW, false);
			$t->set_var("minimum_amount_title", MINIMUM_PURCHASE_AMOUNT_MSG);
			$t->set_var("maximum_amount_title", MAXIMUM_PURCHASE_AMOUNT_MSG);
			$t->set_var("min_quantity_desc", MINIMUM_PURCHASE_AMOUNT_NOTE);
			$t->set_var("max_quantity_desc", MAXIMUM_PURCHASE_AMOUNT_NOTE);
		} else if ($discount_type == 5) {
			$r->change_property("items_ids",     SHOW, false);
			$r->change_property("free_postage",  SHOW, false);
			$r->change_property("coupon_tax_free",SHOW, false);
			$r->change_property("order_tax_free",SHOW, false);
			$r->change_property("discount_quantity",SHOW, false);
			$r->change_property("min_quantity",SHOW, false);
			$r->change_property("max_quantity",SHOW, false);
			$r->change_property("minimum_amount",SHOW, false);
			$r->change_property("maximum_amount",SHOW, false);
			$r->change_property("discount_type", SHOW, false);
			$r->change_property("is_exclusive",  SHOW, false);
			$r->change_property("quantity_limit",SHOW, false);
			$r->set_value("quantity_limit", 0);
			$r->change_property("discount_type", USE_IN_INSERT, false);
			$r->change_property("discount_type", USE_IN_UPDATE, false);
		} else  {
			$discount_types = array( array(3, PERCENTAGE_PER_PRODUCT_MSG), array(4, AMOUNT_PER_PRODUCT_MSG));
			$r->change_property("discount_type", VALUES_LIST, $discount_types);
			$r->change_property("free_postage", SHOW, false);
			$r->change_property("coupon_tax_free",SHOW, false);
			$r->change_property("order_tax_free", SHOW, false);
			$r->change_property("discount_type_text", SHOW, false);
			$r->change_property("discount_type_text", USE_IN_INSERT, false);
			$r->change_property("discount_type_text", USE_IN_UPDATE, false);
			$t->set_var("minimum_amount_title", MINIMUM_PRICE_OF_PRODUCT_MSG);
			$t->set_var("maximum_amount_title", MAXIMUM_PRICE_OF_PRODUCT_MSG);
			$t->set_var("min_quantity_desc", MIN_QTY_SAME_PRODUCTS_MSG);
			$t->set_var("max_quantity_desc", MAX_QTY_SAME_PRODUCTS_MSG);

			$items_ids = $r->get_value("items_ids");
			if ($items_ids) {
				$sql  = " SELECT i.item_id, i.item_name ";
				$sql .= " FROM " . $table_prefix . "items i ";
		    $sql .= " WHERE item_id IN (" . $db->tosql($items_ids, TEXT, false) . ")";
				$sql .= " ORDER BY i.item_name ";
				$db->query($sql);
				while($db->next_record())
				{
					$row_item_id = $db->f("item_id");
					$item_name = $db->f("item_name");
		  
					$t->set_var("related_id", $row_item_id);
					$t->set_var("item_name", $item_name);
					$t->set_var("item_name_js", str_replace("\"", "&quot;", $item_name));
		  
					$t->parse("selected_items", true);
					$t->parse("selected_items_js", true);
				}
			}
		}
	}

	function set_coupon_data()  
	{
		global $r, $sitelist;
		if (!$sitelist) {
			$r->set_value("sites_all", 1);
		}
	}

	

?>