<?php
/*
  ****************************************************************************
  ***                                                                      ***
  ***      ViArt Shop 3.5                                                  ***
  ***      File:  admin_ads_edit.php                                       ***
  ***      Built: Fri Jun 20 19:43:16 2008                                 ***
  ***                                                 ***
  ***                                                                      ***
  ****************************************************************************
*/


	include_once("./admin_config.php");
	include_once($root_folder_path . "includes/common.php");
	include_once("./admin_common.php");
	include_once($root_folder_path . "includes/record.php");
	include_once($root_folder_path . "includes/friendly_functions.php");

	check_admin_security("ads");

	$category_id = get_param("category_id");
	
	$content_types = 
		array( 
			array(1, HTML_MSG), array(0, PLAIN_TEXT_MSG)
		);

	$t = new VA_Template($settings["admin_templates_dir"]);
	$t->set_file("main", "admin_ads_edit.html");

	$t->set_var("admin_ads_edit_href", "admin_ads_edit.php");
	$t->set_var("admin_upload_href", "admin_upload.php");
	$t->set_var("admin_select_href", "admin_select.php");
	$t->set_var("admin_ads_href", "admin_ads.php");
	$t->set_var("date_format", join("", $date_edit_format));

	$t->set_var("currency_left", $currency["left"]);
	$t->set_var("currency_right", $currency["right"]);
	$t->set_var("currency_rate", $currency["rate"]);

	$duplicate_properties = get_param("duplicate_properties");
	$duplicate_specification = get_param("duplicate_specification");
	$duplicate_categories = get_param("duplicate_categories");
	$duplicate_images = get_param("duplicate_images");

	$tree = new VA_Tree("category_id", "category_name", "parent_category_id", $table_prefix . "ads_categories", "tree", "Ads");
	$tree->show($category_id);

	$approve_values = array(array(1, YES_MSG), array(0, NO_MSG));
	$days_to_run = array(
		array("", ""), array(0, CLOSED_MSG), array(1, "1 " . DAY_MSG), array(3, "3 " . DAYS_MSG), 
		array(7, "7 " . DAYS_MSG), array(14, "14 " . DAYS_MSG), array(30, "30 " . DAYS_MSG), 
		array(60, "60 " . DAYS_MSG), array(90, "90 " . DAYS_MSG), array(180, "180 " . DAYS_MSG)
	);
	$item_types = get_db_values("SELECT * FROM " . $table_prefix . "ads_types", array(array("", "")));
	$states = get_db_values("SELECT state_id,state_name FROM " . $table_prefix . "states ORDER BY state_name ", array(array("", SELECT_STATE_MSG)));
	$countries = get_db_values("SELECT country_id,country_name FROM " . $table_prefix . "countries ORDER BY country_order, country_name ", array(array("", SELECT_COUNTRY_MSG)));

	$r = new VA_Record($table_prefix . "ads_items");

	// set up html form parameters
	$r->add_where("item_id", INTEGER);
	$r->change_property("item_id", USE_IN_INSERT, true);
	$r->add_hidden("category_id", INTEGER);
	$r->add_radio("is_approved", INTEGER, $approve_values, IS_APPROVED_MSG);

	$r->add_select("type_id", INTEGER, $item_types, TYPE_MSG);
	$r->parameters["type_id"][REQUIRED] = true;
	$r->add_textbox("language_code", TEXT);
	$r->change_property("language_code", USE_SQL_NULL, false);
	//$r->add_textbox("item_order", INTEGER);
	$r->add_textbox("item_title", TEXT, TITLE_MSG);
	$r->parameters["item_title"][REQUIRED] = true;
	$r->add_textbox("friendly_url", TEXT, FRIENDLY_URL_MSG);
	$r->change_property("friendly_url", USE_SQL_NULL, false);
	$r->change_property("friendly_url", BEFORE_VALIDATE, "validate_friendly_url");
	$r->add_textbox("admin_id", INTEGER);
	$r->add_textbox("user_id", INTEGER);
	$r->change_property("user_id", USE_IN_INSERT, false);
	$r->change_property("user_id", USE_IN_UPDATE, false);

	$r->add_textbox("date_start",   DATETIME);
	$r->change_property("date_end",   REQUIRED, true);
	$r->change_property("date_start", VALUE_MASK, $date_edit_format);
	$r->add_select("days_to_run", INTEGER, $days_to_run, AD_RUNS_MSG);
	$r->change_property("days_to_run",   REQUIRED, true);
	$r->change_property("days_to_run", USE_IN_INSERT, false);
	$r->change_property("days_to_run", USE_IN_UPDATE, false);
	$r->change_property("days_to_run", USE_IN_SELECT, false);

	$r->add_textbox("date_end",     DATETIME);
	$r->change_property("date_end", VALUE_MASK, $date_edit_format);
	$r->add_textbox("date_added",   DATETIME);
	$r->change_property("date_added", USE_IN_UPDATE, false);
	$r->add_textbox("date_updated", DATETIME);

	$r->add_textbox("price", NUMBER, PRICE_MSG);
	$r->parameters["price"][REQUIRED] = true;
	$r->add_textbox("quantity", NUMBER);
	$r->add_textbox("availability", TEXT);
	$r->add_checkbox("is_compared", INTEGER);
	$r->add_textbox("total_views", INTEGER);
	$r->change_property("total_views", USE_IN_INSERT, false);
	$r->change_property("total_views", USE_IN_UPDATE, false);

	$r->add_checkbox("is_hot", INTEGER);
	$r->add_textbox("hot_description", TEXT);
	$r->add_textbox("short_description", TEXT);
	$r->add_textbox("full_description", TEXT);
	$r->add_textbox("image_small", TEXT);
	$r->add_textbox("image_large", TEXT);

	$r->add_textbox("location_info", TEXT);
	$r->add_textbox("location_city", TEXT);
	$r->add_textbox("location_postcode", ZIP_FIELD);
	$r->change_property("location_postcode", USE_SQL_NULL, false);
	$r->add_select("location_state_id", INTEGER, $states, STATE_FIELD);
	$r->change_property("location_state_id", USE_SQL_NULL, false);
	$r->add_select("location_country_id", INTEGER, $countries, COUNTRY_FIELD);
	$r->change_property("location_country_id", USE_SQL_NULL, false);

	$r->get_form_values();

	$item_id = get_param("item_id");
	$operation = get_param("operation");
	$return_page = "admin_ads.php?category_id=" . $category_id;

	if (strlen($operation))
	{
		if ($operation == "cancel")
		{
			header("Location: " . $return_page);
			exit;
		}
		elseif ($operation == "delete" && $item_id)
		{
			// ads tables with item_id: 
			$db->query("DELETE FROM " . $table_prefix . "ads_properties WHERE item_id=" . $db->tosql($item_id, INTEGER));		
			$db->query("DELETE FROM " . $table_prefix . "ads_assigned WHERE item_id=" . $db->tosql($item_id, INTEGER));		
			$db->query("DELETE FROM " . $table_prefix . "ads_features WHERE item_id=" . $db->tosql($item_id, INTEGER));		
			$db->query("DELETE FROM " . $table_prefix . "ads_images WHERE item_id=" . $db->tosql($item_id, INTEGER));		
			$db->query("DELETE FROM " . $table_prefix . "ads_items WHERE item_id=" . $db->tosql($item_id, INTEGER));		

			header("Location: " . $return_page);
			exit;
		}

		$is_valid = $r->validate();
		
		if ($is_valid)
		{
			$date_start = $r->get_value("date_start");
			$days_to_run = $r->get_value("days_to_run");
			$date_end_ts = mktime(0,0,0, $date_start[MONTH], $date_start[DAY] + $days_to_run, $date_start[YEAR]);
			$r->set_value("date_end", va_time($date_end_ts));
			$r->set_value("admin_id", get_session("session_admin_id"));

			if ($operation == "duplicate" && $item_id) {
				// duplicate product with new id 
				$db->query("SELECT MAX(item_id) FROM " . $table_prefix . "ads_items");
				$db->next_record();
				$new_item_id = $db->f(0) + 1;
				$r->set_value("item_title", $r->get_value("item_title") . " (".DUPLICATE_BUTTON.")");
				$r->set_value("item_id", $new_item_id);
				$record_updated = $r->insert_record();


				// duplicate product features
				if ($record_updated && $duplicate_specification == 1) {
					$item_features = array();
					$sql  = " SELECT group_id, feature_name, feature_value FROM " . $table_prefix . "features ";
					$sql .= " WHERE item_id=" . $db->tosql($item_id, INTEGER);
					$sql .= " ORDER BY feature_id ";
					$db->query($sql);
					while ($db->next_record()) {
						$item_features[] = array($db->f("group_id"), $db->f("feature_name"), $db->f("feature_value"));
					}
					for ($i = 0; $i < sizeof($item_features); $i++) {
						$group_id = $item_features[$i][0];
						$feature_name = $item_features[$i][1];
						$feature_value = $item_features[$i][2];
						$sql  = " INSERT INTO " . $table_prefix . "ads_features (item_id, group_id, feature_name, feature_value) VALUES (";
						$sql .= $db->tosql($new_item_id, INTEGER) . "," . $db->tosql($group_id, INTEGER) . "," . $db->tosql($feature_name, TEXT) . "," . $db->tosql($feature_value, TEXT) . ")";
						$db->query($sql);
					}
				}
				
				// duplicate product categories
				if ($record_updated && $duplicate_categories == 1) {
					$item_categories = array();
					$sql  = " SELECT category_id FROM " . $table_prefix . "ads_categories ";
					$sql .= " WHERE item_id=" . $db->tosql($item_id, INTEGER);
					$db->query($sql);
					while ($db->next_record()) {
						$item_categories[] = $db->f("category_id");
					}
					for ($i = 0; $i < sizeof($item_categories); $i++) {
						$item_category_id = $item_categories[$i];
						$sql  = " INSERT INTO " . $table_prefix . "ads_categories (item_id,category_id) VALUES (";
						$sql .= $db->tosql($new_item_id, INTEGER) . ",";
						$sql .= $db->tosql($item_category_id, INTEGER) . ")";
						$db->query($sql);
					}
				} else {
					$sql  = " INSERT INTO " . $table_prefix . "ads_categories (item_id,category_id) VALUES (";
					$sql .= $db->tosql($new_item_id, INTEGER) . ",";
					$sql .= $db->tosql($category_id, INTEGER) . ")";
					$db->query($sql);
				}

				// duplicate product images
				if ($record_updated && $duplicate_images == 1) {
					$item_images = array();
					$sql  = " SELECT image_small, small_width, small_height, ";
					$sql .= " image_large, image_title, image_description ";
					$sql .= " FROM " . $table_prefix . "ads_images ";
					$sql .= " WHERE item_id=" . $db->tosql($item_id, INTEGER);
					$db->query($sql);
					while ($db->next_record()) {
						$item_images[] = array(
							$db->f("image_small"), $db->f("small_width"), $db->f("small_height"),
							$db->f("image_large"), $db->f("image_title"), $db->f("image_description")
						);
					}
					for ($i = 0; $i < sizeof($item_images); $i++) {
						list ($image_small, $small_width, $small_height, $image_large, $image_title, $image_description) = $item_images[$i];
						$sql  = " INSERT INTO " . $table_prefix . "ads_images ";
						$sql .= " (item_id, image_small, small_width, small_height, image_large, image_title, image_description) VALUES (";
						$sql .= $db->tosql($new_item_id, INTEGER) . "," . $db->tosql($image_small, TEXT) . ",";
						$sql .= $db->tosql($small_width, INTEGER) . "," . $db->tosql($small_height, INTEGER) . ",";
						$sql .= $db->tosql($image_large, TEXT) . "," . $db->tosql($image_title, TEXT) . "," . $db->tosql($image_description, TEXT) . ")";
						$db->query($sql);
					}
				}

				// duplicate all properties
				if ($record_updated && $duplicate_properties == 1) {
					$item_properties = array();
					$sql  = " SELECT * FROM " . $table_prefix . "ads_properties ";
					$sql .= " WHERE item_id=" . $db->tosql($item_id, INTEGER);
					$db->query($sql);
					if ($db->next_record()) {
						do {
							$item_properties[] = array($db->f("property_id"), $db->f("property_name"), $db->f("property_value"));
						} while ($db->next_record());
			  
						$ip = new VA_Record($table_prefix . "ads_properties");
						$ip->add_textbox("property_id", INTEGER);
						$ip->add_textbox("item_id", INTEGER);
						$ip->add_textbox("property_name", TEXT);
						$ip->add_textbox("property_value", TEXT);
						$ip->set_value("item_id", $new_item_id);
						
						for ($i = 0; $i < sizeof($item_properties); $i++) {
							$property_id = $item_properties[$i][0];
							$db->query("SELECT MAX(property_id) FROM " . $table_prefix . "ads_properties ");
							$db->next_record();
							$new_property_id = $db->f(0) + 1;
							$ip->set_value("property_id", $new_property_id);
							$ip->set_value("property_name", $item_properties[$i][1]);
							$ip->set_value("property_value", $item_properties[$i][2]);
							$ip->insert_record();
						}
					}
				}
				// end of saving properties

			} elseif (strlen($item_id)) {
				set_friendly_url();
				$r->set_value("date_updated", va_time());
				$record_updated = $r->update_record();
			} else {
				set_friendly_url();
				$r->set_value("date_added", va_time());
				$r->set_value("date_updated", va_time());
				$db->query("SELECT MAX(item_id) FROM " . $table_prefix . "ads_items");
				$db->next_record();
				$item_id = $db->f(0) + 1;
				$r->set_value("item_id", $item_id);
				$record_updated = $r->insert_record();
				if ($record_updated) {
					$sql  = " INSERT INTO " . $table_prefix . "ads_assigned (item_id,category_id) VALUES (";
					$sql .= $db->tosql($item_id, INTEGER) . ",";
					$sql .= $db->tosql($category_id, INTEGER) . ")";
					$db->query($sql);
				} else {
					$item_id = "";
					$r->set_value("item_id", "");
				}
			}
	
			if ($record_updated) {
				header("Location: " . $return_page);
				exit;
			}
		}
	}
	elseif (strlen($item_id))
	{
		$r->get_db_values();
		$date_start = $r->get_value("date_start");
		$date_end = $r->get_value("date_end");
		$date_start_ts = mktime(0,0,0, $date_start[MONTH], $date_start[DAY], $date_start[YEAR]);
		$date_end_ts = mktime(0,0,0, $date_end[MONTH], $date_end[DAY], $date_end[YEAR]);
		$time_to_run = $date_end_ts - $date_start_ts;
		$days_to_run = round($time_to_run / (60 * 60 * 24));
		$r->set_value("days_to_run", $days_to_run);
	}
	else // new record (set default values)
	{
		$r->set_value("is_approved", 1);
		$r->set_value("date_start", va_time());
		$r->set_value("days_to_run", 14);
/*
		$sql  = " SELECT MAX(item_order) FROM " . $table_prefix . "ads_items i, " . $table_prefix . "ads_assigned ic ";
		$sql .= " WHERE i.item_id=ic.item_id ";
		$sql .= " AND ic.category_id=" . $db->tosql($category_id, INTEGER);
		$item_order = get_db_value($sql);
		$item_order = ($item_order) ? ($item_order + 1) : 1;
		$r->set_value("item_order", $item_order);
*/
	}

	$r->set_form_parameters();

	if (strlen($item_id))	
	{
		// set created by link
		$user_id = $r->get_value("user_id");
		$admin_id = $r->get_value("admin_id");
		if ($user_id) {
			$created_by = get_db_value("SELECT login FROM " . $table_prefix . "users WHERE user_id=" . $db->tosql($user_id, INTEGER));
			$created_by_href = "admin_user.php?user_id=" . $user_id;
		} else {
			$created_by = get_db_value("SELECT login FROM " . $table_prefix . "admins WHERE admin_id=" . $db->tosql($admin_id, INTEGER));
			$created_by_href = "admin_admin.php?admin_id=" . $admin_id;
		}		
		$t->set_var("created_by", $created_by);
		$t->set_var("created_by_href", $created_by_href);
		
		$duplicate_properties    = ($duplicate_properties == 1) ? " checked " : "";
		$duplicate_specification = ($duplicate_specification == 1) ? " checked " : "";
		$duplicate_categories    = ($duplicate_categories == 1) ? " checked " : "";
		$duplicate_images        = ($duplicate_images == 1) ? " checked " : "";

		$t->set_var("duplicate_properties",    $duplicate_properties);
		$t->set_var("duplicate_specification", $duplicate_specification);
		$t->set_var("duplicate_categories",    $duplicate_categories);
		$t->set_var("duplicate_images",        $duplicate_images);

		$t->set_var("save_button", UPDATE_BUTTON);
		$t->parse("delete", false);	
		$t->parse("duplicate", false);	
	}
	else
	{
		$t->set_var("save_button", ADD_NEW_MSG);
		$t->set_var("delete", "");	
		$t->set_var("duplicate", "");	
	}

	include_once("./admin_header.php");
	include_once("./admin_footer.php");

	$t->pparse("main");

?>