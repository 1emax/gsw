<?php
/*
  ****************************************************************************
  ***                                                                      ***
  ***      ViArt Shop 3.5                                                  ***
  ***      File:  admin_review.php                                         ***
  ***      Built: Fri Jun 20 19:43:16 2008                                 ***
  ***                                                 ***
  ***                                                                      ***
  ****************************************************************************
*/


	include_once("./admin_config.php");
	include_once($root_folder_path."includes/common.php");
	include_once($root_folder_path . "includes/record.php");
	include_once($root_folder_path."messages/".$language_code."/reviews_messages.php");

	include_once("./admin_common.php");

	check_admin_security("products_reviews");

	$sf = get_param("sf");
	$s_a = get_param("s_a");

	$t = new VA_Template($settings["admin_templates_dir"]);
	$t->set_file("main","admin_review.html");
	$t->set_var("admin_href", "admin.php");
	$t->set_var("admin_review_href", "admin_review.php");
	$t->set_var("admin_articles_href", "admin_articles.php");
	$t->set_var("admin_articles_top_href", "admin_articles_top.php");
	$t->set_var("admin_items_list_href", "admin_items_list.php");

	$art_cat_id = get_param("art_cat_id");
	if (strlen($art_cat_id)) {
		$sql  = " SELECT category_name FROM " . $table_prefix . "articles_categories ";
		$sql .= " WHERE category_id=" . $db->tosql($art_cat_id, INTEGER);
		$db->query($sql);
		if ($db->next_record()) {
			$articles_category = $db->f("category_name");
		} else {
			$art_cat_id = "";
		}
	}

	$reviews_href  = "admin_reviews.php";
	$reviews_href .= "?sf=" . urlencode($sf);
	if(strlen($s_a)) {
		$reviews_href .= "&s_a=" . urlencode($s_a);
	}
	if(strlen($art_cat_id)) {
		$reviews_href .= "&art_cat_id=" . urlencode($art_cat_id);
	}


	$t->set_var("articles_links", "");
	$t->set_var("products_links", "");
	$t->set_var("art_cat_id", htmlspecialchars($art_cat_id));
	$t->set_var("admin_reviews_href", $reviews_href);
	if (strlen($art_cat_id)) {
		$column_name = "article_id";
		$column_id  = get_param("article_id");
		$table_name = $table_prefix . "articles_reviews ";

		$t->set_var("reviewed_item", "article");
		$t->set_var("reviewed_item_title", ARTICLE_TITLE_MSG);
		$t->set_var("articles_category", $articles_category);
		$t->parse("articles_links", false);
	} else {
		$column_name = "item_id";
		$column_id  = get_param("item_id");
		$table_name = $table_prefix . "reviews ";

		$t->set_var("reviewed_item", "product");
		$t->set_var("reviewed_item_title", ADMIN_PRODUCT_MSG);
		$t->parse("products_links", false);
	}
	$t->set_var("column_name", htmlspecialchars($column_name));
	$t->set_var("column_id", htmlspecialchars($column_id));

	$r = new VA_Record($table_name);
	$r->return_page = $reviews_href;

	$yes_no = 
		array( 
			array(0, NO_MSG), array(1, YES_MSG)
		);

	$ratings = 
		array( 
			array(0, NONE_MSG), array(1, 1), array(2, 2), array(3, 3), array(4, 4), array(5, 5)
		);

	$r->add_where("review_id", INTEGER);
	$r->add_textbox($column_name, INTEGER);
	$r->change_property($column_name, USE_IN_UPDATE, false);
	$r->add_textbox("date_added", DATETIME, REVIEW_DATE_MSG);
	$r->change_property("date_added", REQUIRED, true);
	$r->change_property("date_added", VALUE_MASK, $datetime_edit_format);
	$r->add_textbox("summary", TEXT);
	$r->add_textbox("comments", TEXT);
	$r->add_textbox("user_name", TEXT, USER_NAME_MSG);
	$r->change_property("user_name", REQUIRED, true);
	$r->add_textbox("remote_address", TEXT);
	$r->add_radio("recommended", INTEGER, $yes_no);
	$r->change_property("recommended", REQUIRED, true);
	$r->add_radio("approved", INTEGER, $yes_no);
	$r->add_radio("rating", INTEGER, $ratings);

	$r->get_form_values();

	$review_id = get_param("review_id");
	if(!strlen($review_id))	
	{
		header("Location: " . $r->return_page);
		exit;
	}

	$operation = get_param("operation");
	if(strlen($operation))
	{
		if($operation == "cancel")
		{
			header("Location: " . $r->return_page);
			exit;
		}
		else if($operation == "delete" && $review_id)
		{
			$db->query("DELETE FROM " . $table_name . " WHERE review_id=" . $db->tosql($review_id, INTEGER));		

			update_rating($table_name, $column_name, $review_id);

			header("Location: " . $r->return_page);
			exit;
		}

		$is_valid = $r->validate();

		if($is_valid)
		{
			if (strlen($r->get_value("review_id"))) {
				$r->update_record();
			} else {
				//posibility to add review from admin
				//$r->insert_record();
			}

			update_rating($table_name, $column_name, $r->get_value("review_id"));

			header("Location: " . $r->return_page);
			exit;
		}
	}
	else if(strlen($r->get_value("review_id")))
	{
		$r->get_db_values();
	}

	$r->set_parameters();

	if (strlen($art_cat_id)) {
		$sql = "SELECT article_title FROM " . $table_prefix . "articles WHERE article_id=" . $db->tosql($r->get_value($column_name), INTEGER);
	} else {
		$sql = "SELECT item_name FROM " . $table_prefix . "items WHERE item_id=" . $db->tosql($r->get_value($column_name), INTEGER);
	}
	$t->set_var("reviewed_item_name", get_db_value($sql));	

	$t->set_var("sf", $sf);
	$t->set_var("s_a", $s_a);

	include_once("./admin_header.php");
	include_once("./admin_footer.php");

	$t->set_var("date_added_format", join("", $datetime_edit_format));
	$t->pparse("main");


?>