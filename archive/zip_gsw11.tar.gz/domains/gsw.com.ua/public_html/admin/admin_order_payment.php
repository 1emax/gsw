<?php
/*
  ****************************************************************************
  ***                                                                      ***
  ***      ViArt Shop 3.5                                                  ***
  ***      File:  admin_order_payment.php                                  ***
  ***      Built: Fri Jun 20 19:43:16 2008                                 ***
  ***                                                 ***
  ***                                                                      ***
  ****************************************************************************
*/


	check_admin_security("create_orders");
	
	$rp = new VA_Record($table_prefix . "orders");
	$rp->errors = "";

	$rp->add_where("order_id", INTEGER);
	$rp->set_value("order_id", $order_id);

	$rp->add_textbox("order_status", INTEGER);
	$rp->add_textbox("error_message", TEXT);
	$rp->add_textbox("pending_message", TEXT);
	$rp->add_textbox("transaction_id", TEXT);
	$rp->change_property("transaction_id", USE_IN_UPDATE, false);
	$order_status = 3;
	$rp->set_value("order_status", 3);


	if ($rp->is_empty("order_id")) {
		$rp->errors .= MISSING_ORDER_NUMBER_MSG."<br>";
	}
	
	if (!strlen($rp->errors))
	{
		$payment_id = "";
		$sql  = " SELECT ps.payment_id ";
		$sql .= " FROM " . $table_prefix . "orders o, " . $table_prefix . "payment_systems ps ";
		$sql .= " WHERE o.payment_id=ps.payment_id ";
		$sql .= " AND o.order_id=" . $db->tosql($order_id, INTEGER);
		$db->query($sql);
		if ($db->next_record()) {
			$payment_id = $db->f("payment_id");
		}

		// get orders variables
		$variables = array();
		$cart_items = array();		
		$variables["order_id"] = $order_id;
		
		$sql = "SELECT * FROM " . $table_prefix . "orders WHERE order_id=" . $db->tosql($order_id, INTEGER);
		$db->query($sql);
		if ($db->next_record()) {
			for ($i = 0; $i < sizeof($parameters); $i++) {
				$variables[$parameters[$i]] = $db->f($parameters[$i]);
				$variables["delivery_" . $parameters[$i]] = $db->f("delivery_" . $parameters[$i]);
			}
			for ($i = 0; $i < sizeof($cc_parameters); $i++) {
				$variables[$cc_parameters[$i]] = $db->f($cc_parameters[$i]);
			}
			if (strlen($variables["cc_name"]) && !strlen($variables["cc_first_name"]) && !strlen($variables["cc_last_name"])) {
				$cc_name = $variables["cc_name"];
				$name_parts = explode(" ", $cc_name, 2);
				if (sizeof($name_parts) == 2) {
					$variables["cc_first_name"] = $name_parts[0];
					$variables["cc_last_name"] = $name_parts[1];
				} else {
					$variables["cc_first_name"] = $name_parts[0];
					$variables["cc_last_name"] = "";
				}
			} elseif (!strlen($variables["cc_name"]) && (strlen($variables["cc_first_name"]) || strlen($variables["cc_last_name"]))) {
				$variables["cc_name"] = trim($variables["cc_first_name"] . " " . $variables["cc_last_name"]);
			}
			$address = $variables["address2"] ? ($variables["address1"] . " " . $variables["address2"]) : $variables["address1"];
			$delivery_address = $variables["delivery_address2"] ? ($variables["delivery_address1"] . " " . $variables["delivery_address2"]) : $variables["delivery_address1"];
			$address_number = (preg_match("/\d+/", $address, $match)) ? $match[0] : "";
			$delivery_address_number = (preg_match("/\d+/", $delivery_address, $match)) ? $match[0] : "";
			$variables["address"] = $address;
			$variables["address_number"] = $address_number;
			$variables["delivery_address"] = $delivery_address;
			$variables["delivery_address_number"] = $delivery_address_number;
		
			$order_placed_date = $db->f("order_placed_date", DATETIME);
			$cc_start_date = $db->f("cc_start_date", DATETIME);
			$cc_expiry_date = $db->f("cc_expiry_date", DATETIME);
		
			$timestamp = mktime($order_placed_date[HOUR], $order_placed_date[MINUTE], $order_placed_date[SECOND], $order_placed_date[MONTH], $order_placed_date[DAY], $order_placed_date[YEAR]);
			$vc = md5($order_id . $order_placed_date[HOUR] . $order_placed_date[MINUTE] . $order_placed_date[SECOND]);
		
			$user_id = $db->f("user_id");
			$affiliate_code = $db->f("affiliate_code");
			$order_currency_code = $db->f("currency_code");
			$order_currency_rate = $db->f("currency_rate");
			$goods_total = $db->f("goods_total");
			$total_discount = $db->f("total_discount");
			$properties_total = $db->f("properties_total");
			$properties_taxable = $db->f("properties_taxable");
			$shipping_cost = $db->f("shipping_cost");
			$shipping_taxable = $db->f("shipping_taxable");
			$total_quantity = $db->f("total_quantity");
			$weight_total = $db->f("weight_total");
			$tax_name = $db->f("tax_name");
			$tax_percent = $db->f("tax_percent");
			$tax_cost = $db->f("tax_total");
			$order_total = $db->f("order_total");
		
			// get payment rate for the selected gateway
			$payment_rate = get_payment_rate($payment_id, $order_currency_rate);
		
			// get numeric code
			$order_currency = get_currency($order_currency_code);
			$order_currency_value = $order_currency["value"];
			$order_currency_decimals = $currency["decimals"];
		
			$variables["vc"] = $vc;
			$variables["timestamp"] = $timestamp;
			$variables["order_placed_timestamp"] = $timestamp;
			$variables["order_placed_date"] = va_date($datetime_show_format, $order_placed_date);
			$variables["cc_start_date"] = va_date(array("MM"," / ","YYYY"), $cc_start_date);
			$variables["cc_expiry_date"] = va_date(array("MM"," / ","YYYY"), $cc_expiry_date);
			$variables["cc_start_year"] = va_date(array("YY"), $cc_start_date);
			$variables["cc_start_yyyy"] = va_date(array("YYYY"), $cc_start_date);
			$variables["cc_expiry_year"] = va_date(array("YY"), $cc_expiry_date);
			$variables["cc_expiry_yyyy"] = va_date(array("YYYY"), $cc_expiry_date);
			$variables["cc_start_month"] = va_date(array("MM"), $cc_start_date);
			$variables["cc_expiry_month"] = va_date(array("MM"), $cc_expiry_date);
		
			$variables["user_id"] = $user_id;
			$variables["affiliate_code"] = $affiliate_code;
			$variables["currency_code"] = $order_currency_code;
			$variables["currency_value"] = $order_currency_value;
			$variables["currency_rate"] = $order_currency_rate;
			$variables["goods_total"] = round($goods_total * $payment_rate, $order_currency_decimals);
			$variables["total_discount"] = round($total_discount * $payment_rate, $order_currency_decimals);
			$goods_with_discount = $goods_total - $total_discount;
			$variables["goods_with_discount"] = round($goods_with_discount * $payment_rate, $order_currency_decimals);
			$variables["total_quantity"] = $total_quantity;
			$variables["weight_total"] = $weight_total;
			$variables["total_weight"] = $weight_total;
			$variables["properties_total"] = number_format($properties_total * $payment_rate, $order_currency_decimals, ".", "");
			$variables["properties_taxable"] = $properties_taxable;
			$variables["shipping_cost"] = round($shipping_cost * $payment_rate, $order_currency_decimals);
			$variables["shipping_taxable"] = $shipping_taxable;
			$variables["tax_name"] = $tax_name;
			$variables["tax_percent"] = $tax_percent;
			$variables["tax_cost"] = $tax_cost;
			$variables["order_total"] = number_format($order_total * $payment_rate, $order_currency_decimals, ".", "");
			$variables["order_total_100"] = round($order_total * $payment_rate * 100, 0);
		
			$variables["company_select"] = get_db_value("SELECT company_name FROM " . $table_prefix . "companies WHERE company_id=" . $db->tosql($variables["company_id"], INTEGER));
			$variables["state"] = get_db_value("SELECT state_name FROM " . $table_prefix . "states WHERE state_id=" . $db->tosql($variables["state_id"], TEXT));
			if (strlen($variables["state_id"])) {
				$variables["state_id_or_province"] = $variables["state_id"];
				$variables["state_or_province"] = $variables["state"];
			} else {
				$variables["state_id_or_province"] = $variables["province"];
				$variables["state_or_province"] = $variables["province"];
			}
			$variables["country"] = get_db_value("SELECT country_name FROM " . $table_prefix . "countries WHERE country_id=" . $db->tosql($variables["country_id"], TEXT));
			$variables["delivery_company_select"] = get_db_value("SELECT company_name FROM " . $table_prefix . "companies WHERE company_id=" . $db->tosql($variables["delivery_company_id"], INTEGER));
			$variables["delivery_state"] = get_db_value("SELECT state_name FROM " . $table_prefix . "states WHERE state_id=" . $db->tosql($variables["delivery_state_id"], TEXT));
			if (strlen($variables["delivery_state_id"])) {
				$variables["delivery_state_id_or_province"] = $variables["delivery_state_id"];
				$variables["delivery_state_or_province"] = $variables["delivery_state"];
			} else {
				$variables["delivery_state_id_or_province"] = $variables["delivery_province"];
				$variables["delivery_state_or_province"] = $variables["delivery_province"];
			}
			$variables["delivery_country"] = get_db_value("SELECT country_name FROM " . $table_prefix . "countries WHERE country_id=" . $db->tosql($variables["delivery_country_id"], TEXT));
			$variables["cc_type"] = get_db_value("SELECT credit_card_code FROM " . $table_prefix . "credit_cards WHERE credit_card_id=" . $db->tosql($variables["cc_type"], INTEGER));
			$variables["cc_number"] = get_session("session_cc_number");
			$variables["cc_number_last"] = get_session("session_cc_number_last");
			$variables["cc_security_code"] = get_session("session_cc_code");
	
		}
		
		if (!strlen($payment_id)) { // check for payment_id if we lost it somewhere
			$sql = "SELECT payment_id FROM " . $table_prefix . "orders WHERE order_id=" . $db->tosql($order_id, INTEGER);
			$payment_id = get_db_value($sql);
			if (!strlen($payment_id)) { // if we missed it again look for it in payment_systems table
				$sql = "SELECT payment_id FROM " . $table_prefix . "payment_systems WHERE is_call_center=1 AND is_advanced=1 ";
				$payment_id = get_db_value($sql);
			}
		}
		
		$is_advanced = false;
		if (strlen($payment_id))
		{
			$db->query("SELECT * FROM " . $table_prefix . "payment_systems WHERE is_call_center=1 AND payment_id=" . $db->tosql($payment_id, INTEGER));
			if ($db->next_record()) {
				$is_advanced  = $db->f("is_advanced");
				$advanced_url = $db->f("advanced_url");
				$advanced_php_lib = $db->f("advanced_php_lib");
				$success_status_id = $db->f("success_status_id");
				$pending_status_id = $db->f("pending_status_id");
				$failure_status_id = $db->f("failure_status_id");
				$failure_action = $db->f("failure_action");
			}
		}
		
		$error_message = ""; $pending_message = ""; $transaction_id = "";
		if ($is_advanced && strlen($advanced_php_lib))
		{
			$post_params = ""; $payment_parameters = array(); $pass_parameters = array(); $fp_hash_name = "";
			$db->query("SELECT * FROM " . $table_prefix . "payment_parameters WHERE payment_id=" . $db->tosql($payment_id, INTEGER));
			while ($db->next_record())
			{
				$parameter_source = $db->f("parameter_source");
				$parameter_name = $db->f("parameter_name");
				$parameter_type = $db->f("parameter_type");
				$not_passed = $db->f("not_passed");
				if (strtolower($parameter_name) == "x_fp_hash" && $parameter_type == "VARIABLE") {
					$fp_hash_name = $parameter_name;
					$fp_not_passed = $not_passed;
				} elseif (preg_match("/\{digit\}/", $parameter_name) || preg_match("/\{no_digit\}/", $parameter_name)) {
					for ($i = 0; $i < sizeof($cart_items); $i++) {
						$cart_item = $cart_items[$i];
						$digit_parameter = str_replace("{digit}", ($i + 1), $parameter_name);
						$digit_parameter = str_replace("{no_digit}", "", $digit_parameter);
						if ($parameter_type == "CONSTANT") {
							$parameter_value = $parameter_source;
						} elseif ($parameter_type == "VARIABLE") {
							if (preg_match_all("/\{(\w+)\}/is", $parameter_source, $matches)) {
								$parameter_value = $parameter_source;
								for ($p = 0; $p < sizeof($matches[1]); $p++) {
									$l_source = strtolower($matches[1][$p]);
									if (isset($cart_item[$l_source])) {
										$parameter_value = str_replace("{".$l_source."}", $cart_item[$l_source], $parameter_value);
									}
								}
							} else {
								$l_source = strtolower($parameter_source);
								$parameter_value = isset($cart_item[$l_source]) ? $cart_item[$l_source] : $parameter_source;
							}
						}
						$payment_parameters[strtolower($digit_parameter)] = $parameter_value;
						if (!$not_passed) {
							$pass_parameters[strtolower($digit_parameter)] = 1;
							if ($post_params) { $post_params .= "&"; }
							$post_params .= $digit_parameter . "=" . urlencode($parameter_value);
						} else {
							$pass_parameters[strtolower($digit_parameter)] = 0;
						}
					}
				} else {
					if ($parameter_type == "CONSTANT") {
						$parameter_value = $parameter_source;
					} elseif ($parameter_type == "VARIABLE") {
						if (preg_match_all("/\{(\w+)\}/is", $parameter_source, $matches)) {
							$parameter_value = $parameter_source;
							for ($p = 0; $p < sizeof($matches[1]); $p++) {
								$l_source = strtolower($matches[1][$p]);
								if (isset($variables[$l_source])) {
									$parameter_value = str_replace("{".$l_source."}", $variables[$l_source], $parameter_value);
								}
							}
						} else {
							$l_source = strtolower($parameter_source);
							$parameter_value = isset($variables[$l_source]) ? $variables[$l_source] : $parameter_source;
						}
					}
					$payment_parameters[strtolower($parameter_name)] = $parameter_value;
					if (!$not_passed) {
						$pass_parameters[strtolower($parameter_name)] = 1;
						if (strlen($post_params)) { $post_params .= "&"; }
						$post_params .= $parameter_name . "=" . urlencode($parameter_value);
					} else {
						$pass_parameters[strtolower($parameter_name)] = 0;
					}
				}
			}
		
			if (strlen($fp_hash_name)) {
				$x_login = isset($payment_parameters["x_login"]) ? $payment_parameters["x_login"] : "";
				$x_tran_key = isset($payment_parameters["x_tran_key"]) ? $payment_parameters["x_tran_key"] : "";
				$x_currency_code = isset($payment_parameters["x_currency_code"]) ? $payment_parameters["x_currency_code"] : "";
		
				$fp_hash_value = calculate_fp ($x_login, $x_tran_key, $variables["order_total"], $variables["order_id"], $variables["timestamp"], $x_currency_code);
				$payment_parameters["x_fp_hash"] = $fp_hash_value;
				if (!$fp_not_passed) {
					if (strlen($post_params)) { $post_params .= "&"; }
					$post_params .= $fp_hash_name . "=" . urlencode($fp_hash_value);
				}
			}
		
			// use foreign php library to handle transaction
			include_once($root_folder_path . $advanced_php_lib);
		
			if (strlen($error_message)) {
				$order_status = $failure_status_id;
			} elseif (strlen($pending_message)) {
				$order_status = $pending_status_id;
			} else {
				$order_status = $success_status_id;
			}
		
			$rp->set_value("order_status", $order_status);
			$rp->set_value("error_message", $error_message);
			$rp->set_value("pending_message", $pending_message);
			if (strlen($transaction_id)) {
				$rp->set_value("transaction_id", $transaction_id);
				$rp->change_property("transaction_id", USE_IN_UPDATE, true);
			}
		
			// check download activation
			$sql = "SELECT download_activation FROM " . $table_prefix . "order_statuses WHERE status_id=" . $db->tosql($order_status, INTEGER);
			$download_action = get_db_value($sql);
			if ($download_action == 1) {
				$sql = "UPDATE " . $table_prefix . "items_downloads SET activated=1 WHERE order_id=" . $db->tosql($order_id, INTEGER);
				$db->query($sql);
				$sql = "UPDATE " . $table_prefix . "orders_items_serials SET activated=1 WHERE order_id=" . $db->tosql($order_id, INTEGER);
				$db->query($sql);
				$sql = "UPDATE " . $table_prefix . "coupons SET is_active=1 WHERE order_id=" . $db->tosql($order_id, INTEGER);
				$db->query($sql);
			} elseif ($download_action == 0) {
				$sql = "UPDATE " . $table_prefix . "items_downloads SET activated=0 WHERE order_id=" . $db->tosql($order_id, INTEGER);
				$db->query($sql);
				$sql = "UPDATE " . $table_prefix . "orders_items_serials SET activated=0 WHERE order_id=" . $db->tosql($order_id, INTEGER);
				$db->query($sql);
				$sql = "UPDATE " . $table_prefix . "coupons SET is_active=0 WHERE order_id=" . $db->tosql($order_id, INTEGER);
				$db->query($sql);
			}
		
		}
		$rp->update_record();
		
		// update items status
		$sql  = " UPDATE " . $table_prefix . "orders_items ";
		$sql .= " SET item_status=" . $db->tosql($order_status, INTEGER);
		$sql .= " WHERE order_id=" . $db->tosql($order_id, INTEGER);
		$db->query($sql);
	}
		
?>