<?php
/*
  ****************************************************************************
  ***                                                                      ***
  ***      ViArt Shop 3.5                                                  ***
  ***      File:  admin_login.php                                          ***
  ***      Built: Fri Jun 20 19:43:16 2008                                 ***
  ***                                                 ***
  ***                                                                      ***
  ****************************************************************************
*/


	include_once ("./admin_config.php");
	include_once ($root_folder_path . "includes/common.php");
	include_once("./admin_common.php");

	$secure_admin_login = get_setting_value($settings, "secure_admin_login", 0);
	$secure_url = get_setting_value($settings, "secure_url", "");
	$site_url = get_setting_value($settings, "site_url", "");
	
	$current_version = va_version();

	// check admin folder	
	$admin_folder = "";
	$request_uri = get_request_uri();
	$request_uri = preg_replace("/\/+/", "/", $request_uri);
	$slash_position = strrpos ($request_uri, "/");
	if ($slash_position !== false) {
		$request_path = substr($request_uri, 0, $slash_position);
		$slash_position = strrpos ($request_path, "/");
		if ($slash_position !== false) {
			$admin_folder = substr($request_path, $slash_position + 1);
		}
	}
	if ($admin_folder) {
		$admin_folder .= "/";
	} else {
		$admin_folder  = "admin/";
	}

	if ($secure_admin_login && $secure_url) {
		//$admin_login_url = $secure_url . $admin_folder . "admin_login.php";
		$admin_login_url = $admin_secure_url . "admin_login.php";
	} else {
		$admin_login_url = "admin_login.php";
	}

	$t = new VA_Template($settings["admin_templates_dir"]);
	$t->set_file("main","admin_login.html");
	$t->set_var("admin_href", "admin.php");
	$t->set_var("admin_login_href", "admin_login.php");
	$t->set_var("admin_login_url", $admin_login_url);
	$t->set_var("admin_privileges_href", "admin_privileges.php");

	$t->set_var("LOGIN_BUTTON", LOGIN_BUTTON);
	$t->set_var("CANCEL_BUTTON", CANCEL_BUTTON);
	$t->set_var("LOGIN_AS_MSG", LOGIN_AS_MSG);
	$t->set_var("CLICK_HERE_MSG", CLICK_HERE_MSG);
	$t->set_var("LOGOUT_BUTTON", LOGOUT_BUTTON);
	$t->set_var("LOGIN_FIELD", LOGIN_FIELD);
	$t->set_var("PASSWORD_FIELD", PASSWORD_FIELD);

	$return_page = get_param("return_page");
	if (!strlen($return_page)) { $return_page = "index.php"; }
	if ($secure_admin_login && $secure_url) {
		$slash_position = strrpos ($return_page, "/");
		$redirect_page = ($slash_position === false) ? $return_page : substr($return_page, $slash_position + 1);
		//$redirect_url = $site_url . $admin_folder . $redirect_page;
		$redirect_url = $admin_secure_url . $redirect_page;
	} else {
		$redirect_url = $return_page;
	}

	$operation = get_param("operation");
	$errors = false; $errors_list = ""; $login = "";
	if (strlen($operation))
	{
		if ($operation == "cancel")
		{
			header("Location: index.php");
			exit;
		}
		elseif ($operation == "logout")
		{
			set_session("session_admin_id", "");
			set_session("session_admin_privilege_id", "");
			set_session("session_admin_name", "");
			set_session("session_admin_permissions", "");
			set_session("session_last_order_id", "");
			set_session("session_last_user_id", "");
			set_session("session_warn_permission", "");
			set_session("session_admin_site_url", "");
			set_session("session_admin_secure_url", "");
		}
		else
		{
			$login = get_param("login");
			$password = get_param("password");
			
			if (!strlen($login)) {
				$error_message = str_replace("{field_name}", LOGIN_FIELD, REQUIRED_MESSAGE);
				$errors_list .= $error_message . "<br>";
				$errors = true;
			}
	  
			if (!strlen($password)) {
				$error_message = str_replace("{field_name}", PASSWORD_FIELD, REQUIRED_MESSAGE);
				$errors_list .= $error_message . "<br>";
				$errors = true;
			}

			/* check for black ips
			if (!$errors && check_black_ip()) {
				$errors_list = BLACK_IP_MSG;
				$errors = true;
			}
			*/

			if (!$errors)
			{
				$password_encrypt = get_setting_value($settings, "password_encrypt", 0);
				if ($password_encrypt == 1) {
					$password_match = md5($password);
				} else {
					$password_match = $password;
				}

				$sql  = " SELECT * FROM " . $table_prefix . "admins WHERE ";
				$sql .= " login = " . $db->tosql($login, TEXT);
				$sql .= " AND password = " . $db->tosql($password_match, TEXT);
				$db->query($sql);
				if ($db->next_record()) {
					$privilege_id = $db->f("privilege_id");
					$admin_id = $db->f("admin_id");
					set_session("session_admin_id", $db->f("admin_id"));
					set_session("session_admin_privilege_id", $db->f("privilege_id"));
					set_session("session_admin_name", $db->f("admin_name"));
					set_session("session_last_order_id", $db->f("last_order_id"));
					set_session("session_last_user_id", $db->f("last_user_id"));
					$permissions = array();
					$sql  = " SELECT block_name, permission FROM " . $table_prefix . "admin_privileges_settings ";
					$sql .= " WHERE privilege_id=" . $db->tosql($privilege_id, INTEGER, true, false);
					$db->query($sql);
					while ($db->next_record()) {
						$block_name = $db->f("block_name");
						$permissions[$block_name] = $db->f("permission");
					}
					set_session("session_admin_permissions", $permissions);	
					
					if ((comp_vers($current_version, "2.8.1") <= 1) && (strpos($redirect_url, "admin.php"))) {
						$sql  = " SELECT url ";
						$sql .= " FROM " . $table_prefix . "bookmarks ";
						$sql .= " WHERE is_start_page=1 AND admin_id=" . $db->tosql($admin_id, INTEGER);
						$start_url = get_db_value($sql);
						if ($start_url) {
							$redirect_url = $start_url;
						}
					}

					header("Location: " . $redirect_url); 
					exit;

				} else {
					$errors_list .= LOGIN_PASSWORD_ERROR . "<br>";
					$errors = true;
				}
			}
		}
	}

	if (get_session("session_admin_id"))	
	{
		$t->set_var("admin_name", get_session("session_admin_name"));
		$t->set_var("operation", "logout");
		$t->set_var("login_form", "");
		$t->parse("logout_form", false);
	}
	else
	{
		$t->set_var("return_page", htmlspecialchars($return_page));
		$t->set_var("login", htmlspecialchars($login));
		$t->set_var("operation", "login");
		$t->set_var("logout_form", "");
		$t->parse("login_form", false);
	}

	$type_error = get_param("type_error");
	if ($type_error == 2) {
		$t->parse("access_error", false);
		$errors = true;
	}

	if ($errors) {
		$t->set_var("errors_list", $errors_list);
		$t->parse("errors", false);
	}	else {
		$t->set_var("errors", "");
	}

	include_once("./admin_header.php");
	include_once("./admin_footer.php");

	$t->pparse("main");

?>