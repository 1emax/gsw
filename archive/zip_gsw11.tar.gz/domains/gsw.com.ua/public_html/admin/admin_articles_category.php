<?php
/*
  ****************************************************************************
  ***                                                                      ***
  ***      ViArt Shop 3.5                                                  ***
  ***      File:  admin_articles_category.php                              ***
  ***      Built: Fri Jun 20 19:43:16 2008                                 ***
  ***                                                 ***
  ***                                                                      ***
  ****************************************************************************
*/


	include_once("./admin_config.php");
	include_once($root_folder_path . "includes/common.php");
	include_once("./admin_common.php");
	include_once($root_folder_path . "includes/record.php");
	include_once($root_folder_path . "includes/friendly_functions.php");

	check_admin_security("articles");

	$t = new VA_Template($settings["admin_templates_dir"]);
	$t->set_file("main", "admin_articles_category.html");

	$html_editor = get_setting_value($settings, "html_editor", 1);
	$t->set_var("html_editor", $html_editor);		

	$site_url_path = $settings["site_url"] ? $settings["site_url"] : "../";
	$t->set_var("css_file", $site_url_path . "styles/" . $settings["style_name"] . ".css");

	include_once("./admin_header.php");
	include_once("./admin_footer.php");

	$t->set_var("admin_articles_top_href",      "admin_articles_top.php");
	$t->set_var("admin_articles_category_href", "admin_articles_category.php");
	$t->set_var("admin_select_href",   "admin_select.php");
	$t->set_var("admin_upload_href",   "admin_upload.php");
	$t->set_var("admin_articles_href", "admin_articles.php");

	$category_id = get_param("category_id");

	$r = new VA_Record($table_prefix . "articles_categories");

	$r->add_where("category_id", INTEGER);
	$r->add_textbox("category_order", INTEGER, CATEGORY_ORDER_MSG);
	$r->change_property("category_order", REQUIRED, true);
	$r->add_textbox("total_views", INTEGER);
	$r->change_property("total_views", USE_IN_INSERT, false);
	$r->change_property("total_views", USE_IN_UPDATE, false);
	$r->add_textbox("category_name", TEXT, CATEGORY_NAME_MSG);
	$r->change_property("category_name", REQUIRED, true);
	$r->change_property("category_name", MAX_LENGTH, 255);
	$r->add_textbox("friendly_url", TEXT, FRIENDLY_URL_MSG);
	$r->change_property("friendly_url", USE_SQL_NULL, false);
	$r->change_property("friendly_url", BEFORE_VALIDATE, "validate_friendly_url");
	$r->add_textbox("articles_list_template", TEXT);
	$r->add_textbox("articles_details_template", TEXT);

	$r->add_checkbox("is_rss", INTEGER);
	$r->add_checkbox("rss_on_breadcrumb", INTEGER);
	$r->add_checkbox("rss_on_list", INTEGER);
	$r->add_textbox("rss_limit", INTEGER);

	$r->add_checkbox("is_remote_rss", INTEGER);
	$r->add_textbox("remote_rss_url", TEXT);
	$r->add_textbox("remote_rss_date_updated", DATETIME);
	$r->change_property("remote_rss_date_updated", VALUE_MASK, $datetime_edit_format);
	$r->add_textbox("remote_rss_ttl", INTEGER);
	$r->add_textbox("remote_rss_refresh_rate", INTEGER);

	$order_columns = array(
		array("", ""), array("article_order", ORDER_COLUMN_MSG),
		array("article_date", DATE_MSG), array("date_end", DATE_END_MSG),
		array("article_title", TITLE_MSG), array("author_name", AUTHOR_NAME_MSG),
		array("date_added", DATE_ADDED_MSG), array("date_updated", DATE_UPDATED_MSG)
	);
	$r->add_select("articles_order_column", TEXT, $order_columns);
	$order_directions = array(array("", ""), array("ascending", ASC_MSG), array("descending", DESC_MSG));
	$r->add_select("articles_order_direction", TEXT, $order_directions);

	$r->add_textbox("article_list_fields", TEXT);
	$r->add_textbox("article_details_fields", TEXT);
	$r->add_textbox("article_required_fields", TEXT);

	$allowed_values = array(array("0", NOBODY_MSG), array("1", FOR_ALL_USERS_MSG), array("2", ONLY_REGISTERED_USERS_MSG));
	$allowed_values = array(array("0", NOBODY_MSG), array("1", FOR_ALL_USERS_MSG));
	$r->add_radio("allowed_view", INTEGER, $allowed_values, ALLOW_VIEW_MSG);
	$r->add_checkbox("allowed_post", INTEGER);
	$r->change_property("allowed_post", SHOW, false);
	$r->add_checkbox("allowed_rate", INTEGER);
	$r->add_textbox("short_description", TEXT);
	$r->add_textbox("full_description", TEXT);

	$r->add_textbox("image_small", TEXT);
	$r->add_textbox("image_small_alt", TEXT);
	$r->add_textbox("image_large", TEXT);
	$r->add_textbox("image_large_alt", TEXT);

	$r->add_textbox("meta_title", TEXT);
	$r->add_textbox("meta_keywords", TEXT);
	$r->add_textbox("meta_description", TEXT);

	$r->add_textbox("parent_category_id", INTEGER);
	$r->change_property("parent_category_id", USE_IN_UPDATE, false);
	$r->add_textbox("category_path", TEXT);
	$r->change_property("category_path", USE_IN_UPDATE, false);

	//$r->add_checkbox("is_contents", INTEGER, "Show category contents");
	//$r->add_checkbox("is_list", INTEGER);
	//$r->add_textbox("moderators_ids", TEXT, "Moderators");
	//$r->add_checkbox("is_hot", INTEGER, "Show on main page");
	//$r->add_textbox("alias_category_id", TEXT);
	//$r->change_property("alias_category_id", USE_IN_UPDATE, false);
	$r->add_textbox("language_code", TEXT, LANGUAGE_CODE_MSG);
	$r->change_property("language_code", MAX_LENGTH, 2);
	$r->change_property("language_code", USE_SQL_NULL, false);
	$r->add_hidden("total_articles", INTEGER);
	$r->change_property("total_articles", USE_IN_INSERT, true);
	$r->add_hidden("total_subcategories", INTEGER);
	$r->change_property("total_subcategories", USE_IN_INSERT, true);

	$r->add_checkbox("user_types_all", INTEGER);
	$r->add_checkbox("sites_all", INTEGER);
	$r->get_form_values();

	$article_fields = array(
		"article_date", "date_end", "article_title", "author_name", "author_email",
		"author_url", "link_url", "download_url", "short_description", "full_description",
		"image_small", "image_large", "stream_video","keywords", "notes"
	);

	if(!strlen($r->get_value("parent_category_id"))) $r->set_value("parent_category_id", "0");
	$parent_category_id = $r->get_value("parent_category_id");

	$tree = new VA_Tree("category_id", "category_name", "parent_category_id", $table_prefix . "articles_categories", "tree", "");
	$tree->show($parent_category_id);

	$list_fields = ""; $details_fields = ""; $required_fields = "";
	$operation = get_param("operation");
	$tab = get_param("tab");
	if (!$tab) { $tab = "general"; }

	if ($parent_category_id > 0) {
		$return_page = "admin_articles.php?category_id=" . $parent_category_id;
	} else {
		$return_page = "admin_articles_top.php";
	}

	$selected_user_types = array();
	if (strlen($operation)) {
		$user_types = get_param("user_types");
		if ($user_types) {
			$selected_user_types = split(",", $user_types);
		}
	} elseif ($category_id) {
		$sql  = "SELECT user_type_id FROM " . $table_prefix . "articles_categories_types ";
		$sql .= " WHERE category_id=" . $db->tosql($category_id, INTEGER);
		$db->query($sql);
		while ($db->next_record()) {
			$selected_user_types[] = $db->f("user_type_id");
		}
	}

	if ($sitelist) {
		$selected_sites = array();
		if (strlen($operation)) {
			$sites = get_param("sites");
			if ($sites) {
				$selected_sites = split(",", $sites);
			}
		} elseif ($category_id) {
			$sql  = "SELECT site_id FROM " . $table_prefix . "articles_categories_sites ";
			$sql .= " WHERE  category_id=" . $db->tosql($category_id, INTEGER);
			$db->query($sql);
			while ($db->next_record()) {
				$selected_sites[] = $db->f("site_id");
			}
		}
	}


	if (strlen($operation))
	{
		$tree = new VA_Tree("category_id", "category_name", "parent_category_id", $table_prefix . "articles_categories", "");

		if ($operation == "cancel") {
			header("Location: " . $return_page);
			exit;
		} elseif ($operation == "delete" && $r->get_value("category_id")) {
			$categories = "";
			$category_path = $tree->get_path($category_id);
			$sql  = " SELECT category_id FROM " . $table_prefix . "articles_categories ";
			$sql .= " WHERE category_id = " . $db->tosql($category_id, INTEGER);
			$sql .= " OR category_path LIKE '" . $db->tosql($category_path, TEXT, false) . "%'";
			$db->query($sql);
			while ($db->next_record()) {
				$categories[] = $db->f("category_id");
			}

			if (is_array($categories)) {
				for ($i = 0; $i < sizeof($categories); $i++) {
					$db->query("DELETE FROM " . $table_prefix . "articles_assigned WHERE category_id = " . $db->tosql($categories[$i], INTEGER));
					$db->query("DELETE FROM " . $table_prefix . "articles_categories WHERE category_id=" . $db->tosql($categories[$i], INTEGER));
					$db->query("DELETE FROM " . $table_prefix . "articles_categories_items WHERE category_id=" . $db->tosql($categories[$i], INTEGER));
					$db->query("DELETE FROM " . $table_prefix . "articles_categories_types WHERE category_id=" . $db->tosql($categories[$i], INTEGER));
					$db->query("DELETE FROM " . $table_prefix . "articles_categories_sites WHERE category_id=" . $db->tosql($categories[$i], INTEGER));
				}
			}
			if ($parent_category_id) {
				$db->query("UPDATE " . $table_prefix . "articles_categories SET total_subcategories=total_subcategories - 1 WHERE category_id = " . $db->tosql($parent_category_id, INTEGER));
			}
			$db->query("DELETE FROM " . $table_prefix . "articles_categories_types WHERE category_id=" . $db->tosql($category_id, INTEGER));
			$db->query("DELETE FROM " . $table_prefix . "articles_categories_sites WHERE category_id=" . $db->tosql($category_id, INTEGER));

			header("Location: " . $return_page);
			exit;
		}

		if ($r->get_value("parent_category_id") == 0) {
			for ($i = 0; $i < sizeof($article_fields); $i++) {
				$field_name = $article_fields[$i];
				if (get_param("list_" . $field_name) == 1) {
					if ($list_fields) { $list_fields .= ","; }
					$list_fields .= $field_name;
				}
				if (get_param("details_" . $field_name) == 1) {
					if ($details_fields) { $details_fields .= ","; }
					$details_fields .= $field_name;
				}
				if (get_param("required_" . $field_name) == 1) {
					if ($required_fields) { $required_fields .= ","; }
					$required_fields .= $field_name;
				}

			}
			$r->set_value("article_list_fields", $list_fields);
			$r->set_value("article_details_fields", $details_fields);
			$r->set_value("article_required_fields", $required_fields);

			$category_order = get_db_value("SELECT MAX(category_order) FROM " . $table_prefix . "articles_categories WHERE parent_category_id=" . $db->tosql($parent_category_id, INTEGER));
			$category_order++;
			$r->set_value("category_order", $category_order);
		}

		$is_valid = $r->validate();

		if ($is_valid)
		{
			if (!$sitelist) {
				$r->set_value("sites_all", 1);
			}
			if (strlen($r->get_value("category_id"))) {
				set_friendly_url();
				$record_updated = $r->update_record();
			} else {
				set_friendly_url();
				$r->set_value("category_path", $tree->get_path($r->get_value("parent_category_id")));
				$r->set_value("total_articles", 0);
				$r->set_value("total_subcategories", 0);
				$db->query("SELECT MAX(category_id) FROM " . $table_prefix . "articles_categories");
				$db->next_record();
				$category_id = $db->f(0) + 1;
				$r->set_value("category_id", $category_id);

				$record_updated = $r->insert_record();
				if ($parent_category_id && $record_updated) {
					$db->query("UPDATE " . $table_prefix . "articles_categories SET total_subcategories = total_subcategories + 1 WHERE category_id = " . $db->tosql($parent_category_id, INTEGER));
				}
			}
			
			$nested_categories = array();
			// update users types

			$user_types_all = $r->get_value('user_types_all');
			if (get_param('save_nested_user_types')) {		
				recursive_save_user_types($category_id, 5);
			} else {
				recursive_save_user_types($category_id, 0);
			}

			// update sites
			if ($sitelist) {
				$sites_all = $r->get_value("sites_all");
				if (get_param("save_nested_sites")) {		
					recursive_save_sites($category_id, 5);
				} else {
					recursive_save_sites($category_id, 0);
				}
			}
			
			if ($record_updated) {
				header("Location: " . $return_page);
				exit;
			}
		}
	} elseif (strlen($r->get_value("category_id"))) { // edit existing category
		$r->get_db_values();
		$list_fields = $r->get_value("article_list_fields");
		$details_fields = $r->get_value("article_details_fields");
		$required_fields = $r->get_value("article_required_fields");
	} else { // new category - set default values
		$category_order = get_db_value("SELECT MAX(category_order) FROM " . $table_prefix . "articles_categories WHERE parent_category_id=" . $db->tosql($parent_category_id, INTEGER));
		$category_order++;
		$r->set_value("category_order", $category_order);
		$r->set_value("allowed_view", 1);
		$r->set_value("allowed_rate", 1);
		$list_fields = "article_date,article_title,image_small,short_description";
		$details_fields = "article_date,article_title,image_large,full_description";
		$required_fields = "article_date,article_title";
		$r->set_value("user_types_all", 1);
		$r->set_value("sites_all", 1);
	}

	$user_types = array();
	$sql = " SELECT type_id, type_name FROM " . $table_prefix . "user_types ";
	$db->query($sql);
	while ($db->next_record())	{
		$type_id = $db->f("type_id");
		$type_name = get_translation($db->f("type_name"));
		$user_types[$type_id] = $type_name;
	}

	foreach ($user_types as $type_id => $type_name) {
		$t->set_var("type_id", $type_id);
		$t->set_var("type_name", $type_name);
		if (in_array($type_id, $selected_user_types)) {
			$t->parse("selected_user_types", true);
		} else {
			$t->parse("available_user_types", true);
		}
	}
	if ($sitelist) {
		$sites = array();
		$sql = " SELECT site_id, site_name FROM " . $table_prefix . "sites ";
		$db->query($sql);
		while ($db->next_record())	{
			$site_id   = $db->f("site_id");
			$site_name = get_translation($db->f("site_name"));
			$sites[$site_id] = $site_name;
			$t->set_var("site_id", $site_id);
			$t->set_var("site_name", $site_name);
			if (in_array($site_id, $selected_sites)) {
				$t->parse("selected_sites", true);
			} else {
				$t->parse("available_sites", true);
			}
		}
	}
	if ($r->get_value("parent_category_id") == 0) {
		$list_fields = ",," . $list_fields . ",,";
		$details_fields = ",," . $details_fields . ",,";
		$required_fields = ",," . $required_fields . ",,";
		for ($i = 0; $i < sizeof($article_fields); $i++) {
			$field_name = $article_fields[$i];
			if (strpos($list_fields, "," . $field_name . ",")) {
				$t->set_var("list_" . $field_name, "checked");
			} else {
				$t->set_var("list_" . $field_name, "");
			}
			if (strpos($details_fields, "," . $field_name . ",")) {
				$t->set_var("details_" . $field_name, "checked");
			} else {
				$t->set_var("details_" . $field_name, "");
			}
			if (strpos($required_fields, "," . $field_name . ",")) {
				$t->set_var("required_" . $field_name, "checked");
			} else {
				$t->set_var("required_" . $field_name, "");
			}
		}
	}
	$r->set_parameters();

	if ($r->get_value("parent_category_id") == 0) {
		$t->parse("layout_properties", false);
	} else {
		$t->set_var("layout_properties", "");
	}

	if (strlen($category_id)) {
		$t->set_var("save_button", UPDATE_BUTTON);
		$t->parse("delete", false);
	} else {
		$t->set_var("save_button", ADD_NEW_MSG);
		$t->set_var("delete", "");
	}


	$tabs = array("general" => EDIT_CATEGORY_MSG, "user_types" => USERS_TYPES_MSG);
	if ($sitelist) {
		$tabs["sites"] = ADMIN_SITES_MSG;
	}
	foreach ($tabs as $tab_name => $tab_title) {
		$t->set_var("tab_id", "tab_" . $tab_name);
		$t->set_var("tab_name", $tab_name);
		$t->set_var("tab_title", $tab_title);
		if ($tab_name == $tab) {
			$t->set_var("tab_class", "adminTabActive");
			$t->set_var($tab_name . "_style", "display: block;");
		} else {
			$t->set_var("tab_class", "adminTab");
			$t->set_var($tab_name . "_style", "display: none;");
		}
		$t->parse("tabs", $tab_title);
	}
	$t->set_var("tab", $tab);

	if ($sitelist) {
		$t->parse("sitelist");
	}

	$t->pparse("main");

	function recursive_save_user_types($category_id, $stop_level = 5, $level = 0) 
	{
		global $db, $table_prefix;
		global $selected_user_types, $user_types_all;
		global $nested_categories;
		
		$db->query("DELETE FROM " . $table_prefix . "articles_categories_types WHERE category_id=" . $db->tosql($category_id, INTEGER));
		for ($ut = 0; $ut < sizeof($selected_user_types); $ut++) {
			$type_id = $selected_user_types[$ut];
			if (strlen($type_id)) {
				$sql  = " INSERT INTO " . $table_prefix . "articles_categories_types (category_id, user_type_id) VALUES (";
				$sql .= $db->tosql($category_id, INTEGER) . ", ";
				$sql .= $db->tosql($type_id, INTEGER) . ") ";
				$db->query($sql);
			}
		}
		
		if ($level < $stop_level) {
			$db->query("UPDATE " . $table_prefix . "articles_categories SET user_types_all= " . $db->tosql($user_types_all, INTEGER, true, false) . " WHERE parent_category_id=" . $db->tosql($category_id, INTEGER));
			if (!isset($nested_categories[$category_id])) {
				$db->query("SELECT category_id FROM " . $table_prefix . "articles_categories WHERE parent_category_id=" . $db->tosql($category_id, INTEGER));
				$nested_categories[$category_id] = array();
				while ($db->next_record()) {
					$nested_categories[$category_id][] = $db->f('category_id');
				}
			}
			if ($nested_categories[$category_id]) {
				for ($i=0, $count=count($nested_categories[$category_id]); $i<$count; $i++) {
					recursive_save_user_types($nested_categories[$category_id][$i], $stop_level, $level+1);
				}
			}
		}		
	}

	function recursive_save_sites($category_id,  $stop_level = 5, $level = 0) 
	{
		global $db, $table_prefix;
		global $selected_sites, $sites_all;
		global $nested_categories;
		
		$db->query("DELETE FROM " . $table_prefix . "articles_categories_sites WHERE category_id=" . $db->tosql($category_id, INTEGER));
		for ($st = 0; $st < sizeof($selected_sites); $st++) {
			$selected_site_id = $selected_sites[$st];
			if (strlen($selected_site_id)) {
				$sql  = " INSERT INTO " . $table_prefix . "articles_categories_sites (category_id, site_id) VALUES (";
				$sql .= $db->tosql($category_id, INTEGER, true, false) . ", ";
				$sql .= $db->tosql($selected_site_id, INTEGER, true, false) . ") ";
				$db->query($sql);
			}
		}
		
		if ($level < $stop_level) {
			$db->query("UPDATE " . $table_prefix . "articles_categories SET sites_all= " . $db->tosql($sites_all, INTEGER, true, false) . " WHERE parent_category_id=" . $db->tosql($category_id, INTEGER));
			if (!isset($nested_categories[$category_id])) {
				$db->query("SELECT category_id FROM " . $table_prefix . "articles_categories WHERE parent_category_id=" . $db->tosql($category_id, INTEGER));
				$nested_categories[$category_id] = array();
				while ($db->next_record()) {
					$nested_categories[$category_id][] = $db->f('category_id');
				}
			}
			if ($nested_categories[$category_id]) {
				for ($i=0, $count=count($nested_categories[$category_id]); $i<$count; $i++) {
					recursive_save_sites($nested_categories[$category_id][$i], $stop_level, $level+1);
				}
			}			
		}		
	}

?>