<?php
/*
  ****************************************************************************
  ***                                                                      ***
  ***      ViArt Shop 3.5                                                  ***
  ***      File:  admin_tax_rates.php                                      ***
  ***      Built: Fri Jun 20 19:43:16 2008                                 ***
  ***                                                 ***
  ***                                                                      ***
  ****************************************************************************
*/


	include_once("./admin_config.php");
	include_once($root_folder_path."includes/common.php");
	include_once($root_folder_path . "includes/sorter.php");
	include_once($root_folder_path . "includes/navigator.php");

	include_once("./admin_common.php");

	check_admin_security("sales_orders");
	check_admin_security("tax_rates");

  $t = new VA_Template($settings["admin_templates_dir"]);
  $t->set_file("main","admin_tax_rates.html");

	$t->set_var("admin_tax_rates_href", "admin_tax_rates.php");
	$t->set_var("admin_tax_rate_href", "admin_tax_rate.php");

	$s = new VA_Sorter($settings["admin_templates_dir"], "sorter_img.html", "admin_tax_rates.php");
	$s->set_sorter(ID_MSG, "sorter_tax_id", "1", "tax_id");
	$s->set_sorter(COUNTRY_FIELD, "sorter_country_name", "2", "country_name");
	$s->set_sorter(STATE_FIELD, "sorter_state_name", "3", "state_name");
	$s->set_sorter(TAX_PERCENT_MSG, "sorter_tax_percent", "4", "tax_percent");
	$s->set_sorter(TAX_PERCENT_MSG, "sorter_tax_percent", "4", "tax_percent");
	$s->set_sorter(DEFAULT_MSG, "sorter_is_default", "5", "is_default");
	$n = new VA_Navigator($settings["admin_templates_dir"], "navigator.html", "admin_tax_rates.php");

	include_once("./admin_header.php");
	include_once("./admin_footer.php");

	// set up variables for navigator
	$db->query("SELECT COUNT(*) FROM " . $table_prefix . "tax_rates");
	$db->next_record();
	$total_records = $db->f(0);
	$records_per_page = get_param("q") > 0 ? get_param("q") : 25;
	$pages_number = 5;
	$page_number = $n->set_navigator("navigator", "page", SIMPLE, $pages_number, $records_per_page, $total_records, false);

	$sql  = " SELECT tr.tax_id,c.country_name,s.state_name,tr.tax_percent,tr.is_default ";
	$sql .= " FROM ((" . $table_prefix . "tax_rates tr ";
	$sql .= " INNER JOIN " . $table_prefix . "countries c ON c.country_id=tr.country_id) ";
	$sql .= " LEFT JOIN " . $table_prefix . "states s ON s.state_id=tr.state_id) ";
	$db->RecordsPerPage = $records_per_page;
	$db->PageNumber = $page_number;
	$db->query($sql . $s->order_by);
	if($db->next_record())
	{
		$t->set_var("no_records", "");
		$t->parse("sorters", false);
		do {
			$t->set_var("tax_id", $db->f("tax_id"));
			$t->set_var("country_name", $db->f("country_name"));
			$t->set_var("state_name", $db->f("state_name"));
			$t->set_var("tax_percent", number_format($db->f("tax_percent"), 3));

			$is_default = $db->f("is_default");
			if ($is_default) {
				$is_default = "<font color=\"blue\"><b>" . YES_MSG . "</b></font>";
			} else  {
				$is_default = "<font color=\"silver\">" . NO_MSG . "</font>";
			} 

			$t->set_var("is_default", $is_default);

			$t->parse("records", true);
		} while($db->next_record());
	}
	else
	{
		$t->set_var("records", "");
		$t->set_var("navigator", "");
		$t->parse("no_records", false);
	}

	$t->set_var("admin_href", "admin.php");
	$t->set_var("admin_lookup_tables_href", "admin_lookup_tables.php");
	$t->pparse("main");

?>
