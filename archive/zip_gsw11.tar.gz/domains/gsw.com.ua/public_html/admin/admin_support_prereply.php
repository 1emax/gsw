<?php
/*
  ****************************************************************************
  ***                                                                      ***
  ***      ViArt Shop 3.5                                                  ***
  ***      File:  admin_support_prereply.php                               ***
  ***      Built: Fri Jun 20 19:43:16 2008                                 ***
  ***                                                 ***
  ***                                                                      ***
  ****************************************************************************
*/


	include_once("./admin_config.php");
	include_once($root_folder_path."includes/common.php");
	include_once($root_folder_path . "includes/record.php");

	// get permissions
	$permissions = get_permissions();
	$allow_predefined_edit  = get_setting_value($permissions, "support_predefined_reply", 0); 

	include_once($root_folder_path."messages/".$language_code."/support_messages.php");
	include_once("./admin_common.php");

	check_admin_security("support");
	$is_popup = get_param("is_popup");

	$admin_support_prereplies = new VA_URL("admin_support_prereplies.php", false);
	$admin_support_prereplies->add_parameter("s_kw", REQUEST, "s_kw");
	$admin_support_prereplies->add_parameter("s_type", REQUEST, "s_type");
	$admin_support_prereplies->add_parameter("is_popup", REQUEST, "is_popup");
	$admin_support_prereplies->add_parameter("sort_ord", REQUEST, "sort_ord");
	$admin_support_prereplies->add_parameter("sort_dir", REQUEST, "sort_dir");
	$admin_support_prereplies->add_parameter("page", REQUEST, "page");

  $t = new VA_Template($settings["admin_templates_dir"]);
	if ($is_popup) {
	  $t->set_file("main","admin_support_prereply_popup.html");
	} else {
	  $t->set_file("main","admin_support_prereply.html");
	}

	$t->set_var("admin_support_href", "admin_support.php");
	$t->set_var("admin_support_prereply_href", "admin_support_prereply.php");
	$t->set_var("admin_support_prereplies_href", "admin_support_prereplies.php");
	$t->set_var("admin_support_prereplies_url", $admin_support_prereplies->get_url());

	$r = new VA_Record($table_prefix . "support_predefined");
	$r->return_page = "admin_support_prereplies.php";
	$r->add_hidden("s_kw", TEXT);
	$r->add_hidden("s_type", TEXT);
	$r->add_hidden("is_popup", TEXT);
	$r->add_hidden("sort_ord", TEXT);
	$r->add_hidden("sort_dir", TEXT);
	$r->add_hidden("page", TEXT);

	$r->add_where("reply_id", INTEGER);
	$sql  = " SELECT reply_type as reply_value,reply_type as reply_desc FROM " . $table_prefix . "support_predefined ";
	$sql .= " GROUP BY reply_type ";
	$sql .= " ORDER BY reply_type ";
	$reply_types = get_db_values($sql, array(array("", SELECT_REPLY_TYPE_MSG)));
	$r->add_select("reply_type", TEXT, $reply_types, TYPE_MSG);
	$r->parameters["reply_type"][REQUIRED] = true;
	$r->add_textbox("subject", TEXT, ADMIN_TITLE_MSG);
	$r->parameters["subject"][REQUIRED] = true;
	$r->add_textbox("body", TEXT, BODY_MSG);
	$r->change_property("body", REQUIRED, true);

	$r->set_event(BEFORE_DELETE,   "check_predefined_permissions");
	$r->set_event(BEFORE_VALIDATE, "check_predefined_permissions");

	$r->process();
	if ($allow_predefined_edit) {
		$t->parse("edit_button", false);
	} else {
		$t->set_var("delete", "");
	}
	$t->set_var("is_popup",   $is_popup);

	if (!$is_popup) { 						
		include_once("./admin_header.php");
		include_once("./admin_footer.php");
 	}	
	$t->set_var("admin_href", "admin.php");

	$t->pparse("main");

	function check_predefined_permissions()
	{
		global $allow_predefined_edit;
		if (!$allow_predefined_edit) {
			die(PREDEFINED_REPLIES_NOT_ALLOWED_MSG);
		}
	}

?>