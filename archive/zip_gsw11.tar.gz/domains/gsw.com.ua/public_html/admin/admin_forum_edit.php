<?php
/*
  ****************************************************************************
  ***                                                                      ***
  ***      ViArt Shop 3.5                                                  ***
  ***      File:  admin_forum_edit.php                                     ***
  ***      Built: Fri Jun 20 19:43:16 2008                                 ***
  ***                                                 ***
  ***                                                                      ***
  ****************************************************************************
*/


	include_once ("./admin_config.php");
	include_once ($root_folder_path . "includes/common.php");
	include_once ($root_folder_path . "includes/record.php");
	include_once ($root_folder_path . "includes/friendly_functions.php");
	include_once("./admin_common.php");
	include_once($root_folder_path."messages/".$language_code."/forum_messages.php");


	check_admin_security("forum");

	$t = new VA_Template($settings["admin_templates_dir"]);
	$t->set_file("main", "admin_forum_edit.html");

	$t->set_var("admin_upload_href", "admin_upload.php");
	$t->set_var("admin_select_href", "admin_select.php");
	$t->set_var("admin_forum_href", "admin_forum.php");
	$t->set_var("admin_forum_edit_href", "admin_forum_edit.php");

	$r = new VA_Record($table_prefix . "forum_list");
	$r->return_page = "admin_forum.php";

	$admins =array();
	$sql = " SELECT admin_id, admin_name FROM " . $table_prefix . "admins ORDER BY admin_id ASC";
	$db->query($sql);
	if ($db->next_record()) {
		$usr = new VA_Record($table_prefix . "admins");
		do {
			$admins[$db->f("admin_id")] = $db->f("admin_name");
			$usr->add_checkbox("admin_" . $db->f("admin_id"), INTEGER);
		}
		while($db->next_record());
	}	

	$r->get_form_values();
	$usr->get_form_values();

	$r->add_where("forum_id", INTEGER);
	$r->add_textbox("forum_order", TEXT, FORUM_ORDER_MSG);
	$r->change_property("forum_order", REQUIRED, true);
	$r->add_textbox("forum_name", TEXT, FORUM_NAME_MSG);
	$r->change_property("forum_name", REQUIRED, true);
	$r->change_property("forum_name", MAX_LENGTH, 255);
	$r->add_textbox("friendly_url", TEXT, FRIENDLY_URL_MSG);
	$r->change_property("friendly_url", USE_SQL_NULL, false);
	$r->change_property("friendly_url", BEFORE_VALIDATE, "validate_friendly_url");
	$r->add_textbox("short_description", TEXT);
	$r->add_textbox("full_description", TEXT);

	// forum settings
	$allowed_values = array(array("0", NOBODY_MSG), array("1", FOR_ALL_USERS_MSG), array("2", ONLY_REGISTERED_USERS_MSG));
	$r->add_radio("allowed_view", INTEGER, $allowed_values, ALLOW_VIEW_FORUM_MSG);
	$r->add_radio("allowed_view_topics", INTEGER, $allowed_values, ALLOW_VIEW_FORUM_TOPICS_LIST_MSG);
	$r->add_radio("allowed_view_topic", INTEGER, $allowed_values, ALLOW_VIEW_FORUM_TOPICS_DETAILS_MSG);
	$r->add_radio("allowed_post_topics", INTEGER, $allowed_values, ALLOW_POST_NEW_TOPICS_MSG);
	$r->add_radio("allowed_post_replies", INTEGER, $allowed_values, ALLOW_POST_REPLIES_MSG);

	$r->add_textbox("small_image", TEXT);
	$r->add_textbox("large_image", TEXT);

	$sql = "SELECT category_id, category_name FROM " . $table_prefix . "forum_categories";
	$categories = get_db_values($sql, array(array("", SELECT_CATEGORY_MSG)));
	if (sizeof($categories) == 1) {
		$categories = array(array("", FORUM_CATEGORIES_ERROR_MSG));
	}
	$r->add_select("category_id", TEXT, $categories, CATEGORY_MSG);
	$r->change_property("category_id", REQUIRED, true);
	
	
	$r->add_checkbox("view_forum_types_all", INTEGER);
	$r->add_checkbox("view_topics_types_all", INTEGER);
	$r->add_checkbox("view_topic_types_all", INTEGER);
	$r->add_checkbox("post_topics_types_all", INTEGER);
	$r->add_checkbox("post_replies_types_all", INTEGER);
	$r->add_checkbox("allowed_attachments", INTEGER);
	$r->add_checkbox("attachments_types_all", INTEGER);

	$r->add_textbox("date_added", DATETIME, DATE_ADDED_MSG);
	$r->change_property("date_added", USE_IN_UPDATE, false);
	$r->add_textbox("threads_number", TEXT);
	$r->change_property("threads_number", USE_IN_UPDATE, false);
	$r->add_textbox("messages_number", TEXT);
	$r->change_property("messages_number", USE_IN_UPDATE, false);
	$r->add_textbox("last_post_added", DATETIME, LAST_POST_ADDED_MSG);
	$r->change_property("last_post_added", USE_IN_UPDATE, false);
	$r->add_textbox("last_post_user_id", INTEGER);
	$r->change_property("last_post_user_id", USE_IN_UPDATE, false);
	$r->add_textbox("last_post_thread_id", INTEGER);
	$r->change_property("last_post_thread_id", USE_IN_UPDATE, false);

	$r->get_form_values();
	$operation = get_param("operation");
	$forum_id = get_param("forum_id");
	$current_tab = get_param("current_tab");
	if (!$current_tab) { $current_tab = "general"; }
	
	$user_types_tables = array(
		'forum_view_types', 
		'forum_view_topics', 
		'forum_view_topic', 
		'forum_post_topics', 
		'forum_post_replies', 
		'forum_attachments_types'
	);
	$user_types_struct =array();	
	foreach ($user_types_tables AS $user_types_table){
		$user_types_struct[$user_types_table]['selected'] =  array();
		if (strlen($operation)) {
			$user_types = get_param($user_types_table);
			if ($user_types) {
				$user_types_struct[$user_types_table]['selected'] = split(",", $user_types);
			}
		} elseif ($forum_id) {
			$sql  = "SELECT user_type_id FROM " . $table_prefix . $user_types_table;
			$sql .= " WHERE forum_id=" . $db->tosql($forum_id, INTEGER);
			$db->query($sql);
			while ($db->next_record()) {
				$user_types_struct[$user_types_table]['selected'][] = $db->f("user_type_id");
			}
		}		
	}
	

	if(strlen($operation))	{
		$is_valid = true;
		if($operation == "cancel") {
			header("Location: " . $r->return_page);
			exit;
		}
		else if($operation == "delete" && $forum_id)    // delete forum
		{
			// delete topics' messages
			$sql = "SELECT thread_id, topic FROM " . $table_prefix . "forum WHERE forum_id = " . $db->tosql($forum_id, INTEGER);
			$threads = get_db_values($sql, "");
			$threads_str = "";
			foreach ($threads as $thread) {
				if ($threads_str) {
					$threads_str .= ",";
				}
				else {
					$threads_str = "(";
				}
				$threads_str .= $thread[0];
			}
			if ($threads_str) {
				$threads_str .= ")";
				$db->query("DELETE FROM " . $table_prefix . "forum_messages WHERE thread_id IN " . $threads_str);
			}
			// delete moderators and topics
			$db->query("DELETE FROM " . $table_prefix . "forum_moderators WHERE forum_id = " . $db->tosql($forum_id, INTEGER));
			$db->query("DELETE FROM " . $table_prefix . "forum WHERE forum_id = " . $db->tosql($forum_id, INTEGER));
			foreach ($user_types_tables AS $user_types_table){
				$db->query("DELETE FROM " . $table_prefix . $user_types_table . " WHERE forum_id = " . $db->tosql($forum_id, INTEGER));		
			}			
			// delete attachments
			$sql = "SELECT file_path FROM " . $table_prefix . "forum_attachments WHERE forum_id=" . $db->tosql($r->get_value("forum_id"), INTEGER);
			$db->query($sql);
			while ($db->next_record()) {
				$file_path = $db->f("file_path");
				$is_file_exists = file_exists($file_path);
				if (!$is_file_exists && file_exists("../" . $file_path)) {
					$file_path = "../" . $file_path;
				}
				@unlink($file_path);
			}
	  
			$sql = "DELETE FROM " . $table_prefix . "forum_attachments WHERE forum_id=" . $db->tosql($r->get_value("forum_id"), INTEGER);
			$db->query($sql);

			$r->delete_record();

			header("Location: " . $r->return_page);
			exit;
		}	
		if($is_valid) {
			$is_valid = $r->validate();
		}
		if($is_valid)	{
			if(strlen($r->get_value("forum_id"))) {   // update existing forum
				set_friendly_url();
				$record_updated = $r->update_record();
			} else {
				set_friendly_url();
				$r->set_value("date_added", va_time());
				$r->set_value("last_post_user_id", 0);
				$r->set_value("last_post_thread_id", 0);
				$r->set_value("last_post_added", va_time());
				$record_updated = $r->insert_record(); // insert new forum
				if ($record_updated) {
					$sql = "SELECT MAX(forum_id) FROM " . $table_prefix . "forum_list";
					$forum_id = get_db_value($sql);
					$r->set_value("forum_id", $forum_id);
				}				
			}
			if ($record_updated) {
				// update users types
				foreach ($user_types_tables AS $user_types_table){
					$db->query("DELETE FROM " . $table_prefix . $user_types_table . " WHERE forum_id = " . $db->tosql($forum_id, INTEGER));		
					for ($ut = 0; $ut < sizeof($user_types_struct[$user_types_table]['selected']); $ut++) {
						$type_id = $user_types_struct[$user_types_table]['selected'][$ut];
						if (strlen($type_id)) {
							$sql  = " INSERT INTO " . $table_prefix . $user_types_table . " (forum_id, user_type_id) VALUES (";
							$sql .= $db->tosql($forum_id, INTEGER) . ", ";
							$sql .= $db->tosql($type_id, INTEGER) . ") ";
							$db->query($sql);
						}
					}
				}
				
				foreach($admins as $admin_id => $admin_name) {
					$admin = "admin_" . $admin_id;
					if ($usr->get_value($admin)) {
						$sql  = " SELECT forum_id FROM " . $table_prefix . "forum_moderators ";
						$sql .= " WHERE forum_id = " . $db->tosql($forum_id, INTEGER);
						$sql .= " AND admin_id = " . $db->tosql($admin_id, INTEGER);
						$db->query($sql);
						if (!$db->next_record()) {
							$sql  = " INSERT INTO " . $table_prefix . "forum_moderators (admin_id, forum_id) VALUES (";
							$sql .= $db->tosql($admin_id, INTEGER) . ", ";
							$sql .= $db->tosql($forum_id, INTEGER) . ")";
							$db->query($sql);
						}
					} else {
						$sql  = " DELETE FROM " . $table_prefix . "forum_moderators ";
						$sql .= " WHERE forum_id = " . $db->tosql($forum_id, INTEGER);
						$sql .= " AND admin_id = " . $db->tosql($admin_id, INTEGER);
						$db->query($sql);
					}
				}
 				header("Location: " . $r->return_page);
				exit;
			}
		}
	}
	else if(strlen($r->get_value("forum_id")))   	// show existing values 
	{
		$r->get_db_values();
		$r->set_value("date_added", va_date($datetime_show_format, $r->get_value("date_added")));
		$r->set_value("last_post_added", va_date($datetime_show_format, $r->get_value("last_post_added")));
		$admin_checked = array();
    	$sql  = " SELECT admin_id FROM " . $table_prefix . "forum_moderators ";
		$sql .= " WHERE forum_id = " . $db->tosql($forum_id, INTEGER);
		$db->query($sql);
		while($db->next_record()) {
			$admin_checked[$db->f("admin_id")] = 1;
		}
		foreach ($admins as $admin_id => $admin_name)
		{
			$admin = "admin_" . $admin_id;
			if (isset($admin_checked[$admin_id])) {
				if($admin_checked[$admin_id]) {
					$usr->set_value($admin, 1);
				}
				else {
					$usr->set_value($admin, 0);
				}
			}
			else {
				$usr->set_value($admin, 0);
			}
		}	
	}
	else // set default values
	{
		$forum_order = get_db_value("SELECT MAX(forum_order) FROM " . $table_prefix . "forum_list");
		$forum_order++;
		$r->set_value("forum_order", $forum_order);
		$r->set_value("allowed_view",         1);
		$r->set_value("allowed_view_topics",  1);
		$r->set_value("allowed_view_topic",   1);
		$r->set_value("allowed_post_topics",  1);
		$r->set_value("allowed_post_replies", 1);
		$r->set_value("threads_number", 0);
		$r->set_value("messages_number", 0);
		$r->set_value("date_added", va_time());
		$r->set_value("last_post_user_id", 0);
		$r->set_value("last_post_thread_id", 0);
		$r->set_value("last_post_added", va_time());
		
		$r->set_value("view_forum_types_all",   1);
		$r->set_value("view_topics_types_all",  1);
		$r->set_value("view_topic_types_all",   1);
		$r->set_value("post_topics_types_all",  1);
		$r->set_value("post_replies_types_all", 1);
		$r->set_value("allowed_attachments",    1);
		$r->set_value("attachments_types_all",  1);
	}

	foreach($admins as $admin_id => $admin_name) {
		$admin = "admin_" . $admin_id;
		$admin_name_checked = $usr->get_value($admin) ? "checked" : "";
		$admin_checkbox = "<input type=\"checkbox\" name=\"$admin\" $admin_name_checked value=\"$admin_id\">";
		$t->set_var("admin_name", $admin_name);
		$t->set_var("admin_checkbox", $admin_checkbox);
		$t->parse("admin_rows", true);
	}

	$r->set_parameters();
	
	$user_types = array();
	$sql = " SELECT type_id, type_name FROM " . $table_prefix . "user_types ";
	$db->query($sql);
	while ($db->next_record())	{
		$type_id = $db->f("type_id");
		$type_name = $db->f("type_name");
		$user_types[$type_id] = $type_name;
	}
	

	foreach($user_types as $type_id => $type_name) {
		$t->set_var("type_id", $type_id);
		$t->set_var("type_name", $type_name);
		foreach ($user_types_tables AS $user_types_table){
			if (in_array($type_id, $user_types_struct[$user_types_table]['selected'])) {
				$t->parse("selected_" . $user_types_table, true);
			} else {
				$t->parse("available_" . $user_types_table, true);
			}
		}
	}
	
	// set styles for tabs
	$tabs = array(
		"general" => ADMIN_GENERAL_MSG,
		"admin" => ASSIGN_MODERATORS_MSG, 
		"forum_view_types"  => FORUM_VIEW_MSG,
		"forum_view_topics" => VIEW_TOPICS_MSG,
		"forum_view_topic"  => VIEW_TOPIC_MSG,
		"forum_post_topics" => POST_TOPICS_MSG,
		"forum_post_replies" => FORUM_REPLIES_COLUMN,
		"forum_attachments_types" => ATTACHMENTS_MSG
	);
	foreach ($tabs as $tab_name => $tab_title) {
		$t->set_var("tab_id", "tab_" . $tab_name);
		$t->set_var("tab_name", $tab_name);
		$t->set_var("tab_title", $tab_title);
		if ($tab_name == $current_tab) {
			$t->set_var("tab_class", "adminTabActive");
			$t->set_var($tab_name . "_style", "display: block;");
		} else {
			$t->set_var("tab_class", "adminTab");
			$t->set_var($tab_name . "_style", "display: none;");
		}
		$t->parse("tabs", $tab_title);
	}
	$t->set_var("current_tab", $current_tab);
	
	
	if($r->get_value("forum_id")) {
		$t->set_var("save_button", UPDATE_BUTTON);
		$t->parse("delete", false);	
	}
	else {
		$t->set_var("save_button", ADD_NEW_MSG);
		$t->set_var("delete", "");	
	}

	include_once("./admin_header.php");
	include_once("./admin_footer.php");

	$t->set_var("admin_href", "admin.php");
	$t->pparse("main");

?>