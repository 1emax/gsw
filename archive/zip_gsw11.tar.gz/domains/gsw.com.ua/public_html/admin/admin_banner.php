<?php
/*
  ****************************************************************************
  ***                                                                      ***
  ***      ViArt Shop 3.5                                                  ***
  ***      File:  admin_banner.php                                         ***
  ***      Built: Fri Jun 20 19:43:16 2008                                 ***
  ***                                                 ***
  ***                                                                      ***
  ****************************************************************************
*/


	include_once("./admin_config.php");
	include_once($root_folder_path."includes/common.php");
	include_once("./admin_common.php");
	include_once($root_folder_path . "includes/record.php");

	check_admin_security("static_tables");

	$banner_id = get_param("banner_id");

	$t = new VA_Template($settings["admin_templates_dir"]);
	$t->set_file("main","admin_banner.html");

	$t->set_var("admin_href", "admin.php");
	$t->set_var("admin_banner_href",     "admin_banner.php");
	$t->set_var("admin_banners_href",    "admin_banners.php");
	$t->set_var("admin_select_href",     "admin_select.php");
	$t->set_var("admin_upload_href",     "admin_upload.php");
	$t->set_var("datetime_format", join("", $datetime_edit_format));


	$r = new VA_Record($table_prefix . "banners");
	$r->return_page = "admin_banners.php";

	$r->add_where("banner_id", INTEGER);
	$r->add_checkbox("is_active", INTEGER);
	$r->change_property("is_active", DEFAULT_VALUE, 1);
	$r->add_textbox("banner_rank", INTEGER, RANK_MSG);
	$r->change_property("banner_rank", DEFAULT_VALUE, 1);
	$r->add_textbox("banner_title", TEXT, TITLE_MSG);
	$r->change_property("banner_title", REQUIRED, true);
	$r->add_checkbox("show_title", INTEGER);
	$r->add_textbox("image_src", TEXT);
	$r->add_textbox("image_alt", TEXT);
	$r->add_textbox("html_text", TEXT);
	$r->add_textbox("target_url", TEXT, TARGET_URL_MSG);
	$r->change_property("target_url", REQUIRED, true);
	$r->add_checkbox("is_new_window", INTEGER);
	$r->add_checkbox("show_on_ssl", INTEGER);
	$r->add_textbox("max_impressions", INTEGER, MAX_IMPRESSIONS_MSG);
	$r->change_property("max_impressions", DEFAULT_VALUE, 0);
	$r->change_property("max_impressions", REQUIRED, true);
	$r->add_textbox("max_clicks", INTEGER, MAX_CLICKS_MSG);
	$r->change_property("max_clicks", DEFAULT_VALUE, 0);
	$r->change_property("max_clicks", REQUIRED, true);
	$r->add_textbox("total_impressions", INTEGER);
	$r->change_property("total_impressions", DEFAULT_VALUE, 0);
	$r->change_property("total_impressions", USE_IN_UPDATE, false);
	$r->add_textbox("total_clicks", INTEGER);
	$r->change_property("total_clicks", DEFAULT_VALUE, 0);
	$r->change_property("total_clicks", USE_IN_UPDATE, false);
	$r->add_textbox("expiry_date", DATETIME, ADMIN_EXPIRY_DATE_MSG);
	$r->change_property("expiry_date", VALUE_MASK, $datetime_edit_format);

	$r->events[BEFORE_INSERT] = "set_banner_id";
	$r->events[AFTER_INSERT] = "update_banner_groups";
	$r->events[AFTER_UPDATE] = "update_banner_groups";
	$r->events[AFTER_DELETE] = "delete_banner_groups";

	$r->add_hidden("page", INTEGER);

	$r->process();

	$t->set_var("groups", "");
	$t->set_var("selected_groups", "");

	$sql = " SELECT group_id, group_name FROM " . $table_prefix . "banners_groups ORDER BY group_id ";
	$db->query($sql);
	while($db->next_record())
	{
		$t->set_var("group_id", strtoupper($db->f("group_id")));
		$t->set_var("group_name", str_replace("\"", "\\\"", $db->f("group_name")));
		$t->parse("groups");
	}

	$operation = get_param("operation");
	if ($operation == "save") {
		$groups = get_param("groups");
		if($groups) {
			$selected_groups = split(",", $groups);
			for($i = 0; $i < sizeof($selected_groups); $i++) {
				$t->set_var("group_id", strtoupper($selected_groups[$i]));
				$t->parse("selected_groups");
			}
		}
	} else if($r->get_value("banner_id")) {
		$sql = " SELECT group_id FROM " . $table_prefix . "banners_assigned WHERE banner_id=" . $db->tosql($r->get_value("banner_id"), INTEGER);
		$db->query($sql);
		while($db->next_record())
		{
			$t->set_var("group_id", strtoupper($db->f("group_id")));
			$t->parse("selected_groups");
		}
	}

	include_once("./admin_header.php");
	include_once("./admin_footer.php");


	$t->pparse("main");

	function set_banner_id()  {
		global $db, $table_prefix, $r;
		$sql = "SELECT MAX(banner_id) FROM " . $table_prefix . "banners ";
		$db->query($sql);
		if($db->next_record()) {
			$banner_id = $db->f(0) + 1;
			$r->change_property("banner_id", USE_IN_INSERT, true);
			$r->set_value("banner_id", $banner_id);
		}	
	}

	function update_banner_groups()  {
		global $db, $table_prefix, $r;

		$banner_id = $r->get_value("banner_id");
		$db->query("DELETE FROM " . $table_prefix . "banners_assigned WHERE banner_id=" . $db->tosql($banner_id, INTEGER));

		$groups = get_param("groups");
		if (strlen($groups)) {
			$selected_groups = split(",", $groups);
			for($i = 0; $i < sizeof($selected_groups); $i++) {
				$db->query("INSERT INTO " . $table_prefix . "banners_assigned (banner_id, group_id) VALUES (" . $db->tosql($banner_id, INTEGER) . "," . $db->tosql($selected_groups[$i], INTEGER) . ")");
			}
		}
	}

	function delete_banner_groups()  {
		global $db, $table_prefix, $r;
		$banner_id = $r->get_value("banner_id");
		$db->query("DELETE FROM " . $table_prefix . "banners_assigned WHERE banner_id=" . $db->tosql($banner_id, INTEGER));
	}

?>